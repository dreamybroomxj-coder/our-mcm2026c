# 第四问完整计算

本工程按用户指定XGBoost电价预测，重新计算波动电价下的第二、三问。先读《第四问_结果与结论》，再读《第四问_模型与操作方法》。结果文件在results/final中，原始队伍及题目文件不被修改。

## 打开结果

- results/final/reports/result4-2.xlsx、result4-3.xlsx：完整题目模板。
- results/final/reports/第四问_Q4-2_指定四日填表.xlsx、第四问_Q4-3_指定四日填表.xlsx：四个自然日的论文表。
- results/final/reports/第四问_XGBoost分版本电价.xlsx：0/6/12/18瞬时预测、区间价格及已知/估计标志。
- results/final/main：12条334窗主轨迹、逐段现金/电池账本与实际签约记录。
- results/final/selection.json：只依据七个开发窗的冻结选择。
- results/final/sensitivity、causal_replay、analysis、figures：参数、执行、边界与比较证据。

点价格模式仍保留负载/PV场景；联合价格模式才加入配对的价格误差。两分支PV预测不同，不能把总费差全部说成调单收益。合同窗为D00:10—D+1 00:10；自然日表已做跨日映射。费用按供电区间实际均价结算是本次明确假设。当前已知左端实际价格可参与控制，未来价格使用预测；未来真实右端价格只能事后用于结算。

## 安装与完整复现

实际数值环境为Python 3.13.9，依赖锁定在requirements.txt。先把终端位置切换到本工程根目录（含code、data、results的目录），建立独立环境：

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python code/run_all.py --out results/reproduced --workers 4
```

Windows激活命令改为`.venv\Scripts\activate`。完整入口会生成中文图，因此开始前还须确认系统安装Songti、SimSun或Noto Serif CJK中的一种字体；字体不由requirements安装，无字体的环境会在绘图阶段报错。Word/PDF转换额外需要本机Pandoc和LibreOffice；不生成文档不影响计算和Excel结果。

顺序为价格来源核验→测试→18候选开发校准→冻结选择→12条334窗主回放→32条14窗敏感性和八月6条历史窗检查→独立审计→固定合同分钟回放→原模板/四日/图表/结论。八月补充是因为二月底历史不足56天，不用它改选模型。完整重算需要时间，脚本输出当前完成日期。默认新结果放results/reproduced，保留已经交付的results/final。

已完成的同签名结果可复用。输入字节、数值核心、配置或数值库不同，程序拒绝把旧数值冒称新结果，需换新输出目录。不同机器的限时MILP可能返回略有不同的可行解，应同时比较物理误差、现金和Gap，不能要求所有浮点数逐位一致。本交付的同环境验证记录见run_all_manifest和notes运行日志；未冒称全新环境安装已经验证。

## 分步运行

```bash
python code/price_inputs.py --workers 3
python code/audit_price_inputs.py
python -m unittest discover -s code -p 'test*.py'
python code/q4_study.py --stage calibration --out results/reproduced --workers 4
python code/q4_study.py --stage freeze --out results/reproduced
python code/q4_study.py --stage main --out results/reproduced --workers 4
python code/q4_study.py --stage sensitivity --out results/reproduced --workers 4
python code/q4_audit.py --data data --results results/reproduced
```

之后运行完整入口会核对并复用已有数值，再补分钟、填表和分析。单条试算例如：

```bash
python code/q4_runner.py --out results/demo --branch 4-2 --schedule 0 --price-mode point --days 3
```

该3日只是接口示范，不是年度比较。`q4_runner.py`完整API允许更改场景数、历史天数、初态、κ等，参考q4_study.py中的实验字典。

## 数据文件与替换

data/attachment2.xlsx、attachment4.xlsx为真实瞬时节点；load_forecasts.xlsx含问题二负载/PV区间均值；pv_forecasts.xlsx含问题三四个发行版本的区间均值。data/xgboost_midnight_predictions.npz逐值继承上一阶段冻结零点XGB；price_inputs.npz含本次0/6/12/18价格节点和区间映射，晚版过去时段为NaN。

零点预测是本次规划的已生成输入，统一入口不会重新挑选价格模型。06/12/18预测代码在本工程内，`price_inputs.py --force`可重新生成日内版本；输出不同后须重做规划，不能沿用旧计划。此前完整电价模型比较及其代码仍在上一阶段交付《第四问_电价预测》中。

换预测时必须提供同样日期/版本的历史预测，重新建立同日误差库并校准。当前接口明确针对2025年2月1—12月31的334日期及144/109/73/37有效区间，不静默接受未知日期或错误时钟。功率均值只乘1/6；价格节点只平均不乘1/6。不要手改CSV总费后当作重新优化。

本包的附加求解精度诊断专门重构Q43_point_H0_18轨迹。原输入复现会生成该轨迹；如果以后更换预测导致冻结为joint且主轨迹中不再包含它，须先将诊断目标适配到新的已生成轨迹，再运行完整后处理链。这项限制不影响当前输入或主优化器，但不能将本次诊断脚本当作任意新数据的通用自动审查器。

## 结果的适用边界

首窗口SOC6000为指定实验初态，后续连续，不是从一月预热推算。主执行采用当前10分钟实际功率均值的快反馈近似，另有严格节点分钟敏感性；未来实际右端电价始终不进入控制。末跨年右节点缺失，估计段保留标志。整套结果以当前预测、结算约定与有限场景为条件，不宣称任意年份或全部可能策略的全局最优。
