# 结果台账

数值结果以各run的summary.json、trace.csv、event_log.json为准。每份summary含实际输入/数值核心/配置/数值依赖版本联合SHA签名。交付文件另有逐文件SHA清单。

|组|入口|范围|用途|
|---|---|---|---|
|price_inputs|price_inputs.py|334天×4发行版|冻结零点继承，1002次日内XGB拟合|
|calibration|q4_study.py --stage calibration|18×24窗|只在Feb17—23选择|
|selection|q4_study.py --stage freeze|7开发窗|冻结P/J和调单组合|
|main|q4_study.py --stage main|12×334窗|主费用、310窗留出比较|
|sensitivity|q4_study.py --stage sensitivity|32×14窗|预设参数变体，不回写选择|
|causal|q4_causal_replay.py|4×7窗，选中2条再细化|固定正式合同的执行近似|
|analysis|q4_analysis.py|费用、Bootstrap、末端|从冻结轨迹复算|
|reports|q4_reports.py|原result4模板+四日|不重优化和不重置库存|
|audit|q4_audit.py|全部正式主/校准/敏感性|独立原数据、订单、物理和现金核对|

状态与实际完成数量以统一入口run_all_manifest.json、independent_audit.json为准；不得把正在生成的目录当完整结果。
