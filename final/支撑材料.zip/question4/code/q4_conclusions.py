"""Build a compact narrative from completed, independently checked results."""
from pathlib import Path
import argparse,json

ROOT=Path(__file__).resolve().parents[1]


def read(path):return json.loads(Path(path).read_text(encoding='utf-8'))
def money(x):return f'{x:,.2f}'
def movement(x):return ('增加' if x>=0 else '减少')+money(abs(x))+'元'


def build_conclusions(results_dir=ROOT/'results/final',output=None):
    result=Path(results_dir).resolve()
    a=read(result/'analysis/analysis.json');r=read(result/'reports/报表与账本核验.json')
    audit=read(result/'independent_audit.json');ca=read(result/'causal_replay/comparison.json')
    causal_audit=read(result/'causal_replay/independent_audit.json')
    solver_check=read(result/'solver_check/summary.json')
    if not all([a['complete'],r['complete'],audit['passed'],ca['checks_passed'],causal_audit['passed'],solver_check['complete']]):
        raise RuntimeError('Narrative requires complete, audited real results')
    sel=a['selection'];names=[sel['selected_q42'],sel['selected_q43']]
    runs={x['strategy']:x for x in a['main_summary']};chosen=[runs[n] for n in names]
    mode=lambda s: '电价点预测＋负载/PV场景' if s=='point' else '负载/PV/价格联合场景'
    lines=['# 第四问：计算结果与结论','',
        f"按照预先确定的开发期选择规则，4-2采用**{mode(chosen[0]['price_mode'])}**；4-3采用**{mode(chosen[1]['price_mode'])}**，在**{chosen[1]['trade_hours']}点**启用PV预报并正式调单。两分支电池均保留MPC，价格均在0、6、12、18点更新。XGBoost价格模型是用户指定的冻结预测器。",'',
        '这不是先看全年谁最便宜再选谁：只用2月17—23日七个已兑现开发窗口，在模拟2月25日00:00冻结。之后310窗检验不改变冻结选择。开发窗数量有限，不能据此声称该选择对所有季节稳定最优。','',
        '## 1. 完整费用和原模板','',
        '|分支|334合同窗现金费/元|2月1日至12月31日自然日期间费/元|期末SOC/kWh|紧急电量/kWh|',
        '|---|---:|---:|---:|---:|']
    for label,z in zip(('4-2 固定普通计划','4-3 允许指定时刻调单'),chosen):
        lines.append(f"|{label}|{money(z['full_cash_yuan'])}|{money(z['natural_period_cash_yuan'])}|{z['final_soc_kwh']:,.3f}|{z['emergency_kwh']:,.3f}|")
    diff=chosen[1]['full_cash_yuan']-chosen[0]['full_cash_yuan']
    lines += ['',f"4-3相对4-2的334合同窗总费{movement(diff)}（{100*abs(diff)/chosen[0]['full_cash_yuan']:.4f}%）。双方PV预测也不同，因此这不是单独的调单净收益。相同PV版本下的控制比较见下文。",'',
        '两个原模板result4-2.xlsx、result4-3.xlsx和四指定日表均在reports目录。购电sheet按D00:10至D+1 00:10合同窗，储能/紧急sheet按自然日。首日00:00—00:10启动段与跨年尾段另列并完成对账；上面两种范围的总费不能混用。合同总费含热身/开发窗，最后一段含估计右端点，不是365日全年实测。','',
        '主现金组成如下；退款已从原费扣回，违约费另加，库存软罚不计真实电费。','',
        '|分支|原计划费/元|净调整费/元|紧急费/元|', '|---|---:|---:|---:|']
    for label,z in zip(('4-2','4-3'),chosen):
        lines.append(f"|{label}|{money(z['original_plan_cost_yuan'])}|{money(z['net_adjustment_cost_yuan'])}|{money(z['emergency_cost_yuan'])}|")
    lines += ['','## 2. 点价格、联合价格和调单的对比','',
        '这里点价格模式仍包含负载/PV场景。联合方案只额外加入同日配对的价格比例误差，未额外叠加裕量或CVaR。全部策略重新签原单，各自连续运行，因此测试初SOC可能不同；另报共同库存价值校正，避免忽略库存差异。','',
        '|对照（左减右，负数左方更便宜）|334窗现金差/元|310测试窗现金差/元|',
        '|---|---:|---:|']
    for z in a['comparisons']:
        lines.append(f"|{z['comparison']}|{z['full_cash_difference_yuan']:+,.2f}|{z['test_cash_difference_yuan']:+,.2f}|")
    for z in a['comparisons'][:2]:
        branch='4-2' if z['comparison'].startswith('4-2') else '4-3'
        lines.append(f"\n{branch}联合价格情景在310测试窗使现金费{movement(z['test_cash_difference_yuan'])}。这是留出期结果，不回写七开发窗的选择；若与开发判断不同，应解释为选择不稳定并扩大开发覆盖，不能悄悄改名为事前最优。")
    lines += ['','7日移动块重采样对平均日现金差给出下列95%区间；3/14日块结果也保存在analysis中，均为2000次。区间不是价格预测区间，单年季节性、跨日库存和开发选择误差限制其解释。','',
        '|对比|平均日差/元|95%区间/元|','|---|---:|---:|']
    for z in a['bootstrap_intervals']:
        if z['block_days']==7 and z['metric']=='cash_cost_yuan':
            lines.append(f"|{z['comparison']}|{z['mean_daily_difference_yuan']:+,.3f}|[{z['mean_difference_ci_lower_yuan']:+,.3f}, {z['mean_difference_ci_upper_yuan']:+,.3f}]|")
    lines += ['','## 3. 是否需要其他时刻PV预报和调单','',
        f"价格模式固定为{chosen[1]['price_mode']}，重新计算全部8个组合。价格更新权限共同保持0/6/12/18；以下是策略整体比较，PV版本与调单机会随组合一起变化。星号表示开发期选中，测试排名不改变它。",'',
        '|启用PV/调单时刻|334合同窗费/元|310测试窗费/元|期末SOC/kWh|','|---|---:|---:|---:|']
    schedule_rows=sorted([z for z in a['main_summary'] if z['branch']=='4-3' and z['price_mode']==chosen[1]['price_mode']],key=lambda x:(len(x['trade_hours']),x['trade_hours']))
    for z in schedule_rows:
        star=' ★' if z['strategy']==names[1] else ''
        lines.append(f"|{z['trade_hours']}{star}|{money(z['full_cash_yuan'])}|{money(z['test_cash_yuan'])}|{z['final_soc_kwh']:,.3f}|")
    best=min(schedule_rows,key=lambda x:x['test_inventory_score_yuan'])
    lines += ['',f"按测试库存校正回顾，8组合中最低的是{best['trade_hours']}点，{'与开发期选择一致' if best['strategy']==names[1] else '与开发期选择不同；仅作事后诊断，主交付仍保留原冻结选择'}。每个目标段只在最近启用时刻正式调整一次，是本次策略约束，不是题面穷尽的所有可能政策。",'',
        '## 4. 参数与MPC敏感性','',
        '以下都是2月25日起共同6000初态的独立14窗试验，改变初态的两组除外；局部终止规则相同。不是把主334窗截取片段当基准，也不把14窗结论外推到全年。κ变化时评价的ν仍固定为一月估计0.5163888889。','',
        '|分支|变体|现金费/元|相对所列参考的库存校正差/元|参考|','|---|---|---:|---:|---|']
    for z in a['sensitivity_summary']:
        lines.append(f"|{z['branch']}|{z['strategy'].split('_',1)[1]}|{money(z['cash_yuan'])}|{z['inventory_score_change_yuan']:+,.2f}|{z['reference_strategy'].split('_',1)[1]}|")
    sensitivity={z['strategy']:z for z in a['sensitivity_summary']}
    for prefix,label in [('Q42','4-2'),('Q43','4-3')]:
        greedy=sensitivity[prefix+'_greedy'];midnight=sensitivity[prefix+'_price_midnight_only']
        lines.append(f"\n{label}：贪心相对MPC现金费{movement(greedy['cash_change_yuan'])}；仅零点价格相对0/6/12/18价格更新现金费{movement(midnight['cash_change_yuan'])}。原单随状态变化重优化，这是完整局部策略对比，不能称同g消融；分钟回放才锁定正式合同。")
    lines += ['','原二月底history56是上限，实际只有23—36（4-2）或23—37（4-3）条完整历史。为检验真正的56窗，追加8月1—14的同6000初态检查：','',
        '|分支|历史上限/实际条数|14窗现金费/元|相对28窗的库存校正差/元|',
        '|---|---:|---:|---:|']
    for z in a['history_check_summary']:
        lines.append(f"|{z['branch']}|{z['history_cap_days']}/{z['actual_history_paths_min']}|{money(z['cash_yuan'])}|{z['inventory_score_change_from_28_yuan']:+,.2f}|")
    lines += ['','八月结果不用于重新选择原模型，且与二月底试验不同季节，不把两组现金水平直接作优劣比较。']
    lines += ['','## 5. 更严格的分钟执行与末端估计','',
        '主回放当前10分钟实际均值反馈是等效近似。四策略用原正式合同、共同6000初态独立重放7窗，并与只读当前节点的分钟反馈比较；当时尚未正式签定的未来q不提前揭示。环境在十分钟实际节点间人工线性插值，没有高频实测，故不是精确物理验证。','',
        '|策略|执行|7窗现金费/元|相对本地10分钟均值差/元|末SOC/kWh|', '|---|---|---:|---:|---:|']
    for z in ca['rows']:
        lines.append(f"|{z['strategy']}|{z['variant']}|{money(z['cash_cost_yuan'])}|{z['cash_difference_vs_mean']:+,.2f}|{z['soc_end_kwh']:,.3f}|")
    lines += ['', '两条冻结选中分支还有0.1分钟细化，信号左端积分差按解析式缩小10倍；费用还受段内方向/放电预算限制影响，不能把全部差当积分误差。上表只支持7窗执行近似评估，不用它重新选择年度合同模型。','',
        '最后跨年尾段固定已签g/q和入段SOC，三种功率端点估计重新执行一步，再组合三种实际价估计结算；控制仍用原预测价。选中方案的九组合范围：','',
        '|策略|总现金跨度/元|末SOC范围/kWh|','|---|---:|---:|']
    for z in a['endpoint_summary']:
        if z['strategy'] in names:
            lines.append(f"|{z['strategy']}|{z['cash_span_yuan']:.6f}|[{z['final_soc_min_kwh']:.6f}, {z['final_soc_max_kwh']:.6f}]|")
    lines += ['','这里的跨度是最大费用减最小费用，并非相对默认持平方案的单边变化；两条选中方案相对默认值的最大绝对变化都小于5.804元。','',
        '## 6. 四个指定自然日','',
        '详细表1、表2、表3已分别写入四日Excel和论文表格Markdown；不只给日总费。此处汇总便于核对，所有日期均144个完整自然日区间，00:00首段取前一合同，SOC不重置。','',
        '|日期|4-2现金费/元|4-3现金费/元|4-2紧急电/kWh|4-3紧急电/kWh|','|---|---:|---:|---:|---:|']
    for date,x in r['four_day_summary']['Q4-2'].items():
        y=r['four_day_summary']['Q4-3'][date]
        lines.append(f"|{date}|{money(x['cash_cost_yuan'])}|{money(y['cash_cost_yuan'])}|{x['emergency_kwh']:.4f}|{y['emergency_kwh']:.4f}|")
    maxgap=max(z['solver_max_gap'] for z in a['main_summary'])
    unproven=sum(z['solver_unproven_calls'] for z in a['main_summary'])
    lines += ['','## 7. 数值核验与结论适用范围','',
        f"独立审计通过{audit['audited_runs']}条正式校准/主/敏感性轨迹，共{audit['audited_intervals']:,}段；原始节点均值、订单时序、跨场景共享、SOC、能量、退费和费用均重算。主12策略合计{unproven}次求解调用未被原程序标记为已证明达到请求Gap，最大保存相对Gap为{100*maxgap:.6f}%；所有被执行计划都通过可行性核验。这个计数包括净目标接近零时的浮点比例放大，不能将最大百分比解释成全年费用误差或全部次数都是限时难解。详细状态保留，不将固定模式LP精修称为MILP全局最优。",'',
        f"独立抽查{solver_check['unique_frozen_states']}个固定状态、{solver_check['recorded_solver_calls']}次重解，其中{solver_check['forty_five_second_calls']}次延长至45秒并收紧Gap；最大绝对目标界差仅{solver_check['max_absolute_objective_bound_gap_yuan']:.3g}元，却可显示{100*solver_check['max_relative_gap']:.4f}%的相对值。原因是控制净目标近零，分母被程序限定为1×10⁻¹⁰。首动作相对主轨迹最大差{solver_check['max_action_difference_from_main_kwh']:.3g}kWh。这支持数值比例放大的解释，但不冒称定位并重解了所有未记录的控制调用。正式签单的Gap与剩余控制净目标的Gap应分开读，详见solver_check。",'',
        '结论是当前队伍预测、XGBoost价格输入、统一初态和供电期均价结算约定下的经验比较。有限开发窗、两阶段未来回补近似、10分钟均值反馈和单年数据，均限制推广。更换预测后必须重建历史误差并重新评估；队伍预测训练信息集仍需其代码记录佐证。原始文件和前三问冻结结果没有修改，本轮没有推送GitHub。','',
        '复现命令、依赖和分步流程见README；模型公式与外部原始方法出处见《第四问_模型与操作方法》。']
    text='\n'.join(lines)+'\n'
    destination=Path(output) if output else result/'reports/第四问_结果与结论.md'
    destination.parent.mkdir(parents=True,exist_ok=True);destination.write_text(text,encoding='utf-8')
    return {'output':str(destination),'selected':names,'complete':True}


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--results',type=Path,default=ROOT/'results/final')
    args=p.parse_args();print(json.dumps(build_conclusions(args.results),ensure_ascii=False))
