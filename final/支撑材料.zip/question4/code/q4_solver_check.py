"""Read-only frozen-state solver sensitivity; never replaces selected/main runs.

The main ledger records executed actions, not every MPC dual bound. This module
reconstructs selected ordinary intraday MPC problems from the immutable source
forecasts and the original trajectory state. Future contract changes are hidden
until their real gate; only formal already-signed changes are revealed.
"""
from pathlib import Path
import argparse, hashlib, json
import numpy as np
import pandas as pd
from q4_io import load_inputs, selected_pv
from q4_risk import HOURS, future_mask, latest_hour
from q4_optimizer import solve_dispatch, LOW

ROOT = Path(__file__).resolve().parents[1]


def available_contract(original, final, future):
    """Future final orders must not leak back into an earlier MPC call."""
    original=np.asarray(original,float);final=np.asarray(final,float)
    future=np.asarray(future,bool)
    if original.shape!=final.shape or original.shape!=future.shape:
        raise ValueError('Contract arrays must align')
    return np.where(future,original,final)


def reconstruct_control(data, trace, config, day, t):
    """Return original normal intraday MPC inputs, excluding midnight bridges."""
    if not 0 <= t < 143:
        raise ValueError('Only ordinary intraday steps 0..142; bridges need a different reconstruction')
    date=str(data['dates'][day]);part=trace.loc[trace.window_date==date].reset_index(drop=True)
    if len(part)!=144:
        raise ValueError('A complete immutable contract trace is required')
    expected=data['window_start'][day]+pd.Timedelta(minutes=10*t)
    row=part.iloc[t]
    if pd.Timestamp(row.interval_start)!=pd.Timestamp(expected):
        raise ValueError('Trace timestamp does not match contract slot')
    fh=latest_hour(config['forecast_hours'],t);ph=latest_hour(config['price_hours'],t)
    future=future_mask(config['trade_hours'],t)
    if not future.any():raise ValueError('This call is an LP/direct action, not the questioned MILP control')
    g=part.g_kwh.to_numpy()[t:]
    q=available_contract(g,part.q_kwh.to_numpy()[t:],future)
    L=data['load_f'][day,t:].copy()/6
    G=data['policy_pv'][day,HOURS.index(fh),t:].copy()/6
    L[0]=data['load_a'][day,t]/6;G[0]=data['pv_a'][day,t]/6
    p=data['price_f'][day,HOURS.index(ph),t:].copy()
    p[0]=(data['price_nodes_a'][day,t]+data['price_nodes_f'][day,HOURS.index(ph),t+1])/2
    if L[0]-q[0]-G[0] < -1e-9:raise ValueError('Surplus is executed directly, not an MILP control')
    if not np.isclose(q[0],row.q_kwh,rtol=0,atol=1e-7):raise ValueError('Current contract is not the executed order')
    if not np.isclose(p[0],row.price_forecast_yuan_per_kwh,rtol=0,atol=1e-10):raise ValueError('Information price differs from main run')
    if not np.isclose(data['policy_pv'][day,HOURS.index(fh),t],row.pv_forecast_kw,rtol=0,atol=1e-6):
        raise ValueError('PV forecast version differs from main run')
    return dict(load=L[None,:],pv=G[None,:],price=p,s0=float(row.soc_start_kwh),
        base_g=g,booked_q=q,future_adjust_mask=future,day=day,t=t,date=date,
        interval_start=row.interval_start,forecast_hour=fh,price_hour=ph,
        original_action={k:float(row[k]) for k in ['charge_kwh','discharge_kwh','emergency_kwh']})


def candidates(trace,config):
    """Specified-day stratified diagnostic sample, selected without solver output."""
    selected=[]
    for date in ['2025-03-20','2025-06-21','2025-09-23','2025-12-21']:
        part=trace.loc[trace.window_date==date].reset_index(drop=True)
        if len(part)!=144:raise ValueError('Missing specified day')
        deficit=part.load_actual_kw/6-part.q_kwh-part.pv_actual_kw/6
        eligible=[i for i in range(143) if deficit.iloc[i]>1e-6
                  and part.soc_start_kwh.iloc[i]>LOW+.1 and future_mask(config['trade_hours'],i).any()]
        used=set()
        for target in (30,55,90):
            remaining=[i for i in eligible if i not in used]
            if remaining:
                t=min(remaining,key=lambda i:(abs(i-target),i));used.add(t);selected.append((date,t))
    return selected


def summarize(sol, inputs, limit):
    c=float(sol['c'][0,0]);d=float(sol['d'][0,0]);e=float(sol['e'][0,0])
    return dict(window_date=inputs['date'],slot=inputs['t'],interval_start=inputs['interval_start'],
        time_limit_seconds=limit,status=sol['status'],solver_status_code=sol['status_code'],requested_mip_gap=sol['requested_mip_gap'],objective_yuan=sol['objective'],
        dual_bound_yuan=sol['dual_bound'],absolute_gap_yuan=sol['absolute_gap_yuan'],relative_gap=sol['gap'],
        original_cost_excluded_yuan=float(inputs['price']@inputs['base_g']),
        expected_adjustment_yuan=sol['expected_adjustment_cost'],expected_emergency_yuan=sol['expected_emergency_cost'],
        terminal_yuan=sol['terminal_cost'],solve_seconds=sol['solve_seconds'],charge_kwh=c,discharge_kwh=d,emergency_kwh=e,
        charge_minus_main_kwh=c-inputs['original_action']['charge_kwh'],
        discharge_minus_main_kwh=d-inputs['original_action']['discharge_kwh'],
        emergency_minus_main_kwh=e-inputs['original_action']['emergency_kwh'],
        max_physical_violation_kwh=sol['checks']['max_violation_kwh'],
        signed_order_count=int(np.count_nonzero(sol['signed_mask'])))


def run_check(data_dir=ROOT/'data',results_dir=ROOT/'results/final',strategy='Q43_point_H0_18',out_dir=None,refine_count=4):
    out=Path(out_dir or ROOT/'results/solver_check')/strategy;out.mkdir(parents=True,exist_ok=True)
    source=Path(results_dir)/'main'/strategy
    summary=json.loads((source/'summary.json').read_text());config=summary['config']
    trace=pd.read_csv(source/'trace.csv')
    data=load_inputs(data_dir);data['policy_pv']=selected_pv(data,config['branch'],config['pv_source'])
    bydate={str(x):i for i,x in enumerate(data['dates'])}
    chosen=candidates(trace,config);rows=[];problems=[]
    meta={'strategy':strategy,'main_run_signature':summary['run_signature'],
        'source_trace_sha256':hashlib.sha256((source/'trace.csv').read_bytes()).hexdigest(),
        'sample_rule':'For each four specified day, nearest eligible deficit/SOC step to slots30,55,90; no solver-output screening.',
        'main_state_and_contracts_frozen':True,'main_selection_unchanged':True,
        'baseline_time_limit':10,'refined_time_limit':45,'refined_mip_gap':1e-6,
        'replay_limitations':'Only sampled same-state controls; not a counterfactual full trajectory, not a global policy cost bound. The original maximum-gap control timestamp was not logged.',
        'relative_gap_definition':'max(polished primal - original MILP dual bound,0)/abs(polished primal); the objective excludes original sunk plan fees and includes future cancellation refunds and inventory penalty.'}
    def solve_one(inp,limit,gap):
        return solve_dispatch(inp['load'],inp['pv'],inp['price'],inp['s0'],mode='control',
            base_g=inp['base_g'],booked_q=inp['booked_q'],future_adjust_mask=inp['future_adjust_mask'],
            terminal_weight=data['inventory_value']*config['terminal_multiplier'],time_limit=limit,mip_gap=gap)
    def save():
        (out/'checks.json').write_text(json.dumps({**meta,'complete':False,'checks':rows},indent=2,ensure_ascii=False))
        pd.DataFrame(rows).to_csv(out/'checks.csv',index=False,encoding='utf-8-sig')
    for date,t in chosen:
        inp=reconstruct_control(data,trace,config,bydate[date],t);problems.append(inp)
        rows.append(summarize(solve_one(inp,10,config['mip_gap']),inp,10));save()
        print(json.dumps(rows[-1],ensure_ascii=False),flush=True)
    # Refine largest certified absolute gaps, with relative gap and main-action
    # discrepancy as tie breakers. This deliberately targets the numerical issue.
    ordered=sorted(range(len(rows)),key=lambda i:(rows[i]['absolute_gap_yuan'] or 0,rows[i]['relative_gap'] or 0,
        abs(rows[i]['discharge_minus_main_kwh'])),reverse=True)[:refine_count]
    for i in ordered:
        inp=problems[i];r=summarize(solve_one(inp,45,1e-6),inp,45);base=rows[i]
        r.update(objective_minus_10sec_yuan=r['objective_yuan']-base['objective_yuan'],
            discharge_minus_10sec_kwh=r['discharge_kwh']-base['discharge_kwh'],
            charge_minus_10sec_kwh=r['charge_kwh']-base['charge_kwh'],
            emergency_minus_10sec_kwh=r['emergency_kwh']-base['emergency_kwh'])
        rows.append(r);save();print(json.dumps(r,ensure_ascii=False),flush=True)
    meta['complete']=True;meta['checks']=rows
    meta['main_trace_unchanged']=hashlib.sha256((source/'trace.csv').read_bytes()).hexdigest()==meta['source_trace_sha256']
    if not meta['main_trace_unchanged']:raise RuntimeError('Main trace changed during diagnostic')
    (out/'checks.json').write_text(json.dumps(meta,indent=2,ensure_ascii=False))
    return meta

def study_signature(data_dir,results_dir):
    """Cache depends on the frozen source state, data and reconstruction/core code."""
    from q4_runner import CORE
    import scipy
    root=Path(results_dir)/'main'/'Q43_point_H0_18'
    h=hashlib.sha256((np.__version__+'|'+scipy.__version__).encode())
    for path in [root/'summary.json',root/'trace.csv']:
        h.update(path.name.encode());h.update(path.read_bytes())
    for path in sorted(Path(data_dir).glob('*')):
        if path.is_file():h.update(path.name.encode());h.update(path.read_bytes())
    for name in (*CORE,'q4_solver_check.py','q4_solver_zero_screen.py'):
        path=ROOT/'code'/name;h.update(name.encode());h.update(path.read_bytes())
    return h.hexdigest()


def finalize_solver_study(data_dir,results_dir,out_dir=None):
    """Aggregate completed diagnostic records; refresh formal-order inventory."""
    results_dir=Path(results_dir);out=Path(out_dir or results_dir/'solver_check')
    sample=out/'Q43_point_H0_18'
    a=json.loads((sample/'checks.json').read_text());b=json.loads((sample/'zero_objective_screen.json').read_text())
    if not a['complete'] or not b['complete']:raise ValueError('Incomplete solver diagnostics')
    rows=a['checks']+b['sampled_controls']+b['refinements']
    source=results_dir/'main'/'Q43_point_H0_18'
    if hashlib.sha256((source/'trace.csv').read_bytes()).hexdigest()!=a['source_trace_sha256']:
        raise ValueError('Diagnostic source trajectory has changed')
    formal=[]
    for path in sorted((results_dir/'main').glob('*/summary.json')):
        summary=json.loads(path.read_text())
        if not summary.get('complete'):continue
        events=json.loads((path.parent/'event_log.json').read_text())['events']
        largest=max(events,key=lambda e:e['gap'] or 0)
        formal.append(dict(strategy=path.parent.name,all_solver_max_relative_gap=summary['solver']['max_gap'],
            formal_events=len(events),formal_event_max_relative_gap=largest['gap'],
            formal_max_gap_time=largest['decision_at'],formal_max_gap_kind=largest['kind'],
            formal_max_gap_objective_yuan=largest['objective'],
            formal_max_gap_absolute_yuan_from_logged_gap=(largest['gap'] or 0)*max(abs(largest['objective']),1e-10),
            formal_max_absolute_gap_yuan=max((e['gap'] or 0)*max(abs(e['objective']),1e-10) for e in events)))
    action_error=max(abs(r[k]) for r in rows for k in ('charge_minus_main_kwh','discharge_minus_main_kwh','emergency_minus_main_kwh'))
    result=dict(complete=True,study_signature=study_signature(data_dir,results_dir),
        strategy='Q43_point_H0_18',main_run_signature=a['main_run_signature'],
        recorded_solver_calls=len(rows),unique_frozen_states=len({(r['window_date'],r['slot']) for r in rows}),
        ten_second_calls=sum(r['time_limit_seconds']==10 for r in rows),forty_five_second_calls=sum(r['time_limit_seconds']==45 for r in rows),
        max_action_difference_from_main_kwh=action_error,all_sampled_actions_same_as_main=action_error<1e-7,
        max_absolute_objective_bound_gap_yuan=max(r['absolute_gap_yuan'] or 0 for r in rows),
        max_relative_gap=max(r['relative_gap'] or 0 for r in rows),
        max_physical_violation_kwh=max(r['max_physical_violation_kwh'] for r in rows),
        near_zero_high_relative_gap_cases=[r for r in b['refinements']],
        max_45sec_vs_10sec_action_difference_kwh=max(abs(r['discharge_minus_10sec_kwh']) for r in a['checks']+b['refinements'] if 'discharge_minus_10sec_kwh' in r),
        main_results_changed=False,formal_order_diagnostics=formal,
        limitation=f'{len(rows)} reported calls at {len({(r["window_date"],r["slot"]) for r in rows})} frozen states (development reruns not counted). Neither every main control nor the original maximum-gap step was logged/replayed. This demonstrates the denominator artifact, not a full-year policy-optimality proof. Formal event absolute gaps are recovered from the exact logged relative-gap formula; they are not actual bill bounds.')
    (out/'summary.json').write_text(json.dumps(result,indent=2,ensure_ascii=False))
    pd.DataFrame(rows).to_csv(out/'全部同状态重解.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(formal).to_csv(out/'正式签单求解精度.csv',index=False,encoding='utf-8-sig')
    return result


def run_solver_check(data_dir=ROOT/'data',results_dir=ROOT/'results/final'):
    """Public entry point for run_all; source/code hashes guard the diagnostic cache."""
    out=Path(results_dir)/'solver_check';cached=out/'summary.json'
    if cached.exists():
        prior=json.loads(cached.read_text())
        if prior.get('complete') and prior.get('study_signature')==study_signature(data_dir,results_dir):
            return finalize_solver_study(data_dir,results_dir,out)
        raise RuntimeError('Stale solver diagnostic cache; choose a new result directory')
    from q4_solver_zero_screen import run_zero_screen
    run_check(data_dir,results_dir,out_dir=out)
    run_zero_screen(data_dir,results_dir,out_dir=out)
    return finalize_solver_study(data_dir,results_dir,out)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data',type=Path,default=ROOT/'data')
    parser.add_argument('--results',type=Path,default=ROOT/'results/final')
    args=parser.parse_args()
    print(json.dumps(run_solver_check(args.data,args.results),indent=2,ensure_ascii=False))
