"""绘制第四问图17：八种组合相对主策略的库存评价差。"""
from pathlib import Path
import json

import matplotlib.pyplot as plt
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
CSV = ROOT / "results" / "final" / "analysis" / "主实验比较.csv"
OUT = Path(r"F:\work\mcm2026\CUMCM2026Problems\C题\附件\多时间尺度与动态电价下微网购电及储能协同调控模型\figures")


def main() -> None:
    df = pd.read_csv(CSV)
    # 图17比较问题4-3的八种光伏预报/调单组合。
    df = df[(df["branch"] == "4-3") & (df["price_mode"] == "point")].copy()
    df["label"] = df["pv_hours"].map(lambda x: "/".join(f"{int(h):02d}" for h in x.split(",")))
    selected = df.loc[df["selected_by_development"], "strategy"].iloc[0]
    selection = json.loads((ROOT / "results" / "final" / "selection.json").read_text(encoding="utf-8"))
    development = {row["strategy"]: row["score"] for row in selection["development"]
                   if row["branch"] == "4-3" and row["price_mode"] == "point"}

    panels = [
        ("开发期7窗", "开发期7窗"),
        ("留出期310窗", "留出期310窗"),
    ]
    # 主策略作为共同零点；两面板均以每窗口库存评价表示，避免把合同窗总费
    # 与自然日费用混用。
    base = df.loc[df["strategy"] == selected, "test_inventory_score_yuan"].iloc[0] / 310
    dev_base = development[selected] / 7
    values = {
        "开发期7窗": (df["strategy"].map(development) / 7 - dev_base),
        "留出期310窗": (df["test_inventory_score_yuan"] / 310 - base),
    }

    plt.rcParams.update({
        "font.family": "sans-serif",
        "font.sans-serif": ["Microsoft YaHei", "SimHei", "DejaVu Sans"],
        "axes.unicode_minus": False,
        "font.size": 10,
    })
    fig, axes = plt.subplots(1, 2, figsize=(12.0, 5.2), sharey=True)
    color_main = "#2F7F73"
    color_other = "#9AAEBA"

    for ax, (title, xlabel) in zip(axes, panels):
        plot_df = df[["label", "strategy"]].copy()
        plot_df["delta"] = values[title].to_numpy()
        plot_df = plot_df.sort_values("delta", ascending=True)
        colors = [color_main if s == selected else color_other for s in plot_df["strategy"]]
        bars = ax.barh(plot_df["label"], plot_df["delta"], color=colors, edgecolor="white", linewidth=0.7)
        ax.axvline(0, color="#333333", linewidth=1.0)
        selected_pos = plot_df.index[plot_df["strategy"] == selected][0]
        selected_y = list(plot_df.index).index(selected_pos)
        ax.scatter([0], [selected_y], marker="D", s=30, color=color_main, zorder=4)
        ax.grid(axis="x", color="#D9E0E3", linewidth=0.8, alpha=0.8)
        ax.set_axisbelow(True)
        ax.set_title(title, pad=10, fontsize=12, fontweight="bold")
        ax.set_xlabel("相对主策略多出的库存评价（元/窗）")
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.spines["left"].set_color("#555555")
        ax.spines["bottom"].set_color("#555555")
        max_delta = max(plot_df["delta"].max(), 1)
        ax.set_xlim(-max_delta * 0.10, max_delta * 1.18)
        for bar, val in zip(bars, plot_df["delta"]):
            x = val + max_delta * 0.025
            ax.text(x, bar.get_y() + bar.get_height() / 2, f"{val:+.0f}", va="center", ha="left", fontsize=9)

    axes[0].set_ylabel("光伏预报/调单时刻组合")
    fig.suptitle("八种策略相对主策略的费用差", fontsize=14, fontweight="bold", y=1.02)
    fig.text(0.5, -0.02, "绿色：开发期冻结的主策略（相对值为0）", ha="center", fontsize=9)
    fig.tight_layout()
    OUT.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUT / "q4_eight_schedules.png", dpi=350, bbox_inches="tight")
    fig.savefig(OUT / "q4_eight_schedules.pdf", bbox_inches="tight")
    plt.close(fig)


if __name__ == "__main__":
    main()
