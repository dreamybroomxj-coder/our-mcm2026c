"""Question 4 contract and battery MILP; all flows supplied in kWh.

Day-ahead orders and current adjustments are shared across scenarios. Future
adjustments and battery recourse foresee an entire scenario: this is explicitly
a rolling two-stage approximation, not a nonanticipative multistage policy.
Only ``signed_mask`` entries can be contracted by the caller. The optimizer
never records a transaction, and forecast recourse costs are not actual bills.
"""
from __future__ import annotations

from time import perf_counter
import os
import warnings

import numpy as np
from scipy.optimize import Bounds, LinearConstraint, linprog, milp
from scipy.sparse import coo_matrix, vstack

LOW = 1200.0
HIGH = 10800.0
RATE = 5000.0 / 6.0
ETA_C = ETA_D = float(os.environ.get("MCM_BATTERY_ETA", "0.9"))
PHYSICAL_TOL = 1e-5
OBJECTIVE_TOL = 1e-4
SOLVER_TOL = 1e-9


def solve_fixed_control(load, pv, price, booked, s0, *, terminal_weight, s_ref=6000., time_limit=10.):
    """Exact LP for fixed contracts under the ordinary surplus/deficit rule.

    With A=max(q+PV-load,0), D=max(load-q-PV,0), c<=A and d<=D
    imply charge/discharge exclusivity without binary variables. Emergency
    energy is D-d and can never charge the battery. No transaction is signed.
    """
    start=perf_counter()
    L=_vector(load,'load');n=len(L)
    G=_vector(pv,'pv',n);p=_vector(price,'price',n);q=_vector(booked,'booked',n)
    if (p<=0).any() or not LOW<=s0<=HIGH or terminal_weight<0:
        raise ValueError('Fixed-control inputs outside admissible domain')
    A=np.maximum(q+G-L,0);D=np.maximum(L-q-G,0)
    cmax=np.minimum(A,RATE);dmax=np.minimum(D,RATE)
    cost=np.r_[np.zeros(n),-5*p,np.zeros(n),terminal_weight]
    ri=[];ci=[];values=[]
    for t in range(n):
        for col,v in ((t,-ETA_C),(n+t,1/ETA_D),(2*n+t,1.)):
            ri.append(t);ci.append(col);values.append(v)
        if t:
            ri.append(t);ci.append(2*n+t-1);values.append(-1.)
    eq=coo_matrix((values,(ri,ci)),shape=(n,3*n+1)).tocsc()
    b=np.r_[s0,np.zeros(n-1)]
    terminal=coo_matrix(([-1.,-1.],([0,0],[3*n-1,3*n])),shape=(1,3*n+1)).tocsc()
    bounds=np.column_stack((np.r_[np.zeros(2*n),np.full(n,LOW),0.],
        np.r_[cmax,dmax,np.full(n,HIGH),max(s_ref-LOW,0)]))
    res=linprog(cost,A_eq=eq,b_eq=b,A_ub=terminal,b_ub=[-s_ref],bounds=bounds,method='highs-ds',
        options={'time_limit':float(time_limit),'primal_feasibility_tolerance':SOLVER_TOL,
                 'dual_feasibility_tolerance':SOLVER_TOL})
    if not res.success or res.x is None:
        raise RuntimeError(f'Fixed-contract control LP failed: {res.message}')
    c=np.maximum(res.x[:n],0);d=np.maximum(res.x[n:2*n],0);e=np.maximum(D-d,0)
    s=np.r_[s0,s0+np.cumsum(ETA_C*c-d/ETA_D)]
    error=max(float(np.max(np.abs(eq@res.x-b))),float(max(LOW-s.min(),s.max()-HIGH,0.)),
        float(np.max(np.minimum(c,d))),float(np.max(np.minimum(c,e))))
    if error>PHYSICAL_TOL:
        raise RuntimeError(f'LP physical violation {error}')
    return {'c':c,'d':d,'e':e,'s':s,'solve_seconds':perf_counter()-start,'max_violation_kwh':error,
        'objective':float(5*p@D+res.fun),'optimality_proven':True,'method':'fixed_contract_LP'}


def _vector(value, name, n=None):
    a = np.asarray(value, dtype=float).copy()
    if (a.ndim != 1 or not len(a) or (n is not None and len(a) != n)
            or not np.isfinite(a).all() or np.any(a < 0)):
        raise ValueError(f"{name} must be a finite nonnegative vector of length {n}.")
    return a


def _mask(value, name, n):
    if value is None:
        return np.zeros(n, dtype=bool)
    a = np.asarray(value)
    if a.shape != (n,) or not np.isin(a, [False, True]).all():
        raise ValueError(f"{name} must be a Boolean vector of length {n}.")
    return a.astype(bool)


def cash_components(p, base_g, delivered_q, emergency, *, adjustment_mask=None):
    """Single-settlement actual bill, separate from any soft inventory penalty.

    Supply only formally contracted ``delivered_q``; never pass future scenario
    proposals. Original charges cover all supplied g. ``adjustment_mask`` can
    restrict this particular adjustment event; otherwise all slots are billed.
    Each slot may be adjusted only once relative to base_g under this policy.
    A cancelled kWh refunds its original price and incurs a 50% penalty.
    """
    p = _vector(p, "p")
    n = len(p)
    g = _vector(base_g, "base_g", n)
    q = _vector(delivered_q, "delivered_q", n)
    e = _vector(emergency, "emergency", n)
    mask = np.ones(n, bool) if adjustment_mask is None else _mask(adjustment_mask, "adjustment_mask", n)
    increase = np.maximum(q-g, 0) * mask
    decrease = np.maximum(g-q, 0) * mask
    original = float(p @ g)
    increase_cost = float(1.5 * p @ increase)
    refund = float(p @ decrease)
    penalty = .5 * refund
    emergency_cost = float(5 * p @ e)
    net_adjustment = increase_cost-refund+penalty
    return {"original_cost": original, "increase_cost": increase_cost,
            "refund": refund, "cancellation_penalty": penalty,
            "net_adjustment_cost": net_adjustment,
            "emergency_cost": emergency_cost,
            "total_cash_cost": original+net_adjustment+emergency_cost}


def _polish(c, matrix, row_lo, row_hi, lower, upper, integer, incumbent, limit):
    """Fix exact rounded MILP modes then solve the unchanged continuous LP."""
    binary = integer.astype(bool)
    rounded = np.rint(incumbent[binary])
    error = float(np.max(np.abs(incumbent[binary]-rounded)))
    if error > PHYSICAL_TOL or np.any(rounded < 0) or np.any(rounded > 1):
        raise RuntimeError(f"Unacceptable incumbent integrality error: {error}")
    lo, hi = lower.copy(), upper.copy()
    lo[binary] = hi[binary] = rounded
    equal = np.isfinite(row_lo) & np.isfinite(row_hi) & (row_lo == row_hi)
    finite_hi = np.isfinite(row_hi) & ~equal
    finite_lo = np.isfinite(row_lo) & ~equal
    start = perf_counter()
    result = linprog(c, A_ub=vstack((matrix[finite_hi], -matrix[finite_lo]), format="csc"),
                     b_ub=np.r_[row_hi[finite_hi], -row_lo[finite_lo]],
                     A_eq=matrix[equal], b_eq=row_lo[equal],
                     bounds=np.column_stack((lo, hi)), method="highs-ds",
                     options={"time_limit": float(limit), "disp": False,
                              "primal_feasibility_tolerance": SOLVER_TOL,
                              "dual_feasibility_tolerance": SOLVER_TOL})
    if result.status != 0 or result.x is None or not np.isfinite(result.x).all():
        raise RuntimeError(f"Fixed-mode LP polish failed: {result.message}")
    return result, error, perf_counter()-start


def solve_dispatch(load_scenarios, pv_scenarios, p, s0, *, mode="dayahead",
                   base_g=None, booked_q=None, locked_mask=None, current_mask=None,
                   future_adjust_mask=None, probabilities=None, terminal_weight=None,
                   s_ref=6000.0, time_limit=10.0, mip_gap=1e-4):
    """Solve a day-ahead, adjustment, or control problem with identical physics.

    Inputs load_scenarios/pv_scenarios have shape (M,n), in kWh.
    p is a positive vector (n,) or scenario array (M,n), in yuan/kWh.
    ``locked_mask``, ``current_mask`` and ``future_adjust_mask`` are disjoint.
    In day-ahead mode, unlocked g is shared and newly signed; locked slots use
    booked_q (e.g. the previous contract's midnight bridge) without recharging
    their sunk original fee. Only future_adjust_mask permits scenario q != g.
    In adjust mode, base_g is the immutable original contract; current_mask q
    is shared and formally adjustable now, future q is scenario-dependent, and
    all other q is booked_q. In control mode current_mask must be empty, so no
    contract can be signed. Per-slot additions cost 1.5p, cancellations net -0.5p.

    Every scenario has exact charge/discharge exclusivity; emergency energy
    cannot charge the battery. Discarding energy while discharging is excluded,
    matching the Question 2 ordinary-surplus/deficit execution convention.
    Terminal shortfall is a soft algorithmic penalty, not electricity expense.
    MILP and the mandatory fixed-mode LP each receive time_limit seconds.
    """
    start = perf_counter()
    load, pv = np.asarray(load_scenarios, float).copy(), np.asarray(pv_scenarios, float).copy()
    if (load.ndim != 2 or load.shape[0] == 0 or load.shape[1] == 0 or pv.shape != load.shape
            or not np.isfinite(load).all() or not np.isfinite(pv).all()
            or np.any(load < 0) or np.any(pv < 0)):
        raise ValueError("load_scenarios/pv_scenarios must have identical finite nonnegative (M,n) shapes.")
    m = load.shape[0]
    n = load.shape[1]
    price = np.asarray(p, float).copy()
    if price.shape == (n,):
        price = np.broadcast_to(price, (m,n)).copy()
    if price.shape != (m,n) or not np.isfinite(price).all() or (price <= 0).any():
        raise ValueError('p must have shape (n,) or (M,n) and strictly positive finite prices')
    if mode not in {"dayahead", "adjust", "control"}:
        raise ValueError("mode must be dayahead, adjust, or control.")
    locked = _mask(locked_mask, "locked_mask", n)
    current = _mask(current_mask, "current_mask", n)
    future = _mask(future_adjust_mask, "future_adjust_mask", n)
    if np.any((locked.astype(int)+current+future) > 1):
        raise ValueError("locked/current/future masks must be disjoint.")
    if mode != "adjust" and current.any():
        raise ValueError("Only adjust mode may have a nonempty current_mask.")
    probability = np.full(m, 1/m) if probabilities is None else _vector(probabilities, "probabilities", m)
    if abs(float(probability.sum())-1) > 1e-8:
        raise ValueError("probabilities must sum to one.")
    probability /= probability.sum()
    expected_price = probability @ price
    if not np.isfinite(s0) or not LOW-PHYSICAL_TOL <= s0 <= HIGH+PHYSICAL_TOL:
        raise ValueError("s0 must lie in the battery operating range.")
    s0 = float(np.clip(s0, LOW, HIGH))
    kappa = float(np.min(price)/ETA_C if terminal_weight is None else terminal_weight)
    if (not np.isfinite(kappa) or kappa < 0 or not np.isfinite(s_ref) or s_ref < 0
            or not np.isfinite(time_limit) or time_limit <= 0
            or not np.isfinite(mip_gap) or not 0 <= mip_gap < 1):
        raise ValueError("Invalid terminal reference/weight, time_limit, or mip_gap.")
    if mode != "dayahead" and base_g is None:
        raise ValueError("adjust/control mode requires immutable base_g.")
    g_input = np.zeros(n) if base_g is None else _vector(base_g, "base_g", n)
    if booked_q is None:
        if mode == "dayahead" and locked.any():
            raise ValueError("dayahead locked slots require booked_q.")
        booked = g_input.copy()
    else:
        booked = _vector(booked_q, "booked_q", n)
    adjust = future | current
    sufficient = load.max(axis=0)+RATE
    cap = np.maximum.reduce([sufficient, g_input, booked])
    # Shared original g plus shared currently executable q; then each scene
    # stores q,a,b,c,d,e,v,r,S,u,xi. Fixed/unused blocks keep interface explicit.
    width = 10*n+1
    size = 2*n+m*width
    cost, lower, upper = np.zeros(size), np.zeros(size), np.full(size, np.inf)
    integer = np.zeros(size, np.uint8)
    upper[:2*n] = np.tile(cap, 2)
    if mode == "dayahead":
        cost[:n] = expected_price * ~locked
        lower[:n][locked] = upper[:n][locked] = booked[locked]
    else:
        lower[:n] = upper[:n] = g_input
        lower[n:2*n][~current] = upper[n:2*n][~current] = booked[~current]
    row_i, col_i, coeff, row_lo, row_hi = [], [], [], [], []

    def row(entries, lo=-np.inf, hi=np.inf):
        idx = len(row_lo)
        for col, value in entries:
            if value:
                row_i.append(idx); col_i.append(col); coeff.append(value)
        row_lo.append(lo); row_hi.append(hi)

    if mode == "dayahead":
        for t in range(n):
            row([(n+t, 1), (t, -1)], 0, 0)
    for j in range(m):
        block = 2*n+j*width
        upper[block:block+3*n] = np.tile(cap, 3)
        upper[block+3*n:block+5*n] = RATE
        upper[block+5*n:block+6*n] = load[j]
        upper[block+6*n:block+7*n] = cap
        upper[block+7*n:block+8*n] = pv[j]
        lower[block+8*n:block+9*n] = LOW
        upper[block+8*n:block+9*n] = HIGH
        upper[block+9*n:block+10*n] = 1
        integer[block+9*n:block+10*n] = 1
        xi = block+10*n
        upper[xi] = max(s_ref-LOW, 0)
        cost[block+n:block+2*n] = probability[j]*1.5*price[j]
        cost[block+2*n:block+3*n] = -probability[j]*.5*price[j]
        cost[block+5*n:block+6*n] = probability[j]*5*price[j]
        cost[xi] = probability[j]*kappa
        for t in range(n):
            q, a, b, c, d, e, v, r, s, u = (block+k*n+t for k in range(10))
            if adjust[t]:
                row([(q, 1), (t, -1), (a, -1), (b, 1)], 0, 0)
                row([(b, 1), (t, -1)], hi=0)
            else:
                upper[a] = upper[b] = 0
            if not future[t]:
                row([(q, 1), (n+t, -1)], 0, 0)
            L, G = float(load[j, t]), float(pv[j, t])
            row([(q, 1), (c, -1), (d, 1), (e, 1), (v, -1), (r, -1)], L-G, L-G)
            state = [(s, 1), (c, -ETA_C), (d, 1/ETA_D)]
            if t:
                state.append((s-1, -1))
            row(state, s0 if t == 0 else 0, s0 if t == 0 else 0)
            row([(c, 1), (u, -RATE)], hi=0)
            row([(d, 1), (u, RATE)], hi=RATE)
            row([(e, 1), (u, L)], hi=L)
            row([(v, 1), (r, 1), (u, -(cap[t]+G))], hi=0)
            row([(v, 1), (q, -1)], hi=0)
        row([(block+9*n-1, -1), (xi, -1)], hi=-s_ref)
    matrix = coo_matrix((coeff, (row_i, col_i)), shape=(len(row_lo), size)).tocsc()
    row_lo, row_hi = np.asarray(row_lo), np.asarray(row_hi)
    mip_start = perf_counter()
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", category=RuntimeWarning,
            message=r"Unrecognized options detected: \{'mip_feasibility_tolerance'\}\. These will be passed to HiGHS verbatim\.")
        result = milp(cost, integrality=integer, bounds=Bounds(lower, upper),
                      constraints=LinearConstraint(matrix, row_lo, row_hi),
                      options={"time_limit": float(time_limit), "mip_rel_gap": float(mip_gap),
                               "mip_feasibility_tolerance": SOLVER_TOL, "disp": False})
    mip_seconds = perf_counter()-mip_start
    if result.status not in (0, 1) or result.x is None or not np.isfinite(result.x).all():
        raise RuntimeError(f"No accepted MILP incumbent: {result.status}; {result.message}")
    polished, old_integer_error, polish_seconds = _polish(
        cost, matrix, row_lo, row_hi, lower, upper, integer, result.x, time_limit)
    x = polished.x
    g = np.maximum(x[:n], 0)
    fields = {key: np.empty((m, n)) for key in ["q_scenarios", "a", "b", "c", "d", "e", "v", "r"]}
    raw_states, raw_modes, raw_xi = np.empty((m,n)), np.empty((m,n)), np.empty(m)
    for j in range(m):
        offset = 2*n+j*width
        for k, key in enumerate(fields):
            fields[key][j] = np.maximum(x[offset+k*n:offset+(k+1)*n], 0)
        raw_states[j] = x[offset+8*n:offset+9*n]
        raw_modes[j] = x[offset+9*n:offset+10*n]
        raw_xi[j] = x[offset+10*n]
    q_s, c, d, e, v, r = (fields[key] for key in ["q_scenarios","c","d","e","v","r"])
    # Zero-price LP degeneracy may represent a=q-g+b with both positive.
    # Positive-part normalization is equivalent and does not alter q or cost.
    fields["a"] = np.maximum(q_s-g, 0)*adjust
    fields["b"] = np.maximum(g-q_s, 0)*adjust
    modes = np.rint(raw_modes).astype(int)
    states = np.column_stack([np.full(m, s0), s0+np.cumsum(ETA_C*c-d/ETA_D, axis=1)])
    shared_q = g.copy() if mode == "dayahead" else booked.copy()
    shared_q[current] = q_s[0,current]
    signed = (~locked).copy() if mode == "dayahead" else current.copy()
    original_cost = float(expected_price[~locked] @ g[~locked]) if mode == "dayahead" else 0.0
    scene_adjustment = np.sum((1.5*fields["a"]-.5*fields["b"])*price, axis=1)
    scene_emergency = np.sum(5*e*price, axis=1)
    shortfall = np.maximum(s_ref-states[:,-1], 0)
    scene_terminal = kappa*shortfall
    value = original_cost+float(probability @ (scene_adjustment+scene_emergency+scene_terminal))
    surplus, deficit = np.maximum(q_s+pv-load, 0), np.maximum(load-q_s-pv, 0)
    def maxabs(a):
        return float(np.max(np.abs(a))) if np.size(a) else 0.
    def positive(a):
        return float(max(np.max(a), 0)) if np.size(a) else 0.
    row_value = matrix @ x
    checks = {
        "constraint_matrix_violation_kwh": max(positive(row_lo-row_value), positive(row_value-row_hi)),
        "variable_bound_violation_kwh": max(positive(lower-x), positive(x-upper)),
        "energy_balance_kwh": maxabs(q_s+pv-v-r+d+e-load-c),
        "soc_solver_agreement_kwh": maxabs(states[:,1:]-raw_states),
        "soc_lower_kwh": positive(LOW-states), "soc_upper_kwh": positive(states-HIGH),
        "charge_rate_kwh": positive(c-RATE), "discharge_rate_kwh": positive(d-RATE),
        "charge_mode_kwh": positive(c-RATE*modes),
        "discharge_mode_kwh": positive(d-RATE*(1-modes)),
        "emergency_charge_kwh": maxabs(np.minimum(c,e)),
        "simultaneous_charge_discharge_kwh": maxabs(np.minimum(c,d)),
        "charge_exceeds_surplus_kwh": positive(c-surplus),
        "discharge_exceeds_deficit_kwh": positive(d-deficit),
        "emergency_deficit_equation_kwh": maxabs(e-deficit+d),
        "unused_surplus_equation_kwh": maxabs(v+r-surplus+c),
        "unused_contract_bound_kwh": positive(v-q_s),
        "pv_curtailment_bound_kwh": positive(r-pv),
        "adjustment_relation_kwh": maxabs((q_s-g-fields["a"]+fields["b"])[:,adjust]),
        "shared_current_q_kwh": maxabs(q_s[:,current]-shared_q[current]),
        "fixed_q_kwh": maxabs(q_s[:,~future & ~current]-shared_q[~future & ~current]),
        "terminal_shortfall_kwh": positive(s_ref-states[:,-1]-raw_xi),
    }
    checks["max_violation_kwh"] = max(checks.values())
    checks["integrality_error"] = maxabs(raw_modes-modes)
    checks["original_integrality_error"] = old_integer_error
    checks["objective_difference_yuan"] = abs(value-float(polished.fun))
    checks["passed"] = bool(checks["max_violation_kwh"] <= PHYSICAL_TOL
        and checks["integrality_error"] <= PHYSICAL_TOL
        and checks["objective_difference_yuan"] <= OBJECTIVE_TOL)
    if not checks["passed"]:
        raise RuntimeError(f"Physical/accounting verification failed: {checks}")
    dual = getattr(result, "mip_dual_bound", None)
    dual = None if dual is None or not np.isfinite(dual) else float(dual)
    consistent = dual is not None and dual <= value+OBJECTIVE_TOL
    absolute_gap = max(value-dual, 0) if consistent else None
    gap = absolute_gap/max(abs(value), 1e-10) if consistent else None
    proven = bool(result.status == 0 and gap is not None and gap <= mip_gap+1e-10)
    return {"g": g, "q": shared_q, **fields, "s": states, "u": modes,
            "signed_mask": signed, "signed_q": shared_q[signed].copy(),
            "current_mask": current, "future_adjust_mask": future, "locked_mask": locked,
            "objective": value, "original_cost_in_objective": original_cost,
            "new_plan_cost": original_cost, "scenario_adjustment_cost": scene_adjustment,
            "scenario_emergency_cost": scene_emergency, "scenario_terminal_cost": scene_terminal,
            "expected_adjustment_cost": float(probability @ scene_adjustment),
            "expected_emergency_cost": float(probability @ scene_emergency),
            "terminal_cost": float(probability @ scene_terminal),
            "probabilities": probability, "scenario_prices":price,
            "expected_price":expected_price, "terminal_weight": kappa, "s_ref": s_ref,
            "status": "optimal_within_requested_gap" if proven else "feasible_unproven",
            "status_code": int(result.status), "optimality_proven": proven,
            "gap": gap, "mip_gap": gap, "dual_bound": dual, "absolute_gap_yuan": absolute_gap,
            "checks": checks, "success": True, "solve_seconds": perf_counter()-start,
            "mip_seconds": mip_seconds, "polish_seconds": polish_seconds,
            "requested_mip_gap": mip_gap, "time_limit_per_stage": time_limit,
            "gap_basis": "Polished primal versus original global MILP dual bound, not the fixed-mode LP bound.",
            "recourse_information": "Future adjustment and storage recourse foresee each scenario; rolling two-stage approximation.",
            "cash_warning": "objective includes unexecuted future proposals and a soft inventory penalty; it is not an actual bill."}
