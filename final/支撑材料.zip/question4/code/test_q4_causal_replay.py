"""Independent causal/event/integration checks, using two complete toy windows."""
import copy
import csv
import datetime as dt
import json
from pathlib import Path
import shutil
import tempfile
import unittest
from unittest.mock import patch

import numpy as np
import pandas as pd

from q4_causal_replay import causal_price_vector, run_replay
from q4_causal_audit import audit_replay


def synthetic_case(folder, *, controller='mpc', trade=(0,6), mixed_supply=False):
    dates=[dt.date(2025,2,25)+dt.timedelta(days=i) for i in range(2)]
    starts=[dt.datetime.combine(d,dt.time(0,10)) for d in dates]
    ends=[d+dt.timedelta(days=1) for d in starts]
    x=np.arange(289,dtype=float)
    l=1800+x;g=300+.2*x;p=.5+.001*x
    nodes=lambda a:np.array([a[:145],a[144:]])
    load_nodes,pv_nodes,price_nodes=map(nodes,(l,g,p))
    mean=lambda a:(a[:,:-1]+a[:,1:])/2
    load_a,pv_a,price_a=map(mean,(load_nodes,pv_nodes,price_nodes))
    price_nodes_f=np.repeat((price_nodes+.07)[:,None,:],4,axis=1)
    price_f=mean(price_nodes)[:,None,:]+np.array([.07,.06,.05,.04])[None,:,None]
    data=dict(dates=dates,window_start=starts,window_end=ends,
        load_nodes=load_nodes,pv_nodes=pv_nodes,price_nodes_a=price_nodes,
        load_a=load_a,pv_a=pv_a,price_a=price_a,load_f=load_a+400,
        q2_pv_f=pv_a*.8,price_nodes_f=price_nodes_f,price_f=price_f,
        bridge_price_forecast=np.array([.51,.63]),inventory_value=.4)
    events=[];rows=[]
    for day,date in enumerate(dates):
        base=np.full(144,100.+100*day)
        if mixed_supply:base+=300*(np.arange(144)//18%2)
        final=base.copy()
        if 6 in trade:final[35:]+=75.
        events.append(dict(window_date=str(date),kind='dayahead',
            decision_at=dt.datetime.combine(date,dt.time()).isoformat()))
        if 6 in trade:
            events.append(dict(window_date=str(date),kind='adjust',commit_start=35,commit_end=144,
                decision_at=dt.datetime.combine(date,dt.time(6)).isoformat()))
        for t in range(144):
            rows.append(dict(window_date=str(date),interval_start=(starts[day]+dt.timedelta(minutes=10*t)).isoformat(),
                price_yuan_per_kwh=price_a[day,t],load_actual_kw=load_a[day,t],pv_actual_kw=pv_a[day,t],
                load_forecast_kw=data['load_f'][day,t],g_kwh=base[t],q_kwh=final[t],soc_start_kwh=7654.))
    folder.mkdir()
    with (folder/'trace.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    cfg=dict(strategy='synthetic',branch='4-2',trade_hours=list(trade),forecast_hours=[0],
             price_hours=[0,6,12,18],controller=controller)
    (folder/'event_log.json').write_text(json.dumps(dict(config=cfg,events=events)))
    (folder/'summary.json').write_text('{}')
    return data


class TestCausalReplay(unittest.TestCase):
    def test_current_actual_left_only_affects_current_price(self):
        with tempfile.TemporaryDirectory() as temp:
            data=synthetic_case(Path(temp)/'source')
            original=causal_price_vector(data,0,35,6)
            changed=copy.deepcopy(data)
            changed['price_nodes_a'][0,36:]+=900
            changed['price_a'][0,35:]+=500
            np.testing.assert_array_equal(original,causal_price_vector(changed,0,35,6))
            changed['price_nodes_a'][0,35]+=.2
            altered=causal_price_vector(changed,0,35,6)
            self.assertAlmostEqual(altered[0]-original[0],.1)
            np.testing.assert_array_equal(altered[1:],original[1:])
            with self.assertRaises(ValueError):causal_price_vector(data,0,34,6)

    def test_future_formal_q_is_hidden_until_its_gate_and_next_g_until_midnight(self):
        calls=[]
        def dispatch(L,G,p,state,**kw):
            booked=kw['booked_q'].copy();calls.append((len(p),booked,kw['future_adjust_mask'].copy()))
            deficit=np.maximum(L-G-booked,0)
            return dict(c=np.zeros_like(L),d=np.zeros_like(L),e=deficit,
                        optimality_proven=True,solve_seconds=0.)
        def fixed(L,G,p,booked,state,**kw):
            calls.append((len(p),booked.copy(),np.zeros(len(p),bool)))
            return dict(c=np.zeros_like(L),d=np.zeros_like(L),e=np.maximum(L-G-booked,0),solve_seconds=0.)
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);data=synthetic_case(root/'source')
            with patch('q4_causal_replay.solve_dispatch',side_effect=dispatch),patch('q4_causal_replay.solve_fixed_control',side_effect=fixed):
                result=run_replay(None,root/'source',root/'out',0,2,6000.,(1.,),data_override=data)
            # First window until 06:00: even the far future is the original100,
            # although the full source ledger already contains the signed175.
            for n,booked,future in calls[:35]:
                self.assertEqual(booked.max(),100.)
                self.assertTrue(future[-1])
            self.assertEqual(calls[35][0],109)
            self.assertEqual(calls[35][1].min(),175.)
            # The first bridge is the first145-step control call, after next
            # midnight, with old signed175 and new original200 (not future275).
            bridge=next(item for item in calls if item[0]==145)
            self.assertEqual(bridge[1][0],175.)
            np.testing.assert_array_equal(bridge[1][1:],np.full(144,200.))
            reveal=json.loads((root/'out/contract_reveals_1min_causal.json').read_text())
            self.assertEqual([r['kind'] for r in reveal],['dayahead','adjust','dayahead','adjust'])
            self.assertEqual(reveal[2]['at'],'2025-02-26T00:00:00')
            self.assertTrue(result['checks_passed'])
            self.assertEqual(result['main_trace_original_local_initial_soc'],7654.)
            self.assertEqual(result['summary']['1min_causal']['soc_start_kwh'],6000.)

    def test_synthetic_two_window_physics_loss_and_refinement_integral(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);data=synthetic_case(root/'source',controller='greedy',trade=(0,),mixed_supply=True)
            result=run_replay(None,root/'source',root/'out',0,2,6000.,(1.,.1),data_override=data)
            base=result['summary']['10min_mean']
            for label in ('10min_mean','1min_causal','0.1min_causal'):
                part=result['summary'][label]
                self.assertGreater(part['charge_kwh'],0)
                self.assertGreater(part['discharge_kwh'],0)
                # Independent aggregate battery balance, including conversionloss.
                self.assertAlmostEqual(part['soc_end_kwh']-6000.,
                    part['charge_kwh']-part['discharge_kwh']-part['battery_loss_kwh'],places=7)
                self.assertEqual(part['ordinary_cost_yuan'],base['ordinary_cost_yuan'])
                with (root/'out'/f'trace_{label}.csv').open() as f: rows=list(csv.DictReader(f))
                for a,b in zip(rows,rows[1:]):
                    self.assertEqual(a['interval_end'],b['interval_start'])
                    self.assertAlmostEqual(float(a['soc_end_kwh']),float(b['soc_start_kwh']),places=9)
                self.assertEqual(rows[-1]['interval_end'],'2025-02-27T00:10:00')
                self.assertLess(part['solver']['max_violation_kwh'],1e-7)
            for key in ('load','pv'):
                coarse=result['signal_energy_integration_checks']['1min_causal']['observed_bias_kwh'][key]
                fine=result['signal_energy_integration_checks']['0.1min_causal']['observed_bias_kwh'][key]
                self.assertAlmostEqual(coarse/10,fine,places=7)

    def test_real_lp_path_runs_and_respects_battery_constraints(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);data=synthetic_case(root/'source',trade=(0,),mixed_supply=True)
            result=run_replay(None,root/'source',root/'out',0,1,6000.,(1.,),data_override=data)
            self.assertGreater(result['summary']['1min_causal']['solver']['lp_solves'],0)
            self.assertTrue(result['checks_passed'])

    def test_invalid_common_state_and_micro_step_are_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);data=synthetic_case(root/'source')
            for state,steps in ((1000.,(1.,)),(6000.,(3.,)),(6000.,(1.,1.))):
                with self.assertRaises(ValueError):
                    run_replay(None,root/'source',root/'out',0,2,state,steps,data_override=data)

    def test_independent_audit_rejects_future_price_and_cash_tampering(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);data=synthetic_case(root/'source',controller='greedy',trade=(0,),mixed_supply=True)
            run_replay(None,root/'source',root/'out',0,2,6000.,(1.,),data_override=data)
            self.assertTrue(audit_replay(root/'out',data)['passed'])
            path=root/'out/trace_1min_causal.csv'
            with path.open() as f:rows=list(csv.DictReader(f))
            original=rows[0]['control_price_forecast']
            rows[0]['control_price_forecast']=str(data['price_a'][0,0])
            def save():
                with path.open('w',newline='') as f:
                    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
            save()
            with self.assertRaisesRegex(ValueError,'unavailable price'):audit_replay(root/'out',data)
            rows[0]['control_price_forecast']=original
            rows[0]['cash_cost_yuan']=str(float(rows[0]['cash_cost_yuan'])+1)
            save()
            with self.assertRaises(AssertionError):audit_replay(root/'out',data)

    def test_packaged_ledger_is_checked_even_when_old_original_still_exists(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);data=synthetic_case(root/'source',controller='greedy',trade=(0,),mixed_supply=True)
            out=root/'final/causal_replay/synthetic'
            run_replay(None,root/'source',out,0,2,6000.,(1.,),data_override=data)
            parallel=root/'final/main/synthetic'
            shutil.copytree(root/'source',parallel)
            self.assertTrue(audit_replay(out,data)['passed'])
            # Keep the original unmodified and present; a path-based fallback
            # must not let that old file hide alteration in the package copy.
            with (parallel/'trace.csv').open('a') as stream:stream.write('\n')
            self.assertTrue((root/'source/trace.csv').exists())
            with self.assertRaisesRegex(ValueError,'Source digest mismatch'):audit_replay(out,data)

    def test_summary_micro_state_and_reveal_record_tampering_are_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);data=synthetic_case(root/'source',controller='greedy',trade=(0,))
            out=root/'out';run_replay(None,root/'source',out,0,2,6000.,(1.,),data_override=data)
            self.assertTrue(audit_replay(out,data)['passed'])
            summary_path=out/'summary.json';original=summary_path.read_bytes()
            summary=json.loads(original);summary['summary']['1min_causal']['cash_cost_yuan']+=1.
            summary_path.write_text(json.dumps(summary))
            with self.assertRaisesRegex(AssertionError,'Summary'):audit_replay(out,data)
            summary_path.write_bytes(original)
            path=out/'micro_trace_1min_causal.csv.gz';original_micro=path.read_bytes()
            micro=pd.read_csv(path)
            # A constant SOC offset keeps every micro recursion unchanged and
            # remains inside physical limits here, but breaks the actual link.
            micro['soc_start_kwh']+=1.;micro['soc_end_kwh']+=1.
            self.assertLessEqual(micro.soc_end_kwh.max(),10800.)
            self.assertGreaterEqual(micro.soc_end_kwh.min(),1200.)
            micro.to_csv(path,index=False,compression='gzip')
            with self.assertRaises(AssertionError):audit_replay(out,data)
            path.write_bytes(original_micro)
            path=out/'contract_reveals_1min_causal.json'
            reveal=json.loads(path.read_text());reveal[0]['at']='2025-02-25T06:00:00';path.write_text(json.dumps(reveal))
            with self.assertRaisesRegex(ValueError,'Contract reveal'):audit_replay(out,data)


if __name__=='__main__':unittest.main()
