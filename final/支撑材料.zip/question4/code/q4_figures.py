"""Read-only scientific figures and summary tables for Q4 dispatch experiments.

Selection is read from the calibration freeze; held-out rankings and parameter
sensitivities never replace the frozen displayed policies. No numerical-core imports.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import argparse
import hashlib
import json
import os

import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
DATES=('2025-03-20','2025-06-21','2025-09-23','2025-12-21')
BRANCH_LABEL={'4-2':'Q4-2','4-3':'Q4-3'}
SENS_LABEL={'reference':'冻结方案参考','history14':'残差历史14天','history56':'残差历史56天','scenes4':'4个情景','scenes16':'16个情景',
    'terminal_half':'软末态权重×0.5','terminal_double':'软末态权重×2','seed13':'随机种子13','seed14':'随机种子14',
    'price_midnight_only':'仅零点电价预报','greedy':'电池贪心执行','initial1200':'初态1200kWh','initial10800':'初态10800kWh',
    'joint_mean':'联合价格均值','joint_shuffled':'打乱价格配对','joint_reference':'联合情景参考'}


def read_json(path):return json.loads(Path(path).read_text(encoding='utf-8'))
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def write_json(path,value):Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
def close(a,b,label,tol=1e-4):
    if not np.isclose(a,b,rtol=1e-10,atol=tol):raise ValueError(f'{label}: {a} != {b}')


@dataclass
class Run:
    name:str
    path:Path
    summary:dict
    daily:pd.DataFrame

    @property
    def branch(self):return self.summary['config']['branch']
    @property
    def mode(self):return self.summary['config']['price_mode']
    @property
    def schedule(self):return tuple(self.summary['config']['trade_hours'])


@dataclass
class Study:
    root:Path
    selection:dict
    main:dict[str,Run]
    sensitivity:dict[str,Run]
    source_hashes:dict[str,str]

    def selected(self,branch):return self.main[self.selection['selected_q42' if branch=='4-2' else 'selected_q43']]


def load_run(path,expected_days=None):
    path=Path(path);summary=read_json(path/'summary.json')
    if not summary.get('complete'):raise ValueError(f'Incomplete result: {path}')
    daily=pd.read_csv(path/'daily.csv')
    required=('window_date','cash_cost_yuan','inventory_adjusted_cost_yuan','soc_start_kwh','soc_end_kwh','emergency_kwh')
    if any(k not in daily for k in required):raise ValueError(f'Missing daily ledger fields: {path}')
    dates=pd.to_datetime(daily.window_date)
    if dates.duplicated().any() or not dates.is_monotonic_increasing:raise ValueError('Daily dates must be sorted and unique')
    if len(daily)!=summary['windows'] or (expected_days is not None and len(daily)!=expected_days):raise ValueError('Incomplete daily coverage')
    if len(dates)>1 and not (dates.diff().dropna()==pd.Timedelta(days=1)).all():raise ValueError('Daily gaps in continuous run')
    close(daily.cash_cost_yuan.sum(),summary['cash_cost_yuan'],'summary cash')
    close(daily.inventory_adjusted_cost_yuan.sum(),summary['inventory_adjusted_cost_yuan'],'summary inventory evaluation')
    if len(daily)>1 and not np.allclose(daily.soc_end_kwh.to_numpy()[:-1],daily.soc_start_kwh.to_numpy()[1:],atol=1e-5,rtol=0):raise ValueError('Daily SOC is not continuous')
    return Run(path.name,path,summary,daily)


def _load_design_runs(directory,expected_days=None):
    directory=Path(directory);design=read_json(directory/'design.json');runs={}
    for job in design['jobs']:
        name=job['name'];runs[name]=load_run(directory/name,expected_days)
    if len(runs)!=len(design['jobs']):raise ValueError('Duplicate design names')
    return runs


def load_study(results_dir):
    root=Path(results_dir);selection=read_json(root/'selection.json')
    if selection.get('model_or_schedule_reselection_from_test') is not False:raise ValueError('Need explicit pre-test selection freeze')
    main=_load_design_runs(root/'main',334);sensitivity=_load_design_runs(root/'sensitivity',14)
    for branch,key in [('4-2','selected_q42'),('4-3','selected_q43')]:
        if selection[key] not in main:raise ValueError('Frozen selected main run is missing')
        choice=selection['branch_selections'][branch];run=main[selection[key]]
        if run.branch!=branch or run.mode!=choice['price_mode'] or run.schedule!=tuple(choice['trade_hours']):raise ValueError('Frozen choice/config mismatch')
        if run.daily.window_date.iloc[0]!='2025-02-01' or run.daily.window_date.iloc[-1]!='2025-12-31':raise ValueError('Expected February-December contracts')
    paths=[root/'selection.json',root/'main/design.json',root/'sensitivity/design.json']
    for run in list(main.values())+list(sensitivity.values()):paths.extend([run.path/'summary.json',run.path/'daily.csv'])
    return Study(root,selection,main,sensitivity,{str(path):digest(path) for path in paths})


def fee_components(study):
    out=[]
    for branch in ('4-2','4-3'):
        run=study.selected(branch);trace=pd.read_csv(run.path/'trace.csv');study.source_hashes[str(run.path/'trace.csv')]=digest(run.path/'trace.csv')
        fields=('plan_cost_yuan','increase_cost_yuan','refund_yuan','penalty_yuan','emergency_cost_yuan')
        row={k:float(trace[k].sum()) for k in fields}
        row.update(branch=branch,strategy=run.name,cash_cost_yuan=run.summary['cash_cost_yuan'],soc_start_kwh=run.summary['soc_start_kwh'],soc_end_kwh=run.summary['soc_end_kwh'])
        close(row['plan_cost_yuan']+row['increase_cost_yuan']-row['refund_yuan']+row['penalty_yuan']+row['emergency_cost_yuan'],row['cash_cost_yuan'],'fee decomposition')
        out.append(row)
    return pd.DataFrame(out)


def monthly_main(study):
    records=[]
    for branch in ('4-2','4-3'):
        run=study.selected(branch);frame=run.daily.copy();frame['month']=frame.window_date.str[:7]
        for month,rows in frame.groupby('month',sort=True):
            records.append(dict(branch=branch,strategy=run.name,month=month,windows=len(rows),cash_cost_yuan=float(rows.cash_cost_yuan.sum()),inventory_adjusted_cost_yuan=float(rows.inventory_adjusted_cost_yuan.sum()),emergency_kwh=float(rows.emergency_kwh.sum())))
    return pd.DataFrame(records)


def schedule_comparison(study):
    choice=study.selection['branch_selections']['4-3'];mode=choice['price_mode'];selected=study.selection['selected_q43'];records=[]
    development=[r for r in study.selection['development'] if r['branch']=='4-3' and r['price_mode']==mode]
    if len(development)!=8:raise ValueError('Eight Q4-3 schedules required within frozen price mode')
    for dev in development:
        run=study.main[dev['strategy']];test=run.daily[run.daily.window_date.between('2025-02-25','2025-12-31')]
        if len(test)!=310:raise ValueError('Held-out schedule comparison requires 310 windows')
        records.append(dict(strategy=run.name,schedule='/'.join(f'{h:02d}' for h in run.schedule),price_mode=mode,selected_before_test=run.name==selected,
            development_windows=7,development_inventory_score_yuan=float(dev['score']),development_cash_yuan=float(dev['cash']),
            development_daily_score_yuan=float(dev['score'])/7,test_windows=310,test_cash_yuan=float(test.cash_cost_yuan.sum()),
            test_inventory_score_yuan=float(test.inventory_adjusted_cost_yuan.sum()),test_daily_score_yuan=float(test.inventory_adjusted_cost_yuan.mean())))
    frame=pd.DataFrame(records)
    frame['development_rank']=frame.development_inventory_score_yuan.rank(method='min').astype(int)
    frame['test_rank_retrospective']=frame.test_inventory_score_yuan.rank(method='min').astype(int)
    return frame.sort_values(['development_rank','strategy']).reset_index(drop=True)


def paired_price_modes(study):
    records=[];summaries=[]
    for branch in ('4-2','4-3'):
        schedule=study.selected(branch).schedule
        candidates={r.mode:r for r in study.main.values() if r.branch==branch and r.schedule==schedule and r.mode in ('point','joint') and r.summary['config'].get('pv_source','supplied')=='supplied'}
        if set(candidates)!={'point','joint'}:raise ValueError(f'Missing matched point/joint experiment: {branch}, {schedule}')
        point,joint=candidates['point'],candidates['joint']
        if not point.daily.window_date.equals(joint.daily.window_date):raise ValueError('Paired runs use different dates')
        if point.summary['soc_start_kwh']!=joint.summary['soc_start_kwh']:raise ValueError('Paired runs start with different stock')
        a=point.daily;b=joint.daily;delta=b.cash_cost_yuan.to_numpy()-a.cash_cost_yuan.to_numpy();delta_inv=b.inventory_adjusted_cost_yuan.to_numpy()-a.inventory_adjusted_cost_yuan.to_numpy()
        for i,date in enumerate(a.window_date):
            records.append(dict(branch=branch,window_date=date,point_strategy=point.name,joint_strategy=joint.name,
                point_cash_yuan=float(a.cash_cost_yuan.iloc[i]),joint_cash_yuan=float(b.cash_cost_yuan.iloc[i]),joint_minus_point_cash_yuan=float(delta[i]),
                cumulative_cash_difference_yuan=float(delta[:i+1].sum()),joint_minus_point_inventory_score_yuan=float(delta_inv[i]),
                cumulative_inventory_difference_yuan=float(delta_inv[:i+1].sum()),joint_minus_point_emergency_kwh=float(b.emergency_kwh.iloc[i]-a.emergency_kwh.iloc[i])))
        summaries.append(dict(branch=branch,point_strategy=point.name,joint_strategy=joint.name,windows=len(delta),joint_minus_point_cash_yuan=float(delta.sum()),
            joint_minus_point_inventory_score_yuan=float(delta_inv.sum()),joint_cheaper_windows=int((delta<-1e-5).sum()),point_cheaper_windows=int((delta>1e-5).sum()),
            joint_cash_difference_percent=100*float(delta.sum())/float(a.cash_cost_yuan.sum()),point_end_soc=point.summary['soc_end_kwh'],joint_end_soc=joint.summary['soc_end_kwh']))
    return pd.DataFrame(records),pd.DataFrame(summaries)


def sensitivity_comparison(study):
    records=[]
    for branch in ('4-2','4-3'):
        prefix='Q'+branch.replace('-','')+'_';reference=study.sensitivity[prefix+'reference']
        joint_reference=study.sensitivity.get(prefix+'joint_reference',reference)
        for name,run in study.sensitivity.items():
            if run.branch!=branch:continue
            label=name.removeprefix(prefix);base=reference
            s=run.summary;r=base.summary;cash=float(s['cash_cost_yuan']);score=float(s['inventory_adjusted_cost_yuan'])
            if not run.daily.window_date.equals(base.daily.window_date):raise ValueError('Sensitivity dates are not matched')
            row=dict(branch=branch,experiment=name,label=label,label_zh=SENS_LABEL.get(label,label),reference=base.name,windows=len(run.daily),
                first_date=run.daily.window_date.iloc[0],last_date=run.daily.window_date.iloc[-1],cash_cost_yuan=cash,inventory_score_yuan=score,
                cash_delta_yuan=cash-r['cash_cost_yuan'],inventory_delta_yuan=score-r['inventory_adjusted_cost_yuan'],
                inventory_delta_percent=100*(score-r['inventory_adjusted_cost_yuan'])/r['inventory_adjusted_cost_yuan'],
                initial_soc=s['soc_start_kwh'],final_soc=s['soc_end_kwh'],emergency_kwh=s['emergency_kwh'])
            if label in ('joint_mean','joint_shuffled'):
                row.update(joint_layer_reference=joint_reference.name,joint_layer_inventory_delta_yuan=score-joint_reference.summary['inventory_adjusted_cost_yuan'])
            records.append(row)
    return pd.DataFrame(records)


def selected_day_profiles(study):
    profiles=[]
    for branch in ('4-2','4-3'):
        run=study.selected(branch);trace=pd.read_csv(run.path/'trace.csv')
        study.source_hashes[str(run.path/'trace.csv')]=digest(run.path/'trace.csv')
        trace['date']=trace.interval_start.str[:10]
        for date in DATES:
            rows=trace[trace.date==date].copy()
            if len(rows)!=144:raise ValueError('Specified-day plot requires full natural day')
            expected=pd.date_range(date,periods=144,freq='10min')
            if not np.array_equal(pd.to_datetime(rows.interval_start).to_numpy(),expected.to_numpy()):raise ValueError('Specified day contains shifted slots')
            rows['branch']=branch;profiles.append(rows)
    return pd.concat(profiles,ignore_index=True)


def build_tables(study):
    paired,paired_summary=paired_price_modes(study)
    return {'主策略费用组成':fee_components(study),'主策略逐月费用':monthly_main(study),'八组合开发与留出比较':schedule_comparison(study),
        '电价点值与联合场景逐窗配对':paired,'电价点值与联合场景比较':paired_summary,'参数敏感性比较':sensitivity_comparison(study),'指定四日逐段图形数据':selected_day_profiles(study)}


def _plot_setup(out_dir):
    os.environ.setdefault('MPLCONFIGDIR',str(Path(out_dir)/'.mplconfig'))
    import matplotlib
    matplotlib.use('Agg')
    from matplotlib import pyplot as plt,font_manager
    candidate=Path('/System/Library/Fonts/Supplemental/Songti.ttc')
    if candidate.exists():font_manager.fontManager.addfont(str(candidate));font=font_manager.FontProperties(fname=str(candidate)).get_name()
    else:
        fonts=[f.name for f in font_manager.fontManager.ttflist if any(x in f.name for x in ('Songti','SimSun','Noto Serif CJK'))]
        
        if not fonts:raise RuntimeError('Install Songti, SimSun, or Noto Serif CJK for legible Chinese plots')
        font=fonts[0]
    plt.rcParams.update({'font.family':font,'font.size':11,'axes.unicode_minus':False,'axes.spines.top':False,'axes.spines.right':False,
        'axes.linewidth':.7,'pdf.fonttype':42,'savefig.dpi':240,'xtick.direction':'out','ytick.direction':'out','axes.labelpad':8})
    return plt,font


def create_figures(study,tables,out_dir):
    out_dir=Path(out_dir);out_dir.mkdir(parents=True,exist_ok=True);plt,font=_plot_setup(out_dir)
    import matplotlib.dates as mdates
    manifest=[];colors={'4-2':'#4D718C','4-3':'#467E76'}
    def save(fig,name,caption,family):
        fig.savefig(out_dir/(name+'.png'),bbox_inches='tight',facecolor='white');fig.savefig(out_dir/(name+'.pdf'),bbox_inches='tight',facecolor='white');plt.close(fig)
        manifest.append(dict(stem=name,family=family,caption=caption,font=font,png_dpi=240,in_figure_title=False))
    # 1. Signed refund is shown below zero instead of silently omitted.
    fees=tables['主策略费用组成'];fig,ax=plt.subplots(figsize=(10.8,4.5),layout='constrained')
    fields=[('plan_cost_yuan','原计划费','#829AA8'),('increase_cost_yuan','增购费','#5E8D81'),('penalty_yuan','违约费','#B5A492'),('emergency_cost_yuan','紧急费','#BE8E61')]
    pos=np.zeros(2)
    for field,label,color in fields:
        values=fees[field].to_numpy()/10000;ax.barh([0,1],values,left=pos,label=label,color=color,height=.48);pos+=values
    refund=-fees.refund_yuan.to_numpy()/10000;ax.barh([0,1],refund,label='取消退原费',color='#77818A',hatch='///',height=.48)
    ax.set_yticks([0,1],['Q4-2主策略','Q4-3主策略']);ax.invert_yaxis();ax.axvline(0,color='#444444',linewidth=.7);ax.set_xlabel('334合同窗口费用组成（万元）')
    for i,row in fees.iterrows():ax.text(pos[i]+max(pos)*.025,i,f"净现金 {row.cash_cost_yuan/10000:.2f}",va='center',fontsize=10)
    ax.set_xlim(min(refund)*1.15,max(pos)*1.30);ax.legend(ncol=3,frameon=False,loc='upper center',bbox_to_anchor=(.5,1.28));ax.grid(axis='x',alpha=.16)
    save(fig,'01_selected_fee_components','两主策略的334个合同窗口费用；取消退原费为负项，库存评价和启动段另列。两分支输入信息不同，跨分支差额不能全部归因于调单权限。',1)
    # 2. Monthly cash, not the optimization objective.
    month=tables['主策略逐月费用'];fig,ax=plt.subplots(figsize=(10.8,4.6),layout='constrained')
    for branch in ('4-2','4-3'):
        rows=month[month.branch==branch];ax.plot([int(v[-2:]) for v in rows.month],rows.cash_cost_yuan/10000,color=colors[branch],marker='o',markersize=4,label=BRANCH_LABEL[branch],linewidth=1.8)
    ax.set_xticks(range(2,13));ax.set_xlabel('合同发行月份');ax.set_ylabel('实际合同费用（万元）');ax.legend(frameon=False);ax.grid(axis='y',alpha=.2)
    save(fig,'02_monthly_selected_cost','各月按合同发行日分组，比较两项事先选定主策略的实际现金费，不是自然日费用，也不据单月最低重选策略。',2)
    # 3. Same schedule order in development and held-out panels.
    schedules=tables['八组合开发与留出比较'];fig,axes=plt.subplots(1,2,figsize=(12,5.6),sharey=True,layout='constrained')
    labels=[f"{row.schedule} {'＊' if row.selected_before_test else ''}" for row in schedules.itertuples()]
    for ax,column,xlabel in [(axes[0],'development_daily_score_yuan','开发7窗日均库存评价（万元/窗）'),(axes[1],'test_daily_score_yuan','留出310窗日均库存评价（万元/窗）')]:
        vals=schedules[column].to_numpy()/10000;ax.barh(np.arange(8),vals,color=['#467E76' if x else '#9AAEB9' for x in schedules.selected_before_test],height=.55)
        ax.set_yticks(range(8),labels);ax.invert_yaxis() if not ax.yaxis_inverted() else None;ax.set_xlabel(xlabel);ax.grid(axis='x',alpha=.18)
        ax.set_xlim(0,max(vals)*1.19)
        ranks=schedules.development_rank if column.startswith('development') else schedules.test_rank_retrospective
        for i,(val,rank) in enumerate(zip(vals,ranks)):ax.text(val+max(vals)*.016,i,f'{val:.3f}  #{rank}',va='center',fontsize=9)
    axes[0].set_ylabel('启用调单时刻（＊为事先选定）');axes[1].tick_params(labelleft=True)
    save(fig,'03_eight_schedule_development_holdout','同一个冻结价格模式下的8种Q4-3调单组合。按开发期顺序排列；右图排名只是留出期回顾，绿色及星号始终表示开发期冻结的主策略。两期长度不同，画每窗平均的共同库存评价，非真实电费。',3)
    # 4. Four independent 3x1 panels; no unreadable twelve-panel page.
    profiles=tables['指定四日逐段图形数据']
    for date in DATES:
        fig,axes=plt.subplots(3,1,figsize=(10.8,8.8),sharex=True,layout='constrained');h=np.arange(144)/6
        selected_rows={branch:profiles[(profiles.branch==branch)&(profiles.date==date)] for branch in ('4-2','4-3')}
        for branch,rows in selected_rows.items():
            soc=np.r_[rows.soc_start_kwh.iloc[0],rows.soc_end_kwh.to_numpy()]
            axes[0].plot(np.arange(145)/6,soc,color=colors[branch],label=BRANCH_LABEL[branch],linewidth=1.7)
            shift=.035 if branch=='4-2' else .11
            axes[1].bar(h+shift,rows.emergency_kwh,width=.065,color=colors[branch],label=BRANCH_LABEL[branch])
        for bound in (1200,10800):axes[0].axhline(bound,color='#A5AAAD',linestyle=':',linewidth=.9)
        axes[0].set_ylim(850,11150);axes[0].set_ylabel('储电量（kWh）');axes[0].legend(frameon=False,ncol=2)
        axes[1].set_ylabel('每10分钟紧急电量（kWh）')
        peak_emergency=float(profiles[profiles.interval_start.str[:10]==date].emergency_kwh.max())
        axes[1].set_ylim(0,max(1.,peak_emergency*1.12))
        if peak_emergency<1e-7:axes[1].text(.5,.5,'两项主策略当日均无紧急购电',transform=axes[1].transAxes,ha='center',va='center',color='#58636B')
        left=selected_rows['4-2'];right=selected_rows['4-3']
        if not np.allclose(left.price_yuan_per_kwh,right.price_yuan_per_kwh,atol=1e-12,rtol=0):raise ValueError('Selected branches do not share actual prices')
        axes[2].plot(h,left.price_yuan_per_kwh,color='#41474B',linewidth=1.4,label='实际结算区间价')
        same=np.allclose(left.price_forecast_yuan_per_kwh,right.price_forecast_yuan_per_kwh,atol=1e-12,rtol=0)
        axes[2].plot(h,left.price_forecast_yuan_per_kwh,color=colors['4-2'],linestyle='--',linewidth=1.3,label='决策时采用的预测价' if same else 'Q4-2决策预测价')
        if not same:axes[2].plot(h,right.price_forecast_yuan_per_kwh,color=colors['4-3'],linestyle='-.',linewidth=1.3,label='Q4-3决策预测价')
        axes[2].set_ylabel('区间电价（元/kWh）');axes[2].legend(frameon=False,ncol=3,fontsize=10)
        axes[-1].set_xticks(range(0,25,4),[f'{v:02d}:00' for v in range(0,25,4)]);axes[-1].set_xlabel('自然日执行区间起点 / 储电状态时刻');axes[-1].set_xlim(0,24)
        for ax in axes:ax.grid(axis='y',alpha=.17)
        save(fig,'04_'+date.replace('-','')+'_state_emergency_price',f'{date}自然日两主策略的实际SOC、紧急电量及执行时采用的预测/结算区间价格。00:00首段取前一合同；SOC虚线为1200和10800kWh边界，价格为区间端点均值，不是原始瞬时表。',4)
    # 5. Independent continuously run policies, not forced identical g or state.
    paired=tables['电价点值与联合场景逐窗配对'];fig,axes=plt.subplots(1,2,figsize=(12,4.6),layout='constrained')
    for ax,branch in zip(axes,('4-2','4-3')):
        rows=paired[paired.branch==branch];dates=pd.to_datetime(rows.window_date)
        ax.plot(dates,rows.cumulative_cash_difference_yuan/10000,color=colors[branch],linewidth=1.8,label='实际现金差')
        ax.plot(dates,rows.cumulative_inventory_difference_yuan/10000,color=colors[branch],linestyle='--',linewidth=1.3,label='共同库存评价差')
        ax.axhline(0,color='#666666',linewidth=.8);ax.set_ylabel(f'{BRANCH_LABEL[branch]} 联合 - 点价累计差（万元）');ax.set_xlabel('合同发行日期')
        ax.set_xlim(dates.iloc[0],dates.iloc[-1]);ax.xaxis.set_major_locator(mdates.MonthLocator(bymonth=[2,4,6,8,10,12]));ax.xaxis.set_major_formatter(mdates.DateFormatter('%m月'));ax.legend(frameon=False);ax.grid(axis='y',alpha=.17)
    save(fig,'05_point_joint_paired_difference','同一分支、相同调单时刻和负载/光伏信息，比较电价点值与同日联合价格情景；两边均保留负载/光伏情景。负值为联合价格方案累计费用较低。各自从共同初态连续运行，不强制相同购电或逐日SOC。',5)
    # 6. Common inventory valuation keeps initial-state comparisons interpretable.
    sens=tables['参数敏感性比较'];fig,axes=plt.subplots(1,2,figsize=(12.6,7.8),layout='constrained')
    for ax,branch in zip(axes,('4-2','4-3')):
        rows=sens[(sens.branch==branch)&(sens.label!='reference')].reset_index(drop=True);positions=np.arange(len(rows))
        values=rows.inventory_delta_percent.to_numpy();ax.barh(positions,values,color=colors[branch],height=.55,alpha=.85)
        ax.set_yticks(positions,rows.label_zh);ax.invert_yaxis();ax.axvline(0,color='#4C5357',linewidth=.7)
        ax.set_xlabel(f'{BRANCH_LABEL[branch]} 相对冻结参考的库存评价变化（%）');ax.grid(axis='x',alpha=.17)
    save(fig,'06_parameter_sensitivity','两分支分别在同一14个发行窗口中检验参数及执行方式；每组独立从明确初态运行。以共同库存评价衡量初态差，负值为评价费用下降。均值/打乱联合价格等实验不是事后调参依据，条件联合参考差另列CSV。',6)
    result=dict(figure_families=6,figure_files=len(manifest),figures=manifest,selected_q42=study.selection['selected_q42'],selected_q43=study.selection['selected_q43'],selection_changed=False)
    write_json(out_dir/'figure_manifest.json',result)
    (out_dir/'图注.md').write_text('\n\n'.join(f"图{row['family']}（{row['stem']}）：{row['caption']}" for row in manifest)+'\n',encoding='utf-8')
    return result


def build_figures(results_dir=ROOT/'results/final',out_dir=None,tables_dir=None):
    results_dir=Path(results_dir);out_dir=Path(out_dir) if out_dir else results_dir/'figures';tables_dir=Path(tables_dir) if tables_dir else results_dir/'reports/图形数据'
    study=load_study(results_dir);tables=build_tables(study);tables_dir.mkdir(parents=True,exist_ok=True)
    for name,frame in tables.items():frame.to_csv(tables_dir/(name+'.csv'),index=False,encoding='utf-8-sig')
    manifest=create_figures(study,tables,out_dir)
    for path,old in study.source_hashes.items():
        if digest(path)!=old:raise RuntimeError('Figure generation changed an input')
    summary=dict(complete=True,selected_q42=study.selection['selected_q42'],selected_q43=study.selection['selected_q43'],
        model_or_schedule_reselected=False,main_strategy_count=len(study.main),sensitivity_count=len(study.sensitivity),figure_manifest=manifest,
        point_joint_comparison=tables['电价点值与联合场景比较'].to_dict(orient='records'),source_sha256=study.source_hashes,source_files_unchanged=True)
    write_json(tables_dir/'图形数据核验.json',summary)
    return summary


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--results',type=Path,default=ROOT/'results/final');parser.add_argument('--out',type=Path);parser.add_argument('--tables',type=Path)
    args=parser.parse_args();value=build_figures(args.results,args.out,args.tables);print(json.dumps({'complete':True,'figure_families':6,'figure_files':value['figure_manifest']['figure_files'],'selected_q42':value['selected_q42'],'selected_q43':value['selected_q43']},ensure_ascii=False))
