"""Bounded supplemental search for near-zero control objectives; read-only inputs."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from q4_solver_check import ROOT,reconstruct_control,summarize
from q4_io import load_inputs,selected_pv
from q4_risk import future_mask
from q4_optimizer import solve_dispatch


def run_zero_screen(data_dir,results_dir,strategy="Q43_point_H0_18",out_dir=None):
    out=Path(out_dir or ROOT/"results/solver_check")/strategy;out.mkdir(parents=True,exist_ok=True)
    source=Path(results_dir)/"main"/strategy
    config=json.loads((source/'summary.json').read_text())['config'];trace=pd.read_csv(source/'trace.csv')
    data=load_inputs(data_dir);data['policy_pv']=selected_pv(data,config['branch'],config['pv_source'])
    rows=[];pairs=[]
    # Inspect two early weeks plus each later month's first contract window; select
    # up to six evenly spaced eligible deficit steps per day, max144 calls in all.
    chosen=list(range(14))+[i for i,date in enumerate(data['dates']) if date.day==1 and date.month>2]
    for day in chosen:
     part=trace.loc[trace.window_date==str(data['dates'][day])].reset_index(drop=True)
     D=part.load_actual_kw/6-part.q_kwh-part.pv_actual_kw/6
     eligible=[t for t in range(107) if D.iloc[t]>1e-6 and future_mask(config['trade_hours'],t).any()]
     for pos in np.unique(np.linspace(0,len(eligible)-1,min(6,len(eligible))).astype(int)):
      pairs.append((day,eligible[pos]))
    for day,t in pairs:
     inp=reconstruct_control(data,trace,config,day,t)
     sol=solve_dispatch(inp['load'],inp['pv'],inp['price'],inp['s0'],mode='control',base_g=inp['base_g'],
      booked_q=inp['booked_q'],future_adjust_mask=inp['future_adjust_mask'],terminal_weight=data['inventory_value'],time_limit=10,mip_gap=1e-4)
     row=summarize(sol,inp,10);rows.append(row)
     result={'selection_rule':'First14days and firstday of eachlatermonth; at most6 evenlyspaced positive-deficit ordinary MILP steps/day, up to144 calls. Stop after3 relative gaps over1%. Read-only frozenstate diagnostic.',
     'complete':False,'sampled_controls':rows}
     (out/'zero_objective_screen.json').write_text(json.dumps(result,indent=2,ensure_ascii=False))
     if row['relative_gap'] is not None and row['relative_gap']>.01:
      print(json.dumps(row,ensure_ascii=False),flush=True)
     if sum((r['relative_gap'] or 0)>.01 for r in rows)>=3:break
    refinements=[]
    for baseline in [r for r in rows if (r['relative_gap'] or 0)>.01]:
     day=next(i for i,date in enumerate(data['dates']) if str(date)==baseline['window_date'])
     inp=reconstruct_control(data,trace,config,day,baseline['slot'])
     sol=solve_dispatch(inp['load'],inp['pv'],inp['price'],inp['s0'],mode='control',base_g=inp['base_g'],
      booked_q=inp['booked_q'],future_adjust_mask=inp['future_adjust_mask'],terminal_weight=data['inventory_value'],time_limit=45,mip_gap=1e-6)
     row=summarize(sol,inp,45)
     row.update(objective_minus_10sec_yuan=row['objective_yuan']-baseline['objective_yuan'],
      discharge_minus_10sec_kwh=row['discharge_kwh']-baseline['discharge_kwh'],
      emergency_minus_10sec_kwh=row['emergency_kwh']-baseline['emergency_kwh'])
     refinements.append(row)
    result['complete']=True;result['calls']=len(rows);result['planned_maximum_calls']=len(pairs)
    result['refinements']=refinements
    result['limitations']='Original maximum-gap step was not logged. Similar large relative gaps were reproduced and shown to have tiny absolute gaps; this bounded audit does not classify every unproven step in the334-window run.'
    (out/'zero_objective_screen.json').write_text(json.dumps(result,indent=2,ensure_ascii=False))
    print(json.dumps({'calls':len(rows),'planned_maximum_calls':len(pairs),'largest_gaps':sorted(rows,key=lambda r:r['relative_gap'] or 0,reverse=True)[:5]},ensure_ascii=False),flush=True)
    return result

if __name__=="__main__":
    run_zero_screen(ROOT/"data",ROOT/"results/final")
