"""Portable, read-only export of frozen XGBoost prices and actual-node status."""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import openpyxl
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from price_inputs import load_price_data

ROOT=Path(__file__).resolve().parents[1]


def clock_label(minutes):
    prefix='次日' if minutes>=1440 else ''
    return f'{prefix}{minutes%1440//60:02d}:{minutes%60:02d}'


def _specifications(price):
    dates=[x.strftime('%Y-%m-%d') for x in price.dates]
    specs={}
    for v,hour in enumerate(price.vintages):
        slot=price.gate_slots[v]
        first=0 if hour==0 else slot+1
        known=price.known_midnight if hour==0 else price.nodes[:,v,slot]
        node_data=np.column_stack((known,price.nodes[:,v,first:]))
        headers=['发行日期',f'已知{hour:02d}:00瞬时值（非预测）']+[clock_label(10*(j+1)) for j in range(first,145)]
        specs[f'{hour:02d}时_瞬时预测']=(headers,node_data,dates,None)
        labels=[f'{clock_label(10*(j+1))}—{clock_label(10*(j+2))}' for j in range(slot,144)]
        specs[f'{hour:02d}时_区间均价']=(['发行日期']+labels,price.predicted[:,v,slot:],dates,None)
    node_status=['实测']*len(dates);node_status[-1]='最后次日00:10缺实测；留空'
    specs['实际瞬时节点_缺失留空']=(['合同窗口日期']+[clock_label(10*(j+1)) for j in range(145)],price.raw_actual_nodes,dates,node_status)
    raw_means=(price.raw_actual_nodes[:,:-1]+price.raw_actual_nodes[:,1:])/2
    interval_status=['实测端点均价']*len(dates);interval_status[-1]='最后区间右端缺实测；均价留空'
    labels=[f'{clock_label(10*(j+1))}—{clock_label(10*(j+2))}' for j in range(144)]
    specs['实际区间均价_缺失留空']=(['合同窗口日期']+labels,raw_means,dates,interval_status)
    specs['零点桥接预测']=(['发行日期','已知00:00（非预测）','预测00:10','00:00—00:10预测均价'],
        np.column_stack((price.known_midnight,price.nodes[:,0,0],price.forecast_bridge)),dates,None)
    return specs


def _style_sheet(sheet, known=False):
    fill=PatternFill('solid',fgColor='17365D');pale=PatternFill('solid',fgColor='EDF3F8')
    for cell in sheet[1]:
        cell.fill=fill;cell.font=Font(name='Calibri',color='FFFFFF',bold=True,size=11)
        cell.alignment=Alignment(horizontal='center',vertical='center',wrap_text=True)
    sheet.row_dimensions[1].height=44
    sheet.freeze_panes='C2' if known else 'B2'
    sheet.auto_filter.ref=sheet.dimensions
    sheet.column_dimensions['A'].width=16
    for column in range(2,sheet.max_column+1):sheet.column_dimensions[get_column_letter(column)].width=18
    if known:sheet.column_dimensions['B'].width=25
    for row in sheet.iter_rows(min_row=2):
        for cell in row:
            cell.font=Font(name='Calibri',size=11)
            if isinstance(cell.value,(int,float)):cell.number_format='0.000000'
            if cell.row%2==0:cell.fill=pale
            if cell.value is None:cell.fill=PatternFill('solid',fgColor='FFF2CC')
    sheet.sheet_view.zoomScale=85


def verify_price_report(path, data_dir):
    path=Path(path);data_dir=Path(data_dir);price=load_price_data(data_dir/'price_inputs.npz')
    with np.load(data_dir/'xgboost_midnight_predictions.npz',allow_pickle=False) as old:
        np.testing.assert_array_equal(price.nodes[:,0],old['predictions'])
    book=openpyxl.load_workbook(path,read_only=True,data_only=False)
    counts={};errors={}
    try:
        specs=_specifications(price)
        if set(book.sheetnames)!=set(specs)|{'口径与来源','末端估计_不是实测'}:raise ValueError('Unexpected price workbook sheets')
        for name,(headers,values,dates,status) in specs.items():
            sheet=book[name];rows=list(sheet.iter_rows(values_only=True))
            expected_headers=headers+(['尾节点或尾段状态'] if status is not None else [])
            if list(rows[0])!=expected_headers or len(rows)!=335:raise ValueError(f'Wrong header or row count: {name}')
            if [row[0] for row in rows[1:]]!=dates:raise ValueError('Price workbook dates changed')
            n=values.shape[1]
            observed=np.asarray([[np.nan if cell is None else float(cell) for cell in row[1:n+1]] for row in rows[1:]])
            if not np.array_equal(np.isnan(observed),np.isnan(values)):raise ValueError('Missing actual value was silently filled')
            np.testing.assert_allclose(observed,values,atol=2e-14,rtol=0,equal_nan=True)
            errors[name]=float(np.nanmax(np.abs(observed-values)))
            if status is not None and [row[-1] for row in rows[1:]]!=status:raise ValueError('Missing actual flags changed')
            counts[name]=dict(data_rows=334,numeric_columns=n,verified_numeric_cells=int(np.isfinite(values).sum()),missing_cells=int(np.isnan(values).sum()))
            for row in rows:
                for value in row:
                    if isinstance(value,str) and (value.startswith('=') or value in {'#VALUE!','#DIV/0!','#REF!','#NAME?','#NULL!','#NUM!','#N/A'}):
                        raise ValueError('Unexpected formula or Excel error')
        boundary=list(book['末端估计_不是实测'].values)
        if boundary[0]!=('方法','缺失节点估计（元/kWh）','最后区间估计均价（元/kWh）','状态'):raise ValueError('Wrong boundary estimate header')
        for row,method in zip(boundary[1:],('hold','linear2','ols6')):
            expected=price.boundary_alternatives[method]
            if row[0]!=method or row[3]!='估计，不是实测':raise ValueError('Boundary status changed')
            np.testing.assert_allclose(row[1:3],[expected['last_node_price'],expected['last_interval_price']],atol=2e-14,rtol=0)
    finally:book.close()
    return dict(passed=True,workbook_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),sheets=counts,
        maximum_excel_roundtrip_difference=max(errors.values()),per_sheet_roundtrip_difference=errors,
        original_midnight_predictions_inherited_exactly_before_serialization=True,
        missing_actual_node_left_blank=True,missing_actual_interval_left_blank=True,
        source_sha256={name:hashlib.sha256((data_dir/name).read_bytes()).hexdigest()
                       for name in ('price_inputs.npz','xgboost_midnight_predictions.npz')},
        formulas_written=False,prices_multiplied_by_one_sixth=False)


def build_price_report(data_dir,results_dir):
    data_dir=Path(data_dir);output=Path(results_dir)/'reports';output.mkdir(parents=True,exist_ok=True)
    price=load_price_data(data_dir/'price_inputs.npz')
    # Prove exact reuse before the decimal serialization used by Excel.
    with np.load(data_dir/'xgboost_midnight_predictions.npz',allow_pickle=False) as old:
        np.testing.assert_array_equal(price.nodes[:,0],old['predictions'])
    workbook=openpyxl.Workbook();readme=workbook.active;readme.title='口径与来源'
    info=[('项目','说明'),('用途','第四问调度的冻结 XGBoost 分版本电价输入；本工作簿只导出已有数组，不训练、不选参。'),
        ('单位','全部价格单位元/kWh；价格不乘 1/6。只有功率转电量时才乘小时数。'),
        ('合同窗口','发行日期 D 的 00:10 至 D+1 00:10，共 144 个十分钟区间。'),
        ('0 点瞬时预测','00:10 至次日00:10，共145个未来节点。B列是发行时已知的00:00节点，不是预测。原生成的零点 XGBoost 预测逐值继承。'),
        ('6/12/18 点瞬时预测','分别从06:10/12:10/18:10至次日00:10，共109/73/37个未来节点。B列为相应发行时刻已经观测的左端节点，不计作预测。'),
        ('对应区间均价','0点144段，6/12/18点109/73/37段。节点端点取平均。日内版本首段使用发行时已知左端与预测右端；后续段两端都是当时预测。'),
        ('十分钟实时控制','工作簿保留每版发行时的原始预测。后续MPC首段应再以当前已观测左端替换预测左端，右端仍使用该版预测；不能用实际右端参与当时决策。'),
        ('零点桥接','单独记录已知00:00与预测00:10形成的00:00—00:10桥接预测均价，不把它塞进本合同144段重复计费。'),
        ('用于评估的实测曲线','单独放在“实际瞬时节点”“实际区间均价”两表中，不混入未来预测列；预测表仅另列发行时已知的观测节点。最后2026-01-01 00:10缺实测，节点及相关区间均价均留空并标记。'),
        ('末端估计','默认持平、2点线性、6点OLS估计单列“末端估计_不是实测”。不将这些数字写进实测表。主调度使用持平估计结算并标记estimated。'),
        ('日内模型','使用同一组冻结 XGBoost 超参数，按相同发行小时的历史样本每天重拟合；仅用发行时已兑现标签，不因本次测试误差重选参数。'),
        ('重叠目标','不同发行版本可能预测相同目标；按发行日期及版本分别保留，不能将重叠节点当独立额外实测样本。'),
        ('显示与保存','显示6位小数，单元格保存完整数值；逐值重开验证允许不超过2e-14的Excel十进制往返误差，不主动舍入原数组。'),
        ('原价预测文件 SHA256',hashlib.sha256((data_dir/'xgboost_midnight_predictions.npz').read_bytes()).hexdigest()),
        ('分版本价格数组 SHA256',hashlib.sha256((data_dir/'price_inputs.npz').read_bytes()).hexdigest())]
    for row in info:readme.append(row)
    _style_sheet(readme);readme.column_dimensions['A'].width=28;readme.column_dimensions['B'].width=115
    for row in readme.iter_rows(min_row=2):
        readme.row_dimensions[row[0].row].height=44
        for cell in row:cell.alignment=Alignment(vertical='center',wrap_text=True)
    for name,(headers,values,dates,status) in _specifications(price).items():
        sheet=workbook.create_sheet(name);sheet.append(headers+(['尾节点或尾段状态'] if status is not None else []))
        for i,date in enumerate(dates):
            sheet.append([date]+[float(x) if np.isfinite(x) else None for x in values[i]]+([status[i]] if status is not None else []))
        _style_sheet(sheet,known=('瞬时预测' in name or name=='零点桥接预测'))
        if status is not None:sheet.column_dimensions[get_column_letter(sheet.max_column)].width=44
    sheet=workbook.create_sheet('末端估计_不是实测')
    sheet.append(['方法','缺失节点估计（元/kWh）','最后区间估计均价（元/kWh）','状态'])
    for method in ('hold','linear2','ols6'):
        record=price.boundary_alternatives[method]
        sheet.append([method,record['last_node_price'],record['last_interval_price'],'估计，不是实测'])
    _style_sheet(sheet)
    for column in ('B','C','D'):sheet.column_dimensions[column].width=32
    path=output/'第四问_XGBoost分版本电价.xlsx';workbook.save(path)
    verification=verify_price_report(path,data_dir)
    (output/'第四问_XGBoost分版本电价_核验.json').write_text(json.dumps(verification,ensure_ascii=False,indent=2))
    return verification


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--data',type=Path,default=ROOT/'data')
    p.add_argument('--results',type=Path,default=ROOT/'results/final');args=p.parse_args()
    print(json.dumps(build_price_report(args.data,args.results),ensure_ascii=False))
