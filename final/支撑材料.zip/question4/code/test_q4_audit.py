"""Tampering tests for the independent auditor using a freshly executed day."""
import copy
import json
from pathlib import Path
import shutil
import tempfile
import unittest
from unittest.mock import patch

import pandas as pd

import q4_runner as runner
from q4_audit import audit_all,audit_run,source_data,ROOT


class TestIndependentAudit(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory()
        cls.work=Path(cls.temp.name)
        cls.source=source_data(ROOT/'data')
        # One real-data day is fast and gives a self-contained fixture, so the
        # tests do not depend on optional pilot or delivered result folders.
        runner.run_strategy(ROOT/'data',cls.work,(0,),branch='4-2',days=1,
            name='fixture',config={'scenarios':1,'controller':'greedy'})
        cls.fixture=cls.work/'fixture'

    @classmethod
    def tearDownClass(cls):cls.temp.cleanup()

    def variant(self,name):
        path=self.work/name
        if path.exists():shutil.rmtree(path)
        shutil.copytree(self.fixture,path)
        return path

    def test_fresh_run_and_external_absolute_output_path_pass(self):
        result=audit_run(self.fixture,ROOT/'data',self.source)
        self.assertTrue(result['passed'])
        self.assertEqual(result['intervals'],144)
        self.assertEqual(result['january_night_intervals'],1115)
        self.assertEqual(result['path'],str(self.fixture.resolve()))

    def test_cash_column_tampering_is_detected(self):
        path=self.variant('cash')
        rows=pd.read_csv(path/'trace.csv');rows.loc[0,'cash_cost_yuan']+=.1
        rows.to_csv(path/'trace.csv',index=False)
        with self.assertRaisesRegex(AssertionError,'cash_cost_yuan'):
            audit_run(path,ROOT/'data',self.source)

    def test_unexecuted_or_altered_signed_order_is_detected(self):
        path=self.variant('order')
        doc=json.loads((path/'event_log.json').read_text())
        doc['events'][0]['signed_q'][0]+=1
        (path/'event_log.json').write_text(json.dumps(doc))
        with self.assertRaisesRegex(AssertionError,'immutable original plan'):
            audit_run(path,ROOT/'data',self.source)

    def test_realized_price_cannot_be_relabeled_as_control_forecast(self):
        path=self.variant('future_price')
        rows=pd.read_csv(path/'trace.csv')
        rows.loc[0,'price_forecast_yuan_per_kwh']+=.1
        rows.to_csv(path/'trace.csv',index=False)
        with self.assertRaisesRegex(AssertionError,'known-left/predicted-right'):
            audit_run(path,ROOT/'data',self.source)

    def test_changed_input_cannot_reuse_old_run_signature(self):
        path=self.variant('source')
        # The source field is reviewed before any physical values, so even an
        # apparently numerically identical old run may not claim provenance.
        doc=json.loads((path/'summary.json').read_text());doc['run_signature']='0'*64
        (path/'summary.json').write_text(json.dumps(doc))
        with self.assertRaisesRegex(AssertionError,'signature mismatch'):
            audit_run(path,ROOT/'data',self.source)

    def test_incomplete_declared_experiment_cannot_pass_as_full_audit(self):
        stage=self.work/'coverage';stage.mkdir(exist_ok=True)
        shutil.copytree(self.fixture,stage/'fixture',dirs_exist_ok=True)
        (stage/'design.json').write_text(json.dumps({'jobs':[{'name':'fixture'},{'name':'missing'}]}))
        with patch('q4_audit.source_data',return_value=self.source):
            report=audit_all(ROOT/'data',stage)
        self.assertFalse(report['passed'])
        self.assertEqual(report['audited_runs'],1)
        self.assertEqual(len(report['pending_runs']),1)
        self.assertIn('missing',report['pending_runs'][0])


if __name__=='__main__':unittest.main()
