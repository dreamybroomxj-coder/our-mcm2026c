"""Run and summarize the preregistered short fixed-contract execution checks."""
import argparse
import csv
import hashlib
import json
from pathlib import Path

from q4_causal_replay import run_replay
from q4_io import load_inputs

ROOT=Path(__file__).resolve().parents[1]


def planned_jobs(result_root):
    selected=json.loads((Path(result_root)/'selection.json').read_text())
    winners=[selected['selected_q42'],selected['selected_q43']]
    names=[]
    for name in winners:
        names.extend([name,name.replace('_point_','_joint_') if '_point_' in name else name.replace('_joint_','_point_')])
    return [(name,(1.,.1) if name in winners else (1.,)) for name in names]


def summarize(result_root):
    result_root=Path(result_root);folder=result_root/'causal_replay'
    rows=[];checks=[]
    for name,steps in planned_jobs(result_root):
        path=folder/name/'summary.json'
        if not path.exists():raise FileNotFoundError(f'Incomplete causal study: {path}')
        r=json.loads(path.read_text())
        if not r['checks_passed'] or r['local_initial_soc']!=6000. or r['days']!=7 or r['start_day']!=24:
            raise ValueError('Inconsistent local replay design')
        for source,digest in r['source_hashes'].items():
            if hashlib.sha256((result_root/'main'/name/source).read_bytes()).hexdigest()!=digest:
                raise ValueError('Frozen source changed after replay')
        for source,digest in r['replay_code_sha256'].items():
            if hashlib.sha256((ROOT/'code'/source).read_bytes()).hexdigest()!=digest:
                raise ValueError('Replay numerical implementation changed')
        for variant,z in r['summary'].items():
            rows.append(dict(strategy=name,variant=variant,days=r['days'],initial_soc_kwh=r['local_initial_soc'],
                cash_cost_yuan=z['cash_cost_yuan'],inventory_adjusted_cost_yuan=z['inventory_adjusted_cost_yuan'],
                soc_end_kwh=z['soc_end_kwh'],emergency_kwh=z['emergency_kwh'],battery_loss_kwh=z['battery_loss_kwh'],
                cash_difference_vs_mean=z['cash_cost_yuan']-r['summary']['10min_mean']['cash_cost_yuan'],
                max_physical_error_kwh=z['solver']['max_violation_kwh'],
                max_charge_power_kw=z['solver']['max_charge_power_kw'],
                max_discharge_power_kw=z['solver']['max_discharge_power_kw'],
                min_soc_kwh=z['solver']['min_soc_kwh'],max_soc_kwh=z['solver']['max_soc_kwh']))
        checks.append(dict(strategy=name,summary_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                           fine_step_minutes=r['fine_step_minutes'],signal_energy_integration_checks=r['signal_energy_integration_checks']))
    with (folder/'comparison.csv').open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    report=dict(scope='2025-02-25 00:10 to 2025-03-04 00:10, seven windows, identical configured6000 start; policy-specific frozen orders',
                rows=rows,checks=checks,checks_passed=True,selection_revised=False)
    (folder/'comparison.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
    lines=['# 分钟因果执行敏感性','',
        '这是固定正式合同条件下的执行近似检验，不是重新训练预测器或重新选择整年交易政策。四条策略均在 2025 年 2 月 25 日 00:10 以 6000 kWh 开始，连续执行到 3 月 4 日 00:10；各自原合同来自完整主回放，没有为这个局部起点重新优化。',
        '',
        '策略名中的 point 仅指价格采用点预测，负载与光伏仍按主模型处理场景；joint 表示价格也加入同日配对场景。这里的电池执行统一使用当时点预测进行滚动优化。',
        '',
        '每条策略本地重放一次十分钟实测均值反馈，另做一分钟因果反馈；冻结开发期选中的两条策略再细化到 0.1 分钟。两种执行共用该策略的原 g 和正式 q，只在原签单时刻揭示。跨午夜先揭示下一日原 g，然后执行旧合同最后十分钟。未来调单只能作为优化预案，不能提前读最终正式 q。',
        '',
        '一分钟和 0.1 分钟仅改变人工环境积分与底层约束执行步长，MPC 都仍然每十分钟重算一次；不是每分钟或每六秒重新优化电池计划。因此，二者费用差不能解释为提高 MPC 重算频率的收益或损失。',
        '',
        '每十分钟下指令时，细步控制只收到此刻的负载、光伏、真实电价左端节点；本段优化价格为真实左端与当时版本预测右端的平均。未来实际右端价格只供事后结算和人工环境生成，不进入优化目标。未来负载/光伏沿用当时发布的区间预测。',
        '',
        '人工环境在原十分钟实际节点之间线性插值。每个微步只读取当前节点并持平执行该微步：每十分钟内充放电方向不反转，放电不超过该十分钟原指令预算；微步可按 SOC、功率与负载缺口提前停止。紧急电只补当时缺口，不能给电池充电。该实验没有高频实测，因此不能称精确物理验证。',
        '',
        '十分钟合同电量 q 按恒定供电功率均匀分配到各微步，这是把原十分钟合同转为细步执行的补充假设。一个十分钟内可能先出现充电、后出现紧急购电，但二者在同一微步不能同时发生；该十分钟的充电/放电方向仍不反转。',
        '',
        '所有方案的现金账单均按同一个实际十分钟端点均价结算，即 p·g + 1.5p·增加量 − 0.5p·取消量 + 5p·紧急电量。没有把微步价格与微步功率相乘引入另一种结算规则。末态共同库存价值保持一月确定的数值，库存调整费只用于比较，不是实际付款。',
        '',
        '|策略|执行|现金费（元）|较本地十分钟增加（元）|库存调整费（元）|末 SOC（kWh）|紧急电（kWh）|电池损耗（kWh）|',
        '|---|---|---:|---:|---:|---:|---:|---:|']
    for r in rows:
        lines.append(f"|{r['strategy']}|{r['variant']}|{r['cash_cost_yuan']:.2f}|{r['cash_difference_vs_mean']:+.2f}|{r['inventory_adjusted_cost_yuan']:.2f}|{r['soc_end_kwh']:.3f}|{r['emergency_kwh']:.3f}|{r['battery_loss_kwh']:.3f}|")
    lines+=['','细化步长还改变了左端持平的积分近似。连续节点环境下，步长 δ 分钟导致的总电量差为 δ×（首个瞬时功率−最后瞬时功率）/120 kWh，相对于准确端点平均积分计算。程序对负载和光伏分别核验此恒等式；从 1 分钟细化到 0.1 分钟，该信号积分差缩小十倍。费用变化还包含未知段内变化与冻结方向/放电预算的影响，不等同于单纯积分误差。','']
    for name,_ in planned_jobs(result_root):
        rr={r['variant']:r for r in rows if r['strategy']==name}
        if '0.1min_causal' in rr:
            delta=rr['0.1min_causal']['cash_cost_yuan']-rr['1min_causal']['cash_cost_yuan']
            inventory_delta=rr['0.1min_causal']['inventory_adjusted_cost_yuan']-rr['1min_causal']['inventory_adjusted_cost_yuan']
            lines.append(f"- {name}：0.1 分钟相对 1 分钟现金变化 {delta:+.3f} 元，库存调整费变化 {inventory_delta:+.3f} 元。这是本轮细化稳定性结果，不外推为全年比例。")
    lines+=['','四条策略之间合同不同，共同 6000 起点只能使本次局部执行条件一致，不能把固定合同比较解释成重新优化后的完整政策优劣。跨策略只比较相同步长，不能用一条策略的 0.1 分钟费用与另一条的一分钟费用判优；两种细步也不足以证明已经收敛到连续时间精确结果。分钟结果不用于改写已冻结的开发期选择。',
        '', '复现：在工程根目录执行 `python code/q4_causal_study.py --results results/final`。输入主轨迹需已完整生成；输出包括十分钟轨迹、压缩微步轨迹、逐时签单揭示记录、物理核验与汇总。无需重新训练电价模型。']
    (ROOT/'notes/分钟因果执行敏感性.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    return report


def run_study(result_root, data_dir=ROOT/'data', only=None):
    result_root=Path(result_root);jobs=planned_jobs(result_root)
    if only is not None:jobs=[(name,steps) for name,steps in jobs if name in only]
    data=load_inputs(data_dir)
    for name,steps in jobs:
        source=result_root/'main'/name;target=result_root/'causal_replay'/name
        if not (source/'summary.json').exists():raise FileNotFoundError(f'Main run must finish first: {source}')
        if (target/'summary.json').exists():
            r=json.loads((target/'summary.json').read_text())
            if r['fine_step_minutes']!=list(steps):raise ValueError('Existing replay has different fine steps')
            if not r['checks_passed'] or r['start_day']!=24 or r['days']!=7 or r['local_initial_soc']!=6000.:
                raise ValueError('Existing replay has a different local design or failed checks')
            if r['input_source_sha256']!=data.get('metadata',{}).get('source_sha256',{}):
                raise ValueError('Replay source inputs changed; use a new output directory')
            for filename,digest in r['source_hashes'].items():
                if hashlib.sha256((source/filename).read_bytes()).hexdigest()!=digest:raise ValueError('Replay source changed')
            for filename,digest in r['replay_code_sha256'].items():
                if hashlib.sha256((ROOT/'code'/filename).read_bytes()).hexdigest()!=digest:raise ValueError('Replay code changed')
            print(f'Reused matching replay: {name}',flush=True)
            continue
        print(f'Replaying {name}: {steps} minute(s)',flush=True)
        run_replay(data_dir,source,target,24,7,6000.,steps,data_override=data)
        print(f'Completed: {name}',flush=True)
    # Partial jobs may run concurrently; only a full sequential call or the
    # explicit summarize command writes the shared comparison artifacts.
    if only is None and all((result_root/'causal_replay'/name/'summary.json').exists() for name,_ in planned_jobs(result_root)):
        return summarize(result_root)
    return {'partial':True,'completed_requested':[name for name,_ in jobs]}


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--results',type=Path,default=ROOT/'results/final')
    parser.add_argument('--data',type=Path,default=ROOT/'data')
    parser.add_argument('--only',help='Optional comma-separated names as their main runs finish')
    parser.add_argument('--summarize-only',action='store_true')
    args=parser.parse_args()
    report=summarize(args.results) if args.summarize_only else run_study(args.results,args.data,None if args.only is None else args.only.split(','))
    print(json.dumps({key:value for key,value in report.items() if key in ('checks_passed','partial','completed_requested')},ensure_ascii=False))
