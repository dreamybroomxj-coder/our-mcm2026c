import unittest
import numpy as np
from q4_solver_check import available_contract

class ReconstructionTests(unittest.TestCase):
    def test_unrevealed_future_order_hidden(self):
        np.testing.assert_array_equal(available_contract([10,20,30],[11,22,999],[False,False,True]),[11,22,30])
    def test_future_order_perturbation_invariant(self):
        g=[1,2,3];mask=[False,True,True]
        np.testing.assert_array_equal(available_contract(g,[4,5,6],mask),available_contract(g,[4,999,888],mask))
    def test_all_original_before_first_gate(self):
        np.testing.assert_array_equal(available_contract([1,2],[8,9],[True,True]),[1,2])
    def test_shape_mismatch_rejected(self):
        with self.assertRaises(ValueError):available_contract([1,2],[3],[False,True])

class FullInputReconstructionTests(unittest.TestCase):
    def fixture(self):
        import datetime as dt
        import pandas as pd
        date=dt.date(2025,2,2);start=dt.datetime(2025,2,2,0,10)
        data={'dates':[date],'window_start':[start],'load_f':np.full((1,144),12.),
            'load_a':np.full((1,144),12.),'pv_a':np.zeros((1,144)),
            'policy_pv':np.zeros((1,4,144)),'price_f':np.full((1,4,144),2.),
            'price_nodes_a':np.ones((1,145)),'price_nodes_f':np.full((1,4,145),3.)}
        frame=pd.DataFrame({'window_date':[str(date)]*144,
            'interval_start':[str(start+dt.timedelta(minutes=10*t)) for t in range(144)],
            'g_kwh':np.ones(144),'q_kwh':np.r_[np.ones(107),np.full(37,999.)],
            'soc_start_kwh':np.full(144,6000.),'price_forecast_yuan_per_kwh':np.full(144,2.),
            'pv_forecast_kw':np.zeros(144),'charge_kwh':np.zeros(144),
            'discharge_kwh':np.ones(144),'emergency_kwh':np.zeros(144)})
        config={'forecast_hours':[0,18],'price_hours':[0,6,12,18],'trade_hours':[0,18]}
        return data,frame,config
    def test_full_reconstruction_hides_future_contracts(self):
        from q4_solver_check import reconstruct_control
        data,frame,config=self.fixture();r=reconstruct_control(data,frame,config,0,0)
        np.testing.assert_array_equal(r['booked_q'],np.ones(144))
    def test_unknown_actual_right_price_not_used(self):
        from q4_solver_check import reconstruct_control
        data,frame,config=self.fixture();first=reconstruct_control(data,frame,config,0,0)
        data['price_nodes_a'][0,1:]=100000
        other=reconstruct_control(data,frame,config,0,0)
        np.testing.assert_array_equal(first['price'],other['price'])
    def test_bridge_step_rejected(self):
        from q4_solver_check import reconstruct_control
        data,frame,config=self.fixture()
        with self.assertRaises(ValueError):reconstruct_control(data,frame,config,0,143)

if __name__=='__main__':unittest.main()
