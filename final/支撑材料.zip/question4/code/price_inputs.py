"""Versioned Q4 price inputs: inherited midnight and causal XGBoost updates.

All price arrays use CNY/kWh. No multiplication by 1/6 occurs in this module.
The 144 contract intervals start D 00:10 and end D+1 00:10.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed
import argparse
import hashlib
import importlib.metadata
import json
import numpy as np
import pandas as pd
import openpyxl

from xgb_intraday import forecast_intraday

ROOT=Path(__file__).resolve().parents[1]
VINTAGES=(0,6,12,18)
GATE_SLOTS=(0,35,71,107)


def _sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read_attachment4(path: Path) -> np.ndarray:
    book=openpyxl.load_workbook(path,read_only=True,data_only=False)
    try:
        sheet=book.active
        if len(book.sheetnames)!=1 or (sheet.max_row,sheet.max_column)!=(366,145):
            raise ValueError('Attachment4 must contain 365 dates by 144 instantaneous nodes')
        rows=list(sheet.iter_rows(values_only=True))
        dates=pd.DatetimeIndex([r[0] for r in rows[1:]])
        if not dates.equals(pd.date_range('2025-01-01',periods=365)):
            raise ValueError('Price dates are not the expected complete 2025 daily sequence')
        # This source is the hash-verified original attachment, but still check
        # that its node headers run 00:10 ... 24:00 rather than interval means.
        for j,label in enumerate(rows[0][1:]):
            minutes=(label.hour*60+label.minute) if hasattr(label,'hour') else None
            if isinstance(label,str):
                text=label.replace('：',':').replace('次日','').replace('+1','').strip()
                h,m=map(int,text.split(':')[:2]);minutes=h*60+m
                if j==143 and minutes==0:minutes=1440
            if hasattr(label,'total_seconds'):minutes=label.total_seconds()/60
            if minutes!=(j+1)*10:raise ValueError(f'Unexpected instantaneous node header at column {j+2}')
        values=np.asarray([r[1:] for r in rows[1:]],dtype=float)
        if values.shape!=(365,144) or not np.isfinite(values).all():raise ValueError('Invalid actual price values')
        return values
    finally:book.close()


def extrapolate_last_node(history: np.ndarray, method: str) -> float:
    """Only the final missing Jan1 00:10 node is extrapolated, and flagged."""
    y=np.asarray(history,dtype=float).reshape(-1)
    if len(y)<6 or not np.isfinite(y[-6:]).all():raise ValueError('Need six finite historical nodes')
    if method=='hold':return float(y[-1])
    if method=='linear2':return float(2*y[-1]-y[-2])
    if method=='ols6':return float(np.polyval(np.polyfit(np.arange(6),y[-6:],1),6))
    raise ValueError('Boundary method must be hold, linear2 or ols6')


@dataclass(frozen=True)
class PriceData:
    dates: pd.DatetimeIndex
    predicted: np.ndarray
    nodes: np.ndarray
    actual: np.ndarray
    actual_nodes: np.ndarray
    raw_actual_nodes: np.ndarray
    actual_estimated: np.ndarray
    forecast_bridge: np.ndarray
    actual_bridge: np.ndarray
    known_midnight: np.ndarray
    audit: dict
    vintages: tuple=VINTAGES
    gate_slots: tuple=GATE_SLOTS

    @property
    def point_nodes(self):return self.nodes

    @property
    def startup_actual(self):return float(self.actual_bridge[0])

    @property
    def boundary_alternatives(self):return self.audit['final_boundary_alternatives']

    def day_index(self, day):
        if isinstance(day,(int,np.integer)) and not isinstance(day,bool):index=int(day)
        else:index=int(self.dates.get_indexer([pd.Timestamp(day)])[0])
        if not 0<=index<len(self.dates):raise IndexError('Price date outside experiment')
        return index

    def for_day(self, day, version_hour=0, remaining=False):
        i=self.day_index(day)
        if version_hour not in self.vintages:raise ValueError('Price version must be 0,6,12 or18')
        v=self.vintages.index(version_hour)
        return self.predicted[i,v,self.gate_slots[v]:] if remaining else self.predicted[i,v]

    def actual_with_boundary(self, method='hold'):
        out=self.actual.copy()
        out[-1,-1]=self.boundary_alternatives[method]['last_interval_price']
        return out


def load_price_data(path: Path | str = ROOT/'data/price_inputs.npz') -> PriceData:
    with np.load(path,allow_pickle=False) as z:
        keys=['predicted','nodes','actual','actual_nodes','raw_actual_nodes','actual_estimated',
              'forecast_bridge','actual_bridge','known_midnight']
        arrays={k:z[k].copy() for k in keys}
        dates=pd.DatetimeIndex(z['dates'].astype(str))
        audit=json.loads(str(z['audit_json'].item()))
    if arrays['predicted'].shape!=(334,4,144) or arrays['nodes'].shape!=(334,4,145):
        raise ValueError('Versioned price arrays have unexpected dimensions')
    for x in arrays.values():x.setflags(write=False)
    return PriceData(dates=dates,**arrays,audit=audit)


def _forecast_vintage(hour,values,config):
    predictions=[];diagnostics=[]
    for i,day in enumerate(range(31,365)):
        cutoff=day*144+hour*6
        p,d=forecast_intraday(values[:cutoff],day,hour,config)
        predictions.append(p);diagnostics.append(d)
        if (i+1)%40==0:print(f'price {hour:02d}:00: {i+1}/334 forecasts',flush=True)
    return hour,np.asarray(predictions),diagnostics


def assemble_arrays(raw: np.ndarray, midnight: np.ndarray, updates: dict) -> dict:
    """Pure time mapping: 145 inherited nodes become 144 intervals."""
    raw=np.asarray(raw,float)
    if raw.shape!=(365,144) or midnight.shape!=(334,145):raise ValueError('Wrong source shapes')
    flat=raw.ravel();nodes=np.full((334,4,145),np.nan)
    nodes[:,0]=midnight
    raw_actual_nodes=np.full((334,145),np.nan)
    midnight_actual=raw[np.arange(31,365)-1,143]
    for i,day in enumerate(range(31,365)):
        first=day*144
        end=min(first+145,len(flat))
        raw_actual_nodes[i,:end-first]=flat[first:end]
        for v,hour in enumerate(VINTAGES[1:],1):
            slot=GATE_SLOTS[v]
            nodes[i,v,slot]=flat[first+slot]  # known release-time left node
            nodes[i,v,slot+1:]=updates[hour][i]
    actual_nodes=raw_actual_nodes.copy()
    actual_nodes[-1,-1]=extrapolate_last_node(flat,'hold')
    predicted=(nodes[:,:,:-1]+nodes[:,:,1:])/2
    actual=(actual_nodes[:,:-1]+actual_nodes[:,1:])/2
    estimated=~(np.isfinite(raw_actual_nodes[:,:-1])&np.isfinite(raw_actual_nodes[:,1:]))
    bridge=(midnight_actual+midnight[:,0])/2
    actual_bridge=(midnight_actual+raw[31:,0])/2
    if not np.array_equal(nodes[:,0],midnight):raise AssertionError('Midnight node inheritance changed')
    for v,slot in enumerate(GATE_SLOTS):
        if not np.isnan(predicted[:,v,:slot]).all() or not np.isfinite(predicted[:,v,slot:]).all():
            raise AssertionError('Wrong pre/post-vintage availability')
    assert estimated.sum()==1 and estimated[-1,-1]
    return dict(predicted=predicted,nodes=nodes,actual=actual,actual_nodes=actual_nodes,
                raw_actual_nodes=raw_actual_nodes,actual_estimated=estimated,forecast_bridge=bridge,
                actual_bridge=actual_bridge,known_midnight=midnight_actual)


def build_price_inputs(data_dir: Path | str = ROOT/'data', workers: int=3, force=False) -> PriceData:
    data_dir=Path(data_dir);data_dir.mkdir(parents=True,exist_ok=True)
    sources={name:data_dir/name for name in ('attachment4.xlsx','xgboost_midnight_predictions.npz','xgboost_midnight_summary.json')}
    summary=json.loads(sources['xgboost_midnight_summary.json'].read_text())
    if summary['family']!='XGBoost' or not summary.get('complete'):raise ValueError('Completed XGBoost midnight run required')
    config=summary['config']
    hashes={name:_sha(path) for name,path in sources.items()}
    if hashes['attachment4.xlsx']!=summary['source_sha256']:raise ValueError('Actual input differs from source used for frozen midnight forecasts')
    core_hashes={name:_sha(Path(__file__).parent/name) for name in ('price_inputs.py','xgb_intraday.py')}
    spec={'sources':hashes,'core':core_hashes,'config':config,'xgboost_version':importlib.metadata.version('xgboost')}
    signature=hashlib.sha256(json.dumps(spec,sort_keys=True).encode()).hexdigest()
    output=data_dir/'price_inputs.npz'
    if output.exists() and not force:
        old=load_price_data(output)
        if old.audit.get('signature')!=signature:raise ValueError('Cached price inputs use different sources/code; use a new data directory or explicit force rebuild')
        return old
    raw=read_attachment4(sources['attachment4.xlsx']);flat=raw.ravel()
    with np.load(sources['xgboost_midnight_predictions.npz'],allow_pickle=False) as z:
        midnight=z['predictions'].copy();origins=z['origins'].copy();old_truth=z['actual'].copy()
    if not np.array_equal(origins,np.arange(31,365)) or midnight.shape!=(334,145) or not np.isfinite(midnight).all():
        raise ValueError('Midnight predictions must have all 334 requested dates and 145 finite nodes')
    if not np.array_equal(old_truth[:,:144],raw[31:]):raise ValueError('Frozen midnight truth and original attachment disagree')
    updates={};fit_diagnostics={}
    with ProcessPoolExecutor(max_workers=min(3,workers)) as pool:
        tasks=[pool.submit(_forecast_vintage,hour,flat,config) for hour in (6,12,18)]
        for task in as_completed(tasks):
            hour,pred,diag=task.result();updates[hour]=pred;fit_diagnostics[str(hour)]=diag
    arrays=assemble_arrays(raw,midnight,updates)
    boundary={method:{'last_node_price':extrapolate_last_node(flat,method),
                      'last_interval_price':(flat[-1]+extrapolate_last_node(flat,method))/2}
              for method in ('hold','linear2','ols6')}
    comparison=[]
    for v,hour in enumerate(VINTAGES[1:],1):
        slot=GATE_SLOTS[v]
        truth=arrays['raw_actual_nodes'][:,slot+1:]
        new=arrays['nodes'][:,v,slot+1:];old=midnight[:,slot+1:]
        good=np.isfinite(truth)
        comparison.append({'issue_hour':hour,'scored_future_nodes':int(good.sum()),
             'target_note':'same target right nodes after issue; known issue node excluded; absent final actual excluded',
             'updated_MAE':float(np.abs(new[good]-truth[good]).mean()),
             'midnight_MAE_same_targets':float(np.abs(old[good]-truth[good]).mean()),
             'updated_bias':float((new[good]-truth[good]).mean())})
    finite_nodes=arrays['nodes'][np.isfinite(arrays['nodes'])]
    audit={'signature':signature,'provenance':spec,'complete':True,
       'quantity':'interval price CNY/kWh formed from instantaneous node endpoint average',
       'price_times_1_over_6':False,'forecast_origins':'2025-02-01 through 2025-12-31 at 0/6/12/18',
       'contract_window':'D00:10 through D+1 00:10, 144 ten-minute intervals',
       'vintages':list(VINTAGES),'gate_slots':list(GATE_SLOTS),'array_shape':[334,4,144],
       'midnight_exact_inheritance':True,'midnight_retuned_or_refit':False,
       'intraday_method':'same-hour direct multi-horizon XGBoost; frozen midnight hyperparameters; daily refit using only observed labels',
       'new_intraday_hyperparameters_selected_on_test':False,
       'minimum_price_node_all_versions_including_known_left':float(finite_nodes.min()),
       'nonpositive_price_nodes':int((finite_nodes<=0).sum()),'negative_prices_clipped':False,
       'estimated_actual_intervals':int(arrays['actual_estimated'].sum()),
       'missing_actual_right_node':'2026-01-01 00:10; default hold; still flagged estimated',
       'final_boundary_alternatives':boundary,
       'midnight_bridge':'mean of currently known D00:00 actual and inherited prediction D00:10',
       'startup_actual_interval_price':float(arrays['actual_bridge'][0]),
       'intraday_fits':1002,'fit_seconds':sum(d['fit_seconds'] for ds in fit_diagnostics.values() for d in ds),
       'forecast_diagnostic_comparisons':comparison,
       'diagnostic_comparison_used_to_retune':False,
       'scope_limit':'Intraday same-hour forecasters are an explicit no-retuning extension; midnight validation did not validate these new issue-hour designs.'}
    dates=pd.date_range('2025-02-01',periods=334).strftime('%Y-%m-%d').to_numpy(dtype='U10')
    temp=data_dir/'price_inputs.pending.npz'
    np.savez_compressed(temp,dates=dates,**arrays,audit_json=json.dumps(audit,ensure_ascii=False))
    temp.replace(output)
    (data_dir/'price_inputs_audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2))
    (data_dir/'intraday_price_fit_diagnostics.json').write_text(json.dumps(fit_diagnostics,ensure_ascii=False,indent=2))
    return load_price_data(output)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--data-dir',type=Path,default=ROOT/'data');p.add_argument('--workers',type=int,default=3);p.add_argument('--force',action='store_true')
    a=p.parse_args()
    if a.workers<1:p.error('workers must be positive')
    data=build_price_inputs(a.data_dir,a.workers,a.force)
    print(json.dumps(data.audit,ensure_ascii=False,indent=2))
