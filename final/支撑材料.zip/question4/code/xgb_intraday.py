"""Price-only XGBoost updates at 06/12/18 with frozen Q4 hyperparameters.

Each update learns from previous forecast-origin days at the SAME issue hour.
Every historical feature is reconstructed from its own information prefix.
The target is only the remaining nodes through next-day 00:10.  This is a
declared extension of the midnight forecaster, not a newly tuned model.
"""
from __future__ import annotations

import time
import numpy as np
import pandas as pd

FEATURE_NAMES = ['slot','horizon','target_weekday','sin1','cos1','sin2','cos2','sin3','cos3',
 'same_clock_latest','target_lag2d','target_lag3d','target_lag7d','mean_last3_same_clock',
 'mean_last7_same_clock','std_last7_same_clock','latest_minus_mean7','known_issue_price',
 'last6_mean','last18_mean','previous_24h_mean','previous_24h_std','previous_24h_min',
 'previous_24h_max','last3day_mean','last7day_mean','issue_change_1d','lag1_unavailable']


def features_at_issue(history: np.ndarray, day: int, hour: int,
                      start_date: str = '2025-01-01') -> tuple[np.ndarray,np.ndarray,np.ndarray]:
    """Features for future right nodes; history beyond the issue is ignored.

    Raw observation index k is at Jan1 00:10 + k*10min.  Therefore a release
    at day*24h+hour has exactly day*144+hour*6 available observations.
    For midnight only, this reduces numerically to the previous Q4 feature
    contract. Midnight predictions themselves must still be inherited.
    """
    if type(day) is not int or day < 7 or hour not in (0,6,12,18):
        raise ValueError('Need >=7 historical days and a 0/6/12/18 issue hour')
    cutoff = day*144 + hour*6
    hist = np.asarray(history, dtype=float).reshape(-1)[:cutoff]
    if len(hist) != cutoff or not np.isfinite(hist).all():
        raise ValueError('History does not contain the complete known issue-time prefix')
    steps = 145-hour*6
    h = np.arange(1,steps+1)
    targets = cutoff+h-1
    slot = targets%144
    # Even lead145 at midnight uses a two-day-lag node if its one-day-lag
    # target is not observed yet. No negative or future indexing is allowed.
    cycles = (h+143)//144
    latest = targets-cycles*144
    previous_indices = latest[:,None]-np.arange(7)[None,:]*144
    assert previous_indices.min()>=0 and previous_indices.max()<cutoff
    previous = hist[previous_indices]
    lag2 = hist[targets-288];lag3=hist[targets-432];lag7=hist[targets-1008]
    phase = 2*np.pi*((targets+1)%144)/144
    target_dates = pd.Timestamp(start_date)+pd.to_timedelta((targets+1)*10,unit='min')
    repeated=lambda value:np.full(steps,float(value))
    features=np.column_stack([slot,h,np.asarray(target_dates.dayofweek),np.sin(phase),np.cos(phase),
       np.sin(2*phase),np.cos(2*phase),np.sin(3*phase),np.cos(3*phase),
       previous[:,0],lag2,lag3,lag7,previous[:,:3].mean(axis=1),previous.mean(axis=1),
       previous.std(axis=1),previous[:,0]-previous.mean(axis=1),repeated(hist[-1]),
       repeated(hist[-6:].mean()),repeated(hist[-18:].mean()),repeated(hist[-144:].mean()),
       repeated(hist[-144:].std()),repeated(hist[-144:].min()),repeated(hist[-144:].max()),
       repeated(hist[-432:].mean()),repeated(hist[-1008:].mean()),repeated(hist[-1]-hist[-145]),
       targets-144>=cutoff])
    assert features.shape==(steps,len(FEATURE_NAMES))
    return features,lag7,targets


def training_arrays_at_issue(history: np.ndarray, day: int, hour: int,
                              window_days: int | None = 28):
    if hour not in (0,6,12,18): raise ValueError('Invalid issue hour')
    cutoff=day*144+hour*6
    hist=np.asarray(history,float).reshape(-1)[:cutoff]
    if len(hist)!=cutoff or not np.isfinite(hist).all():raise ValueError('Invalid current history cutoff')
    if window_days is not None and (type(window_days) is not int or window_days<7):
        raise ValueError('Training window must be >=7 origin days')
    first=max(7,0 if window_days is None else day-window_days)
    X=[];y=[];anchors=[];label_indices=[];origin_days=[]
    for origin in range(first,day):
        xx,aa,tt=features_at_issue(hist,origin,hour)
        keep=tt<cutoff
        X.append(xx[keep]);y.append(hist[tt[keep]]);anchors.append(aa[keep]);label_indices.extend(tt[keep]);origin_days.extend([origin]*int(keep.sum()))
    if not X:raise ValueError('No completed historical same-hour training labels')
    diagnostics={'training_rows':sum(len(a) for a in y),'first_training_origin_day':first,
       'last_training_origin_day':day-1,'same_issue_hour':hour,
       'max_label_index':int(max(label_indices)),'cutoff_last_index':cutoff-1,
       'last_training_feature_source_index':(day-1)*144+hour*6-1,
       'window_interpretation':'previous W same-hour forecast-origin days; each historical feature uses its own prefix',
       'label_indices':np.array(label_indices,dtype=int),'origin_days':np.array(origin_days,dtype=int)}
    return np.vstack(X),np.concatenate(y),np.concatenate(anchors),diagnostics


def forecast_intraday(history: np.ndarray, day: int, hour: int, config: dict):
    """Return 109/73/37 predicted future right nodes; never clip prices."""
    import xgboost as xgb
    if hour not in (6,12,18):raise ValueError('Midnight must use the frozen supplied forecasts')
    cfg=dict(config)
    if cfg.get('family')!='XGBoost':raise ValueError('Frozen XGBoost configuration required')
    t0=time.perf_counter()
    X,y,anchor,diag=training_arrays_at_issue(history,day,hour,cfg.get('window_days',28))
    Xp,ap,_=features_at_issue(history,day,hour)
    target=cfg.get('target','level')
    if target not in ('level','weekly_residual'):raise ValueError('Unknown frozen target transform')
    fit_y=y-anchor if target=='weekly_residual' else y
    model=xgb.XGBRegressor(n_estimators=cfg.get('n_estimators',200),learning_rate=cfg.get('learning_rate',.04),
       reg_lambda=cfg.get('reg_lambda',5.),reg_alpha=cfg.get('reg_alpha',0.),random_state=cfg.get('seed',20260912),n_jobs=1,
       objective='reg:squarederror',tree_method='hist',max_bin=128,max_depth=cfg.get('max_depth',3),
       min_child_weight=cfg.get('min_child_weight',20),subsample=.9,colsample_bytree=.9)
    model.fit(X,fit_y)
    prediction=np.asarray(model.predict(Xp),dtype=float)
    if target=='weekly_residual':prediction+=ap
    if not np.isfinite(prediction).all():raise RuntimeError('Nonfinite intraday price forecast')
    diag.pop('label_indices');diag.pop('origin_days')
    diag.update(config=cfg,day_index=day,issue_hour=hour,forecast_nodes=len(prediction),
       fit_seconds=time.perf_counter()-t0,negative_or_zero_predictions=int((prediction<=0).sum()),
       minimum_prediction=float(prediction.min()),clipped=False,hyperparameters_retuned=False,
       current_feature_source_last_index=day*144+hour*6-1)
    return prediction,diag
