"""Combine unchanged Q2/Q3 physical inputs with frozen XGBoost price vintages."""
from pathlib import Path
import json
import numpy as np
from openpyxl import load_workbook
import pandas as pd
from physical_io import load_inputs as load_physical, interval_header, numeric_array, sha
from price_inputs import load_price_data
from q4_optimizer import ETA_C

ROOT=Path(__file__).resolve().parents[1]


def load_inputs(data_dir=ROOT/'data'):
    data_dir=Path(data_dir)
    data=load_physical(data_dir)
    book=load_workbook(data_dir/'load_forecasts.xlsx',read_only=True,data_only=True)
    try:
        rows=list(book['自适应加权_光伏'].values)
    finally:
        book.close()
    if [interval_header(x) for x in rows[0][1:]] != [(m,m+10) for m in range(10,1441,10)]:
        raise ValueError('Q2 PV must contain exactly 144 interval means')
    data['q2_pv_f']=numeric_array([r[1:] for r in rows[1:]],(334,144),'Q2 PV forecast')
    prices=load_price_data(data_dir/'price_inputs.npz')
    if [str(x)[:10] for x in prices.dates] != [str(x) for x in data['dates']]:
        raise ValueError('Price dates disagree with power forecast dates')
    data['price_f']=prices.predicted
    data['price_nodes_f']=prices.nodes
    data['price_a']=prices.actual
    data['price_nodes_a']=prices.actual_nodes
    data['price_estimated']=prices.actual_estimated
    data['price_bundle']=prices
    book=load_workbook(data_dir/'attachment4.xlsx',read_only=True,data_only=True)
    try:
        raw=np.asarray([row[1:] for row in list(book.active.values)[1:]],float).reshape(-1)
    finally:
        book.close()
    stamps=pd.date_range('2025-01-01 00:10',periods=len(raw),freq='10min')
    night=(stamps[:-1].month==1)&(stamps[:-1].hour<6)&(stamps[1:]<pd.Timestamp('2025-02-01'))
    january_night=(raw[:-1]+raw[1:])[night]/2
    data['inventory_value']=float(np.median(january_night)/ETA_C)
    first=31*144
    data['startup_price_actual']=float((raw[first-1]+raw[first])/2)
    data['midnight_observed_price']=raw[np.arange(31,365)*144-1].copy()
    data['bridge_price_forecast']=(data['midnight_observed_price']+data['price_nodes_f'][:,0,0])/2
    # This file belongs to price forecasting provenance and never determines
    # a dispatch hyperparameter from test outcomes.
    price_audit=json.loads((data_dir/'price_inputs_audit.json').read_text())
    data['metadata']['price']=price_audit
    data['metadata']['source_sha256'].update({p.name:sha(p) for p in data_dir.glob('*') if p.is_file()})
    data['metadata']['q4_settlement']='Quantity contracted in advance; price not locked. All fees use delivery interval actual endpoint-mean price, with cancellation refund and 50% penalty.'
    data['metadata']['common_inventory_value']={'value':data['inventory_value'],
        'basis':'median of completely observed January intervals starting 00:00..05:50, divided by 0.9',
        'included_intervals':int(night.sum()),'unknown_Jan1_midnight_not_filled':True,
        'valuation_fixed_across_strategies_and_terminal_weight_sensitivity':True}
    del data['price']  # Prevent accidental reuse of the Q3 fixed tariff.
    return data


def selected_pv(data,branch,pv_source='supplied'):
    if branch=='4-2' and pv_source!='q3_all':
        return np.repeat(data['q2_pv_f'][:,None,:],4,axis=1)
    return data['pv_f'] if pv_source!='linear' else data['pv_linear_f']
