"""Additional history-cap verification where all 56 old paths are available.

The original Feb25--Mar10 sensitivity cannot fill a 56-window residual cap.
This supplementary Aug1--14 experiment checks that limitation without changing
the frozen branch choices, price model or any original sensitivity run.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
from pathlib import Path

from q4_audit import audit_selection
from q4_study import run_jobs

ROOT=Path(__file__).resolve().parents[1]
START_DAY=(dt.date(2025,8,1)-dt.date(2025,2,1)).days


def history_jobs(selection):
    jobs=[]
    for branch in ('4-2','4-3'):
        chosen=selection['branch_selections'][branch]
        for cap in (14,28,56):
            jobs.append({'branch':branch,'trade_hours':tuple(chosen['trade_hours']),
                'start_day':START_DAY,'days':14,
                'config':{'price_mode':chosen['price_mode'],'history_days':cap,'initial_soc':6000.},
                'name':'Q'+branch.replace('-','')+f'_aug_history{cap}'})
    return jobs


def run_history_check(data_dir=ROOT/'data',results_dir=ROOT/'results/final',workers=2):
    data_dir=Path(data_dir).resolve();results_dir=Path(results_dir).resolve()
    if not isinstance(workers,int) or workers<1:raise ValueError('workers must be positive')
    selected_path=results_dir/'selection.json';before=selected_path.read_bytes()
    selection=json.loads(before)
    audit=audit_selection(results_dir)
    if not audit.get('present') or not audit.get('passed'):raise RuntimeError('Frozen development selection not verified')
    out=results_dir/'history_check';out.mkdir(parents=True,exist_ok=True)
    manifest={'reason':'The original Feb25--Mar10 14-window sensitivity cannot fill a residual-history cap of 56; add a mature-history verification.',
        'period':'2025-08-01..2025-08-14, fourteen shifted contract windows',
        'start_day':START_DAY,'days':14,'history_caps':[14,28,56],'initial_soc_kwh':6000.,
        'same_independent_initial_state_and_end_rule':True,
        'posthoc_scope_correction':True,'used_for_reselection':False,
        'frozen_branch_choices':{b:selection['branch_selections'][b]['strategy'] for b in ('4-2','4-3')},
        'interpretation':'Caps denote maximum completed residual paths; event logs certify actual realized history counts. This supplements, not replaces, original sensitivities.'}
    (out/'scope.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    results=run_jobs(data_dir,out,history_jobs(selection),workers)
    if selected_path.read_bytes()!=before:raise RuntimeError('Frozen selection changed during supplementary experiment')
    return {'complete':True,'runs':results,'scope':manifest,'selection_unchanged':True}


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--data',type=Path,default=ROOT/'data')
    p.add_argument('--results',type=Path,default=ROOT/'results/final');p.add_argument('--workers',type=int,default=2)
    a=p.parse_args();r=run_history_check(a.data,a.results,a.workers)
    print(json.dumps({'complete':r['complete'],'runs':len(r['runs']),'selection_unchanged':r['selection_unchanged']},ensure_ascii=False))
