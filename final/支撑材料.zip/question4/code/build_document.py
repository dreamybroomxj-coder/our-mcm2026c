"""Build an editable Q4 stage report; no numerical optimization is performed."""
from pathlib import Path
import argparse,hashlib,json,os,shutil,subprocess,tempfile,zipfile
from xml.etree import ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def executable(name,provided=None):
    value=provided or shutil.which(name)
    if value:return str(value)
    candidates={'pandoc':[Path('/opt/anaconda3/bin/pandoc')],
        'soffice':[Path.home()/'.cache/codex-runtimes/codex-primary-runtime/dependencies/bin/override/soffice',
            Path('/Applications/LibreOffice.app/Contents/MacOS/soffice')]}
    for candidate in candidates.get(name,[]):
        if candidate.exists():return str(candidate)
    raise RuntimeError(f'Install {name}, or provide its executable path')


def set_font(style,name,size):
    from docx.shared import Pt
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    style.font.name=name;style.font.size=Pt(size)
    prop=style.element.get_or_add_rPr()
    fonts=prop.find(qn('w:rFonts'))
    if fonts is None:fonts=OxmlElement('w:rFonts');prop.append(fonts)
    for slot in ('ascii','hAnsi','eastAsia'):fonts.set(qn('w:'+slot),name)


def build_document(results_dir=ROOT/'results/final',pandoc=None,soffice=None):
    from docx import Document
    from docx.shared import Cm,Pt
    from docx.enum.style import WD_STYLE_TYPE
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    result=Path(results_dir).resolve();build=result/'document_build';build.mkdir(parents=True,exist_ok=True)
    method=ROOT/'第四问_模型与操作方法.md'
    conclusions=result/'reports/第四问_结果与结论.md'
    for p in (method,conclusions):
        if not p.exists():raise FileNotFoundError(f'Final narrative required: {p}')
    figures=[('01_selected_fee_components.png','图1  两主策略的费用组成；跨分支同时含PV信息差异。'),
        ('03_eight_schedule_development_holdout.png','图2  八组合的开发与留出表现；主策略由开发期冻结。'),
        ('05_point_joint_paired_difference.png','图3  联合价格减点价格的累计实际费用差；两边均保留负载/PV情景。')]
    sources=[method,conclusions]+[result/'figures'/name for name,_ in figures]
    for p in sources:
        if not p.exists():raise FileNotFoundError(p)
    text='---\ntitle: "第四问：波动电价下的购电与储能调度"\nsubtitle: "XGBoost · 共享合同MILP · 电池MPC · 费用比较与填表"\n---\n\n'
    text+='本说明是第四问的专项计算报告，配套完整源代码、两份原结果模板和四个指定自然日表。它不是整份竞赛论文的替代稿。\n\n'
    text+='# 第一部分　模型与复现方法\n\n'+method.read_text().split('\n',1)[1].strip()
    text+='\n\n# 第二部分　结果与评价\n\n'+conclusions.read_text().split('\n',1)[1].strip()
    text+='\n\n# 第三部分　主要比较图\n\n全部9幅PNG/PDF及作图数据保存在figures目录，这里选3幅展示。图中的价格是规划或结算的区间均价；原始XGBoost仍输出瞬时节点。\n\n'
    for name,caption in figures:
        text+=f'![{caption}]({(result/"figures"/name).as_posix()}){{width=16cm}}\n\n'
    source=build/'第四问_排版源.md';source.write_text(text,encoding='utf-8')
    template=build/'A4参考样式.docx';d=Document()
    for section in d.sections:
        section.page_width=Cm(21);section.page_height=Cm(29.7)
        section.top_margin=section.bottom_margin=Cm(2)
        section.left_margin=section.right_margin=Cm(2.2)
        section.header_distance=section.footer_distance=Cm(.8)
        section.header.paragraphs[0].text='第四问  |  波动电价下的购电与储能调度'
        set_font(d.styles['Header'],'Heiti SC',8)
        f=section.footer.paragraphs[0];f.alignment=1
        field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');f._p.append(field)
    for name in ('Normal','Body Text','First Paragraph','Compact'):
        if name not in d.styles:d.styles.add_style(name,WD_STYLE_TYPE.PARAGRAPH)
        set_font(d.styles[name],'Songti SC',10.5)
        d.styles[name].paragraph_format.line_spacing=1.3
        d.styles[name].paragraph_format.space_after=Pt(5)
    if 'Table' not in d.styles:d.styles.add_style('Table',WD_STYLE_TYPE.TABLE)
    set_font(d.styles['Table'],'Songti SC',8.5)
    set_font(d.styles['Title'],'Heiti SC',22)
    for n,size in ((1,16),(2,13),(3,11)):
        set_font(d.styles[f'Heading {n}'],'Heiti SC',size)
        d.styles[f'Heading {n}'].paragraph_format.keep_with_next=True
    d.save(template)
    intermediate=build/'converted.docx';docx=result/'reports/第四问_模型与结果说明.docx'
    command=[executable('pandoc',pandoc),str(source),'-f','markdown+tex_math_dollars+raw_attribute',
        '--reference-doc',str(template),'-o',str(intermediate)]
    conversion=subprocess.run(command,capture_output=True,text=True,check=True)
    if conversion.stderr.strip():raise RuntimeError('Review Pandoc warnings before release: '+conversion.stderr)
    d=Document(intermediate)
    # Pandoc's default zoom can omit the required OOXML percentage attribute.
    zoom=d.settings.element.find(qn('w:zoom'))
    if zoom is not None and zoom.get(qn('w:percent')) is None:
        zoom.set(qn('w:percent'),'100')
    from docx.enum.table import WD_TABLE_ALIGNMENT
    for table in d.tables:
        # Explicit cell widths prevent Pandoc tables collapsing in LibreOffice.
        table.autofit=False;table.alignment=WD_TABLE_ALIGNMENT.CENTER
        count=len(table.columns)
        header=[cell.text for cell in table.rows[0].cells]
        weights=[1.0]*count
        if count==3 and header[0].startswith('对比'):weights=[2.,1.,1.3]
        elif count==3 and header[0].startswith('对照'):weights=[2.4,1.,1.]
        elif count==5 and header[1]=='变体':weights=[.5,1.7,1.1,1.4,1.1]
        elif count==5 and header[0]=='策略':weights=[1.5,1.3,1.,1.3,.9]
        elif count==5 and header[0]=='分支':weights=[1.1,1.2,1.4,.9,1.]
        total=9411
        widths=[round(total*w/sum(weights)) for w in weights]
        widths[-1]=total-sum(widths[:-1])
        prop=table._tbl.tblPr
        width=prop.find(qn('w:tblW'));width.set(qn('w:type'),'dxa');width.set(qn('w:w'),str(total))
        borders=OxmlElement('w:tblBorders')
        for side in ('top','left','bottom','right','insideH','insideV'):
            edge=OxmlElement('w:'+side);edge.set(qn('w:val'),'single' if side in ('top','bottom') else 'nil')
            edge.set(qn('w:sz'),'8');edge.set(qn('w:color'),'415E75');borders.append(edge)
        prop.insert_element_before(borders,'w:shd','w:tblLayout','w:tblCellMar','w:tblLook')
        for column,w in zip(table.columns,widths):column.width=Cm(w/567.)
        for i,row in enumerate(table.rows):
            prop=row._tr.get_or_add_trPr();prop.append(OxmlElement('w:cantSplit'))
            if i==0 and prop.find(qn('w:tblHeader')) is None:prop.append(OxmlElement('w:tblHeader'))
            for cell,w in zip(row.cells,widths):
                cell.width=Cm(w/567.)
                if i==0:
                    cb=OxmlElement('w:tcBorders');edge=OxmlElement('w:bottom')
                    edge.set(qn('w:val'),'single');edge.set(qn('w:sz'),'4');edge.set(qn('w:color'),'415E75')
                    cb.append(edge);cell._tc.get_or_add_tcPr().append(cb)
                for para in cell.paragraphs:
                    para.paragraph_format.space_after=Pt(3);para.paragraph_format.space_before=Pt(3)
                    para.paragraph_format.line_spacing=1.1
                    if len(table.rows)<=10 and i<len(table.rows)-1:
                        para.paragraph_format.keep_with_next=True
                    for run in para.runs:
                        run.font.size=Pt(8.5)
                        if i==0:run.bold=True
    paragraphs=d.paragraphs
    for j,para in enumerate(paragraphs):
        if para.style.name=='Caption':para.paragraph_format.keep_with_next=False
        if para._p.findall('.//'+qn('w:drawing')):
            para.paragraph_format.keep_with_next=True
        if (j+1<len(paragraphs) and para._p.findall('.//'+qn('m:oMath'))
                and paragraphs[j+1]._p.findall('.//'+qn('m:oMath'))):
            para.paragraph_format.keep_with_next=True
    d.save(docx)
    env=os.environ.copy()
    # Local font discovery for headless LibreOffice; no fonts are downloaded.
    if Path('/System/Library/Fonts').exists():
        fontconfig=build/'fonts.conf';cache=build/'fontcache';cache.mkdir(exist_ok=True)
        fontconfig.write_text('<?xml version="1.0"?><!DOCTYPE fontconfig SYSTEM "urn:fontconfig:fonts.dtd"><fontconfig>'
            '<dir>/System/Library/Fonts</dir><dir>/System/Library/Fonts/Supplemental</dir><dir>/Library/Fonts</dir>'
            f'<cachedir>{cache}</cachedir><alias><family>Cambria Math</family><prefer><family>STIX Two Math</family></prefer></alias></fontconfig>')
        env['FONTCONFIG_FILE']=str(fontconfig)
    with tempfile.TemporaryDirectory(prefix='q4_doc_') as profile:
        render=subprocess.run([executable('soffice',soffice),'-env:UserInstallation='+Path(profile).as_uri(),
            '--headless','--convert-to','pdf','--outdir',str(docx.parent),str(docx)],
            capture_output=True,text=True,env=env,timeout=60,check=True)
    pdf=docx.with_suffix('.pdf')
    if not pdf.exists():raise RuntimeError('PDF renderer did not create the expected file')
    with zipfile.ZipFile(docx) as z:
        root=ET.fromstring(z.read('word/document.xml'))
        ns={'m':'http://schemas.openxmlformats.org/officeDocument/2006/math','w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
        counts={'native_formulas':len(root.findall('.//m:oMath',ns)),
            'tables':len(root.findall('.//w:tbl',ns)),
            'figures':len([x for x in z.namelist() if x.startswith('word/media/')])}
        if counts['native_formulas']<6 or counts['figures']!=3:raise RuntimeError('Document object count mismatch')
    manifest={'complete':True,'scope':'Q4 stage report, not full contest manuscript',
        'sources':{(str(x.relative_to(ROOT)) if x.is_relative_to(ROOT) else str(x)):sha(x) for x in sources},
        'source_markdown_sha256':sha(source),'template_sha256':sha(template),
        'pandoc_output_sha256':sha(intermediate),'docx_sha256':sha(docx),'pdf_sha256':sha(pdf),
        'counts':counts,'presentation_changes':['A4 Chinese styles','explicit table/grid/cell widths','three-line tables','8.5pt repeated-header non-splitting table rows','valid paragraph-level page field','required zoom percentage'],
        'numerical_outputs_modified':False,'pandoc_stderr':conversion.stderr,'render_stdout':render.stdout,
        'visual_review_required':True}
    (docx.parent/'文稿生成记录.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    return manifest


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--results',type=Path,default=ROOT/'results/final')
    p.add_argument('--pandoc');p.add_argument('--soffice');a=p.parse_args()
    print(json.dumps(build_document(a.results,a.pandoc,a.soffice),ensure_ascii=False,indent=2))
