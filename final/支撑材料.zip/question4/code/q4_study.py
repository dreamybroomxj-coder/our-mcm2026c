"""Predeclared calibration, frozen-choice main comparisons and sensitivities."""
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
import argparse,json
import pandas as pd
from q4_runner import ROOT,SCHEDULES,run_strategy,dump,signature


def strategy_name(branch,mode,schedule):
    return 'Q'+branch.replace('-','')+'_'+mode+'_H'+'_'.join(map(str,schedule))


def jobs_for_calibration():
    jobs=[]
    for branch,schedules in [('4-2',[(0,)]),('4-3',SCHEDULES)]:
        for mode in ('point','joint'):
            for schedule in schedules:
                jobs.append(dict(branch=branch,trade_hours=schedule,config={'price_mode':mode},
                    name=strategy_name(branch,mode,schedule),days=24))
    return jobs


def run_jobs(data_dir,out_dir,jobs,workers):
    out_dir=Path(out_dir);out_dir.mkdir(parents=True,exist_ok=True)
    dump(out_dir/'design.json',{'jobs':jobs,'workers':workers})
    results=[]
    with ProcessPoolExecutor(max_workers=min(workers,len(jobs))) as pool:
        futures={pool.submit(run_strategy,data_dir,out_dir,**job):job for job in jobs}
        for future in as_completed(futures):
            result=future.result();results.append(result)
            print('Finished',result['strategy'],f"cash={result['cash_cost_yuan']:.4f}",flush=True)
    dump(out_dir/'comparison.json',results)
    return results


def freeze(results_dir,data_dir=ROOT/'data'):
    results_dir=Path(results_dir);records=[]
    for job in jobs_for_calibration():
        path=results_dir/'calibration'/job['name']
        summary=json.loads((path/'summary.json').read_text())
        if not summary['complete']:raise RuntimeError('Incomplete calibration')
        if summary['run_signature']!=signature(data_dir,summary['config']):
            raise RuntimeError('Calibration input/core/config signature changed; rerun in a new output directory')
        daily=pd.read_csv(path/'daily.csv')
        development=daily[daily.window_date.between('2025-02-17','2025-02-23')]
        if len(development)!=7:raise ValueError('Calibration must include seven completely realized windows')
        records.append(dict(strategy=job['name'],branch=job['branch'],price_mode=job['config']['price_mode'],
            trade_hours=list(job['trade_hours']),score=float(development.inventory_adjusted_cost_yuan.sum()),
            cash=float(development.cash_cost_yuan.sum()),run_signature=summary['run_signature']))
    selected={branch:min([r for r in records if r['branch']==branch],key=lambda r:(r['score'],r['strategy']))
              for branch in ('4-2','4-3')}
    payload=dict(freeze_time='2025-02-25T00:00:00',development_windows='2025-02-17..2025-02-23',
        excluded_last_unrealized_window='2025-02-24 ends at 2025-02-25 00:10',
        test_windows='2025-02-25..2025-12-31',selected_q42=selected['4-2']['strategy'],
        selected_q43=selected['4-3']['strategy'],branch_selections=selected,development=records,
        price_forecaster='XGBoost explicitly selected by user; midnight predictions reused unchanged',
        score='sum(cash - fixed January inventory value * state change)',
        model_or_schedule_reselection_from_test=False)
    dump(results_dir/'selection.json',payload)
    return payload


def main_jobs(selection):
    mode=selection['branch_selections']['4-3']['price_mode']
    chosen_schedule=tuple(selection['branch_selections']['4-3']['trade_hours'])
    other='point' if mode=='joint' else 'joint'
    jobs=[dict(branch='4-2',trade_hours=(0,),config={'price_mode':m},name=strategy_name('4-2',m,(0,)))
          for m in ('point','joint')]
    jobs += [dict(branch='4-3',trade_hours=s,config={'price_mode':mode},name=strategy_name('4-3',mode,s)) for s in SCHEDULES]
    jobs += [dict(branch='4-3',trade_hours=chosen_schedule,config={'price_mode':other},name=strategy_name('4-3',other,chosen_schedule))]
    jobs += [dict(branch='4-2',trade_hours=(0,),forecast_hours=chosen_schedule,
        config={'price_mode':mode,'pv_source':'q3_all'},name='Q42_matched_Q43_PV')]
    return jobs


def sensitivity_jobs(selection):
    variants=[('reference',{}),('history14',{'history_days':14}),('history56',{'history_days':56}),
        ('scenes4',{'scenarios':4}),('scenes16',{'scenarios':16}),
        ('terminal_half',{'terminal_multiplier':.5}),('terminal_double',{'terminal_multiplier':2.}),
        ('seed13',{'seed':20260913}),('seed14',{'seed':20260914}),
        ('price_midnight_only',{'price_hours':[0]}),('greedy',{'controller':'greedy'}),
        ('initial1200',{'initial_soc':1200.}),('initial10800',{'initial_soc':10800.}),
        ('joint_mean',{'price_mode':'mean'}),('joint_shuffled',{'price_mode':'shuffled'})]
    jobs=[]
    for branch in ('4-2','4-3'):
        chosen=selection['branch_selections'][branch]
        for label,change in variants:
            jobs.append(dict(branch=branch,trade_hours=tuple(chosen['trade_hours']),start_day=24,days=14,
                config={'price_mode':chosen['price_mode'],**change},name='Q'+branch.replace('-','')+'_'+label))
        if chosen['price_mode']=='point':
            jobs.append(dict(branch=branch,trade_hours=tuple(chosen['trade_hours']),start_day=24,days=14,
                config={'price_mode':'joint'},name='Q'+branch.replace('-','')+'_joint_reference'))
    return jobs


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--stage',choices=('calibration','freeze','main','sensitivity'),required=True)
    p.add_argument('--data',type=Path,default=ROOT/'data');p.add_argument('--out',type=Path,default=ROOT/'results')
    p.add_argument('--workers',type=int,default=6);a=p.parse_args()
    if a.workers<1:p.error('workers must be positive')
    if a.stage=='calibration':run_jobs(a.data,a.out/'calibration',jobs_for_calibration(),a.workers)
    elif a.stage=='freeze':print(json.dumps(freeze(a.out,a.data),ensure_ascii=False,indent=2))
    else:
        selection=json.loads((a.out/'selection.json').read_text())
        verified=freeze(a.out,a.data)
        if (selection['selected_q42'],selection['selected_q43'])!=(verified['selected_q42'],verified['selected_q43']):
            raise RuntimeError('Saved selection differs from calibration')
        jobs=main_jobs(selection) if a.stage=='main' else sensitivity_jobs(selection)
        run_jobs(a.data,a.out/('main' if a.stage=='main' else 'sensitivity'),jobs,a.workers)
