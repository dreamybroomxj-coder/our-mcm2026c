"""Verify native formulas, table/media objects, PDF bounds and result values."""
from pathlib import Path
import argparse,hashlib,json,re,subprocess,shutil,zipfile
from xml.etree import ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def verify_document(results_dir=ROOT/'results/final',render=False,visual_reviewed=False):
    import pdfplumber
    result=Path(results_dir).resolve();reports=result/'reports'
    docx=reports/'第四问_模型与结果说明.docx';pdf=docx.with_suffix('.pdf')
    build=result/'document_build';origin=json.loads((reports/'文稿生成记录.json').read_text())
    if sha(docx)!=origin['docx_sha256'] or sha(pdf)!=origin['pdf_sha256']:raise ValueError('Document source chain changed')
    for filename,expected in origin['sources'].items():
        source=Path(filename)
        if not source.is_absolute():source=ROOT/source
        if not source.exists() or sha(source)!=expected:raise ValueError('Changed narrative or figure source: '+filename)
    with zipfile.ZipFile(docx) as z:
        if z.testzip() is not None:raise ValueError('DOCX CRC error')
        root=ET.fromstring(z.read('word/document.xml'))
        ns={'m':'http://schemas.openxmlformats.org/officeDocument/2006/math','w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
        text=''.join(x.text or '' for x in root.findall('.//w:t',ns))
        formulas=len(root.findall('.//m:oMath',ns));tables=len(root.findall('.//w:tbl',ns))
        if formulas<6 or 'EQ_' in text or r'\_' in text or '$$' in text:raise ValueError('Formula objects or placeholders invalid')
    texts=[];outside=[]
    with pdfplumber.open(pdf) as book:
        count=len(book.pages)
        for i,p in enumerate(book.pages):
            texts.append(p.extract_text() or '')
            for ch in p.chars:
                if ch['x0']<-.5 or ch['x1']>p.width+.5 or ch['top']<-.5 or ch['bottom']>p.height+.5:
                    outside.append({'page':i+1,'text':ch['text']})
    combined=''.join(texts).replace(' ','')
    if outside:raise ValueError(f'Characters outside PDF pages: {outside[:8]}')
    chinese=len(re.findall('[\u4e00-\u9fff]',combined))
    if chinese<3500 or count<6:raise ValueError('Possible missing text/font or truncation')
    a=json.loads((result/'analysis/analysis.json').read_text());selected={a['selection']['selected_q42'],a['selection']['selected_q43']}
    required=[f"{r['full_cash_yuan']:,.2f}" for r in a['main_summary'] if r['strategy'] in selected]
    for number in required:
        if number not in combined:raise ValueError('Missing main result in PDF: '+number)
    if '/Users/' in combined:raise ValueError('Machine path leaked into reader document')
    if render:
        executable=shutil.which('pdftoppm')
        if not executable:raise RuntimeError('Install pdftoppm for page rendering')
        folder=build/'rendered_pages';folder.mkdir(parents=True,exist_ok=True)
        for pattern in ('page-*.png','contact-*.png'):
            for previous in folder.glob(pattern):previous.unlink()
        subprocess.run([executable,'-r','100','-png',str(pdf),str(folder/'page')],check=True)
        from PIL import Image,ImageDraw
        files=sorted(folder.glob('page-*.png'),key=lambda p:int(p.stem.split('-')[-1]))
        if len(files)!=count:raise ValueError('Rendered page count differs')
        for batch in range(0,count,6):
            canvas=Image.new('RGB',(1200,1740),'#d4d4d4');draw=ImageDraw.Draw(canvas)
            for j,p in enumerate(files[batch:batch+6]):
                im=Image.open(p).convert('RGB');im.thumbnail((390,825))
                x=j%3*400+(400-im.width)//2;y=j//3*870+30
                canvas.paste(im,(x,y));draw.text((x,y-20),p.stem,fill='black')
            canvas.save(folder/f'contact-{batch//6+1}.png')
    record={'passed':True,'visual_reviewed':bool(visual_reviewed),'pages':count,
        'visual_pages_reviewed':list(range(1,count+1)) if visual_reviewed else [],
        'native_formulas':formulas,'tables':tables,'figures':origin['counts']['figures'],
        'chinese_characters':chinese,'out_of_page_characters':outside,
        'main_cash_values_verified':required,'source_chain_verified':True,
        'scope':'Q4 stage explanation, not full contest paper; no full-paper cover/abstract/length assertion',
        'files':{'docx_sha256':sha(docx),'pdf_sha256':sha(pdf)}}
    (reports/'文稿验证.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
    return record


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--results',type=Path,default=ROOT/'results/final')
    p.add_argument('--render',action='store_true');p.add_argument('--visual-reviewed',action='store_true')
    args=p.parse_args();print(json.dumps(verify_document(args.results,args.render,args.visual_reviewed),ensure_ascii=False,indent=2))
