"""Independent counterexamples for Q4 prices, contracts and execution.

These tests deliberately vary future information and scenario probabilities;
they do not merely repeat the implementation's own residual checks.
"""
import copy
import datetime as dt
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import numpy as np
import pandas as pd

import q4_runner as runner
from q4_optimizer import solve_dispatch, solve_fixed_control, cash_components
from q4_risk import scenario_inputs


def synthetic_inputs(n=32):
    dates=[dt.date(2025,2,1)+dt.timedelta(days=i) for i in range(n)]
    starts=[dt.datetime.combine(d,dt.time(0,10)) for d in dates]
    power=np.full((n,144),1500.)
    pn=np.full((n,4,145),.5)
    data=dict(dates=dates,window_start=starts,window_end=[s+dt.timedelta(days=1) for s in starts],
        load_f=power.copy(),load_a=power.copy(),pv_a=np.zeros_like(power),
        q2_pv_f=np.zeros_like(power),pv_f=np.zeros((n,4,144)),
        pv_unused_first_mean_kw=np.zeros(n),price_f=(pn[:,:,:-1]+pn[:,:,1:])/2,
        price_nodes_f=pn,price_a=np.full_like(power,.5),price_nodes_a=np.full((n,145),.5),
        actual_estimated=np.zeros((n,144),bool),price_estimated=np.zeros((n,144),bool),
        inventory_value=.5,bridge_price_forecast=np.full(n,.5),
        first_unexecuted_interval={'load_mean_kw':1500.,'pv_mean_kw':0.},startup_price_actual=.5)
    data['policy_pv']=data['pv_f']
    return data


class TestIndependentOptimizer(unittest.TestCase):
    def test_two_dimensional_constant_prices_reduce_to_one_dimensional(self):
        L=np.array([[400,500,450],[450,480,520.]])
        G=np.array([[0,50,0],[10,0,20.]])
        p=np.array([.4,1.2,.8])
        kw=dict(probabilities=[.3,.7],terminal_weight=.6,time_limit=5,mip_gap=1e-9)
        a=solve_dispatch(L,G,p,1600.,**kw)
        b=solve_dispatch(L,G,np.tile(p,(2,1)),1600.,**kw)
        self.assertAlmostEqual(a['objective'],b['objective'],places=6)
        np.testing.assert_allclose(a['g'],b['g'],atol=1e-6)

    def test_shared_original_cost_uses_probability_weighted_price(self):
        # No PV, no usable initial inventory; identical 100 kWh demand. There
        # is no uncertain quantity to obscure this analytical cost check.
        sol=solve_dispatch(np.full((2,1),100.),np.zeros((2,1)),np.array([[1.],[3.]]),1200.,
            probabilities=[.75,.25],terminal_weight=0,time_limit=5,mip_gap=1e-9)
        self.assertAlmostEqual(sol['g'][0],100.,places=7)
        self.assertAlmostEqual(sol['original_cost_in_objective'],150.,places=7)
        self.assertAlmostEqual(sol['objective'],150.,places=7)

    def test_current_order_is_shared_despite_scenario_price_information(self):
        sol=solve_dispatch(np.array([[100.],[200.]]),np.zeros((2,1)),np.array([[1.],[3.]]),1200.,
            mode='adjust',base_g=[100.],booked_q=[100.],current_mask=[True],
            probabilities=[.75,.25],terminal_weight=0,time_limit=5,mip_gap=1e-9)
        np.testing.assert_allclose(sol['q_scenarios'][:,0],200.,atol=1e-6)
        self.assertAlmostEqual(sol['objective'],225.,places=6)
        self.assertEqual(sol['signed_q'].shape,(1,))
        with self.assertRaises(ValueError):
            solve_dispatch(np.ones((1,1)),np.zeros((1,1)),[1.],1200.,mode='control',
                base_g=[0.],booked_q=[0.],current_mask=[True],terminal_weight=0)

    def test_lp_and_milp_have_same_fixed_contract_value(self):
        cases=[(np.array([100,850,900,400.]),np.array([400,0,0,0.]),
                 np.array([0,100,100,600.]),1500.),
               (np.array([700,200,800,400.]),np.zeros(4),np.array([800,100,100,0.]),10500.)]
        p=np.array([.4,1.3,.9,.5])
        for L,G,q,s0 in cases:
            for weight in (0.,.5,2.):
                lp=solve_fixed_control(L,G,p,q,s0,terminal_weight=weight)
                mip=solve_dispatch(L[None,:],G[None,:],p,s0,mode='control',base_g=q,booked_q=q,
                    terminal_weight=weight,time_limit=5,mip_gap=1e-9)
                self.assertAlmostEqual(lp['objective'],mip['objective'],places=5)

    def test_refund_fee_and_positive_price_domain(self):
        self.assertEqual(cash_components([1],[100],[80],[0])['total_cash_cost'],90)
        self.assertEqual(cash_components([1],[100],[120],[0])['total_cash_cost'],130)
        for p in (0.,-1.):
            with self.assertRaises(ValueError):
                solve_dispatch(np.ones((1,1)),np.zeros((1,1)),[p],1200.,terminal_weight=0)


class TestIndependentRisk(unittest.TestCase):
    def test_joint_price_and_power_residual_dates_remain_paired(self):
        data=synthetic_inputs(32)
        for i in range(31):
            data['load_a'][i]=1500.+6*i
            data['pv_a'][i]=2*i
            data['price_a'][i]=.5*np.exp(i/100)
        cfg={**runner.DEFAULT,'min_history':14,'scenarios':8}
        L,G,P,meta=scenario_inputs(data,31,0,0,0,0,cfg)
        draw=np.array(meta['draw_indices'])
        np.testing.assert_allclose(L[:,0],250+draw)
        np.testing.assert_allclose(G[:,0],draw/3)
        np.testing.assert_allclose(P[:,0],.5*np.exp(draw/100))
        self.assertNotIn(30,meta['history_indices']) # previous tail unfinished
        self.assertTrue(all(data['window_end'][j]<=dt.datetime(2025,3,4) for j in draw))
        point=scenario_inputs(data,31,0,0,0,0,{**cfg,'price_mode':'point'})
        np.testing.assert_array_equal(point[0],L);np.testing.assert_array_equal(point[1],G)
        np.testing.assert_array_equal(point[2],np.full_like(P,.5))
        data['price_a'][meta['draw_indices'][0],0]=0
        with self.assertRaises(ValueError):scenario_inputs(data,31,0,0,0,0,cfg)


class TestIndependentRunner(unittest.TestCase):
    def run_synthetic(self,data,out,name,days=1,**kwargs):
        config={**runner.DEFAULT,'scenarios':1,'controller':'mpc','terminal_multiplier':1.,'time_limit':5}
        config.update(kwargs.pop('config',{}))
        with patch.object(runner,'load_inputs',return_value=data):
            result=runner.run_strategy(Path(out)/'empty_data',out,(0,),branch='4-2',
                name=name,days=days,config=config,**kwargs)
        path=Path(out)/name
        return result,pd.read_csv(path/'trace.csv'),json.loads((path/'event_log.json').read_text())

    def test_future_actual_price_does_not_change_current_order_or_first_action(self):
        a=synthetic_inputs();b=copy.deepcopy(a)
        # First left node is unchanged; unknown right nodes and their resulting
        # settlement prices change. Supplied forecast versions remain frozen.
        b['price_nodes_a'][0,1:]+=4
        b['price_a'][0]=(b['price_nodes_a'][0,:-1]+b['price_nodes_a'][0,1:])/2
        with tempfile.TemporaryDirectory() as out:
            _,ra,ea=self.run_synthetic(a,out,'a')
            _,rb,eb=self.run_synthetic(b,out,'b')
        np.testing.assert_array_equal(ea['events'][0]['signed_q'],eb['events'][0]['signed_q'])
        for col in ('g_kwh','q_kwh','charge_kwh','discharge_kwh','emergency_kwh','price_forecast_yuan_per_kwh'):
            self.assertAlmostEqual(ra.iloc[0][col],rb.iloc[0][col],places=7)
        self.assertNotEqual(ra.iloc[0]['price_yuan_per_kwh'],rb.iloc[0]['price_yuan_per_kwh'])

    def test_price_update_does_not_grant_trade_or_unused_pv_permission(self):
        a=synthetic_inputs();b=copy.deepcopy(a)
        b['pv_f'][:,1:]=1e8
        with tempfile.TemporaryDirectory() as out:
            _,ra,ea=self.run_synthetic(a,out,'a')
            _,rb,eb=self.run_synthetic(b,out,'b')
        self.assertEqual([e['kind'] for e in ea['events']],['dayahead'])
        self.assertEqual(set(ra['price_forecast_hour']),{0,6,12,18})
        np.testing.assert_array_equal(ea['events'][0]['signed_q'],eb['events'][0]['signed_q'])
        np.testing.assert_array_equal(ra['q_kwh'],rb['q_kwh'])

    def test_midnight_bridge_uses_new_price_vintage_but_old_contract(self):
        data=synthetic_inputs()
        data['bridge_price_forecast'][1]=1.4
        seen=[]
        original=runner.solve_dispatch
        def spy(L,G,P,S,**kwargs):
            if kwargs.get('mode')=='dayahead' and L.shape[1]==145:
                seen.append(np.asarray(P).copy())
            return original(L,G,P,S,**kwargs)
        with tempfile.TemporaryDirectory() as out,patch.object(runner,'solve_dispatch',side_effect=spy):
            _,rows,events=self.run_synthetic(data,out,'bridge',days=2)
        self.assertEqual(len(seen),1)
        np.testing.assert_allclose(seen[0][:,0],1.4)
        bridge=rows.iloc[143]
        self.assertEqual(bridge['window_date'],'2025-02-01')
        self.assertEqual(bridge['interval_start'],'2025-02-02T00:00:00')
        self.assertEqual(bridge['price_forecast_issue_time'],'2025-02-02T00:00:00')
        self.assertAlmostEqual(bridge['price_forecast_yuan_per_kwh'],1.4)
        self.assertAlmostEqual(bridge['q_kwh'],events['events'][0]['signed_q'][-1])
        self.assertEqual(len(events['events'][1]['signed_q']),144)


if __name__=='__main__':unittest.main()
