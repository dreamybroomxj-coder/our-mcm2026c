"""Analysis tests use synthetic arrays and a final-step analytical example."""
import unittest
from unittest.mock import patch

import numpy as np
import pandas as pd

import q4_analysis as analysis
from q4_history_check import history_jobs,START_DAY


class TestBlockComparison(unittest.TestCase):
    def test_constant_difference_and_full_sample_block(self):
        constant=np.full(310,-12.5)
        for block in (3,7,14):
            r=analysis.moving_block_mean_interval(constant,block)
            self.assertEqual(r['mean_difference_ci_lower_yuan'],-12.5)
            self.assertEqual(r['mean_difference_ci_upper_yuan'],-12.5)
            self.assertEqual(r['total_difference_yuan'],-3875.)
        # A block equal to the full series must retain the observed mean in
        # every replicate; an IID bootstrap would fail this counterexample.
        r=analysis.moving_block_mean_interval(np.arange(30.),30)
        self.assertEqual(r['mean_difference_ci_lower_yuan'],14.5)
        self.assertEqual(r['mean_difference_ci_upper_yuan'],14.5)

    def test_seed_repeatability_and_translation_equivariance(self):
        y=np.arange(310.)%17+np.linspace(-2,3,310)
        a=analysis.moving_block_mean_interval(y,7)
        b=analysis.moving_block_mean_interval(y,7)
        c=analysis.moving_block_mean_interval(y+100,7)
        self.assertEqual(a,b)
        for key in ('mean_daily_difference_yuan','mean_difference_ci_lower_yuan','mean_difference_ci_upper_yuan'):
            self.assertAlmostEqual(c[key]-a[key],100.,places=10)
        self.assertIn('not a prediction interval',a['interpretation'])

    def test_daily_pairing_sign_and_missing_date_rejection(self):
        dates=pd.date_range('2025-02-01',periods=334).strftime('%Y-%m-%d')
        left=pd.DataFrame({'window_date':dates,'cash_cost_yuan':np.full(334,90.)})
        right=pd.DataFrame({'window_date':dates,'cash_cost_yuan':np.full(334,100.)})
        diff,seen=analysis.paired_daily_difference(left,right)
        self.assertEqual(len(seen),310);np.testing.assert_array_equal(diff,np.full(310,-10.))
        with self.assertRaisesRegex(ValueError,'310 dates'):
            analysis.paired_daily_difference(left,right.drop(25))
        with self.assertRaisesRegex(ValueError,'310 dates'):
            analysis.paired_daily_difference(left,right.iloc[::-1])


class TestEndpointStudy(unittest.TestCase):
    def setUp(self):
        self.row={'interval_start':'2026-01-01T00:00:00','interval_end':'2026-01-01T00:10:00',
            'g_kwh':100.,'q_kwh':100.,'soc_start_kwh':1200.,
            'price_forecast_yuan_per_kwh':.7,'price_yuan_per_kwh':.5}
        base=analysis.execute_tail(self.row,1200.,0.,terminal_weight=.5)
        self.row.update(base)
        self.row['cash_cost_yuan']=analysis.settle_tail(self.row,base,.5)
        self.summary={'common_inventory_value':.5,'terminal_weight':.5,'config':{'controller':'mpc'},
            'cash_cost_yuan':12345.,'inventory_adjusted_cost_yuan':12345.,'soc_start_kwh':1200.,'soc_end_kwh':1200.}
        self.power={'load':{m:{'mean_kw':v} for m,v in zip(analysis.METHODS,(1200.,1260.,1140.))},
            'pv':{m:{'mean_kw':0.} for m in analysis.METHODS}}
        self.prices={m:{'last_interval_price':v} for m,v in zip(analysis.METHODS,(.5,.4,.6))}

    def test_price_only_changes_bill_not_action_or_controller_coefficient(self):
        changed={**self.row,'price_yuan_per_kwh':100000.,'cash_cost_yuan':float('nan')}
        with patch.object(analysis,'solve_fixed_control',wraps=analysis.solve_fixed_control) as spy:
            normal=analysis.execute_tail(self.row,1200.,0.,terminal_weight=.5)
            altered=analysis.execute_tail(changed,1200.,0.,terminal_weight=.5)
        self.assertEqual(normal,altered)
        self.assertEqual(spy.call_args_list[0].args[2],[.7])
        self.assertEqual(spy.call_args_list[1].args[2],[.7])
        self.assertEqual(normal['emergency_kwh'],100.)
        self.assertEqual(analysis.settle_tail(self.row,normal,1.),600.)
        self.assertEqual(analysis.settle_tail(self.row,normal,3.),1800.)

    def test_nine_combinations_reproduce_baseline_and_preserve_price_independence(self):
        rows=analysis.endpoint_variants('analytical',self.summary,self.row,self.power,self.prices)
        self.assertEqual(len(rows),9)
        base=next(r for r in rows if r['power_endpoint_method']==r['price_endpoint_method']=='hold')
        self.assertEqual(base['full_cash_change_yuan'],0.)
        self.assertTrue(all(r['estimated_power_right_endpoint'] and r['estimated_price_right_endpoint'] for r in rows))
        self.assertTrue(all(r['actual_price_used_for_control'] is False for r in rows))
        for method in analysis.METHODS:
            part=[r for r in rows if r['power_endpoint_method']==method]
            self.assertEqual(len({(r['charge_kwh'],r['discharge_kwh'],r['emergency_kwh'],r['soc_end_kwh']) for r in part}),1)
            self.assertEqual(len({r['full_cash_cost_yuan'] for r in part}),3)
        self.assertAlmostEqual(next(r for r in rows if r['power_endpoint_method']=='linear2' and r['price_endpoint_method']=='hold')['full_cash_change_yuan'],25.)

    def test_saturated_surplus_respects_capacity_and_discards_rest(self):
        row={**self.row,'soc_start_kwh':10799.}
        step=analysis.execute_tail(row,0.,6000.,terminal_weight=.5)
        self.assertAlmostEqual(step['charge_kwh'],1/.9)
        self.assertAlmostEqual(step['soc_end_kwh'],10800.)
        self.assertEqual(step['discharge_kwh'],0.)
        self.assertEqual(step['emergency_kwh'],0.)
        self.assertGreater(step['unused_paid_kwh']+step['curtailed_pv_kwh'],1000.)


class TestMatureHistoryCheck(unittest.TestCase):
    def test_jobs_keep_frozen_modes_schedules_and_use_common_august_horizon(self):
        selected={'branch_selections':{'4-2':{'price_mode':'point','trade_hours':[0]},
            '4-3':{'price_mode':'joint','trade_hours':[0,6,18]}}}
        jobs=history_jobs(selected)
        self.assertEqual(START_DAY,181);self.assertEqual(len(jobs),6)
        for branch in ('4-2','4-3'):
            part=[j for j in jobs if j['branch']==branch]
            self.assertEqual([j['config']['history_days'] for j in part],[14,28,56])
            for job in part:
                self.assertEqual(job['start_day'],181);self.assertEqual(job['days'],14)
                self.assertEqual(job['config']['initial_soc'],6000.)
                self.assertEqual(job['config']['price_mode'],selected['branch_selections'][branch]['price_mode'])
                self.assertEqual(list(job['trade_hours']),selected['branch_selections'][branch]['trade_hours'])

    def test_mature_history_summary_refuses_unfilled_56_cap(self):
        runs={}
        for branch in ('4-2','4-3'):
            for cap in (14,28,56):
                name='Q'+branch.replace('-','')+f'_aug_history{cap}'
                runs[name]={'summary':{'windows':14,'config':{'start_day':181,'history_days':cap},
                    'soc_start_kwh':6000.,'soc_end_kwh':6000.,'cash_cost_yuan':float(10000+cap),
                    'inventory_adjusted_cost_yuan':float(10000+cap)},
                    'actual_history_min':cap,'actual_history_max':cap}
        result=analysis.history_check_summary(runs)
        self.assertEqual(len(result),6)
        self.assertTrue(all(r['all_events_fill_history_cap'] for r in result))
        runs['Q42_aug_history56']['actual_history_min']=23
        with self.assertRaisesRegex(ValueError,'did not actually fill'):
            analysis.history_check_summary(runs)


if __name__=='__main__':unittest.main()
