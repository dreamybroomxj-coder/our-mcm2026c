"""Independent value, source, publication and boundary checks on price inputs."""
from pathlib import Path
import hashlib
import json
import numpy as np

from price_inputs import load_price_data,read_attachment4,ROOT


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def audit_prices(data_dir=ROOT/'data'):
    data_dir=Path(data_dir);p=load_price_data(data_dir/'price_inputs.npz')
    raw=read_attachment4(data_dir/'attachment4.xlsx');flat=raw.ravel()
    with np.load(data_dir/'xgboost_midnight_predictions.npz') as z:zero=z['predictions'].copy()
    np.testing.assert_array_equal(zero,p.nodes[:,0])
    np.testing.assert_array_equal((zero[:,:-1]+zero[:,1:])/2,p.predicted[:,0])
    expected=np.empty((334,145));expected[:,:144]=raw[31:];expected[:-1,-1]=raw[32:,0];expected[-1,-1]=np.nan
    np.testing.assert_array_equal(expected,p.raw_actual_nodes)
    held=expected.copy();held[-1,-1]=flat[-1]
    np.testing.assert_array_equal(held,p.actual_nodes)
    np.testing.assert_array_equal((held[:,:-1]+held[:,1:])/2,p.actual)
    expected_est=np.zeros((334,144),bool);expected_est[-1,-1]=True
    np.testing.assert_array_equal(expected_est,p.actual_estimated)
    actual0=raw[30:364,143]
    np.testing.assert_array_equal(actual0,p.known_midnight)
    np.testing.assert_array_equal((actual0+zero[:,0])/2,p.forecast_bridge)
    np.testing.assert_array_equal((actual0+raw[31:,0])/2,p.actual_bridge)
    checks=0
    for v,hour,slot in zip(range(4),p.vintages,p.gate_slots):
        assert np.isnan(p.nodes[:,v,:slot]).all()
        assert np.isnan(p.predicted[:,v,:slot]).all()
        assert np.isfinite(p.predicted[:,v,slot:]).all()
        if v:np.testing.assert_array_equal(p.nodes[:,v,slot],raw[31:,slot])
        np.testing.assert_array_equal(p.predicted[:,v,slot:],(p.nodes[:,v,slot:-1]+p.nodes[:,v,slot+1:])/2)
        checks+=334*(144-slot)
    fits=json.loads((data_dir/'intraday_price_fit_diagnostics.json').read_text())
    fitcount=0
    cfg=json.loads((data_dir/'xgboost_midnight_summary.json').read_text())['config']
    for hour in (6,12,18):
        ds=fits[str(hour)];assert len(ds)==334
        for day,d in zip(range(31,365),ds):
            cutoff=day*144+hour*6
            assert d['day_index']==day and d['issue_hour']==hour
            assert d['same_issue_hour']==hour and d['config']==cfg
            assert d['max_label_index']<cutoff
            assert d['last_training_feature_source_index']==(day-1)*144+hour*6-1
            assert d['current_feature_source_last_index']==cutoff-1
            assert not d['clipped'] and not d['hyperparameters_retuned']
            fitcount+=1
    assert fitcount==1002
    for name,digest in p.audit['provenance']['sources'].items():assert sha(data_dir/name)==digest
    for name,digest in p.audit['provenance']['core'].items():assert sha(Path(__file__).parent/name)==digest
    all_price_nodes=p.nodes[np.isfinite(p.nodes)]
    assert np.all(all_price_nodes>0) and np.all(p.actual>0)
    result={'passed':True,'price_input_sha256':sha(data_dir/'price_inputs.npz'),
       'midnight_inherited_nodes_verified':int(zero.size),'available_versioned_intervals_verified':checks,
       'actual_intervals_verified':int(p.actual.size),'intraday_fit_cutoffs_verified':fitcount,
       'known_release_node_verified':True,'unavailable_past_prices_remain_nan':True,
       'estimated_final_interval_count':1,'startup_actual':p.startup_actual,
       'minimum_predicted_interval_price':float(np.nanmin(p.predicted)),
       'minimum_actual_interval_price':float(p.actual.min()),
       'minimum_known_or_forecast_node':float(all_price_nodes.min()),
       'max_zero_node_inheritance_error':float(np.max(np.abs(zero-p.nodes[:,0]))),
       'all_source_and_numerical_core_hashes_match':True,
       'note':'This audit verifies generated values and stated fit cutoffs. The executable future-perturbation tests independently validate code causality.'}
    (data_dir/'price_inputs_independent_validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    return result


if __name__=='__main__':print(json.dumps(audit_prices(),ensure_ascii=False,indent=2))
