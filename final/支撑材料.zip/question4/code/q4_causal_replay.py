"""Execution-timing sensitivity under the same timestamp-revealed contracts.

Compare the main ten-minute mean-feedback approximation with micro-step causal
left-node feedback. Reoptimize battery execution only, never original orders or
formal adjustments. The simulator linearly interpolates observed ten-minute
nodes into an artificial finer-step environment; the controller only receives
a node when its timestamp is reached. This is a discretization sensitivity,
not higher-frequency measurement or an exact physical validation.
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import hashlib
import json
import gzip
from pathlib import Path

import numpy as np

from q4_io import load_inputs, selected_pv
from q4_optimizer import solve_dispatch, solve_fixed_control, LOW, HIGH, RATE, ETA_C, ETA_D
from q4_risk import HOURS, START, latest_hour, future_mask, current_block


def _read_csv(path):
    with open(path, encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def _write_csv(path, rows):
    if not rows:return
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader(); w.writerows(rows)


def causal_price_vector(data, day, t, price_hour):
    """Current actual left + forecast right; future right actual is inaccessible."""
    if price_hour not in HOURS or not 0<=t<144 or START[price_hour]>t:
        raise ValueError('Requested price forecast is not available at this control time')
    v=HOURS.index(price_hour)
    prices=data['price_f'][day,v,t:].copy()
    prices[0]=(data['price_nodes_a'][day,t]+data['price_nodes_f'][day,v,t+1])/2
    if not np.isfinite(prices).all() or (prices<=0).any():
        raise ValueError('Invalid causal price vector; no silent clipping or future-version fill')
    return prices


def run_replay(data_dir, main_run_dir, outdir, start_day=24, days=7,
               initial_soc=6000., fine_steps=(1.,), *, data_override=None):
    data = load_inputs(data_dir) if data_override is None else data_override
    source, out = Path(main_run_dir), Path(outdir)
    out.mkdir(parents=True, exist_ok=True)
    log = json.loads((source/"event_log.json").read_text())
    cfg = log["config"]
    trade = tuple(cfg["trade_hours"])
    forecasts = tuple(cfg["forecast_hours"])
    price_hours=tuple(cfg.get('price_hours',[0,6,12,18]))
    data['policy_pv']=selected_pv(data,cfg['branch'],cfg.get('pv_source','supplied'))
    if not LOW<=initial_soc<=HIGH:raise ValueError('Local common SOC is outside physical limits')
    fine_steps=tuple(float(x) for x in fine_steps)
    if not fine_steps or len(set(fine_steps))!=len(fine_steps) or any(x<=0 or x>10 or abs(10/x-round(10/x))>1e-8 for x in fine_steps):
        raise ValueError('Fine steps must be unique positive divisors of ten minutes')
    stop = start_day+days
    if start_day < 0 or days < 1 or stop > len(data["dates"]):
        raise ValueError("Requested local replay window is outside input dates.")
    selected = {str(d): [] for d in data["dates"][start_day:stop]}
    for row in _read_csv(source/"trace.csv"):
        if row["window_date"] in selected:
            selected[row["window_date"]].append(row)
    events = {(r["window_date"], r["kind"], r["decision_at"]): r for r in log["events"]}
    original, final_q = {}, {}
    for day in range(start_day, stop):
        date = str(data["dates"][day])
        rows = sorted(selected[date], key=lambda r:r["interval_start"])
        if len(rows) != 144:
            raise ValueError(f"Main trace does not contain all 144 slots for {date}.")
        for t, row in enumerate(rows):
            target = data["window_start"][day]+dt.timedelta(minutes=10*t)
            if row["interval_start"] != target.isoformat():
                raise ValueError("Main trace timestamps do not match the contract window.")
            if abs(float(row["price_yuan_per_kwh"])-data["price_a"][day,t]) > 1e-9:
                raise ValueError("Main trace and input tariff differ.")
            for key in ("load", "pv"):
                if abs(float(row[f"{key}_actual_kw"])-data[f"{key}_a"][day,t]) > 1e-7:
                    raise ValueError("Main trace and input observed interval means differ.")
            if abs(float(row["load_forecast_kw"])-data["load_f"][day,t]) > 1e-7:
                raise ValueError("Main trace and input load forecasts differ.")
        selected[date] = rows
        original[day] = np.array([float(r["g_kwh"]) for r in rows])
        final_q[day] = np.array([float(r["q_kwh"]) for r in rows])
        midnight = dt.datetime.combine(data["dates"][day],dt.time()).isoformat()
        if (date,"dayahead",midnight) not in events:
            raise ValueError("A day-ahead contract has no timestamped release event.")
        adjustable = np.zeros(144, bool)
        for h in trade:
            if h:
                a,b = current_block(trade,h)
                key=(date,"adjust",dt.datetime.combine(data["dates"][day],dt.time(h)).isoformat())
                if key not in events or (events[key]["commit_start"],events[key]["commit_end"]) != (a,b):
                    raise ValueError("A formal adjustment lacks its matching commit event.")
                adjustable[a:b] = True
        if np.max(np.abs((final_q[day]-original[day])[~adjustable]), initial=0) > 1e-5:
            raise ValueError("An order was changed outside the enabled adjustment blocks.")
    main_initial = float(selected[str(data["dates"][start_day])][0]["soc_start_kwh"])
    initial = float(initial_soc)
    nu=float(data['inventory_value'])
    kappa = nu*float(cfg.get('terminal_multiplier',1.))
    solver_options = dict(terminal_weight=kappa, time_limit=cfg.get("time_limit",10),
                          mip_gap=cfg.get("mip_gap",1e-4))
    summaries, trajectories = {}, {}
    variants=[('10min_mean',None)]+[(f'{step:g}min_causal',step) for step in fine_steps]
    for variant,micro_step in variants:
        state = initial
        rows, minute_rows, reveals = [], [], []
        stats = dict(solves=0,solve_seconds=0.,max_violation_kwh=0.,unproven=0,
                     lp_solves=0,milp_solves=0,max_tenminute_direction_overlap_kwh=0.,
                     max_charge_power_kw=0.,max_discharge_power_kw=0.,
                     min_soc_kwh=initial,max_soc_kwh=initial)

        def command(L,G,prices,base,booked,future,now_l,now_pv):
            surplus=max(booked[0]+now_pv-now_l,0.)
            deficit=max(now_l-booked[0]-now_pv,0.)
            if surplus > 1e-9:
                return min(surplus,RATE,max((HIGH-state)/ETA_C,0.)),0.,0.,True
            if cfg.get("controller","mpc") == "greedy":
                d=min(deficit,RATE,max((state-LOW)*ETA_D,0.))
                return 0.,d,max(deficit-d,0.),False
            L,G=L.copy(),G.copy();L[0]=now_l;G[0]=now_pv
            if not future.any():
                z=solve_fixed_control(L,G,prices,booked,state,terminal_weight=kappa,
                                      time_limit=cfg.get('time_limit',10))
                stats['solves']+=1;stats['lp_solves']+=1;stats['solve_seconds']+=z['solve_seconds']
                return float(z['c'][0]),float(z['d'][0]),float(z['e'][0]),False
            z=solve_dispatch(L[None,:],G[None,:],prices,state,mode="control",
                             base_g=base,booked_q=booked,future_adjust_mask=future,**solver_options)
            stats["solves"]+=1;stats["solve_seconds"]+=z["solve_seconds"]
            stats['milp_solves']+=1
            stats["unproven"]+=int(not z["optimality_proven"])
            return float(z["c"][0,0]),float(z["d"][0,0]),float(z["e"][0,0]),False

        def check_step(gq,L,G,c,d,e,v,r,sbefore,safter,rate):
            error=max(abs(gq+G-r-v+d+e-L-c),
                abs(safter-sbefore-ETA_C*c+d/ETA_D),
                LOW-safter,safter-HIGH,c-rate,d-rate,-min(c,d,e,v,r),
                min(c,d),min(c,e),v-gq,r-G,e-L,0.)
            stats["max_violation_kwh"]=max(stats["max_violation_kwh"],error)
            stats['max_charge_power_kw']=max(stats['max_charge_power_kw'],c/rate*5000.)
            stats['max_discharge_power_kw']=max(stats['max_discharge_power_kw'],d/rate*5000.)
            stats['min_soc_kwh']=min(stats['min_soc_kwh'],safter)
            stats['max_soc_kwh']=max(stats['max_soc_kwh'],safter)
            if error > 1e-5:
                raise RuntimeError(f"{variant} physical violation: {error}")

        def execute(day,t,L,G,prices,base,booked,future,fh,ph,price_issue_day=None):
            nonlocal state
            before=state
            begin=data["window_start"][day]+dt.timedelta(minutes=10*t)
            if variant == "10min_mean":
                load=float(data["load_a"][day,t]/6);pv=float(data["pv_a"][day,t]/6)
                c,d,e,direction=command(L,G,prices,base,booked,future,load,pv)
                waste=max(booked[0]+pv+d+e-load-c,0.)
                v=min(booked[0],waste);r=max(waste-v,0.)
                state+=ETA_C*c-d/ETA_D
                check_step(booked[0],load,pv,c,d,e,v,r,before,state,RATE)
            else:
                # The controller receives only the current left node here.
                now_l=float(data["load_nodes"][day,t]/6)
                now_g=float(data["pv_nodes"][day,t]/6)
                cp,dp,ep,direction=command(L,G,prices,base,booked,future,now_l,now_g)
                remaining_d=dp
                c=d=e=v=r=load=pv=0.
                micro_count=int(round(10/micro_step))
                for j in range(micro_count):
                    # Artificial environment: expose only the node at NOW.
                    # A right endpoint is used to construct the environment,
                    # never passed to command() before it becomes observable.
                    fraction=j/micro_count
                    observed_load=float((1-fraction)*data["load_nodes"][day,t]
                                         +fraction*data["load_nodes"][day,t+1])
                    observed_pv=float((1-fraction)*data["pv_nodes"][day,t]
                                       +fraction*data["pv_nodes"][day,t+1])
                    # Price is only a now-observed signal here; the committed
                    # ten-minute direction does not optimize on future prices.
                    observed_price=float((1-fraction)*data['price_nodes_a'][day,t]
                                         +fraction*data['price_nodes_a'][day,t+1])
                    lm,gm=observed_load*micro_step/60,observed_pv*micro_step/60
                    qm=float(booked[0]/micro_count)
                    A=max(qm+gm-lm,0.);D=max(lm-qm-gm,0.)
                    cm=min(A,RATE/micro_count,max((HIGH-state)/ETA_C,0.)) if direction else 0.
                    dm=0. if direction else min(D,RATE/micro_count,max((state-LOW)*ETA_D,0.),remaining_d)
                    em=max(D-dm,0.)
                    wm=max(A-cm,0.);vm=min(qm,wm);rm=max(wm-vm,0.)
                    sb=state;state+=ETA_C*cm-dm/ETA_D
                    remaining_d=max(remaining_d-dm,0.)
                    check_step(qm,lm,gm,cm,dm,em,vm,rm,sb,state,RATE/micro_count)
                    minute_rows.append(dict(interval_start=(begin+dt.timedelta(minutes=j*micro_step)).isoformat(),
                        interval_end=(begin+dt.timedelta(minutes=(j+1)*micro_step)).isoformat(),
                        load_observed_left_kw=observed_load,pv_observed_left_kw=observed_pv,
                        price_observed_left=observed_price,tenminute_settlement_price=float(data['price_a'][day,t]),
                        q_kwh=qm,charge_kwh=cm,discharge_kwh=dm,emergency_kwh=em,
                        unused_paid_kwh=vm,curtailed_pv_kwh=rm,soc_start_kwh=sb,soc_end_kwh=state,
                        command_direction="charge" if direction else "discharge_or_idle",
                        remaining_block_discharge_budget_kwh=remaining_d))
                    c+=cm;d+=dm;e+=em;v+=vm;r+=rm;load+=lm;pv+=gm
                if min(c,d)>1e-7 or c>RATE+1e-6 or d>dp+1e-6:
                    raise RuntimeError('Within-block direction, power or discharge budget violated')
            stats['max_tenminute_direction_overlap_kwh']=max(stats['max_tenminute_direction_overlap_kwh'],min(c,d))
            # Contract settlement is the same realized ten-minute mean tariff
            # for ALL variants, never minute-price weighting or forecast price.
            settlement=float(data['price_a'][day,t])
            ordinary=float(settlement*base[0]);increase=max(booked[0]-base[0],0.);decrease=max(base[0]-booked[0],0.)
            adjustment=float(settlement*(1.5*increase-.5*decrease));emergency=float(5*settlement*e)
            rows.append(dict(variant=variant,window_date=str(data["dates"][day]),
                interval_start=begin.isoformat(),interval_end=(begin+dt.timedelta(minutes=10)).isoformat(),
                forecast_hour=fh,price_forecast_hour=ph,
                price_forecast_issue_date=str(data['dates'][day] if price_issue_day is None else price_issue_day),
                control_price_forecast=float(prices[0]),settlement_price=settlement,
                g_kwh=float(base[0]),q_kwh=float(booked[0]),
                load_energy_kwh=load,pv_energy_kwh=pv,charge_kwh=c,discharge_kwh=d,emergency_kwh=e,
                unused_paid_kwh=v,curtailed_pv_kwh=r,soc_start_kwh=before,soc_end_kwh=state,
                ordinary_cost_yuan=ordinary,adjustment_cost_yuan=adjustment,
                emergency_cost_yuan=emergency,cash_cost_yuan=ordinary+adjustment+emergency))
            rows[-1]['battery_loss_kwh']=(1-ETA_C)*c+(1/ETA_D-1)*d

        for day in range(start_day,stop):
            # New g becomes visible at this midnight, before the old tail is
            # observed. Future formal q remains inaccessible until its gate.
            if day > start_day:
                oldg,oldq=g.copy(),q.copy()
            g=original[day].copy();q=g.copy()
            reveals.append(dict(at=dt.datetime.combine(data["dates"][day],dt.time()).isoformat(),
                                kind="dayahead",window_date=str(data["dates"][day]),start=0,end=144))
            if day > start_day:
                oldfh=latest_hour(forecasts,143)
                lf=np.r_[data["load_f"][day-1,143],data["load_f"][day]]/6
                pf=np.r_[data["policy_pv"][day-1,HOURS.index(oldfh),143],data["policy_pv"][day,0]]/6
                pp=np.r_[data['bridge_price_forecast'][day],data['price_f'][day,0]]
                execute(day-1,143,lf,pf,pp,np.r_[oldg[-1],g],np.r_[oldq[-1],q],
                        np.r_[False,future_mask(trade,0)],oldfh,0,price_issue_day=data['dates'][day])
            for t in range(143):
                h=next((h for h in trade if h and START[h]==t),None)
                if h is not None:
                    a,b=current_block(trade,h)
                    q[a:b]=final_q[day][a:b]  # Only current committed block.
                    reveals.append(dict(at=dt.datetime.combine(data["dates"][day],dt.time(h)).isoformat(),
                                        kind="adjust",window_date=str(data["dates"][day]),start=a,end=b))
                fh=latest_hour(forecasts,t)
                ph=latest_hour(price_hours,t)
                execute(day,t,data["load_f"][day,t:]/6,data["policy_pv"][day,HOURS.index(fh),t:]/6,
                        causal_price_vector(data,day,t,ph),g[t:],q[t:],future_mask(trade,t),fh,ph)
            if not np.allclose(q,final_q[day],rtol=0,atol=1e-5):
                raise RuntimeError("Timestamp-revealed order differs from the fixed main order.")
        day=stop-1;fh=latest_hour(forecasts,143);ph=latest_hour(price_hours,143)
        execute(day,143,data["load_f"][day,143:]/6,data["policy_pv"][day,HOURS.index(fh),143:]/6,
                causal_price_vector(data,day,143,ph),g[-1:],q[-1:],np.zeros(1,bool),fh,ph)
        if len(rows)!=144*days:
            raise RuntimeError("Wrong local replay length.")
        totals={key:float(sum(row[key] for row in rows)) for key in
                ("cash_cost_yuan","ordinary_cost_yuan","adjustment_cost_yuan","emergency_cost_yuan",
                 "emergency_kwh","load_energy_kwh","pv_energy_kwh","charge_kwh","discharge_kwh","battery_loss_kwh")}
        totals.update({key:float(sum(row[key] for row in rows))
                       for key in ('q_kwh','unused_paid_kwh','curtailed_pv_kwh')})
        totals['energy_balance_residual_kwh']=(totals['q_kwh']+totals['pv_energy_kwh']+
            totals['discharge_kwh']+totals['emergency_kwh']-totals['load_energy_kwh']-
            totals['charge_kwh']-totals['unused_paid_kwh']-totals['curtailed_pv_kwh'])
        totals['battery_balance_residual_kwh']=(state-initial-totals['charge_kwh']+
            totals['discharge_kwh']+totals['battery_loss_kwh'])
        if max(abs(totals['energy_balance_residual_kwh']),abs(totals['battery_balance_residual_kwh']))>1e-5:
            raise RuntimeError('Aggregate energy or battery balance failed')
        totals.update(soc_start_kwh=initial,soc_end_kwh=state,
                      inventory_adjusted_cost_yuan=totals["cash_cost_yuan"]-nu*(state-initial),
                      intervals=len(rows),minute_intervals=len(minute_rows),solver=stats)
        summaries[variant]=totals;trajectories[variant]=rows
        _write_csv(out/f"trace_{variant}.csv",rows)
        if minute_rows:
            with gzip.open(out/f'micro_trace_{variant}.csv.gz','wt',encoding='utf-8-sig',newline='') as stream:
                writer=csv.DictWriter(stream,fieldnames=list(minute_rows[0]));writer.writeheader();writer.writerows(minute_rows)
        (out/f"contract_reveals_{variant}.json").write_text(json.dumps(reveals,indent=2))
    base=summaries['10min_mean'];differences={};energy_checks={}
    for step in fine_steps:
        label=f'{step:g}min_causal';fine=summaries[label]
        for key in ("ordinary_cost_yuan","adjustment_cost_yuan"):
            if abs(base[key]-fine[key])>1e-6:
                raise RuntimeError("The controllers did not use identical signed contracts.")
        # Continuous linear-node left-Riemann discrepancy telescopes across windows.
        expected_bias={key:float(step*(data[f"{key}_nodes"][start_day,0]-data[f"{key}_nodes"][stop-1,-1])/120)
                   for key in ("load","pv")}
        observed_bias={key:fine[f"{key}_energy_kwh"]-base[f"{key}_energy_kwh"] for key in ("load","pv")}
        if any(abs(expected_bias[k]-observed_bias[k])>1e-5 for k in expected_bias):
            raise RuntimeError("Minute discretization energy difference disagrees with its analytical identity.")
        differences[label]={k:fine[k]-base[k] for k in ('cash_cost_yuan','emergency_kwh','soc_end_kwh','inventory_adjusted_cost_yuan','battery_loss_kwh')}
        energy_checks[label]=dict(observed_bias_kwh=observed_bias,analytical_bias_kwh=expected_bias)
    result=dict(source_run=str(source.resolve()),source_strategy=cfg["strategy"],
        source_hashes={name:hashlib.sha256((source/name).read_bytes()).hexdigest()
                       for name in ("trace.csv","event_log.json","summary.json")},
        replay_code_sha256={name:hashlib.sha256((Path(__file__).resolve().parent/name).read_bytes()).hexdigest()
                           for name in ('q4_causal_replay.py','q4_optimizer.py','q4_risk.py')},
        input_source_sha256=data.get('metadata',{}).get('source_sha256',{}),
        start_day=start_day,days=days,start=str(data["window_start"][start_day]),end=str(data["window_end"][stop-1]),
        local_initial_state="Common configured SOC at first selected 00:10 for every branch/variant; frozen orders were NOT reoptimized for this state",
        local_initial_soc=initial,main_trace_original_local_initial_soc=main_initial,
        end_rule="Both controllers stop at the selected final 00:10; neither reads the next unselected contract",
        contracts="Same fixed g/q, revealed only at original midnight and enabled intraday commit times",
        minute_method="Artificial linear-node environment; left power held for each micro-step, frozen ten-minute direction and discharge budget",
        fine_step_minutes=list(fine_steps),settlement='All variants use the same actual ten-minute mean price; controller price sees only current left plus predicted right',
        common_inventory_value=nu,terminal_weight=kappa,
        limitations=["Not high-frequency measured data or exact physical validation",
                     "Micro-step left-endpoint power hold differs from exact linear-signal integration; analytical total energy discrepancy and refinement are reported",
                     "Within-block direction cannot reverse; physical stopping, free disposal and emergency balancing remain allowed",
                     "Local fixed-contract sensitivity does not reselect the best annual contract policy"],
        summary=summaries,fine_minus_mean=differences,signal_energy_integration_checks=energy_checks,
        checks_passed=True)
    (out/"summary.json").write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding="utf-8")
    return result


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data",required=True);parser.add_argument("--main-run",required=True)
    parser.add_argument("--out",required=True);parser.add_argument("--start-day",type=int,default=24)
    parser.add_argument("--days",type=int,default=7)
    parser.add_argument('--initial-soc',type=float,default=6000.)
    parser.add_argument('--fine-steps',default='1',help='Comma-separated step minutes, e.g. 1,0.1')
    args=parser.parse_args()
    result=run_replay(args.data,args.main_run,args.out,args.start_day,args.days,args.initial_soc,tuple(map(float,args.fine_steps.split(','))))
    print(json.dumps({"checks_passed":result["checks_passed"],
                      "fine_minus_mean":result["fine_minus_mean"]},ensure_ascii=False))
