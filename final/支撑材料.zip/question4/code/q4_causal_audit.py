"""Read-only independent ledger audit of fixed-contract micro-step experiments."""
import argparse
import datetime as dt
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

from q4_io import load_inputs

ROOT=Path(__file__).resolve().parents[1]


def audit_replay(folder, data):
    folder=Path(folder);report=json.loads((folder/'summary.json').read_text())
    # Prefer this package's frozen main ledger; an old absolute origin may
    # still exist after copying, and must not mask tampering in the copy.
    source=folder.parent.parent/'main'/report['source_strategy']
    if not source.exists():source=Path(report['source_run'])
    for name,digest in report['source_hashes'].items():
        if hashlib.sha256((source/name).read_bytes()).hexdigest()!=digest:raise ValueError('Source digest mismatch')
    for name,digest in report['replay_code_sha256'].items():
        if hashlib.sha256((ROOT/'code'/name).read_bytes()).hexdigest()!=digest:raise ValueError('Replay code digest mismatch')
    if report['input_source_sha256']!=data.get('metadata',{}).get('source_sha256',{}):
        raise ValueError('Replay input source digest mismatch')
    config=json.loads((source/'event_log.json').read_text())['config']
    starts={0:0,6:35,12:71,18:107};hours=(0,6,12,18)
    price_hours=config.get('price_hours',[0,6,12,18]);pv_hours=config['forecast_hours']
    nu=float(data['inventory_value'])
    np.testing.assert_allclose(report['common_inventory_value'],nu,atol=1e-12,rtol=0)
    np.testing.assert_allclose(report['terminal_weight'],nu*config.get('terminal_multiplier',1.),atol=1e-12,rtol=0)
    frozen=pd.read_csv(source/'trace.csv').set_index('interval_start')
    a=report['start_day'];b=a+report['days'];date_map={str(d):i for i,d in enumerate(data['dates'])}
    expected_index=pd.date_range(data['window_start'][a],periods=144*report['days'],freq='10min')
    expected_reveals=[]
    for day in range(a,b):
        date=data['dates'][day]
        expected_reveals.append(dict(at=dt.datetime.combine(date,dt.time()).isoformat(),kind='dayahead',
                                     window_date=str(date),start=0,end=144))
        for hour in config['trade_hours']:
            if not hour:continue
            later=[starts[h] for h in config['trade_hours'] if h>hour]
            expected_reveals.append(dict(at=dt.datetime.combine(date,dt.time(hour)).isoformat(),kind='adjust',
                                         window_date=str(date),start=starts[hour],end=min(later) if later else 144))
    checks=[];recomputed={}
    for label in report['summary']:
        trace=pd.read_csv(folder/f'trace_{label}.csv')
        if json.loads((folder/f'contract_reveals_{label}.json').read_text())!=expected_reveals:
            raise ValueError('Contract reveal times or blocks disagree with the enabled source policy')
        numeric=['g_kwh','q_kwh','load_energy_kwh','pv_energy_kwh','charge_kwh','discharge_kwh','emergency_kwh',
                 'unused_paid_kwh','curtailed_pv_kwh','soc_start_kwh','soc_end_kwh','control_price_forecast',
                 'settlement_price','ordinary_cost_yuan','adjustment_cost_yuan','emergency_cost_yuan','cash_cost_yuan','battery_loss_kwh']
        if not np.isfinite(trace[numeric].to_numpy(dtype=float)).all():raise ValueError('Nonfinite replay ledger value')
        np.testing.assert_array_equal(pd.to_datetime(trace.interval_start).to_numpy(),expected_index.to_numpy())
        np.testing.assert_array_equal(pd.to_datetime(trace.interval_end).to_numpy(),(expected_index+pd.Timedelta(minutes=10)).to_numpy())
        original=frozen.loc[trace.interval_start]
        np.testing.assert_allclose(trace.g_kwh,original.g_kwh,atol=1e-8,rtol=0)
        np.testing.assert_allclose(trace.q_kwh,original.q_kwh,atol=1e-8,rtol=0)
        p=data['price_a'][a:b].ravel()
        np.testing.assert_allclose(trace.settlement_price,p,atol=1e-10,rtol=0)
        for j,row in trace.iterrows():
            day=a+j//144;t=j%144
            issued=date_map[row.price_forecast_issue_date]
            expected_issue=day+1 if t==143 and day<b-1 else day
            expected_hour=0 if expected_issue==day+1 else max(h for h in price_hours if starts[h]<=t)
            if issued!=expected_issue or row.price_forecast_hour!=expected_hour:
                raise ValueError('Price is not the latest enabled vintage under the declared local end rule')
            if row.forecast_hour!=max(h for h in pv_hours if starts[h]<=t):
                raise ValueError('PV is not the latest enabled forecast vintage')
            if issued==day+1:
                if t!=143 or row.price_forecast_hour!=0:raise ValueError('Unavailable next-date price vintage')
                expected=data['bridge_price_forecast'][issued]
            else:
                if issued!=day or row.price_forecast_hour not in (0,6,12,18):
                    raise ValueError('Unavailable price issue date or hour')
                if t<{0:0,6:35,12:71,18:107}[row.price_forecast_hour]:
                    raise ValueError('Unavailable future price vintage')
                version=(0,6,12,18).index(row.price_forecast_hour)
                expected=(data['price_nodes_a'][day,t]+data['price_nodes_f'][day,version,t+1])/2
            if not np.isfinite(expected) or expected<=0:raise ValueError('Invalid expected causal price')
            if abs(row.control_price_forecast-expected)>1e-9:raise ValueError('Control used an unavailable price endpoint/version')
        ordinary=p*trace.g_kwh
        adjustment=p*(1.5*np.maximum(trace.q_kwh-trace.g_kwh,0)-.5*np.maximum(trace.g_kwh-trace.q_kwh,0))
        emergency=p*5*trace.emergency_kwh
        cash=ordinary+adjustment+emergency
        for column,values in [('ordinary_cost_yuan',ordinary),('adjustment_cost_yuan',adjustment),('emergency_cost_yuan',emergency)]:
            np.testing.assert_allclose(trace[column],values,atol=1e-7,rtol=0)
        np.testing.assert_allclose(trace.cash_cost_yuan,cash,atol=1e-7,rtol=0)
        np.testing.assert_allclose(trace.soc_start_kwh.iloc[1:],trace.soc_end_kwh.iloc[:-1],atol=1e-8,rtol=0)
        if abs(trace.soc_start_kwh.iloc[0]-6000.)>1e-8:raise ValueError('Different local initial SOC')
        loss=.1*trace.charge_kwh+(1/.9-1)*trace.discharge_kwh
        np.testing.assert_allclose(trace.battery_loss_kwh,loss,atol=1e-8,rtol=0)
        flow=trace.q_kwh+trace.pv_energy_kwh-trace.curtailed_pv_kwh-trace.unused_paid_kwh+trace.discharge_kwh+trace.emergency_kwh-trace.load_energy_kwh-trace.charge_kwh
        storage=trace.soc_end_kwh-trace.soc_start_kwh-.9*trace.charge_kwh+trace.discharge_kwh/.9
        np.testing.assert_allclose(flow,0,atol=1e-7,rtol=0)
        np.testing.assert_allclose(storage,0,atol=1e-7,rtol=0)
        errors=np.concatenate((1200-trace.soc_end_kwh,trace.soc_end_kwh-10800,
            trace.charge_kwh-5000/6,trace.discharge_kwh-5000/6,
            -trace.g_kwh,-trace.q_kwh,-trace.charge_kwh,-trace.discharge_kwh,-trace.emergency_kwh,
            -trace.unused_paid_kwh,-trace.curtailed_pv_kwh,
            np.minimum(trace.charge_kwh,trace.discharge_kwh),trace.unused_paid_kwh-trace.q_kwh,
            trace.curtailed_pv_kwh-trace.pv_energy_kwh,trace.emergency_kwh-trace.load_energy_kwh))
        if errors.max()>1e-6:raise ValueError('Ten-minute physical limits fail')
        summary={key:float(trace[key].sum()) for key in ('cash_cost_yuan','ordinary_cost_yuan','adjustment_cost_yuan',
            'emergency_cost_yuan','emergency_kwh','load_energy_kwh','pv_energy_kwh','charge_kwh','discharge_kwh',
            'battery_loss_kwh','q_kwh','unused_paid_kwh','curtailed_pv_kwh')}
        summary.update(soc_start_kwh=float(trace.soc_start_kwh.iloc[0]),soc_end_kwh=float(trace.soc_end_kwh.iloc[-1]),
            inventory_adjusted_cost_yuan=float(cash.sum()-nu*(trace.soc_end_kwh.iloc[-1]-trace.soc_start_kwh.iloc[0])),
            intervals=len(trace),minute_intervals=0)
        summary['energy_balance_residual_kwh']=float(flow.sum())
        summary['battery_balance_residual_kwh']=float(storage.sum())
        ledger_error=float(np.max(np.abs(cash-trace.cash_cost_yuan)))
        check=dict(variant=label,tenminute_rows=len(trace),maximum_cash_error_yuan=ledger_error)
        if label=='10min_mean':
            np.testing.assert_allclose(trace.load_energy_kwh,data['load_a'][a:b].ravel()/6,atol=1e-8,rtol=0)
            np.testing.assert_allclose(trace.pv_energy_kwh,data['pv_a'][a:b].ravel()/6,atol=1e-8,rtol=0)
            if np.minimum(trace.charge_kwh,trace.emergency_kwh).max()>1e-7:raise ValueError('Mean model emergency energy charged')
        else:
            micro=pd.read_csv(folder/f'micro_trace_{label}.csv.gz')
            minutes=float(label.removesuffix('min_causal'));count=int(round(10/minutes))
            if len(micro)!=len(trace)*count:raise ValueError('Wrong number of micro intervals')
            begin=pd.to_datetime(micro.interval_start);end=pd.to_datetime(micro.interval_end)
            np.testing.assert_allclose((end-begin).dt.total_seconds(),minutes*60,atol=1e-9,rtol=0)
            np.testing.assert_array_equal(begin.iloc[1:].to_numpy(),end.iloc[:-1].to_numpy())
            c=micro.charge_kwh;d=micro.discharge_kwh;e=micro.emergency_kwh
            L=micro.load_observed_left_kw*minutes/60;G=micro.pv_observed_left_kw*minutes/60
            if not np.isfinite(micro.select_dtypes(include='number').to_numpy()).all():raise ValueError('Nonfinite micro ledger value')
            flow=micro.q_kwh+G-micro.curtailed_pv_kwh-micro.unused_paid_kwh+d+e-L-c
            storage=micro.soc_end_kwh-micro.soc_start_kwh-.9*c+d/.9
            errors=np.concatenate((np.abs(flow),np.abs(storage),1200-micro.soc_end_kwh,
                micro.soc_end_kwh-10800,c-5000*minutes/60,d-5000*minutes/60,
                -c,-d,-e,-micro.unused_paid_kwh,-micro.curtailed_pv_kwh,
                np.minimum(c,d),np.minimum(c,e),micro.unused_paid_kwh-micro.q_kwh,
                micro.curtailed_pv_kwh-G,e-L))
            physical=float(max(errors.max(),0))
            if physical>1e-6:raise ValueError(f'Micro physical constraints fail: {physical}')
            np.testing.assert_allclose(micro.soc_start_kwh.iloc[1:],micro.soc_end_kwh.iloc[:-1],atol=1e-8,rtol=0)
            np.testing.assert_allclose(micro.soc_start_kwh.iloc[::count],trace.soc_start_kwh,atol=1e-8,rtol=0)
            np.testing.assert_allclose(micro.soc_end_kwh.iloc[count-1::count],trace.soc_end_kwh,atol=1e-8,rtol=0)
            np.testing.assert_allclose(micro.q_kwh,np.repeat(trace.q_kwh.to_numpy()/count,count),atol=1e-8,rtol=0)
            group=np.arange(len(micro))//count
            for column in ('q_kwh','charge_kwh','discharge_kwh','emergency_kwh','unused_paid_kwh','curtailed_pv_kwh'):
                values=micro[column].groupby(group).sum()
                np.testing.assert_allclose(values,trace[column],atol=1e-7,rtol=0)
            np.testing.assert_allclose(L.groupby(group).sum(),trace.load_energy_kwh,atol=1e-7,rtol=0)
            np.testing.assert_allclose(G.groupby(group).sum(),trace.pv_energy_kwh,atol=1e-7,rtol=0)
            direction=micro.command_direction.to_numpy().reshape(-1,count)
            np.testing.assert_array_equal(direction,np.repeat(direction[:,0,None],count,axis=1))
            if not np.isin(direction,['charge','discharge_or_idle']).all():raise ValueError('Unknown control direction')
            if np.where(micro.command_direction=='charge',d,c).max()>1e-7:raise ValueError('Micro action contradicts frozen direction')
            budget=np.cumsum(d.to_numpy().reshape(-1,count),axis=1)+micro.remaining_block_discharge_budget_kwh.to_numpy().reshape(-1,count)
            np.testing.assert_allclose(budget,np.repeat(budget[:,0,None],count,axis=1),atol=1e-7,rtol=0)
            if budget.max()>5000/6+1e-7 or micro.remaining_block_discharge_budget_kwh.min()<-1e-7:raise ValueError('Discharge budget is invalid')
            if np.max(np.minimum(trace.charge_kwh,trace.discharge_kwh))>1e-7:
                raise ValueError('Ten-minute direction reversed')
            # Every finer substep is settled at its enclosing ten-minute rate.
            np.testing.assert_allclose(micro.tenminute_settlement_price,np.repeat(p,count),atol=1e-10,rtol=0)
            # Independently verify linear artificial signal construction and
            # left-hold integration; this check is separate from optimization.
            frac=np.tile(np.arange(count)/count,len(trace))
            for key in ('load','pv'):
                nodes=data[f'{key}_nodes'][a:b]
                signal=np.repeat(nodes[:,:-1].ravel(),count)*(1-frac)+np.repeat(nodes[:,1:].ravel(),count)*frac
                np.testing.assert_allclose(micro[f'{key}_observed_left_kw'],signal,atol=1e-7,rtol=0)
            price_nodes=data['price_nodes_a'][a:b]
            price_signal=np.repeat(price_nodes[:,:-1].ravel(),count)*(1-frac)+np.repeat(price_nodes[:,1:].ravel(),count)*frac
            np.testing.assert_allclose(micro.price_observed_left,price_signal,atol=1e-9,rtol=0)
            summary['minute_intervals']=len(micro)
            check.update(micro_rows=len(micro),maximum_physical_error_kwh=physical)
        for key,value in summary.items():
            np.testing.assert_allclose(report['summary'][label][key],value,atol=1e-5,rtol=0,err_msg=f'Summary {label}/{key} differs from ledger')
        recomputed[label]=summary
        checks.append(check)
    for label,summary in recomputed.items():
        if label=='10min_mean':continue
        minutes=float(label.removesuffix('min_causal'))
        for key,value in report['fine_minus_mean'][label].items():
            np.testing.assert_allclose(value,summary[key]-recomputed['10min_mean'][key],atol=1e-5,rtol=0)
        for key in ('load','pv'):
            actual=summary[f'{key}_energy_kwh']-recomputed['10min_mean'][f'{key}_energy_kwh']
            theoretical=minutes*(data[f'{key}_nodes'][a,0]-data[f'{key}_nodes'][b-1,-1])/120
            np.testing.assert_allclose(actual,theoretical,atol=1e-5,rtol=0)
            for kind in ('observed_bias_kwh','analytical_bias_kwh'):
                np.testing.assert_allclose(report['signal_energy_integration_checks'][label][kind][key],actual,atol=1e-5,rtol=0)
    result=dict(strategy=report['source_strategy'],checks=checks,passed=True)
    (folder/'independent_audit.json').write_text(json.dumps(result,indent=2,ensure_ascii=False))
    return result


def audit_study(result_root, data_dir=ROOT/'data'):
    data=load_inputs(data_dir);folders=sorted((Path(result_root)/'causal_replay').glob('Q*/summary.json'))
    if len(folders)!=4:raise ValueError('Expected four completed replay policies')
    results=[audit_replay(path.parent,data) for path in folders]
    result=dict(passed=True,policies=results)
    (Path(result_root)/'causal_replay/independent_audit.json').write_text(json.dumps(result,indent=2,ensure_ascii=False))
    return result


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--results',type=Path,default=ROOT/'results/final')
    p.add_argument('--data',type=Path,default=ROOT/'data');args=p.parse_args()
    print(json.dumps(audit_study(args.results,args.data),ensure_ascii=False))
