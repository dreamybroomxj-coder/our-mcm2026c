"""Joint whole-path residual scenarios with explicitly separate release clocks."""
import datetime as dt
import numpy as np

START={0:0,6:35,12:71,18:107}
HOURS=(0,6,12,18)


def available_history(data,day,decision_hour,window=28):
    cutoff=dt.datetime.combine(data['dates'][day],dt.time(decision_hour))
    return [j for j in range(day) if data['window_end'][j]<=cutoff][-window:]


def latest_hour(enabled_hours,target_index):
    return max(h for h in enabled_hours if START[h]<=target_index)


def future_mask(trade_hours,target_index):
    later=[START[h] for h in trade_hours if h and START[h]>target_index]
    return np.arange(target_index,144)>=min(later) if later else np.zeros(144-target_index,bool)


def current_block(trade_hours,hour):
    later=[START[h] for h in trade_hours if h>hour]
    return START[hour],min(later) if later else 144


def scenario_inputs(data,day,pv_hour,price_hour,decision_hour,begin,config):
    if pv_hour>decision_hour or price_hour>decision_hour or begin<max(START[pv_hour],START[price_hour]):
        raise ValueError('Requested forecast was not yet released or does not cover interval')
    lf=data['load_f'][day,begin:].copy()
    pv=data['policy_pv']
    pf=pv[day,HOURS.index(pv_hour),begin:].copy()
    p=data['price_f'][day,HOURS.index(price_hour),begin:].copy()
    if not np.isfinite(np.r_[lf,pf,p]).all() or (p<=0).any():
        raise ValueError('Invalid available point forecast')
    history=available_history(data,day,decision_hour,config['history_days'])
    meta=dict(forecast_hour=pv_hour,price_hour=price_hour,decision_hour=decision_hour,
        history_indices=history,history_days=len(history),
        history_latest_end=None if not history else data['window_end'][history[-1]].isoformat(),
        price_mode=config['price_mode'],margin_added=False)
    count=config['scenarios']
    if count==1 or len(history)<config['min_history']:
        meta.update(scenarios=1,fallback=count!=1,draw_indices=[])
        return lf[None,:]/6,pf[None,:]/6,p[None,:],meta
    rng=np.random.default_rng(config['seed']+1009*day+59*decision_hour)
    draw=rng.choice(history,min(count,len(history)),replace=False)
    loads=np.maximum(lf+data['load_a'][draw,begin:]-data['load_f'][draw,begin:],0)
    pvs=np.maximum(pf+data['pv_a'][draw,begin:]-pv[draw,HOURS.index(pv_hour),begin:],0)
    predicted_history=data['price_f'][draw,HOURS.index(price_hour),begin:]
    actual_history=data['price_a'][draw,begin:]
    if (predicted_history<=0).any() or (actual_history<=0).any():
        raise ValueError('Multiplicative price scenarios require positive prices')
    log_error=np.log(actual_history/predicted_history)
    if config['price_mode']=='point':
        prices=np.repeat(p[None,:],len(draw),axis=0)
    elif config['price_mode'] in ('joint','shuffled','mean'):
        prices=p*np.exp(log_error)
        if config['price_mode']=='shuffled':
            prices=prices[np.roll(np.arange(len(draw)),1)]
        elif config['price_mode']=='mean':
            prices=np.repeat(prices.mean(axis=0,keepdims=True),len(draw),axis=0)
    else:
        raise ValueError('Unknown price scenario mode')
    if not np.isfinite(prices).all() or (prices<=0).any():
        raise ValueError('Invalid positive price scenarios; no silent clipping')
    meta.update(scenarios=len(draw),fallback=False,draw_indices=draw.tolist(),
        sampling='same-date paired full paths; uniform without replacement',
        price_residual='log(actual/forecast); positive multiplicative reconstruction',
        scenario_price_min=float(prices.min()),scenario_price_max=float(prices.max()))
    return loads/6,pvs/6,prices,meta
