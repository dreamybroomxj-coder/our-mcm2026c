"""Build audited Q4-2/Q4-3 workbooks and both sets of required paper tables.

This module never optimizes dispatch or modifies source ledgers/templates.
Call build_reports(data_dir, results_dir, selected_q42, selected_q43, out_dir) after replay.
"""
from __future__ import annotations

import argparse
import csv
from datetime import datetime, timedelta
import hashlib
import json
import math
from pathlib import Path
import shutil

from openpyxl import Workbook, load_workbook
from openpyxl.chart import BarChart, Reference
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

DATES=('2025-03-20','2025-06-21','2025-09-23','2025-12-21')
SLOTS=('10:00','12:00','14:00','16:00','18:00','20:00')
EPS=1e-5
NUMERIC=('price_yuan_per_kwh','load_forecast_kw','pv_forecast_kw','load_actual_kw',
    'pv_actual_kw','g_kwh','q_kwh','increase_kwh','decrease_kwh','charge_kwh',
    'discharge_kwh','emergency_kwh','unused_paid_kwh','curtailed_pv_kwh',
    'soc_start_kwh','soc_end_kwh','plan_cost_yuan','increase_cost_yuan','refund_yuan',
    'penalty_yuan','adjustment_net_cost_yuan','emergency_cost_yuan','cash_cost_yuan')
SUM_FIELDS=('g_kwh','q_kwh','increase_kwh','decrease_kwh','charge_kwh','discharge_kwh',
    'emergency_kwh','unused_paid_kwh','curtailed_pv_kwh','plan_cost_yuan',
    'increase_cost_yuan','refund_yuan','penalty_yuan','adjustment_net_cost_yuan',
    'emergency_cost_yuan','cash_cost_yuan')
LABELS={'strategy':'策略','date':'日期','g_kwh':'零点原计划量(kWh)',
    'q_kwh':'调整后普通购电量(kWh)','increase_kwh':'增购量(kWh)',
    'decrease_kwh':'取消量(kWh)','charge_kwh':'充电量(kWh)',
    'discharge_kwh':'放电量(kWh)','emergency_kwh':'紧急购电量(kWh)',
    'unused_paid_kwh':'已付未用电量(kWh)','curtailed_pv_kwh':'弃光量(kWh)',
    'plan_cost_yuan':'原计划费(元)','increase_cost_yuan':'增购费(元)',
    'refund_yuan':'取消退原费(元，正数)','penalty_yuan':'取消违约费(元)',
    'adjustment_net_cost_yuan':'调整净费用(元)','emergency_cost_yuan':'紧急费(元)',
    'cash_cost_yuan':'总现金费(元)','ordinary_cost_yuan':'普通购电结算费(元)',
    'soc_start_kwh':'起点储电量(kWh)','soc_end_kwh':'终点储电量(kWh)',
    'startup_cost_yuan':'首日初始化段费(元)','cash_including_startup_yuan':'含首段总费(元)',
    'inventory_adjusted_cost_yuan':'库存修正评价(元，非电费)',
    'natural_period_cash_cost_yuan':'2月1日至12月31日自然日期间费(元)',
    'intervals':'区间数','selected':'主展示策略','retrospective_best':'同分支回溯现金最低'}


LABELS.update({'solver_calls':'优化求解次数','solver_unproven':'未证明达到请求Gap次数','solver_max_gap_percent':'最大相对Gap(%)','solver_seconds':'累计求解时间(秒)','branch':'问题分支','price_mode':'价格不确定性方案','trade_hours':'合同调整时刻','forecast_hours':'光伏预报启用时刻','price_hours':'电价预报启用时刻','pv_source':'光伏数据来源模式','main_selection_candidate':'是否属于原主候选集合','common_inventory_value':'共同库存评价价(元/kWh，非电费)','tail_cost_yuan':'跨年末段费(元)','price_yuan_per_kwh':'实际区间电价(元/kWh)','price_forecast_yuan_per_kwh':'优化预测区间电价(元/kWh)','actual_estimated':'功率实际量含估计','price_estimated':'实际价格含边界估计','interval_start':'执行区间起点','interval_end':'执行区间终点'})


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def total(rows,key):return math.fsum(r[key] for r in rows)
def as_bool(v):return str(v).strip().lower() in ('true','1','yes')
def near(a,b,label,tol=EPS):
    error=abs(a-b)
    if error>tol:raise AssertionError(f'{label}: {a} vs {b}, error={error}')
    return error


def read_trace(path,*,strategy=None):
    with Path(path).open(encoding='utf-8-sig',newline='') as f:raw=list(csv.DictReader(f))
    if not raw:raise ValueError(f'Empty ledger: {path}')
    rows=[]
    for r in raw:
        if strategy is not None and r.get('strategy') and r['strategy']!=strategy:
            # A shared startup file can contain all strategy rows; select exact.
            continue
        v=dict(r)
        for k in NUMERIC:
            if k not in r or r[k] in ('',None):raise ValueError(f'{path}: missing {k}')
            v[k]=float(r[k])
            if not math.isfinite(v[k]):raise ValueError(f'{path}: nonfinite {k}')
        v['actual_estimated']=as_bool(r.get('actual_estimated',False))
        v['price_estimated']=as_bool(r.get('price_estimated',False))
        if r.get('price_forecast_yuan_per_kwh') not in ('',None):
            v['price_forecast_yuan_per_kwh']=float(r['price_forecast_yuan_per_kwh'])
            if not math.isfinite(v['price_forecast_yuan_per_kwh']):raise ValueError('Nonfinite forecast price')
        for key in ('interval_start','interval_end'):
            v[key]=datetime.fromisoformat(r[key]).isoformat()
        if strategy is not None:v['strategy']=strategy
        rows.append(v)
    rows.sort(key=lambda r:r['interval_start'])
    return rows


def audit_trace(rows,*,label,require_contiguous=True):
    """Verify ledger algebra. Finer execution causality remains runner-tested."""
    max_balance=max_soc=max_cash=max_components=0.
    starts=set();prev=None
    for r in rows:
        a=datetime.fromisoformat(r['interval_start']);b=datetime.fromisoformat(r['interval_end'])
        if b-a!=timedelta(minutes=10) or a.minute%10:raise AssertionError('Bad interval')
        if a in starts:raise AssertionError('Duplicate execution interval')
        starts.add(a)
        if prev is not None and require_contiguous:
            if prev['interval_end']!=r['interval_start']:raise AssertionError('Noncontiguous ledger')
            near(prev['soc_end_kwh'],r['soc_start_kwh'],'cross-interval SOC')
        p=r['price_yuan_per_kwh'];g=r['g_kwh'];q=r['q_kwh'];up=r['increase_kwh'];down=r['decrease_kwh']
        c=r['charge_kwh'];d=r['discharge_kwh'];e=r['emergency_kwh']
        v=r['unused_paid_kwh'];curtail=r['curtailed_pv_kwh']
        load=r['load_actual_kw']/6;pv=r['pv_actual_kw']/6
        if min(p,g,q,up,down,c,d,e,v,curtail)<-EPS:raise AssertionError('Negative physical value')
        if min(up,down)>EPS:raise AssertionError('Simultaneous increase/cancellation')
        if max(c,d)>5000/6+EPS:raise AssertionError('Battery power limit')
        if min(c,d)>EPS:raise AssertionError('Simultaneous charge and discharge')
        if e>EPS and c>EPS:raise AssertionError('Emergency purchase cannot charge battery')
        if v>q+EPS or curtail>pv+EPS:raise AssertionError('Waste exceeds available source')
        for s in ('soc_start_kwh','soc_end_kwh'):
            if not 1200-EPS<=r[s]<=10800+EPS:raise AssertionError('SOC bound')
        max_balance=max(max_balance,near(q-v+pv-curtail+d+e,load+c,'AC energy balance'))
        max_soc=max(max_soc,near(r['soc_end_kwh'],r['soc_start_kwh']+.9*c-d/.9,'SOC equation'))
        values=((q,g+up-down,'q=g+increase-decrease'),
            (r['plan_cost_yuan'],p*g,'original cost'),
            (r['increase_cost_yuan'],1.5*p*up,'increase cost'),
            (r['refund_yuan'],p*down,'refund positive magnitude'),
            (r['penalty_yuan'],.5*p*down,'penalty'),
            (r['adjustment_net_cost_yuan'],1.5*p*up-.5*p*down,'net adjustment'),
            (r['emergency_cost_yuan'],5*p*e,'emergency cost'))
        for x,y,name in values:max_components=max(max_components,near(x,y,name))
        max_cash=max(max_cash,near(r['cash_cost_yuan'],p*g+1.5*p*up-.5*p*down+5*p*e,'cash'))
        prev=r
    return {'label':label,'intervals':len(rows),'first_interval':rows[0]['interval_start'] if rows else None,
        'last_interval_end':rows[-1]['interval_end'] if rows else None,
        'max_balance_error_kwh':max_balance,'max_soc_error_kwh':max_soc,
        'max_component_error':max_components,'max_cash_error_yuan':max_cash,
        'actual_estimated_intervals':sum(r['actual_estimated'] for r in rows),
        'price_estimated_intervals':sum(r.get('price_estimated',False) for r in rows),
        'scope':'aggregate physical/transaction ledger; within-interval mode/causality checked separately in runner tests'}


def summarize(rows,strategy,date=None):
    out={k:total(rows,k) for k in SUM_FIELDS}
    out.update(strategy=strategy,date=date,intervals=len(rows),soc_start_kwh=rows[0]['soc_start_kwh'],
        soc_end_kwh=rows[-1]['soc_end_kwh'],ordinary_cost_yuan=out['plan_cost_yuan']+out['adjustment_net_cost_yuan'])
    near(out['cash_cost_yuan'],out['ordinary_cost_yuan']+out['emergency_cost_yuan'],'summary cash')
    return out


def day_groups(rows,*,full_only=True):
    groups={}
    for r in rows:groups.setdefault(r['interval_start'][:10],[]).append(r)
    out={}
    for date,rs in sorted(groups.items()):
        start=datetime.fromisoformat(date)
        full=len(rs)==144 and all(datetime.fromisoformat(r['interval_start'])==start+timedelta(minutes=10*i) for i,r in enumerate(rs))
        if full:out[date]=rs
        elif not full_only:out[date]=rs
    return out


def episodes(rows):
    """Merge positive e intervals; never join across a calendar midnight."""
    out=[];active=None
    for r in rows:
        same=active is not None and active['end']==r['interval_start'] and active['date']==r['interval_start'][:10]
        if r['emergency_kwh']>EPS:
            if not same:
                if active is not None:out.append(active)
                active={'date':r['interval_start'][:10],'start':r['interval_start'],'end':r['interval_end'],
                    'parts':[r['emergency_kwh']]}
            else:
                active['end']=r['interval_end'];active['parts'].append(r['emergency_kwh'])
        elif active is not None:
            out.append(active);active=None
    if active is not None:out.append(active)
    for e in out:
        e['kwh']=math.fsum(e.pop('parts'))
        end='24:00' if e['end'][:10]!=e['date'] else e['end'][11:16]
        e['label']=e['start'][11:16]+'—'+end
    near(math.fsum(e['kwh'] for e in out)+math.fsum(r['emergency_kwh'] for r in rows if r['emergency_kwh']<=EPS),
         total(rows,'emergency_kwh'),'episode sum')
    return out


def style(ws,*,width=20,header_rows=(1,)):
    ws.sheet_view.showGridLines=False
    ws.freeze_panes='B2'
    ws.sheet_properties.pageSetUpPr.fitToPage=True
    ws.page_setup.orientation='landscape';ws.page_setup.paperSize=ws.PAPERSIZE_A4
    ws.page_setup.fitToWidth=1;ws.page_setup.fitToHeight=0
    for col in range(1,ws.max_column+1):ws.column_dimensions[get_column_letter(col)].width=width
    for row in ws:
        ws.row_dimensions[row[0].row].height=27
        for c in row:
            c.font=Font(name='微软雅黑',size=10,color='25354A')
            c.alignment=Alignment(horizontal='center',vertical='center',wrap_text=True)
            if isinstance(c.value,(int,float)):c.number_format='#,##0.0000'
            if c.value is not None:c.border=Border(bottom=Side(style='hair',color='D5DFE7'))
            if c.row in header_rows:
                c.fill=PatternFill('solid',fgColor='213C56');c.font=Font(name='微软雅黑',size=10,bold=True,color='FFFFFF')
            elif c.row%2==0:c.fill=PatternFill('solid',fgColor='F1F6F8')
    ws.print_area=ws.dimensions


def table_sheet(book,name,rows,fields):
    ws=book.create_sheet(name);ws.append([LABELS.get(k,k) for k in fields])
    for r in rows:ws.append([r.get(k) for k in fields])
    style(ws)
    ws.auto_filter.ref=ws.dimensions
    for i,k in enumerate(fields,1):
        if k.endswith('_yuan'):
            for j in range(2,ws.max_row+1):ws.cell(j,i).number_format='#,##0.00'
    return ws


def add_notes(book,selected,variant,selection,*,startup_present):
    ws=book.create_sheet('口径说明',0);ws.append(['事项','说明'])
    notes=[('问题分支',variant),('主展示策略',selected),('选择记录',json.dumps(selection,ensure_ascii=False,default=str)),
        ('合同窗口','行日期D的D00:10至D+1 00:10，共144个10分钟区间；不能当成00:00—24:00自然日。'),
        ('波动电价','price_yuan_per_kwh为供电区间实际价格端点均值；本轮所有实际费用项采用同一交付段实际均价。预测价格只进入优化，不冒充实际结算价。'),
        ('价格近似','节点均价是区间均价近似；它与任意连续价格、功率曲线的精确积分并非自动相同。'),
        ('原计划购电表','Q4-2：填g，全天量Σg，全天费=实际原计划费+紧急费。Q4-3：填原g，全天量Σg，全天费仅为原计划结算费。'),
        ('调整购电表','仅Q4-3：填最终普通总量q，不填差额；全天量Σq，全天费=原计划费+增购费−退费+违约费+紧急费。'),
        ('费用公式','Q4-2：pg+5pe。Q4-3：pg+1.5pa−pb+0.5pb+5pe。取消退费按正数列示、汇总时减去；紧急费计一次。'),
        ('付款与用电','普通g/q按合同支付；已付未用v不自动退款。正式取消b才按退原费用并收50%违约费结算。紧急电仅补负载，不充电。'),
        ('自然日储能','按interval_start汇总00:00—24:00；首段来自前一合同，00:00/24:00储电量取实际执行状态。'),
        ('首日启动段','单独读取本轮startup.csv；电池静置保持统一6000kWh实验初态，首段g使用本轮预测、紧急量和费用按实际运行结算。' if startup_present else '未提供首段，不补造自然日结果。'),
        ('初态限制','6000kWh是本轮明确的共同实验初态；不是已模拟1月份运行所得到的2月1日实际SOC。本轮首段和费用不沿用旧第三问数字。'),
        ('跨年末段','12月31日合同含次年1月1日00:00—00:10；该段计合同费，单列跨年明细，不混入12月31日自然日储能和紧急表。'),
        ('总体范围','主总计是334个移位合同；自然日期间费=主合同费+首段费−跨年尾段费；库存修正评价不是实际电费。'),
        ('论文四日表1','Q4-2指定普通量用g；Q4-3用q。全天现金费均含紧急费，另给普通量+紧急量以及费用拆分。'),
        ('紧急事件','连续e>1e−5kWh段合并，跨自然日拆开；低于阈值的量仍在精确现金与每日电量汇总中。无事件日期明确填0。'),
        ('估计标记','actual_estimated标记功率边界估计，price_estimated标记价格端点估计；这些段不冒称全部为实测。'),
        ('单位','功率kW，电量kWh，价格元/kWh，费用元；报表不对账本电量再次乘1/6。'),
        ('表格精度','按未舍入数值求和；显示电量四位小数、费用两位小数，显示数逐项相加可能有舍入差。'),
        ('信息与最优性','本表只读执行轨迹；预测生成、求解Gap、滚动信息可用性以主runner审计为准。不由报表汇总声称全局最优。')]
    for row in notes:ws.append(row)
    style(ws);ws.column_dimensions['A'].width=24;ws.column_dimensions['B'].width=115
    for i in range(2,ws.max_row+1):ws.row_dimensions[i].height=46


def save_verified(book,path):
    expected={(ws.title,c.coordinate):c.value for ws in book for row in ws for c in row if c.value is not None}
    book.save(path);wb=load_workbook(path,data_only=False,read_only=True);checked=0
    try:
        for ws in wb:
            for row in ws:
                for c in row:
                    if c.data_type=='e':raise AssertionError(f'Excel error {ws.title}!{c.coordinate}')
                    if c.value is None:continue
                    want=expected[(ws.title,c.coordinate)]
                    if isinstance(want,(int,float)) and not isinstance(want,bool):
                        if abs(float(c.value)-want)>max(1e-8,abs(want)*1e-12):raise AssertionError('Workbook numeric drift')
                    elif c.value!=want:raise AssertionError(f'Workbook text/date drift: {want!r} -> {c.value!r}')
                    checked+=1
    finally:wb.close()
    return {'path':str(path),'cells_checked':checked,'excel_errors':0,'sha256':sha(path)}


def _contract_groups(rows):
    groups={}
    for row in rows:groups.setdefault(row['window_date'],[]).append(row)
    for day,group in groups.items():
        zero=datetime.fromisoformat(day)
        if len(group)!=144:raise AssertionError(f'Incomplete contract: {day}')
        for i,row in enumerate(group):
            if datetime.fromisoformat(row['interval_start'])!=zero+timedelta(minutes=10*(i+1)):
                raise AssertionError(f'Shifted/missing contract slot: {day}, {i}')
    return dict(sorted(groups.items()))


def _check_template(book,variant):
    required=['计划购电量','充放电量','紧急购电量']+(['调整购电量'] if variant=='Q4-3' else [])
    if any(name not in book for name in required):raise ValueError('Missing original template sheet')
    for name in ['计划购电量']+(['调整购电量'] if variant=='Q4-3' else []):
        ws=book[name]
        if ws.max_column!=147:raise ValueError('Original purchase template must have 147 columns')
        headers=[c.value for c in ws[1]]
        if headers[1]!='0:10-0:20' or headers[143]!='23:50-0:00+1' or headers[144]!='0:00-0:10+1':
            raise ValueError('Original purchase interval headers differ from audited contract')
        if headers[145:]!=['全天购电量','全天购电费']:raise ValueError('Missing template totals')
    return required


def export_result(template,path,rows,startup,selected,variant,selection):
    if variant not in ('Q4-2','Q4-3'):raise ValueError('Unknown question variant')
    book=load_workbook(template);required=_check_template(book,variant);contracts=_contract_groups(rows)
    headers={name:[c.value for c in book[name][1]] for name in required}
    for name in required:
        ws=book[name]
        for merged in list(ws.merged_cells.ranges):
            if merged.min_row>=2:ws.unmerge_cells(str(merged))
        if ws.max_row>=2:ws.delete_rows(2,ws.max_row-1)
    daily_financial=[]
    for day,rs in contracts.items():
        zero=datetime.fromisoformat(day);summary=summarize(rs,selected,day);daily_financial.append(summary)
        fee=summary['cash_cost_yuan'] if variant=='Q4-2' else summary['plan_cost_yuan']
        book['计划购电量'].append([zero]+[r['g_kwh'] for r in rs]+[summary['g_kwh'],fee])
        if variant=='Q4-3':
            book['调整购电量'].append([zero]+[r['q_kwh'] for r in rs]+[summary['q_kwh'],summary['cash_cost_yuan']])
    natural=day_groups(startup+rows)
    if any(day not in natural for day in contracts):raise AssertionError('Every exported natural day requires all 144 observed/executed slots including startup')
    for day in contracts:
        rs=natural[day];ws=book['充放电量']
        for k in range(6):
            block=rs[k*24:(k+1)*24]
            ws.append([datetime.fromisoformat(day) if k==0 else None,f'{4*k}:00-{4*(k+1)}:00',
                total(block,'charge_kwh'),total(block,'discharge_kwh'),
                '0:00' if k==0 else ('24:00' if k==1 else None),
                rs[0]['soc_start_kwh'] if k==0 else (rs[-1]['soc_end_kwh'] if k==1 else None)])
    events_by_day={}
    for event in episodes(startup+rows):events_by_day.setdefault(event['date'],[]).append(event)
    for day in contracts:
        events=events_by_day.get(day,[])
        if events:
            for j,event in enumerate(events):book['紧急购电量'].append([datetime.fromisoformat(day) if j==0 else None,event['label'],event['kwh']])
        else:book['紧急购电量'].append([datetime.fromisoformat(day),'无紧急购电',0.])
    for name in required:
        if [c.value for c in book[name][1]]!=headers[name]:raise AssertionError('Original header modified')
        style(book[name],width=14 if name in ('计划购电量','调整购电量') else 22)
        book[name].column_dimensions['A'].width=16
        for r in range(2,book[name].max_row+1):
            if isinstance(book[name].cell(r,1).value,datetime):book[name].cell(r,1).number_format='yyyy-mm-dd'
            if name in ('计划购电量','调整购电量'):book[name].cell(r,147).number_format='#,##0.00'
    add_notes(book,selected,variant,selection,startup_present=bool(startup))
    table_sheet(book,'逐合同现金明细',daily_financial,('date',)+SUM_FIELDS+('ordinary_cost_yuan','soc_start_kwh','soc_end_kwh'))
    natural_summaries=[summarize(natural[day],selected,day) for day in contracts]
    table_sheet(book,'逐自然日现金明细',natural_summaries,('date',)+SUM_FIELDS+('ordinary_cost_yuan','soc_start_kwh','soc_end_kwh'))
    table_sheet(book,'首日启动段',startup,('interval_start','interval_end','price_forecast_yuan_per_kwh','price_yuan_per_kwh')+SUM_FIELDS+('soc_start_kwh','soc_end_kwh','actual_estimated','price_estimated'))
    tail=[r for r in rows if r['interval_start'][:10]>max(contracts)]
    table_sheet(book,'跨年合同末段',tail,('interval_start','interval_end','price_forecast_yuan_per_kwh','price_yuan_per_kwh')+SUM_FIELDS+('soc_start_kwh','soc_end_kwh','actual_estimated','price_estimated'))
    checked=save_verified(book,path)
    checked.update(contract_days=len(contracts),natural_days=len(natural_summaries),storage_blocks=6*len(contracts),emergency_events=sum(len(events_by_day.get(day,[])) for day in contracts))
    return checked,natural


def paper_tables(path,md_path,natural,selected,variant):
    book=Workbook();book.remove(book.active);summaries={};s1=book.create_sheet('表1_指定购电');s2=book.create_sheet('表2_充放储电')
    quantity='g_kwh' if variant=='Q4-2' else 'q_kwh';symbol='g' if variant=='Q4-2' else 'q'
    heads1=[];heads2=[];md=[f'# 第四问 {variant} 指定四日论文表格','',f'方案：`{selected}`。日期按00:00—24:00自然日，电量kWh，费用元。',
        f'表1普通购电量使用{symbol}；全天费用含紧急费。首段取前一合同，按真实时间戳重组，不每日重置。','']
    for date in DATES:
        if date not in natural:raise AssertionError(f'Missing required natural day {date}')
        rs=natural[date];summary=summarize(rs,selected,date);summaries[date]=summary
        for ws,heads,title in [(s1,heads1,'表1 购电量及费用'),(s2,heads2,'表2 实际充放电量')]:
            ws.append([f'{date}｜{variant}｜{selected}｜{title}']);heads.extend([ws.max_row,ws.max_row+1]);ws.merge_cells(start_row=ws.max_row,start_column=1,end_row=ws.max_row,end_column=6)
        s1.append(['时间段',f'普通购电量{symbol}','时间段',f'普通购电量{symbol}','时间段',f'普通购电量{symbol}'])
        md.extend([f'## {date}','', '表1：普通购电量与费用','', '| 时间段 | 购电量 | 时间段 | 购电量 | 时间段 | 购电量 |','|---|---:|---|---:|---|---:|'])
        for times in (SLOTS[:3],SLOTS[3:]):
            row=[]
            for t in times:
                ix=int(t[:2])*6
                if rs[ix]['interval_start'][11:16]!=t:raise AssertionError('Specified 10-minute table index shifted')
                row.extend([f'{t}—{t[:3]}10',rs[ix][quantity]])
            s1.append(row);md.append('| '+' | '.join(f'{x:.4f}' if isinstance(x,(int,float)) else x for x in row)+' |')
        s1.append(['全天普通购电量',summary[quantity],'全天购电费(含紧急)',summary['cash_cost_yuan'],'全天紧急量',summary['emergency_kwh']])
        s1.append(['全天总购入量',summary[quantity]+summary['emergency_kwh'],'原计划费',summary['plan_cost_yuan'],'紧急费',summary['emergency_cost_yuan']])
        s1.append(['增购费',summary['increase_cost_yuan'],'退原费用(正数)',summary['refund_yuan'],'违约费',summary['penalty_yuan']]);s1.append([])
        md.extend(['',f"全天普通购电量 **{summary[quantity]:.4f} kWh**；全天现金费（含紧急）**{summary['cash_cost_yuan']:.2f}元**；紧急电量{summary['emergency_kwh']:.4f} kWh。",'',
            '表2：实际充放电量','', '| 时间段 | 充电量 | 放电量 | 时间段 | 充电量 | 放电量 |','|---|---:|---:|---|---:|---:|'])
        s2.append(['时间段','充电量','放电量','时间段','充电量','放电量'])
        for i in (0,2,4):
            row=[]
            for j in (i,i+1):
                block=rs[j*24:(j+1)*24];row.extend([f'{4*j:02d}:00—{4*(j+1):02d}:00',total(block,'charge_kwh'),total(block,'discharge_kwh')])
            s2.append(row);md.append('| '+' | '.join(f'{x:.4f}' if isinstance(x,(int,float)) else x for x in row)+' |')
        s2.append(['00:00储电量',summary['soc_start_kwh'],None,'24:00储电量',summary['soc_end_kwh'],None]);s2.append([])
        md.extend(['',f"00:00储电量：**{summary['soc_start_kwh']:.4f} kWh**；24:00储电量：**{summary['soc_end_kwh']:.4f} kWh**。",''])
    style(s1,header_rows=heads1);style(s2,header_rows=heads2)
    s3=book.create_sheet('表3_连续紧急购电');s3.append([f'{variant}｜{selected}｜指定四日紧急购电(kWh)']);s3.merge_cells('A1:H1')
    s3.append([v for d in DATES for v in (d,None)])
    for col in (1,3,5,7):s3.merge_cells(start_row=2,start_column=col,end_row=2,end_column=col+1)
    s3.append(['时间段','购电量']*4);by_date={date:episodes(natural[date]) for date in DATES}
    md.extend(['## 表3：连续紧急购电','', '| '+' | '.join(d+'时段 | 电量' for d in DATES)+' |','|---|---:|---|---:|---|---:|---|---:|'])
    for i in range(max(1,max(map(len,by_date.values())))):
        row=[]
        for date in DATES:
            es=by_date[date];row.extend([es[i]['label'],es[i]['kwh']] if i<len(es) else (['无紧急购电',0.] if not es and i==0 else [None,None]))
        s3.append(row);md.append('| '+' | '.join('' if x is None else (f'{x:.4f}' if isinstance(x,(int,float)) else x) for x in row)+' |')
    style(s3,header_rows=(1,2,3));table_sheet(book,'四日现金汇总',list(summaries.values()),('date',)+SUM_FIELDS+('ordinary_cost_yuan','soc_start_kwh','soc_end_kwh'))
    md.extend(['','连续事件阈值为1e−5kWh，跨午夜拆开；低于阈值电量仍保留于完整账本的精确电量和费用。'])
    Path(md_path).write_text('\n'.join(md)+'\n',encoding='utf-8');return save_verified(book,path),summaries


def _write_csv(path,rows,fields):
    with Path(path).open('w',newline='',encoding='utf-8-sig') as stream:
        writer=csv.DictWriter(stream,fieldnames=fields);writer.writeheader();writer.writerows({key:r.get(key) for key in fields} for r in rows)


def build_reports(data_dir,results_dir,selected_q42,selected_q43,out_dir=None):
    """Export both selected branches and compare every completed main strategy.

    ``results_dir`` normally contains main/<strategy>/trace.csv and selection.json.
    Explicit selected names are mandatory and never replaced by retrospective cost.
    """
    data_dir=Path(data_dir);results_dir=Path(results_dir);out_dir=Path(out_dir) if out_dir else results_dir/'reports';out_dir.mkdir(parents=True,exist_ok=True)
    main=results_dir/'main' if (results_dir/'main').exists() else results_dir
    selection_path=results_dir/'selection.json';selection=json.loads(selection_path.read_text(encoding='utf-8')) if selection_path.exists() else {'selected_q42':selected_q42,'selected_q43':selected_q43,'source':'explicit build_reports arguments'}
    for key,value in [('selected_q42',selected_q42),('selected_q43',selected_q43)]:
        if key in selection and isinstance(selection[key],str) and selection[key]!=value:raise AssertionError('Explicit selection conflicts with frozen selection file')
    paths=sorted(main.glob('*/trace.csv'))
    if not paths:raise ValueError('No completed main strategy traces')
    selected_rows={};selected_startup={};audits=[];summaries=[];monthly=[];hashes={}
    expected_dates=[(datetime(2025,2,1)+timedelta(days=i)).date().isoformat() for i in range(334)]
    for path in paths:
        name=path.parent.name;rows=read_trace(path,strategy=name);hashes[str(path)]=sha(path)
        contracts=_contract_groups(rows)
        if list(contracts)!=expected_dates:raise AssertionError(f'{name}: expected all 334 February-December contracts')
        sp=path.parent/'startup.csv'
        if not sp.exists():raise FileNotFoundError(f'Missing first natural-day segment for {name}')
        startup=read_trace(sp,strategy=name);hashes[str(sp)]=sha(sp)
        if len(startup)!=1 or startup[0]['interval_start']!='2025-02-01T00:00:00' or startup[0]['interval_end']!=rows[0]['interval_start']:
            raise AssertionError('Expected one explicit 00:00-00:10 startup segment')
        audits.append(audit_trace(startup+rows,label=name+' including startup'))
        if name.startswith('Q42'):
            for r in rows:
                if abs(r['q_kwh']-r['g_kwh'])>EPS or max(r['increase_kwh'],r['decrease_kwh'])>EPS:raise AssertionError('Q4-2 must retain fixed ordinary contract')
        source_path=path.parent/'summary.json';source=json.loads(source_path.read_text(encoding='utf-8'));hashes[str(source_path)]=sha(source_path)
        if source.get('complete') is not True:raise ValueError('Incomplete main strategy cannot be reported as final')
        s=summarize(rows,name);near(s['cash_cost_yuan'],source['cash_cost_yuan'],'runner main cash',tol=1e-4)
        if 'common_inventory_value' not in source:raise ValueError('Need ex-ante common_inventory_value; never infer it from future actual prices')
        inventory_value=float(source['common_inventory_value']);s['common_inventory_value']=inventory_value
        s['inventory_adjusted_cost_yuan']=s['cash_cost_yuan']-inventory_value*(s['soc_end_kwh']-s['soc_start_kwh'])
        near(s['inventory_adjusted_cost_yuan'],source['inventory_adjusted_cost_yuan'],'runner inventory evaluation',tol=1e-4)
        natural=day_groups(startup+rows)
        if not all(day in natural for day in expected_dates):raise AssertionError('Natural-day coverage incomplete')
        startup_cash=total(startup,'cash_cost_yuan');tail=[r for r in rows if r['interval_start'][:10]>'2025-12-31']
        s.update(branch='Q4-2' if name.startswith('Q42') else 'Q4-3',selected=name in (selected_q42,selected_q43),
            startup_cost_yuan=startup_cash,tail_cost_yuan=total(tail,'cash_cost_yuan'),cash_including_startup_yuan=s['cash_cost_yuan']+startup_cash,
            natural_period_cash_cost_yuan=sum(total(natural[day],'cash_cost_yuan') for day in expected_dates),
            actual_estimated_intervals=sum(r['actual_estimated'] for r in rows),price_estimated_intervals=sum(r.get('price_estimated',False) for r in rows),
            solver_calls=source.get('solver',{}).get('solves'),solver_unproven=source.get('solver',{}).get('unproven'),solver_max_gap_percent=100*source.get('solver',{}).get('max_gap',0),solver_seconds=source.get('solver',{}).get('seconds'),
            price_mode=source.get('config',{}).get('price_mode'),pv_source=source.get('config',{}).get('pv_source','supplied'),main_selection_candidate=source.get('config',{}).get('pv_source','supplied')=='supplied',trade_hours=json.dumps(source.get('config',{}).get('trade_hours')),
            forecast_hours=json.dumps(source.get('config',{}).get('forecast_hours')),price_hours=json.dumps(source.get('config',{}).get('price_hours')))
        near(s['natural_period_cash_cost_yuan'],s['cash_cost_yuan']+startup_cash-s['tail_cost_yuan'],'natural/contract fee identity',tol=1e-4)
        summaries.append(s)
        monthgroups={}
        for r in rows:monthgroups.setdefault(r['window_date'][:7],[]).append(r)
        monthly.extend(summarize(rs,name,month) for month,rs in monthgroups.items())
        if name in (selected_q42,selected_q43):selected_rows[name]=rows;selected_startup[name]=startup
    if set(selected_rows)!={selected_q42,selected_q43}:raise ValueError('Selected Q4-2 or Q4-3 trace unavailable')
    for s in summaries:
        branch=[r for r in summaries if r['branch']==s['branch'] and r['main_selection_candidate']]
        s['retrospective_best']=s['main_selection_candidate'] and s['strategy']==min(branch,key=lambda r:r['cash_cost_yuan'])['strategy']
    summaries.sort(key=lambda s:(s['branch'],s['cash_cost_yuan']))
    book=Workbook();book.remove(book.active)
    fields=('strategy','branch','selected','retrospective_best','cash_cost_yuan','inventory_adjusted_cost_yuan','plan_cost_yuan','increase_cost_yuan','refund_yuan','penalty_yuan','adjustment_net_cost_yuan','emergency_cost_yuan','q_kwh','emergency_kwh','soc_start_kwh','soc_end_kwh','startup_cost_yuan','tail_cost_yuan','natural_period_cash_cost_yuan','common_inventory_value','solver_calls','solver_unproven','solver_max_gap_percent','solver_seconds','price_mode','pv_source','main_selection_candidate','trade_hours','forecast_hours','price_hours')
    table_sheet(book,'全策略费用比较',summaries,fields);table_sheet(book,'分月合同费用',monthly,('strategy','date','cash_cost_yuan','plan_cost_yuan','adjustment_net_cost_yuan','emergency_cost_yuan','emergency_kwh','soc_end_kwh'))
    note=book.create_sheet('总体口径');note.append(['事项','解释']);note.append(['主推荐',f'Q4-2={selected_q42}; Q4-3={selected_q43}']);note.append(['费用范围','主费用是334个00:10至次日00:10合同；自然日费另加启动、减跨年尾段。']);note.append(['比较限制','共同初态、物理规则和结算口径；Q4-2与Q4-3的光伏信息不同，另设同光伏对照。事后最低指已完整回放的原输入主候选中现金最低，同PV消融不参与；不代表全部16组合均完成全年比较；库存评价非实际费。']);style(note)
    checks=[save_verified(book,out_dir/'第四问_总体比较.xlsx')];four_days={};natural_counts={}
    for variant,name,filename in [('Q4-2',selected_q42,'result4-2.xlsx'),('Q4-3',selected_q43,'result4-3.xlsx')]:
        template=data_dir/f'{filename[:-5]}_template.xlsx'
        if not template.exists():template=data_dir/filename
        hashes[str(template)]=sha(template)
        checked,natural=export_result(template,out_dir/filename,selected_rows[name],selected_startup[name],name,variant,selection);checks.append(checked);natural_counts[variant]=checked['natural_days']
        paper,days=paper_tables(out_dir/f'第四问_{variant}_指定四日填表.xlsx',out_dir/f'第四问_{variant}_指定四日论文表格.md',natural,name,variant);checks.append(paper);four_days[variant]=days
        source=main/name/'trace.csv';shutil.copy2(source,out_dir/f'{name}_完整逐段账本.csv')
        _write_csv(out_dir/f'{variant}_指定四日逐段.csv',[r for day in DATES for r in natural[day]],list(natural[DATES[0]][0]))
    for path,digest in hashes.items():
        if sha(path)!=digest:raise AssertionError('Report export modified an input')
    _write_csv(out_dir/'第四问_策略费用比较.csv',summaries,fields)
    report={'complete':True,'selected_q42':selected_q42,'selected_q43':selected_q43,'strategy_count':len(summaries),'strategy_summaries':summaries,'trace_audits':audits,'four_day_summary':four_days,'workbook_checks':checks,'source_sha256':hashes,'source_files_unchanged':True,'natural_days_exported':natural_counts,'settlement_rule':'all realized components use the delivery interval actual endpoint-average price; forecasts are planning-only','cash_coverage':'334 shifted contracts; startup and next-year tail separately reconciled to 334 natural days'}
    (out_dir/'报表与账本核验.json').write_text(json.dumps(report,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
    (out_dir/'阅读说明.md').write_text(f'# 第四问调度报表\n\nQ4-2主展示：**{selected_q42}**；Q4-3主展示：**{selected_q43}**。\n\n'
        'result4-2的计划表全天费包括普通计划费与紧急费。result4-3原计划表全天费仅原计划费，调整表全天费为最终现金总费并含紧急费一次；调整144列填最终普通量q。\n\n'
        '全部实际费用使用目标交付区间实际价格端点均值，预测价格只影响决策。取消部分退原费后另收50%违约费。\n\n'
        '储能、紧急事件和指定四日均按自然日汇总；00:00首段取前一合同或本轮启动段，年末次日首段单列。原模板保留表头，示例行扩展为全部334日期。\n\n'
        '总体比较中334合同费、自然日期间费和库存评价分别展示，不能混称同一实际账单。精确数据未舍入，电量显示四位小数、费用两位小数。\n',encoding='utf-8')
    return report


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--data',type=Path,required=True);parser.add_argument('--results',type=Path,required=True);parser.add_argument('--selected-q42',required=True);parser.add_argument('--selected-q43',required=True);parser.add_argument('--out',type=Path)
    args=parser.parse_args();report=build_reports(args.data,args.results,args.selected_q42,args.selected_q43,args.out)
    print(json.dumps({'complete':report['complete'],'strategy_count':report['strategy_count'],'selected_q42':report['selected_q42'],'selected_q43':report['selected_q43']},ensure_ascii=False))
