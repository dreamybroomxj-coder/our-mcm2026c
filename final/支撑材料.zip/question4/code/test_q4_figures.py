"""Dynamic figure-table semantics: preserve freeze and match causal comparisons."""
from pathlib import Path
from copy import deepcopy
import tempfile
import unittest

import numpy as np
import pandas as pd

from q4_figures import Run,Study,monthly_main,schedule_comparison,paired_price_modes,sensitivity_comparison

SCHEDULES=[(0,),(0,6),(0,12),(0,18),(0,6,12),(0,6,18),(0,12,18),(0,6,12,18)]


def fixture_run(name,branch,mode,schedule,base,days=334,start='2025-02-01',initial=6000.):
    values=np.full(days,float(base));date=pd.date_range(start,periods=days).strftime('%Y-%m-%d')
    daily=pd.DataFrame(dict(window_date=date,cash_cost_yuan=values,inventory_adjusted_cost_yuan=values,soc_start_kwh=initial,soc_end_kwh=initial,emergency_kwh=np.zeros(days)))
    s=dict(config=dict(branch=branch,price_mode=mode,trade_hours=list(schedule),pv_source='supplied'),windows=days,cash_cost_yuan=values.sum(),inventory_adjusted_cost_yuan=values.sum(),soc_start_kwh=initial,soc_end_kwh=initial,emergency_kwh=0.)
    return Run(name,Path('/fixture/no-reading'),s,daily)


def fixture_study():
    main={};dev=[]
    for branch in ('4-2','4-3'):
        for mode in ('point','joint'):
            for j,schedule in enumerate([(0,)] if branch=='4-2' else SCHEDULES):
                name='Q'+branch.replace('-','')+'_'+mode+'_H'+'_'.join(map(str,schedule))
                # Joint is cheaper in this artificial test, but the freeze is point.
                main[name]=fixture_run(name,branch,mode,schedule,1000+j*3-(10 if mode=='joint' else 0))
                if branch=='4-3':dev.append(dict(strategy=name,branch=branch,price_mode=mode,trade_hours=list(schedule),score=7000-j*10,cash=7000-j*10))
    selection=dict(selected_q42='Q42_point_H0',selected_q43='Q43_point_H0_6_12_18',branch_selections={'4-2':{'price_mode':'point','trade_hours':[0]},'4-3':{'price_mode':'point','trade_hours':[0,6,12,18]}},development=dev)
    sens={}
    for branch in ('4-2','4-3'):
        prefix='Q'+branch.replace('-','')+'_'
        for label,base in [('reference',1000),('joint_reference',900),('joint_mean',920),('joint_shuffled',910),('history14',1050),('initial1200',1200)]:
            name=prefix+label;sens[name]=fixture_run(name,branch,'joint' if label.startswith('joint') else 'point',(0,),base,14,'2025-02-25',1200. if label=='initial1200' else 6000.)
    return Study(Path('/fixture'),selection,main,sens,{})


class FigureTablesTests(unittest.TestCase):
    def test_heldout_rank_does_not_reselect_development_choice(self):
        study=fixture_study();before=deepcopy(study.selection);table=schedule_comparison(study)
        self.assertEqual(len(table),8);self.assertTrue((table.price_mode=='point').all())
        self.assertEqual(table[table.selected_before_test].strategy.iloc[0],'Q43_point_H0_6_12_18')
        self.assertEqual(table[table.test_rank_retrospective==1].strategy.iloc[0],'Q43_point_H0')
        self.assertEqual(study.selection,before)

    def test_seven_development_and_310_holdout_denominators_distinct(self):
        table=schedule_comparison(fixture_study())
        for row in table.itertuples():
            self.assertEqual(row.development_windows,7);self.assertEqual(row.test_windows,310)
            self.assertAlmostEqual(row.development_daily_score_yuan*7,row.development_inventory_score_yuan)
            self.assertAlmostEqual(row.test_daily_score_yuan*310,row.test_inventory_score_yuan)

    def test_pairing_uses_chosen_schedule_and_excludes_changed_pv_input(self):
        study=fixture_study();confound=fixture_run('Q42_matched_Q43_PV','4-2','joint',(0,),1)
        confound.summary['config']['pv_source']='q3_all';study.main[confound.name]=confound
        records,summary=paired_price_modes(study)
        self.assertEqual(len(records),2*334)
        q42=summary[summary.branch=='4-2'].iloc[0]
        self.assertEqual(q42.joint_strategy,'Q42_joint_H0');self.assertAlmostEqual(q42.joint_minus_point_cash_yuan,-3340.)
        q43=summary[summary.branch=='4-3'].iloc[0]
        self.assertEqual(q43.joint_strategy,'Q43_joint_H0_6_12_18')

    def test_unequal_pair_dates_fail_instead_of_aligning_by_row(self):
        study=fixture_study();run=study.main['Q42_joint_H0'];run.daily.loc[0,'window_date']='2025-01-31'
        with self.assertRaisesRegex(ValueError,'different dates'):paired_price_modes(study)

    def test_joint_layer_sensitivity_uses_its_own_conditional_reference(self):
        rows=sensitivity_comparison(fixture_study());row=rows[rows.experiment=='Q42_joint_mean'].iloc[0]
        self.assertAlmostEqual(row.inventory_delta_yuan,(920-1000)*14)
        self.assertEqual(row.joint_layer_reference,'Q42_joint_reference')
        self.assertAlmostEqual(row.joint_layer_inventory_delta_yuan,(920-900)*14)

    def test_initial_stock_sensitivity_uses_inventory_score_not_raw_cash(self):
        study=fixture_study();r=study.sensitivity['Q42_initial1200']
        r.summary['cash_cost_yuan']=10000.;r.summary['inventory_adjusted_cost_yuan']=15000.
        rows=sensitivity_comparison(study);row=rows[rows.experiment=='Q42_initial1200'].iloc[0]
        self.assertEqual(row.cash_delta_yuan,-4000.);self.assertEqual(row.inventory_delta_yuan,1000.)
        self.assertAlmostEqual(row.inventory_delta_percent,1000/14000*100)

    def test_monthly_costs_sum_to_selected_contract_totals(self):
        study=fixture_study();rows=monthly_main(study)
        self.assertEqual(len(rows),22)
        for branch in ('4-2','4-3'):
            group=rows[rows.branch==branch]
            self.assertEqual(group.windows.sum(),334)
            self.assertAlmostEqual(group.cash_cost_yuan.sum(),study.selected(branch).summary['cash_cost_yuan'])


if __name__=='__main__':unittest.main()
