"""Frozen-choice Q4 comparisons, dependent-data intervals and tail sensitivity.

No original contract is changed. The endpoint experiment only re-executes the
last step from its stored initial state and then re-settles that step. Actual
endpoint prices are never inputs to the control optimization.

API: build_analysis(data_dir, results_dir, outdir=None).
CLI: python code/q4_analysis.py --data data --results results/final
"""
from __future__ import annotations

import argparse
import hashlib
import itertools
import json
from pathlib import Path

import numpy as np
import pandas as pd

from q4_io import load_inputs
from q4_optimizer import solve_fixed_control
from q4_audit import audit_selection,independent_signature

ROOT=Path(__file__).resolve().parents[1]
METHODS=('hold','linear2','ols6')
TEST_START='2025-02-25'
TEST_END='2025-12-31'
SEED=20260912


def ensure(condition,message):
    if not condition:raise ValueError(message)


def near(a,b,name,tol=1e-5):
    error=float(np.max(np.abs(np.asarray(a,float)-np.asarray(b,float))))
    ensure(np.isfinite(error) and error<=tol,f'{name}: difference {error}')
    return error


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def json_write(path,value):
    Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')


def moving_block_mean_interval(differences,block_length,replicates=2000,seed=SEED):
    """Percentile CI for the mean of paired daily differences.

Overlapping, non-circular blocks preserve dependence within each sampled
block. The final drawn block is truncated to keep exactly N observations.
This is a confidence interval for mean difference, not a prediction interval.
"""
    values=np.asarray(differences,float)
    ensure(values.ndim==1 and len(values)>1 and np.isfinite(values).all(),'Need finite one-dimensional paired differences')
    ensure(isinstance(block_length,int) and 1<=block_length<=len(values),'Invalid block length')
    ensure(isinstance(replicates,int) and replicates>=2,'Invalid bootstrap replicate count')
    n=len(values);nblocks=(n+block_length-1)//block_length
    rng=np.random.default_rng(seed)
    starts=rng.integers(0,n-block_length+1,size=(replicates,nblocks))
    indices=(starts[:,:,None]+np.arange(block_length)[None,None,:]).reshape(replicates,-1)[:,:n]
    means=values[indices].mean(axis=1)
    lo,hi=np.quantile(means,[.025,.975])
    return {'observed_days':n,'mean_daily_difference_yuan':float(values.mean()),
        'total_difference_yuan':float(values.sum()),'block_days':block_length,
        'bootstrap_replicates':replicates,'seed':seed,'confidence_level':.95,
        'mean_difference_ci_lower_yuan':float(lo),'mean_difference_ci_upper_yuan':float(hi),
        'ci_excludes_zero':bool(lo>0 or hi<0),'method':'overlapping non-circular moving-block percentile bootstrap',
        'simultaneous_coverage_claimed':False,'multiplicity_adjustment':False,
        'interpretation':'CI for mean paired daily cost difference; not a prediction interval or proof of optimality'}


def paired_daily_difference(left,right,column='cash_cost_yuan'):
    """Require exact dates instead of silently dropping unmatched days."""
    expected=pd.date_range(TEST_START,TEST_END).strftime('%Y-%m-%d').tolist()
    a=left[left['window_date'].between(TEST_START,TEST_END)].copy()
    b=right[right['window_date'].between(TEST_START,TEST_END)].copy()
    ensure(a['window_date'].tolist()==expected and b['window_date'].tolist()==expected,
        'Paired test comparison requires all 310 dates in identical chronological order')
    return a[column].to_numpy(float)-b[column].to_numpy(float),expected


def execute_tail(base_row,load_kw,pv_kw,*,terminal_weight,controller='mpc'):
    """Re-execute one final step; the price argument is the stored forecast."""
    q=float(base_row['q_kwh']);state=float(base_row['soc_start_kwh'])
    load=float(load_kw)/6;pv=float(pv_kw)/6
    price=float(base_row['price_forecast_yuan_per_kwh'])
    ensure(all(np.isfinite(v) for v in (q,state,load,pv,price,terminal_weight)),'Nonfinite tail input')
    ensure(q>=0 and load>=0 and pv>=0 and price>0 and 1200-1e-5<=state<=10800+1e-5,'Invalid tail physical input')
    surplus=max(q+pv-load,0);deficit=max(load-q-pv,0)
    if surplus>1e-9:
        c=min(surplus,5000/6,max((10800-state)/.9,0.));d=e=0.
        method='same surplus direct rule'
    elif controller=='greedy':
        c=0.;d=min(deficit,5000/6,max((state-1200)*.9,0.));e=max(deficit-d,0.)
        method='same greedy rule'
    else:
        ensure(controller=='mpc','Unknown tail controller')
        # Only normalize floating-point boundary noise, within the same 1e-5
        # kWh physical tolerance; stored SOC remains the recursion origin.
        sol=solve_fixed_control([load],[pv],[price],[q],float(np.clip(state,1200,10800)),terminal_weight=terminal_weight)
        c=float(sol['c'][0]);d=float(sol['d'][0]);e=float(sol['e'][0]);method='same one-step fixed-contract LP'
    end=state+.9*c-d/.9
    waste=max(q+pv+d+e-load-c,0.);v=min(q,waste);r=max(waste-v,0.)
    near(q-v+pv-r+d+e,load+c,'tail energy conservation')
    ensure(1200-1e-5<=end<=10800+1e-5,'tail SOC violation')
    ensure(max(c,d)<=5000/6+1e-5 and min(c,d)<=1e-5 and min(c,e)<=1e-5,'tail physical exclusivity violation')
    return {'charge_kwh':c,'discharge_kwh':d,'emergency_kwh':e,'soc_end_kwh':end,
        'unused_paid_kwh':v,'curtailed_pv_kwh':r,'control_price_yuan_per_kwh':price,'control_method':method}


def settle_tail(base_row,execution,actual_price):
    """Delivery-price accounting only; cannot change execution."""
    p=float(actual_price)
    ensure(np.isfinite(p) and p>0,'Tail price must remain in the declared positive-price domain')
    g=float(base_row['g_kwh']);q=float(base_row['q_kwh'])
    return p*(g+1.5*max(q-g,0)-.5*max(g-q,0)+5*execution['emergency_kwh'])


def endpoint_variants(strategy,summary,base_row,power_candidates,price_candidates):
    """3 power endpoint methods × 3 price methods; no full-run reoptimization."""
    rows=[]
    nu=float(summary['common_inventory_value'])
    for power_method in METHODS:
        L=float(power_candidates['load'][power_method]['mean_kw'])
        G=float(power_candidates['pv'][power_method]['mean_kw'])
        execution=execute_tail(base_row,L,G,terminal_weight=summary['terminal_weight'],
            controller=summary['config']['controller'])
        if power_method=='hold':
            for field in ('charge_kwh','discharge_kwh','emergency_kwh','soc_end_kwh'):
                near(execution[field],float(base_row[field]),'unchanged hold-tail '+field)
        for price_method in METHODS:
            price=float(price_candidates[price_method]['last_interval_price'])
            tail_cash=settle_tail(base_row,execution,price)
            total=float(summary['cash_cost_yuan'])-float(base_row['cash_cost_yuan'])+tail_cash
            inventory=total-nu*(execution['soc_end_kwh']-summary['soc_start_kwh'])
            row={'strategy':strategy,'power_endpoint_method':power_method,'price_endpoint_method':price_method,
                'interval_start':base_row['interval_start'],'interval_end':base_row['interval_end'],
                'load_actual_mean_kw':L,'pv_actual_mean_kw':G,'actual_price_yuan_per_kwh':price,
                'g_kwh':float(base_row['g_kwh']),'q_kwh':float(base_row['q_kwh']),
                'soc_start_kwh':float(base_row['soc_start_kwh']),**execution,
                'tail_cash_cost_yuan':tail_cash,'full_cash_cost_yuan':total,
                'full_cash_change_yuan':total-summary['cash_cost_yuan'],
                'final_soc_change_kwh':execution['soc_end_kwh']-summary['soc_end_kwh'],
                'full_inventory_adjusted_cost_yuan':inventory,
                'inventory_score_change_yuan':inventory-summary['inventory_adjusted_cost_yuan'],
                'estimated_power_right_endpoint':True,'estimated_price_right_endpoint':True,
                'all_earlier_actions_unchanged':True,'last_g_q_and_initial_soc_fixed':True,
                'actual_price_used_for_control':False}
            if power_method==price_method=='hold':near(row['full_cash_change_yuan'],0.,'hold/hold reproduces cash',1e-4)
            rows.append(row)
    return rows


def completed_stage(results_dir,stage,data_dir):
    directory=Path(results_dir)/stage;design_path=directory/'design.json'
    ensure(design_path.exists(),f'{stage} design missing; wait for declared experiment')
    jobs=json.loads(design_path.read_text())['jobs']
    ensure(jobs and all(job.get('name') for job in jobs),f'{stage}: missing named jobs')
    names=[job['name'] for job in jobs];ensure(len(names)==len(set(names)),f'{stage}: duplicate jobs')
    runs={}
    for name in names:
        path=directory/name;summary_path=path/'summary.json'
        ensure(summary_path.exists(),f'Incomplete {stage}: {name}')
        summary=json.loads(summary_path.read_text());ensure(summary.get('complete'),f'Incomplete {stage}: {name}')
        ensure(summary['run_signature']==independent_signature(data_dir,summary['config']),f'{name}: changed input/code signature')
        daily=pd.read_csv(path/'daily.csv')
        ensure(len(daily)==summary['windows'] and not daily['window_date'].duplicated().any(),f'{name}: incomplete daily series')
        near(float(daily['cash_cost_yuan'].sum()),summary['cash_cost_yuan'],f'{name}: daily cash sum',1e-4)
        near(float(daily['inventory_adjusted_cost_yuan'].sum()),summary['inventory_adjusted_cost_yuan'],f'{name}: inventory telescoping',1e-4)
        events=json.loads((path/'event_log.json').read_text())['events']
        counts=[len(event['history_indices']) for event in events]
        ensure(counts and all(count==event['history_days'] for count,event in zip(counts,events)),f'{name}: missing/inconsistent actual history counts')
        ensure(max(counts)<=summary['config']['history_days'],f'{name}: history exceeds cap')
        runs[name]={'path':path,'summary':summary,'daily':daily,
            'actual_history_min':min(counts),'actual_history_max':max(counts)}
    return runs


def main_summary(runs,selection):
    rows=[]
    selected={selection['selected_q42'],selection['selected_q43']}
    chosen=selection['branch_selections']['4-3'];mode=chosen['price_mode']
    other='joint' if mode=='point' else 'point'
    schedules=[(0,)+part for n in range(4) for part in itertools.combinations((6,12,18),n)]
    expected_names={'Q42_point_H0','Q42_joint_H0','Q42_matched_Q43_PV',
        'Q43_'+other+'_H'+'_'.join(map(str,chosen['trade_hours']))}
    expected_names.update('Q43_'+mode+'_H'+'_'.join(map(str,hours)) for hours in schedules)
    ensure(set(runs)==expected_names,'Main experiment must include all twelve declared runs and all eight Q43 schedules')
    for name,run in runs.items():
        s=run['summary'];daily=run['daily'];cfg=s['config']
        ensure(s['windows']==334 and cfg['start_day']==0,f'{name}: main run must be complete 334-window replay')
        expected=pd.date_range('2025-02-01',periods=334).strftime('%Y-%m-%d').tolist()
        ensure(daily['window_date'].tolist()==expected,f'{name}: main dates')
        test=daily[daily['window_date'].between(TEST_START,TEST_END)]
        ensure(len(test)==310,f'{name}: test dates')
        rows.append({'strategy':name,'branch':s['branch'],'selected_by_development':name in selected,
            'price_mode':cfg['price_mode'],'trade_hours':','.join(map(str,cfg['trade_hours'])),
            'pv_hours':','.join(map(str,cfg['forecast_hours'])),'price_hours':','.join(map(str,cfg['price_hours'])),
            'pv_source':cfg['pv_source'],'full_windows':334,'test_windows':310,
            'full_cash_yuan':s['cash_cost_yuan'],'test_cash_yuan':float(test['cash_cost_yuan'].sum()),
            'development_and_warmup_cash_yuan':float(daily.iloc[:24]['cash_cost_yuan'].sum()),
            'full_inventory_score_yuan':s['inventory_adjusted_cost_yuan'],
            'test_inventory_score_yuan':float(test['inventory_adjusted_cost_yuan'].sum()),
            'test_initial_soc_kwh':float(test.iloc[0]['soc_start_kwh']),
            'initial_soc_kwh':s['soc_start_kwh'],'final_soc_kwh':s['soc_end_kwh'],
            'emergency_kwh':s['emergency_kwh'],'emergency_cost_yuan':s['emergency_cost_yuan'],
            'original_plan_cost_yuan':s['original_plan_cost_yuan'],'net_adjustment_cost_yuan':s['net_adjustment_cost_yuan'],
            'startup_cash_yuan':s['startup_cash_cost_yuan'],'natural_period_cash_yuan':s['natural_period_cash_cost_yuan'],
            'common_inventory_value':s['common_inventory_value'],'solver_seconds':s['solver']['seconds'],
            'solver_unproven_calls':s['solver']['unproven'],'solver_max_gap':s['solver']['max_gap']})
    return rows


def compare_pairs(runs,selection):
    schedule='_'.join(map(str,selection['branch_selections']['4-3']['trade_hours']))
    mode=selection['branch_selections']['4-3']['price_mode']
    pairs=[('4-2：联合价格场景减点价格','Q42_joint_H0','Q42_point_H0'),
        ('4-3：联合价格场景减点价格',f'Q43_joint_H{schedule}',f'Q43_point_H{schedule}'),
        ('4-3：开发期选中组合减仅零点',selection['selected_q43'],f'Q43_{mode}_H0'),
        ('同光伏信息：4-3减固定普通计划',selection['selected_q43'],'Q42_matched_Q43_PV'),
        ('主策略总对照：4-3减4-2（光伏信息也不同）',selection['selected_q43'],selection['selected_q42'])]
    differences=[];intervals=[];comparisons=[]
    for label,left,right in pairs:
        ensure(left in runs and right in runs,f'Missing paired main comparison: {left}, {right}')
        a=runs[left];b=runs[right]
        full_cash=a['summary']['cash_cost_yuan']-b['summary']['cash_cost_yuan']
        test_cash,dates=paired_daily_difference(a['daily'],b['daily'])
        comparison={'comparison':label,'left_strategy':left,'right_strategy':right,
            'sign':'left minus right; negative means left costs less','full_cash_difference_yuan':full_cash,
            'test_cash_difference_yuan':float(test_cash.sum()),'mean_test_daily_cash_difference_yuan':float(test_cash.mean()),
            'full_cash_change_percent':100*full_cash/b['summary']['cash_cost_yuan'],
            'reoptimized_original_contracts':True,'test_initial_states_may_differ':True,
            'not_proof_of_global_optimality':True}
        comparisons.append(comparison)
        for metric in ('cash_cost_yuan','inventory_adjusted_cost_yuan'):
            diff,dates=paired_daily_difference(a['daily'],b['daily'],metric)
            for date,value in zip(dates,diff):
                differences.append({'comparison':label,'left_strategy':left,'right_strategy':right,
                    'metric':metric,'window_date':date,'paired_difference_yuan':float(value)})
            for block in (3,7,14):
                intervals.append({'comparison':label,'left_strategy':left,'right_strategy':right,'metric':metric,
                    **moving_block_mean_interval(diff,block,replicates=2000,seed=SEED)})
    return comparisons,differences,intervals


def sensitivity_summary(runs):
    rows=[]
    for name,run in runs.items():
        s=run['summary'];cfg=s['config'];prefix='Q'+s['branch'].replace('-','')
        reference=prefix+'_reference'
        if cfg['price_mode'] in ('mean','shuffled') and prefix+'_joint_reference' in runs:
            reference=prefix+'_joint_reference'
        ensure(reference in runs,f'Missing independent 14-day sensitivity reference: {reference}')
        ref=runs[reference]['summary']
        ensure(s['windows']==ref['windows']==14 and cfg['start_day']==ref['config']['start_day']==24,
            'Sensitivity comparisons must have the same independent 14-day horizon')
        rows.append({'strategy':name,'reference_strategy':reference,'branch':s['branch'],
            'start_date':'2025-02-25','last_contract_date':'2025-03-10','windows':14,
            'cash_yuan':s['cash_cost_yuan'],'cash_change_yuan':s['cash_cost_yuan']-ref['cash_cost_yuan'],
            'inventory_score_yuan':s['inventory_adjusted_cost_yuan'],
            'inventory_score_change_yuan':s['inventory_adjusted_cost_yuan']-ref['inventory_adjusted_cost_yuan'],
            'final_soc_kwh':s['soc_end_kwh'],'initial_soc_kwh':s['soc_start_kwh'],
            'emergency_kwh':s['emergency_kwh'],'price_mode':cfg['price_mode'],'controller':cfg['controller'],
            'history_days':cfg['history_days'],'scenarios':cfg['scenarios'],'seed':cfg['seed'],
            'actual_history_paths_min':run['actual_history_min'],'actual_history_paths_max':run['actual_history_max'],
            'history_cap_filled_at_all_events':run['actual_history_min']==cfg['history_days'],
            'terminal_multiplier':cfg['terminal_multiplier'],'price_hours':','.join(map(str,cfg['price_hours'])),
            'scope':'14 independent continuous windows; not a 334-window sensitivity result'})
    return rows


def history_check_summary(runs):
    rows=[]
    for branch in ('4-2','4-3'):
        prefix='Q'+branch.replace('-','');reference=prefix+'_aug_history28'
        ensure(reference in runs,'Missing mature-history 28-cap reference')
        ref=runs[reference]['summary']
        for cap in (14,28,56):
            name=prefix+f'_aug_history{cap}'
            ensure(name in runs,'Missing declared mature-history candidate')
            run=runs[name];s=run['summary'];cfg=s['config']
            ensure(s['windows']==14 and cfg['start_day']==181 and cfg['history_days']==cap,
                'Mature-history check must use Aug1..14 and declared cap')
            ensure(s['soc_start_kwh']==6000.,'Mature-history checks require common independent 6000 initial state')
            ensure(run['actual_history_min']==run['actual_history_max']==cap,'Mature-history experiment did not actually fill its cap')
            rows.append({'strategy':name,'branch':branch,'reference_strategy':reference,
                'start_date':'2025-08-01','last_contract_date':'2025-08-14','windows':14,
                'history_cap_days':cap,'actual_history_paths_min':run['actual_history_min'],
                'actual_history_paths_max':run['actual_history_max'],'all_events_fill_history_cap':True,
                'cash_yuan':s['cash_cost_yuan'],'cash_change_from_28_yuan':s['cash_cost_yuan']-ref['cash_cost_yuan'],
                'inventory_score_yuan':s['inventory_adjusted_cost_yuan'],
                'inventory_score_change_from_28_yuan':s['inventory_adjusted_cost_yuan']-ref['inventory_adjusted_cost_yuan'],
                'initial_soc_kwh':s['soc_start_kwh'],'final_soc_kwh':s['soc_end_kwh'],
                'used_for_reselection':False,'purpose':'Supplement the early sensitivity where a 56-history cap was not actually filled'})
    ensure(len(runs)==6,'Mature-history stage must have exactly six declared runs')
    return rows


def render_markdown(result):
    selected={result['selection']['selected_q42'],result['selection']['selected_q43']}
    lines=['# 第四问规划结果与比较分析','',
        '主策略按开发期固定选择；下列测试比较不会更改这一选择。334 个合同窗口覆盖 2 月 1 日 00:10 至次年 1 月 1 日 00:10，310 个测试窗口从 2 月 25 日开始。库存校正是评价指标，不是实际电费。','',
        '| 策略 | 开发期选中 | 334窗现金/元 | 310测试窗现金/元 | 310测试窗库存校正/元 | 期末SOC/kWh |',
        '|---|---|---:|---:|---:|---:|']
    for row in result['main_summary']:
        lines.append(f"| {row['strategy']} | {'是' if row['strategy'] in selected else ''} | {row['full_cash_yuan']:,.2f} | {row['test_cash_yuan']:,.2f} | {row['test_inventory_score_yuan']:,.2f} | {row['final_soc_kwh']:,.3f} |")
    lines += ['','所有成对差值按“左策略减右策略”计算，负值表示左策略费用较低。各完整策略会重新制定原单，测试起点 SOC 也可能因前期连续运行而不同，因此不把这些结果写成严格同合同、同状态的局部因果收益。','',
        '| 对比 | 334窗现金差/元 | 310测试窗现金差/元 |', '|---|---:|---:|']
    for row in result['comparisons']:
        lines.append(f"| {row['comparison']} | {row['full_cash_difference_yuan']:,.2f} | {row['test_cash_difference_yuan']:,.2f} |")
    lines += ['','对配对的日费用差采用 3、7、14 日移动块重采样，每种 2000 次，固定种子 20260912。下表列 7 日块的现金差结果，完整三种块长及库存校正结果在 CSV/JSON 中。置信区间描述平均日费用差的抽样不确定性，不是未来某一天费用的预测区间，也不证明全局最优。','',
        '| 对比 | 平均日现金差/元 | 95%置信区间/元 |', '|---|---:|---:|']
    for row in result['bootstrap_intervals']:
        if row['metric']=='cash_cost_yuan' and row['block_days']==7:
            lines.append(f"| {row['comparison']} | {row['mean_daily_difference_yuan']:,.3f} | [{row['mean_difference_ci_lower_yuan']:,.3f}, {row['mean_difference_ci_upper_yuan']:,.3f}] |")
    lines += ['','移动块使用连续等长片段且不跨样本首尾拼接，概念见 [arch 官方文档](https://arch.readthedocs.io/en/latest/bootstrap/generated/arch.bootstrap.MovingBlockBootstrap.html)。本项目用 NumPy 直接生成相同类型的重采样索引，不依赖 arch 包。跨块相关性会被切断；季节变化、单年样本、跨日 SOC 依赖及仅 7 个开发窗口的选择不确定性，都会限制上述区间的解释。更换块长用于显示这种敏感性，不从三种块长挑最有利的一种。这些是各项比较自身的区间，未作多重比较校正，不声称所有区间同时具有95%覆盖率。','',
        '4-2 与 4-3 主输入的光伏信息不同；“主策略总对照”同时包含预测信息和合同机制变化。“同光伏信息”对照可以减少这种混淆，但双方仍各自优化原单和连续运行，不能声称仅改变一个已签合同的许可。','',
        '末段边界试验固定全部历史操作、最后 g/q 及入段 SOC，功率右端点按持平、两点线性、六点回归三种方法分别重新执行最后一步，再组合三种电价右端点估计进行结算。实际均价只进账本；原控制价格保持不变。九种组合均属于含估计的敏感性，不被标为实测。','',
        '| 策略 | 九组合现金最大减最小/元 | 相对基准最大绝对现金变化/元 | 期末SOC范围/kWh |',
        '|---|---:|---:|---:|']
    for row in result['endpoint_summary']:
        lines.append(f"| {row['strategy']} | {row['cash_span_yuan']:,.6f} | {row['max_absolute_cash_change_yuan']:,.6f} | [{row['final_soc_min_kwh']:,.6f}, {row['final_soc_max_kwh']:,.6f}] |")
    lines += ['','其余参数敏感性为相同起点日期、相同独立 14 窗时域的试验，不能解释为 334 窗全年敏感性。不同初态使用库存校正辅助比较；库存单价在所有策略中固定，不随终端控制权重改变。','',
        '历史窗参数指“最多使用多少个已完成残差窗口”。2月25日至3月10日的早期试验尚没有56条完整历史，所以 history56 只检验上限56，不能称为实际使用56窗的效果。参数表附有每个正式决策事件的实际历史条数最小/最大值。为核实填满历史后的行为，另外从8月1日6000 kWh共同实验初态运行到8月14日，比较14/28/56上限；这6条是针对早期历史不足的补充验证，不改变原冻结选择。','',
        '| 分支 | 历史上限 | 实际历史条数范围 | 14窗现金/元 | 相对28上限现金差/元 | 库存校正差/元 |',
        '|---|---:|---:|---:|---:|---:|']
    for row in result['history_check_summary']:
        lines.append(f"| {row['branch']} | {row['history_cap_days']} | {row['actual_history_paths_min']}–{row['actual_history_paths_max']} | {row['cash_yuan']:,.2f} | {row['cash_change_from_28_yuan']:,.2f} | {row['inventory_score_change_from_28_yuan']:,.2f} |")
    lines += ['',
        '本报告未重新训练负载/光伏，未利用测试期费用修改 XGBoost 参数，也没有把随机情景优化目标当成兑现账单。正式预测生成器的历史特征可用性，以及当前十分钟功率均值快反馈近似，仍须结合独立数据审计和严格因果执行对照解释。']
    return '\n'.join(lines)+'\n'


def build_analysis(data_dir=ROOT/'data',results_dir=ROOT/'results/final',outdir=None):
    data_dir=Path(data_dir).resolve();results_dir=Path(results_dir).resolve()
    outdir=Path(outdir).resolve() if outdir else results_dir/'analysis'
    selection=json.loads((results_dir/'selection.json').read_text())
    selection_check=audit_selection(results_dir)
    ensure(selection_check['present'] and selection_check['passed'],'Frozen development selection audit failed')
    main=completed_stage(results_dir,'main',data_dir)
    sensitivity=completed_stage(results_dir,'sensitivity',data_dir)
    history_check=completed_stage(results_dir,'history_check',data_dir)
    rows=main_summary(main,selection)
    comparisons,differences,intervals=compare_pairs(main,selection)
    data=load_inputs(data_dir)
    endpoint=[]
    for name,run in main.items():
        trace=pd.read_csv(run['path']/'trace.csv')
        row=trace.iloc[-1].to_dict()
        ensure(row['interval_start']=='2026-01-01T00:00:00' and row['interval_end']=='2026-01-01T00:10:00','Endpoint sensitivity requires final missing boundary')
        endpoint.extend(endpoint_variants(name,run['summary'],row,
            data['metadata']['actual']['last_right_endpoint_candidates'],data['price_bundle'].boundary_alternatives))
    endpoint_summary=[]
    for name in main:
        part=[r for r in endpoint if r['strategy']==name]
        endpoint_summary.append({'strategy':name,'combinations':len(part),
            'cash_span_yuan':max(r['full_cash_cost_yuan'] for r in part)-min(r['full_cash_cost_yuan'] for r in part),
            'max_absolute_cash_change_yuan':max(abs(r['full_cash_change_yuan']) for r in part),
            'final_soc_min_kwh':min(r['soc_end_kwh'] for r in part),'final_soc_max_kwh':max(r['soc_end_kwh'] for r in part)})
    result={'complete':True,'selection':selection,'selection_audit':selection_check,
        'main_summary':rows,'comparisons':comparisons,'bootstrap_intervals':intervals,
        'endpoint_combinations':endpoint,'endpoint_summary':endpoint_summary,
        'sensitivity_summary':sensitivity_summary(sensitivity),
        'history_check_summary':history_check_summary(history_check),
        'interpretation':{'period':'334 shifted contract windows, not 365 days; last interval includes estimated endpoint',
            'test':'310 windows Feb25..Dec31; no test-driven reselection',
            'bootstrap':'paired daily test differences; overlapping non-circular blocks3/7/14,2000 replicates; confidence intervals for mean differences',
            'boundary':'same existing last g/q and initial SOC; only last action re-executed with old forecast price, then actual estimated price settled',
            'scope':'conditional empirical comparisons, not globally optimal policy proof'},
        'provenance':{'selection_sha256':sha(results_dir/'selection.json'),
            'analysis_code_sha256':sha(Path(__file__)),
            'main_signatures':{name:run['summary']['run_signature'] for name,run in main.items()},
            'sensitivity_signatures':{name:run['summary']['run_signature'] for name,run in sensitivity.items()},
            'history_check_signatures':{name:run['summary']['run_signature'] for name,run in history_check.items()}}}
    outdir.mkdir(parents=True,exist_ok=True)
    for filename,records in [('主实验比较.csv',rows),('成对费用比较.csv',comparisons),('配对逐日差值.csv',differences),
            ('移动块置信区间.csv',intervals),('末端九组合敏感性.csv',endpoint),('末端敏感性汇总.csv',endpoint_summary),
            ('参数敏感性比较.csv',result['sensitivity_summary']),('八月完整历史窗验证.csv',result['history_check_summary'])]:
        pd.DataFrame(records).to_csv(outdir/filename,index=False,encoding='utf-8-sig')
    json_write(outdir/'analysis.json',result)
    (outdir/'结果与比较分析.md').write_text(render_markdown(result),encoding='utf-8')
    return result


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--data',type=Path,default=ROOT/'data')
    p.add_argument('--results',type=Path,default=ROOT/'results/final');p.add_argument('--out',type=Path)
    a=p.parse_args();r=build_analysis(a.data,a.results,a.out)
    print(json.dumps({'complete':r['complete'],'main_runs':len(r['main_summary']),
        'sensitivity_runs':len(r['sensitivity_summary']),'endpoint_cases':len(r['endpoint_combinations'])},ensure_ascii=False))
