"""Meaningful Q4 reporting checks with physically balanced toy ledgers."""
from pathlib import Path
from datetime import datetime,timedelta
from copy import deepcopy
import hashlib
import tempfile
import unittest

from openpyxl import load_workbook
from q4_reports import (EPS,audit_trace,day_groups,episodes,export_result,paper_tables,
    summarize,total,_contract_groups,DATES)

ROOT=Path(__file__).resolve().parents[1]


def toy_ledger(variant='Q4-3',dates=2):
    allrows=[];s=6000.;start=datetime(2025,2,1)
    for n in range(dates*144+1):
        a=start+timedelta(minutes=10*n);b=a+timedelta(minutes=10)
        # Contract D starts at D00:10; natural-day midnight belongs to D-1.
        contract=(a-timedelta(minutes=10)).date().isoformat()
        c=d=0.;q=70.+n%20;e=100.-q
        if n==6:c=50.;q=150.;e=0.
        if n==9:d=40.5;q=59.5;e=0.
        g=q+(10. if variant=='Q4-3' else 0.)
        down=g-q;p=.2+(n%6)*.03
        end=s+.9*c-d/.9
        row=dict(strategy='test',window_date=contract,interval_start=a.isoformat(),interval_end=b.isoformat(),
            price_yuan_per_kwh=p,price_forecast_yuan_per_kwh=1.7,load_forecast_kw=590.,pv_forecast_kw=0.,load_actual_kw=600.,pv_actual_kw=0.,
            g_kwh=g,q_kwh=q,increase_kwh=0.,decrease_kwh=down,charge_kwh=c,discharge_kwh=d,emergency_kwh=e,
            unused_paid_kwh=0.,curtailed_pv_kwh=0.,soc_start_kwh=s,soc_end_kwh=end,
            plan_cost_yuan=p*g,increase_cost_yuan=0.,refund_yuan=p*down,penalty_yuan=.5*p*down,
            adjustment_net_cost_yuan=-.5*p*down,emergency_cost_yuan=5*p*e,cash_cost_yuan=p*g-.5*p*down+5*p*e,
            actual_estimated=False,price_estimated=n==dates*144)
        allrows.append(row);s=end
    return allrows[1:],allrows[:1]


class Q4ReportTests(unittest.TestCase):
    def setUp(self):self.temp=tempfile.TemporaryDirectory();self.out=Path(self.temp.name)
    def tearDown(self):self.temp.cleanup()

    def test_actual_not_forecast_price_sets_all_costs(self):
        rows,startup=toy_ledger();audit=audit_trace(startup+rows,label='fixture')
        self.assertLess(audit['max_cash_error_yuan'],1e-9)
        changed=deepcopy(rows);changed[0]['plan_cost_yuan']=changed[0]['price_forecast_yuan_per_kwh']*changed[0]['g_kwh']
        with self.assertRaisesRegex(AssertionError,'original cost'):audit_trace(changed,label='incorrect forecast settlement')

    def test_cancellation_refund_is_subtracted_once(self):
        rows,_=toy_ledger();r=rows[0];p=r['price_yuan_per_kwh']
        self.assertAlmostEqual(r['refund_yuan'],10*p);self.assertAlmostEqual(r['penalty_yuan'],5*p)
        self.assertAlmostEqual(r['cash_cost_yuan'],p*r['g_kwh']-5*p+5*p*r['emergency_kwh'])
        changed=deepcopy(rows);changed[0]['cash_cost_yuan']+=changed[0]['refund_yuan']
        with self.assertRaisesRegex(AssertionError,'cash'):audit_trace(changed,label='no-refund wrong cost')

    def test_natural_day_uses_previous_contract_and_real_soc(self):
        rows,startup=toy_ledger();groups=day_groups(startup+rows)
        self.assertEqual(len(groups),2)
        day=groups['2025-02-02'];self.assertEqual(len(day),144)
        self.assertEqual(day[0]['window_date'],'2025-02-01');self.assertEqual(day[1]['window_date'],'2025-02-02')
        first=groups['2025-02-01'];self.assertAlmostEqual(total(first[:24],'charge_kwh'),50.)
        self.assertAlmostEqual(total(first[:24],'discharge_kwh'),40.5)
        self.assertEqual(first[0]['soc_start_kwh'],6000.);self.assertEqual(first[-1]['soc_end_kwh'],6000.)

    def test_contract_natural_fee_bridge_identity(self):
        rows,startup=toy_ledger();groups=day_groups(startup+rows)
        natural=sum(total(day,'cash_cost_yuan') for day in groups.values());tail=rows[-1]['cash_cost_yuan']
        self.assertAlmostEqual(natural,total(rows,'cash_cost_yuan')+total(startup,'cash_cost_yuan')-tail)
        self.assertEqual(rows[-1]['interval_start'],'2025-02-03T00:00:00')

    def test_emergency_episodes_split_at_midnight_and_conserve_energy(self):
        rows,startup=toy_ledger();events=episodes(startup+rows)
        self.assertTrue(any(e['label'].endswith('24:00') for e in events))
        self.assertTrue(any(e['date']=='2025-02-03' and e['label']=='00:00—00:10' for e in events))
        self.assertAlmostEqual(sum(e['kwh'] for e in events),total(startup+rows,'emergency_kwh'))

    def test_shifted_contract_or_missing_startup_refused(self):
        rows,startup=toy_ledger();changed=deepcopy(rows);changed[0]['interval_start']='2025-02-01T00:00:00'
        with self.assertRaisesRegex(AssertionError,'Shifted/missing'):_contract_groups(changed)
        with self.assertRaisesRegex(AssertionError,'all 144'):
            export_result(ROOT/'data/result4-3_template.xlsx',self.out/'bad.xlsx',rows,[],'test','Q4-3',{})

    def test_q42_template_fee_includes_emergency_and_preserves_headers(self):
        rows,startup=toy_ledger('Q4-2');template=ROOT/'data/result4-2_template.xlsx';before=hashlib.sha256(template.read_bytes()).hexdigest()
        checked,natural=export_result(template,self.out/'result4-2.xlsx',rows,startup,'test','Q4-2',{})
        self.assertEqual(checked['storage_blocks'],12);self.assertEqual(hashlib.sha256(template.read_bytes()).hexdigest(),before)
        book=load_workbook(self.out/'result4-2.xlsx',data_only=True)
        try:
            first=list(_contract_groups(rows).values())[0]
            self.assertEqual(book['计划购电量'].cell(1,145).value,'0:00-0:10+1')
            self.assertAlmostEqual(book['计划购电量'].cell(2,147).value,total(first,'cash_cost_yuan'))
            self.assertAlmostEqual(book['计划购电量'].cell(2,146).value,total(first,'g_kwh'))
            self.assertNotIn('调整购电量',book.sheetnames)
            self.assertEqual(book['充放电量'].max_row,13)
        finally:book.close()

    def test_q43_template_separates_original_and_final_quantities(self):
        rows,startup=toy_ledger();checked,natural=export_result(ROOT/'data/result4-3_template.xlsx',self.out/'result4-3.xlsx',rows,startup,'test','Q4-3',{})
        book=load_workbook(self.out/'result4-3.xlsx',data_only=True)
        try:
            first=list(_contract_groups(rows).values())[0]
            self.assertAlmostEqual(book['计划购电量'].cell(2,147).value,total(first,'plan_cost_yuan'))
            self.assertAlmostEqual(book['调整购电量'].cell(2,147).value,total(first,'cash_cost_yuan'))
            self.assertAlmostEqual(book['调整购电量'].cell(2,2).value,rows[0]['q_kwh'])
            self.assertNotEqual(book['调整购电量'].cell(2,2).value,rows[0]['q_kwh']-rows[0]['g_kwh'])
            dates=[book['紧急购电量'].cell(i,1).value for i in range(2,book['紧急购电量'].max_row+1)]
            self.assertNotIn(datetime(2025,2,3),dates)
            self.assertEqual(book['跨年合同末段'].max_row,2)
        finally:book.close()

    def test_four_required_days_refuse_partial_and_use_specific_slots(self):
        rows,startup=toy_ledger();natural=day_groups(startup+rows)
        with self.assertRaisesRegex(AssertionError,'Missing required'):
            paper_tables(self.out/'bad.xlsx',self.out/'bad.md',natural,'test','Q4-3')
        fixture={}
        source=natural['2025-02-01']
        for stamp in DATES:
            shift=datetime.fromisoformat(stamp)-datetime(2025,2,1);copy=deepcopy(source)
            for row in copy:
                row['interval_start']=(datetime.fromisoformat(row['interval_start'])+shift).isoformat()
                row['interval_end']=(datetime.fromisoformat(row['interval_end'])+shift).isoformat()
            fixture[stamp]=copy
        checked,summaries=paper_tables(self.out/'four.xlsx',self.out/'four.md',fixture,'test','Q4-3')
        self.assertEqual(len(summaries),4)
        book=load_workbook(self.out/'four.xlsx',data_only=True)
        try:self.assertEqual(book['表1_指定购电'].cell(3,2).value,fixture[DATES[0]][60]['q_kwh'])
        finally:book.close()


if __name__=='__main__':unittest.main()
