"""Independent selected-day/template cell review, without report-builder helpers."""
import argparse
import json
from pathlib import Path
import pandas as pd
from openpyxl import load_workbook

ROOT=Path(__file__).resolve().parents[1]
DATES=('2025-03-20','2025-06-21','2025-09-23','2025-12-21')


def sheets(path):
    book=load_workbook(path,read_only=True,data_only=True)
    try:return {s.title:list(s.values) for s in book}
    finally:book.close()


def review_four_days(results_dir=ROOT/'results/final'):
    root=Path(results_dir).resolve();out=root/'reports'
    selected=json.loads((root/'selection.json').read_text());checks=[];cells=0;worst=0.
    def near(a,b,label):
        nonlocal cells,worst
        error=abs(float(a)-float(b));cells+=1;worst=max(worst,error)
        if not error<1e-5:raise AssertionError((label,a,b,error))
    def cell(s,row,col):return s[row-1][col-1]
    for branch,key in [('Q4-2','selected_q42'),('Q4-3','selected_q43')]:
        name=selected[key];trace=pd.read_csv(root/'main'/name/'trace.csv')
        trace['start']=pd.to_datetime(trace.interval_start)
        paper=sheets(out/f'第四问_{branch}_指定四日填表.xlsx')
        template=sheets(out/('result4-2.xlsx' if branch=='Q4-2' else 'result4-3.xlsx'))
        for k,date in enumerate(DATES):
            day=trace[trace.start.dt.strftime('%Y-%m-%d')==date].copy()
            if len(day)!=144:raise AssertionError('Required natural date incomplete')
            if day.start.iloc[0]!=pd.Timestamp(date) or day.start.iloc[-1]!=pd.Timestamp(date)+pd.Timedelta(hours=23,minutes=50):raise AssertionError('Wrong natural-day boundaries')
            if day.window_date.iloc[0]!=str((pd.Timestamp(date)-pd.Timedelta(days=1)).date()):raise AssertionError('First interval must use prior contract')
            s=paper['表1_指定购电'];base=1+8*k;quantity='g_kwh' if branch=='Q4-2' else 'q_kwh'
            for pos,hour in enumerate((10,12,14,16,18,20)):
                near(cell(s,base+2+pos//3,2+2*(pos%3)),day.loc[day.start.dt.hour.eq(hour)&day.start.dt.minute.eq(0),quantity].iloc[0],f'{branch} {date} hour{hour}')
            for row,col,value,label in [(base+4,2,day[quantity].sum(),'daily ordinary'),
                (base+4,4,day.cash_cost_yuan.sum(),'daily cash'),(base+4,6,day.emergency_kwh.sum(),'daily emergency'),
                (base+5,2,day[quantity].sum()+day.emergency_kwh.sum(),'total purchased'),
                (base+5,4,day.plan_cost_yuan.sum(),'plan cash'),(base+5,6,day.emergency_cost_yuan.sum(),'emergency cash')]:
                near(cell(s,row,col),value,label)
            for col,field in [(2,'increase_cost_yuan'),(4,'refund_yuan'),(6,'penalty_yuan')]:near(cell(s,base+6,col),day[field].sum(),field)
            s=paper['表2_充放储电'];base=1+7*k
            for block in range(6):
                rows=day[day.start.dt.hour.between(block*4,block*4+3)]
                rr=base+2+block//2;cc=2+3*(block%2)
                near(cell(s,rr,cc),rows.charge_kwh.sum(),'block charge')
                near(cell(s,rr,cc+1),rows.discharge_kwh.sum(),'block discharge')
            near(cell(s,base+5,2),day.soc_start_kwh.iloc[0],'natural midnight SOC')
            near(cell(s,base+5,5),day.soc_end_kwh.iloc[-1],'natural 24 SOC')
            events=[];current=None
            for _,row in day.iterrows():
                if row.emergency_kwh>1e-5:
                    if current is None:current=[row.interval_start,row.interval_end,float(row.emergency_kwh)]
                    else:current[1]=row.interval_end;current[2]+=row.emergency_kwh
                elif current is not None:events.append(current);current=None
            if current is not None:events.append(current)
            s=paper['表3_连续紧急购电'];col=2*k+1
            if not events:
                if cell(s,4,col)!='无紧急购电':raise AssertionError('Missing no-emergency declaration')
                near(cell(s,4,col+1),0,'no emergency')
            else:
                for j,(a,b,e) in enumerate(events):
                    label=a[11:16]+'—'+('24:00' if b[:10]!=date else b[11:16])
                    if cell(s,4+j,col)!=label:raise AssertionError((date,label,cell(s,4+j,col)))
                    near(cell(s,4+j,col+1),e,'emergency episode')
            contract=trace[trace.window_date==date]
            rr=(pd.Timestamp(date)-pd.Timestamp('2025-02-01')).days+2;s=template['计划购电量']
            for t,v in enumerate(contract.g_kwh):near(cell(s,rr,t+2),v,'original template g')
            near(cell(s,rr,146),contract.g_kwh.sum(),'original template total')
            near(cell(s,rr,147),(contract.cash_cost_yuan if branch=='Q4-2' else contract.plan_cost_yuan).sum(),'original template cash')
            if branch=='Q4-3':
                s=template['调整购电量']
                for t,v in enumerate(contract.q_kwh):near(cell(s,rr,t+2),v,'adjusted template q')
                near(cell(s,rr,146),contract.q_kwh.sum(),'adjusted template total')
                near(cell(s,rr,147),contract.cash_cost_yuan.sum(),'adjusted total cash once')
            checks.append({'branch':branch,'strategy':name,'natural_date':date,'intervals':144,
                'cash_yuan':float(day.cash_cost_yuan.sum()),'emergency_kwh':float(day.emergency_kwh.sum()),
                'episodes':len(events),'first_interval_from_previous_contract':True})
    result={'passed':True,'checked_numeric_cells':cells,'maximum_difference':worst,'days':checks,
        'scope':'Independent from report builder: six specified slots, all six storage blocks, natural midnight states, merged emergency episodes, and 144 g/q cells in original templates on all four required dates; full-template audit remains separate.'}
    (out/'独立四日与关键数核验.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    return result


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--results',type=Path,default=ROOT/'results/final');a=p.parse_args()
    r=review_four_days(a.results)
    print(json.dumps({k:r[k] for k in ('passed','checked_numeric_cells','maximum_difference')},ensure_ascii=False))
