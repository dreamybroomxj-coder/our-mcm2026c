"""Assemble Q4 deliverables and verify ZIP contents without changing inputs."""
from pathlib import Path
import argparse,hashlib,json,shutil,zipfile

ROOT=Path(__file__).resolve().parents[1]


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):h.update(block)
    return h.hexdigest()


def copy_tree(source,target):
    def ignore(directory,names):
        return [name for name in names if name in ('__pycache__','fontcache','rendered_pages')
            or name.endswith(('.pyc','.pending.npz'))]
    shutil.copytree(source,target,ignore=ignore)


def assemble(destination,results_dir=ROOT/'results/final'):
    destination=Path(destination).resolve();results=Path(results_dir).resolve()
    if destination==ROOT or destination in ROOT.parents:raise ValueError('Unsafe delivery destination')
    if destination.exists():raise FileExistsError('Destination already exists; use a new folder, do not overwrite unrelated work')
    checks=[results/'run_all_manifest.json',results/'independent_audit.json',
        results/'causal_replay/independent_audit.json',results/'reports/报表与账本核验.json',
        results/'reports/文稿验证.json']
    for path in checks:
        result=json.loads(path.read_text())
        if not result.get('complete',result.get('passed',False)):
            raise RuntimeError(f'Incomplete required validation: {path}')
        if path.name=='文稿验证.json' and not result.get('visual_reviewed'):
            raise RuntimeError('Document pages must be visually reviewed before packaging')
    destination.mkdir(parents=True)
    for folder in ('code','data','notes'):
        copy_tree(ROOT/folder,destination/folder)
    (destination/'results').mkdir()
    copy_tree(results,destination/'results/final')
    profile=ROOT/'results/data_profile.json'
    if profile.exists():shutil.copy2(profile,destination/'results/data_profile.json')
    for filename in ('README.md','requirements.txt','requirements-documents.txt','第四问_模型与操作方法.md'):
        shutil.copy2(ROOT/filename,destination/filename)
    for filename in ('第四问_结果与结论.md','第四问_模型与结果说明.docx','第四问_模型与结果说明.pdf',
        'result4-2.xlsx','result4-3.xlsx'):
        shutil.copy2(results/'reports'/filename,destination/filename)
    copy_tree(results/'figures',destination/'figures')
    provenance=destination/'provenance'
    if (ROOT/'provenance').exists():copy_tree(ROOT/'provenance',provenance)
    else:provenance.mkdir()
    from q4_runner import CORE
    core=provenance/'numerical_core_used';core.mkdir(exist_ok=True)
    for filename in CORE:shutil.copy2(ROOT/'code'/filename,core/filename)
    support=destination/'support';support.mkdir()
    (support/'阅读与验收说明.md').write_text('''# 支撑材料说明

完整数值源码、实际输入、逐段轨迹和签名在code/data/results；根目录两个result4文件是reports中原模板的相同副本。根figures是正式9图的方便阅读副本。全部实际数值以results/final为准。

方法、结论和Word/PDF为第四问专项说明，未冒称整篇竞赛论文或官方AI报告完成。notes中保留独立审查、通用扫描兼容性、数据口径、求解精度、分钟执行和运行日志。

交付包不含平台相关vendor与Python虚拟环境；requirements锁定实际库版本。数值复现已在同版本环境核验，不冒称新环境安装验收。前阶段电价比较的完整代码仍保留在另行交付《第四问_电价预测》，本包直接使用它的冻结零点输入，并包括本次日内XGBoost更新代码。

本包未推送GitHub。原用户文件和前问冻结结果未改。
''',encoding='utf-8')
    # Development pilots are evidence of engineering, not formal fee results.
    for path in (destination/'notes').glob('pilot*.txt'):path.unlink()
    return destination


def seal(destination):
    destination=Path(destination).resolve()
    files=[p for p in destination.rglob('*') if p.is_file() and p.name!='交付文件清单.json']
    manifest={'file_count':len(files),'files':{str(p.relative_to(destination)):{'sha256':sha(p),'bytes':p.stat().st_size}
        for p in sorted(files)},'scope':'Q4 dispatch with frozen XGBoost price inputs'}
    (destination/'交付文件清单.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    archive=destination.with_suffix('.zip')
    if archive.exists():raise FileExistsError('ZIP already exists; explicitly choose another delivery name')
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted(destination.rglob('*')):
            if p.is_file():z.write(p,str(Path(destination.name)/p.relative_to(destination)))
    with zipfile.ZipFile(archive) as z:
        bad=z.testzip()
        if bad is not None:raise RuntimeError('ZIP CRC failed: '+bad)
        for name,info in manifest['files'].items():
            contents=z.read(str(Path(destination.name)/name))
            if hashlib.sha256(contents).hexdigest()!=info['sha256']:raise RuntimeError('ZIP file SHA mismatch')
    checked={'passed':True,'files_plus_manifest':len(files)+1,'zip_bytes':archive.stat().st_size,
        'zip_sha256':sha(archive),'zip':str(archive),'directory':str(destination),'crc_and_per_file_sha256_verified':True}
    (destination.parent/(destination.name+'_交付校验.json')).write_text(json.dumps(checked,ensure_ascii=False,indent=2),encoding='utf-8')
    return checked


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--dest',type=Path,required=True)
    p.add_argument('--results',type=Path,default=ROOT/'results/final');p.add_argument('--seal-only',action='store_true')
    a=p.parse_args()
    if not a.seal_only:assemble(a.dest,a.results)
    print(json.dumps(seal(a.dest),ensure_ascii=False,indent=2))
