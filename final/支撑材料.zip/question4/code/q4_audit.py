"""Read-only, independent trace/event/summary audit for completed Q4 runs.

Usage: python code/q4_audit.py --data data --results results/final
API: audit_all(data_dir, results_dir) -> JSON-serializable dict.
This module does not call an optimizer or use its cash/physical check helpers.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import importlib.metadata
import json
from pathlib import Path

import numpy as np
import pandas as pd
from openpyxl import load_workbook

ROOT=Path(__file__).resolve().parents[1]
CORE=('physical_io.py','q4_io.py','q4_optimizer.py','q4_risk.py','q4_runner.py','price_inputs.py','xgb_intraday.py')
START={0:0,6:35,12:71,18:107}
HOURS=(0,6,12,18)
TOL=1e-5


def require(condition,message):
    if not condition:raise AssertionError(message)


def close(actual,expected,name,atol=TOL):
    a,b=np.asarray(actual,float),np.asarray(expected,float)
    require(a.shape==b.shape,f'{name}: shape {a.shape} != {b.shape}')
    require(np.isfinite(a).all() and np.isfinite(b).all(),f'{name}: nonfinite')
    err=float(np.max(np.abs(a-b))) if a.size else 0.
    require(err<=atol,f'{name}: maximum difference {err} > {atol}')
    return err


def display(path):
    p=Path(path).resolve()
    try:return str(p.relative_to(ROOT))
    except ValueError:return str(p)


def file_sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def independent_signature(data_dir,config):
    h=hashlib.sha256(json.dumps(config,sort_keys=True).encode())
    for name in CORE:
        p=ROOT/'code'/name
        if p.exists():h.update(name.encode());h.update(p.read_bytes())
    for p in sorted(Path(data_dir).glob('*')):
        if p.is_file() and p.suffix in ('.xlsx','.npz'):
            h.update(p.name.encode());h.update(p.read_bytes())
    for name in ('numpy','scipy','pandas','openpyxl'):
        h.update((name+importlib.metadata.version(name)).encode())
    return h.hexdigest()


def sheet_values(path,sheet=None):
    wb=load_workbook(path,read_only=True,data_only=True)
    try:return list((wb[sheet] if sheet else wb.active).values)
    finally:wb.close()


def source_data(data_dir):
    """Read original values and rederive means without the production adapter."""
    data_dir=Path(data_dir)
    dates=pd.date_range('2025-02-01',periods=334)
    out={'dates':dates}
    for key,sheet in (('load','小区负载'),('pv','光伏发电实际功率'),('price',None)):
        rows=sheet_values(data_dir/('attachment4.xlsx' if key=='price' else 'attachment2.xlsx'),sheet)
        all_dates=pd.DatetimeIndex([r[0] for r in rows[1:]])
        require(all_dates.equals(pd.date_range('2025-01-01',periods=365)),f'{key}: original dates')
        raw=np.asarray([r[1:] for r in rows[1:]],float)
        require(raw.shape==(365,144) and np.isfinite(raw).all(),f'{key}: original nodes')
        nodes=np.column_stack((raw[31:],np.r_[raw[32:,0],raw[-1,-1]]))
        out[key+'_nodes']=nodes
        out[key+'_actual']=(nodes[:,:-1]+nodes[:,1:])/2
        out[key+'_startup']=(raw[30,143]+raw[31,0])/2
        if key=='pv':out['pv_raw']=raw
        if key=='price':out['price_raw']=raw
    with np.load(data_dir/'price_inputs.npz',allow_pickle=False) as z:
        out['price_forecast']=z['predicted'].copy();out['price_nodes_f']=z['nodes'].copy()
        close(z['actual'],out['price_actual'],'price bundle actual means',1e-12)
        close(z['actual_nodes'],out['price_nodes'],'price bundle actual nodes',1e-12)
        out['price_audit']=json.loads(str(z['audit_json'].item()))
    p=out['price_nodes_f']
    for v,h in enumerate(HOURS):
        close(out['price_forecast'][:,v,START[h]:],
              ((p[:,:,:-1]+p[:,:,1:])/2)[:,v,START[h]:],'forecast endpoint average',1e-12)
        require(np.isnan(out['price_forecast'][:,v,:START[h]]).all(),'unreleased prices available')
    with np.load(data_dir/'xgboost_midnight_predictions.npz',allow_pickle=False) as z:
        close(p[:,0],z['predictions'],'unchanged XGBoost midnight nodes',0)
        close(z['actual'][:,:144],out['price_raw'][31:],'original XGBoost source truth',0)
    require(out['price_audit'].get('complete') is True,'incomplete price bundle')
    for name,digest in out['price_audit']['provenance']['sources'].items():
        require(file_sha(data_dir/name)==digest,f'price bundle provenance changed: {name}')
    raw=out['price_raw'].ravel()
    times=pd.date_range('2025-01-01 00:10',periods=len(raw),freq='10min')
    mask=(times[:-1].month==1)&(times[:-1].hour<6)&(times[1:]<pd.Timestamp('2025-02-01'))
    out['nu']=float(np.median((raw[:-1]+raw[1:])[mask]/2)/.9)
    out['nu_intervals']=int(mask.sum())
    out['bridge_price']=(out['price_raw'][30:364,143]+p[:,0,0])/2
    for key,sheet in (('load_f','XGBoost_负载'),('q2_pv','自适应加权_光伏')):
        rows=sheet_values(data_dir/'load_forecasts.xlsx',sheet)
        require(pd.DatetimeIndex([r[0] for r in rows[1:]]).equals(dates),f'{key}: dates')
        out[key]=np.asarray([r[1:] for r in rows[1:]],float)
        require(out[key].shape==(334,144),f'{key}: mean grid')
    pv=np.full((334,4,144),np.nan)
    for v,h in enumerate(HOURS):
        rows=sheet_values(data_dir/'pv_forecasts.xlsx',f'{h:02d}时预报')
        require(pd.DatetimeIndex([r[0] for r in rows[1:]]).equals(dates),'PV dates')
        values=np.asarray([r[1:] for r in rows[1:]],float)
        if h==0:out['pv_startup_forecast']=values[:,0].copy();values=values[:,1:]
        pv[:,v,START[h]:]=values
    out['pv_f']=pv
    rows=sheet_values(data_dir/'attachment3.xlsx');hourly={};date=None
    for row in rows[1:]:
        if row[0]:date=pd.Timestamp(row[0]).date()
        hour=row[1].hour if hasattr(row[1],'hour') else int(str(row[1]).split(':')[0])
        hourly[date,hour]=np.asarray(row[2:],float)
    linear=np.full_like(pv,np.nan)
    for i,date in enumerate(dates):
        for v,h in enumerate(HOURS):
            observed=out['pv_raw'][i+30,143] if h==0 else out['pv_raw'][i+31,h*6-1]
            knots=np.r_[observed,hourly[date.date(),h]]
            t=np.arange(max(10,h*60),1451,10)
            nodes=np.interp(t,np.arange(h,h+25)*60,knots)
            linear[i,v,START[h]:]=(nodes[:-1]+nodes[1:])/2
    out['pv_linear']=linear
    out['source_sha256']={p.name:file_sha(p) for p in data_dir.iterdir() if p.is_file()}
    return out


def as_bool(series):
    mapped=series.astype(str).str.lower().map({'true':True,'false':False,'1':True,'0':False})
    require(mapped.notna().all(),'invalid Boolean provenance flag')
    return np.asarray(mapped,bool)


def audit_run(run_dir,data_dir,source=None,verify_signature=True):
    run_dir=Path(run_dir).resolve();data_dir=Path(data_dir).resolve()
    src=source if source is not None else source_data(data_dir)
    summary=json.loads((run_dir/'summary.json').read_text())
    trace=pd.read_csv(run_dir/'trace.csv')
    daily=pd.read_csv(run_dir/'daily.csv')
    eventdoc=json.loads((run_dir/'event_log.json').read_text());events=eventdoc['events']
    cfg=summary['config'];start=cfg['start_day'];windows=summary['windows'];stop=start+windows
    require(summary.get('complete') is True,'incomplete run')
    require(eventdoc['config']==cfg,'event configuration disagrees')
    if verify_signature:
        require(summary['run_signature']==independent_signature(data_dir,cfg),'source/code/run signature mismatch')
    require(0<=start<stop<=334,'invalid run date range')
    require(windows==min(334,start+(cfg['days'] or 334))-start,'wrong configured run length')
    require(len(trace)==144*windows==summary['intervals'],'incomplete/duplicate trace')
    require(trace['strategy'].eq(summary['strategy']).all(),'strategy names disagree')
    require(trace['branch'].eq(summary['branch']).all(),'branch names disagree')
    begins=pd.date_range(src['dates'][start]+pd.Timedelta(minutes=10),periods=len(trace),freq='10min')
    require(pd.DatetimeIndex(trace['interval_start']).equals(begins),'wrong interval start grid')
    require(pd.DatetimeIndex(trace['interval_end']).equals(begins+pd.Timedelta(minutes=10)),'wrong end grid')
    days=np.repeat(np.arange(start,stop),144);slots=np.tile(np.arange(144),windows)
    require(trace['window_date'].tolist()==[str(src['dates'][i].date()) for i in days],'contract assignment mismatch')
    for key,col in (('load','load_actual_kw'),('pv','pv_actual_kw'),('price','price_yuan_per_kwh')):
        close(trace[col],src[key+'_actual'][days,slots],f'actual {key} endpoint means')
    expected_est=(days==333)&(slots==143)
    require(np.array_equal(as_bool(trace['actual_estimated']),expected_est),'power estimated boundary flag')
    require(np.array_equal(as_bool(trace['price_estimated']),expected_est),'price estimated boundary flag')
    close(trace['load_forecast_kw'],src['load_f'][days,slots],'supplied load means unchanged')
    pv_hours=cfg['forecast_hours'];price_hours=cfg['price_hours'];trade_hours=cfg['trade_hours']
    expected_fh=np.array([max(h for h in pv_hours if START[h]<=t) for t in slots])
    expected_ph=np.array([max(h for h in price_hours if START[h]<=t) for t in slots])
    bridge=(slots==143)&(days<stop-1)
    expected_ph[bridge]=0
    expected_price_issue=[src['dates'][d+int(b)]+pd.Timedelta(hours=int(h)) for d,b,h in zip(days,bridge,expected_ph)]
    expected_pv_issue=[src['dates'][d]+pd.Timedelta(hours=int(h)) for d,h in zip(days,expected_fh)]
    require(pd.DatetimeIndex(trace['price_forecast_issue_time']).equals(pd.DatetimeIndex(expected_price_issue)),'wrong price version timestamp')
    require(pd.DatetimeIndex(trace['forecast_issue_time']).equals(pd.DatetimeIndex(expected_pv_issue)),'wrong PV version timestamp')
    require((pd.DatetimeIndex(expected_price_issue)<=begins).all(),'unreleased price version used')
    close(trace['price_forecast_hour'],expected_ph,'price clock permission',0)
    expected_pf=np.empty(len(trace));expected_pv=np.empty(len(trace))
    q2pv=cfg['branch']=='4-2' and cfg['pv_source']!='q3_all'
    pv_source=src['pv_linear'] if cfg['pv_source']=='linear' else src['pv_f']
    for k,(d,t,ph,fh,b) in enumerate(zip(days,slots,expected_ph,expected_fh,bridge)):
        expected_pf[k]=src['bridge_price'][d+1] if b else (src['price_nodes'][d,t]+src['price_nodes_f'][d,HOURS.index(ph),t+1])/2
        expected_pv[k]=src['q2_pv'][d,t] if q2pv else pv_source[d,HOURS.index(fh),t]
    close(trace['price_forecast_yuan_per_kwh'],expected_pf,'known-left/predicted-right control prices',1e-10)
    close(trace['pv_forecast_kw'],expected_pv,'permitted PV mean')
    g,q,c,d,e,v,r,S0,S1=[trace[col].to_numpy(float) for col in
        ('g_kwh','q_kwh','charge_kwh','discharge_kwh','emergency_kwh','unused_paid_kwh','curtailed_pv_kwh','soc_start_kwh','soc_end_kwh')]
    L=trace['load_actual_kw'].to_numpy(float)/6;G=trace['pv_actual_kw'].to_numpy(float)/6
    p=trace['price_yuan_per_kwh'].to_numpy(float)
    require(np.isfinite(np.r_[g,q,c,d,e,v,r,S0,S1,p]).all(),'nonfinite physical values')
    require(min(np.min(x) for x in (g,q,c,d,e,v,r))>=-TOL,'negative physical flow')
    physical={}
    physical['balance']=close(q-v+G-r+d+e,L+c,'energy conservation')
    physical['soc_recursion']=close(S1,S0+.9*c-d/.9,'SOC recursion')
    physical['continuity']=close(S0[1:],S1[:-1],'continuous actual SOC')
    require(min(S0.min(),S1.min())>=1200-TOL and max(S0.max(),S1.max())<=10800+TOL,'SOC bounds')
    require(max(c.max(),d.max())<=5000/6+TOL,'power/rate limit')
    require(np.max(np.minimum(c,d))<=TOL,'simultaneous charge and discharge')
    require(np.max(np.minimum(c,e))<=TOL,'emergency charging')
    require(np.max(v-q)<=TOL and np.max(r-G)<=TOL,'discard bounds')
    A=np.maximum(q+G-L,0);D=np.maximum(L-q-G,0)
    require(np.max(c-A)<=TOL and np.max(d-D)<=TOL,'ordinary surplus/deficit control convention')
    close(e,D-d,'emergency deficit closure');close(v+r,A-c,'unused surplus closure')
    a=np.maximum(q-g,0);b=np.maximum(g-q,0)
    close(trace['increase_kwh'],a,'signed increase');close(trace['decrease_kwh'],b,'signed decrease')
    costs={'plan_cost_yuan':p*g,'increase_cost_yuan':1.5*p*a,'refund_yuan':p*b,
        'penalty_yuan':.5*p*b,'adjustment_net_cost_yuan':1.5*p*a-.5*p*b,
        'emergency_cost_yuan':5*p*e,'cash_cost_yuan':p*g+1.5*p*a-.5*p*b+5*p*e}
    for col,value in costs.items():close(trace[col],value,col,1e-6)
    close(summary['soc_start_kwh'],S0[0],'summary initial');close(S0[0],cfg['initial_soc'],'configured initial')
    close(summary['soc_end_kwh'],S1[-1],'summary final')
    close(summary['common_inventory_value'],src['nu'],'January-frozen inventory value',1e-12)
    close(summary['terminal_weight'],src['nu']*cfg['terminal_multiplier'],'terminal weight',1e-12)
    for key,expected in {
        'cash_cost_yuan':costs['cash_cost_yuan'].sum(),'original_plan_cost_yuan':costs['plan_cost_yuan'].sum(),
        'net_adjustment_cost_yuan':costs['adjustment_net_cost_yuan'].sum(),'emergency_cost_yuan':costs['emergency_cost_yuan'].sum(),
        'emergency_kwh':e.sum(),'inventory_adjusted_cost_yuan':costs['cash_cost_yuan'].sum()-src['nu']*(S1[-1]-S0[0])}.items():
        close(summary[key],expected,'summary '+key,1e-4)
    require(len(daily)==windows,'daily count')
    close(daily['cash_cost_yuan'],costs['cash_cost_yuan'].reshape(windows,144).sum(axis=1),'daily cash',1e-5)
    close(daily['soc_start_kwh'],S0[::144],'daily initial');close(daily['soc_end_kwh'],S1[143::144],'daily terminal')
    close(daily['emergency_kwh'],e.reshape(windows,144).sum(axis=1),'daily emergency')
    close(daily['inventory_adjusted_cost_yuan'],costs['cash_cost_yuan'].reshape(windows,144).sum(axis=1)-src['nu']*(S1[143::144]-S0[::144]),'daily stock correction',1e-5)
    # Reconstruct actual signed q from immutable original g and event blocks.
    require(len(events)==windows*len(trade_hours),'unexpected/missing transaction events')
    expected_events=[(d,h) for d in range(start,stop) for h in trade_hours]
    require([(ev['day_index'],pd.Timestamp(ev['decision_at']).hour) for ev in events]==expected_events,
        'duplicate/missing/out-of-order formal transaction')
    signed=np.full((windows,144),np.nan);original=np.full_like(signed,np.nan)
    unproven=[]
    for index,ev in enumerate(events):
        day=ev['day_index'];local=day-start
        require(0<=local<windows,'event outside run')
        decision=pd.Timestamp(ev['decision_at']);h=decision.hour
        require(decision==src['dates'][day]+pd.Timedelta(hours=h),'event date/time')
        require(h in trade_hours,'price/PV update improperly grants trade')
        require(ev['objective_is_cash'] is False,'optimization objective mislabeled cash')
        first,last=ev['commit_start'],ev['commit_end'];qty=np.asarray(ev['signed_q'],float)
        require(qty.shape==(last-first,) and np.isfinite(qty).all(),'bad signed quantity block')
        if h==0:
            require(ev['kind']=='dayahead' and first==0 and last==144,'bad original order')
            require(np.isnan(original[local]).all(),'duplicate original signing')
            original[local]=qty;signed[local]=qty
            require(ev['locked_bridge']==(local>0),'midnight bridge lock flag')
        else:
            later=[START[j] for j in trade_hours if j>h]
            require(ev['kind']=='adjust' and first==START[h] and last==(min(later) if later else 144),'adjustment outside authorized block')
            require(np.isfinite(original[local]).all(),'adjustment before original order')
            signed[local,first:last]=qty
        expected_pvh=max(j for j in pv_hours if j<=h)
        expected_priceh=max(j for j in price_hours if j<=h)
        require(ev['forecast_hour']==expected_pvh and ev['price_hour']==expected_priceh,'event information permissions')
        require(ev['decision_hour']==h,'event history cutoff hour')
        history=[j for j in range(day) if src['dates'][j]+pd.Timedelta(days=1,minutes=10)<=decision][-cfg['history_days']:]
        require(ev['history_indices']==history,'future/incorrect residual history')
        require(ev['history_days']==len(history),'history length')
        latest=None if not history else (src['dates'][history[-1]]+pd.Timedelta(days=1,minutes=10)).isoformat()
        require(ev['history_latest_end']==latest,'history availability metadata')
        require(ev['price_mode']==cfg['price_mode'] and ev['margin_added'] is False,'wrong risk variant')
        if cfg['scenarios']==1 or len(history)<cfg['min_history']:
            require(ev['scenarios']==1 and ev['draw_indices']==[],'wrong point fallback')
        else:
            draw=np.random.default_rng(cfg['seed']+1009*day+59*h).choice(history,min(cfg['scenarios'],len(history)),replace=False).tolist()
            require(ev['draw_indices']==draw and ev['scenarios']==len(draw),'unpaired/reseeded scenario sampling')
            price_version=HOURS.index(expected_priceh)
            point=src['price_forecast'][day,price_version,first:]
            past_pred=src['price_forecast'][draw,price_version,first:]
            past_actual=src['price_actual'][draw,first:]
            require((past_pred>0).all() and (past_actual>0).all(),'invalid positive-price residual domain')
            scen=point[None,:]*(past_actual/past_pred)
            if cfg['price_mode']=='point':scen=np.tile(point,(len(draw),1))
            elif cfg['price_mode']=='mean':scen=np.tile(scen.mean(axis=0),(len(draw),1))
            # Shuffling rows changes the pairing, but not global min/max.
            close(ev['scenario_price_min'],scen.min(),'scenario minimum from same historical prices',1e-10)
            close(ev['scenario_price_max'],scen.max(),'scenario maximum from same historical prices',1e-10)
        require(ev['max_violation_kwh']<=TOL,'solver event infeasibility')
        if ev['status']!='optimal_within_requested_gap':unproven.append({'event':index,'gap':ev['gap'],'decision_at':ev['decision_at']})
    close(g,original.ravel(),'immutable original plan from signing events')
    close(q,signed.ravel(),'only formal adjustments change delivered contract')
    startup_cash=0.
    if start==0:
        sr=pd.read_csv(run_dir/'startup.csv');require(len(sr)==1,'missing startup convention')
        row=sr.iloc[0]
        require(row['interval_start']=='2025-02-01T00:00:00','startup interval')
        close(row['price_yuan_per_kwh'],src['price_startup'],'startup actual price',1e-12)
        close(row['load_actual_kw'],src['load_startup'],'startup actual load')
        close(row['pv_actual_kw'],src['pv_startup'],'startup actual PV')
        pv_startup_forecast=src['q2_pv'][0,0] if q2pv else src['pv_startup_forecast'][0]
        expected_g=max((src['load_f'][0,0]-pv_startup_forecast)/6,0.)
        expected_e=max((src['load_startup']-src['pv_startup'])/6-expected_g,0.)
        close(row['g_kwh'],expected_g,'startup causal original quantity')
        close(row['q_kwh'],expected_g,'startup no adjustment')
        close(row['emergency_kwh'],expected_e,'startup emergency')
        # Startup policy is battery idle; its supply is recorded separately.
        close(row['charge_kwh'],0.,'startup idle charge');close(row['discharge_kwh'],0.,'startup idle discharge')
        close(row['soc_start_kwh'],cfg['initial_soc'],'startup SOC');close(row['soc_end_kwh'],cfg['initial_soc'],'startup SOC unchanged')
        startup_cash=float(row['price_yuan_per_kwh']*(row['g_kwh']+5*row['emergency_kwh']))
        close(row['cash_cost_yuan'],startup_cash,'startup cash')
    close(summary['startup_cash_cost_yuan'],startup_cash,'startup total')
    natural=costs['cash_cost_yuan'][begins.normalize()<=src['dates'][stop-1]].sum()+startup_cash
    close(summary['natural_period_cash_cost_yuan'],natural,'natural-period total',1e-4)
    return {'passed':True,'path':display(run_dir),'strategy':summary['strategy'],'branch':summary['branch'],
        'windows':windows,'intervals':len(trace),'cash_cost_yuan':float(costs['cash_cost_yuan'].sum()),
        'physical_maximum_error_kwh':max(physical.values()),'january_inventory_value':src['nu'],
        'january_night_intervals':src['nu_intervals'],'unproven_logged_events':unproven,
        'configured_history_cap':cfg['history_days'],
        'actual_history_paths_min':min(len(ev['history_indices']) for ev in events),
        'actual_history_paths_max':max(len(ev['history_indices']) for ev in events),
        'scope':'Full trace/event/cash and current source audit; optimizer control calls not all logged, so only event-level Gap is enumerated.'}


def audit_selection(results_dir):
    """Recompute frozen choices using development windows, never test winners."""
    root=Path(results_dir)
    path=root/'selection.json'
    if not path.exists():return {'present':False,'passed':True,'reason':'selection not yet frozen or auditing a stage folder'}
    saved=json.loads(path.read_text())
    require(saved['freeze_time']=='2025-02-25T00:00:00','wrong selection freeze time')
    require(saved['model_or_schedule_reselection_from_test'] is False,'test-based reselection claimed')
    require(len(saved['development'])==18,'incomplete declared development candidates')
    recomputed=[]
    for record in saved['development']:
        run=root/'calibration'/record['strategy']
        summary=json.loads((run/'summary.json').read_text())
        daily=pd.read_csv(run/'daily.csv')
        dev=daily[daily['window_date'].between('2025-02-17','2025-02-23')]
        require(dev['window_date'].tolist()==pd.date_range('2025-02-17',periods=7).strftime('%Y-%m-%d').tolist(),
                'development must use seven completed windows before freeze')
        score=float(dev['inventory_adjusted_cost_yuan'].sum())
        close(record['score'],score,'development inventory-corrected score',1e-5)
        close(record['cash'],float(dev['cash_cost_yuan'].sum()),'development cash',1e-5)
        require(record['run_signature']==summary['run_signature'],'selection source signature mismatch')
        require(record['branch']==summary['branch'] and record['price_mode']==summary['config']['price_mode']
                and record['trade_hours']==summary['config']['trade_hours'],'selection candidate configuration mismatch')
        recomputed.append({**record,'score':score})
    winners={}
    for branch,key in [('4-2','selected_q42'),('4-3','selected_q43')]:
        best=min((r for r in recomputed if r['branch']==branch),key=lambda r:(r['score'],r['strategy']))
        require(saved[key]==best['strategy'],'selected strategy is not development minimum')
        require(saved['branch_selections'][branch]==next(r for r in saved['development'] if r['strategy']==best['strategy']),
                'branch selection differs from development record')
        winners[branch]=best['strategy']
    return {'present':True,'passed':True,'development_candidates':18,'development_windows':7,
        'selection':winners,'uses_test_cash_for_choice':False}


def audit_all(data_dir=ROOT/'data',results_dir=ROOT/'results'):
    data_dir=Path(data_dir).resolve();results_dir=Path(results_dir).resolve()
    source=source_data(data_dir)
    reports=[];errors=[];pending=[];designs=[]
    for design_path in sorted(results_dir.rglob('design.json')):
        design=json.loads(design_path.read_text())
        if 'jobs' not in design:continue
        names=[job.get('name') for job in design['jobs']]
        require(all(names) and len(names)==len(set(names)),f'{design_path}: invalid/duplicate planned jobs')
        designs.append({'path':display(design_path),'expected_runs':len(names)})
        for name in names:
            summary_path=design_path.parent/name/'summary.json'
            if not summary_path.exists() or not json.loads(summary_path.read_text()).get('complete'):
                pending.append(display(summary_path.parent))
    for path in sorted(results_dir.rglob('summary.json')):
        doc=json.loads(path.read_text())
        if not (doc.get('complete') and doc.get('branch') in ('4-2','4-3') and 'run_signature' in doc):continue
        try:reports.append(audit_run(path.parent,data_dir,source))
        except Exception as exc:errors.append({'path':display(path.parent),'error':f'{type(exc).__name__}: {exc}'})
    try:selection=audit_selection(results_dir)
    except Exception as exc:
        selection={'present':True,'passed':False};errors.append({'path':display(results_dir/'selection.json'),'error':f'{type(exc).__name__}: {exc}'})
    return {'passed':bool(reports) and not errors and not pending,'audited_runs':len(reports),'errors':errors,
        'pending_runs':pending,'declared_designs':designs,'selection_audit':selection,
        'audited_intervals':sum(r['intervals'] for r in reports),'runs':reports,
        'source_sha256':source['source_sha256'],'source_observation_kind':'original instantaneous nodes averaged exactly once',
        'covered_run_format':'q4_runner strategy traces/events; causal micro-step replay uses its separate q4_causal_audit',
        'settlement':'actual delivery endpoint-mean price; original+1.5*increase-0.5*decrease+5*emergency',
        'boundary':'last missing actual right node held and flagged; no future node fabricated as observed'}


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--data',type=Path,default=ROOT/'data')
    p.add_argument('--results',type=Path,default=ROOT/'results');p.add_argument('--output',type=Path)
    a=p.parse_args();result=audit_all(a.data,a.results)
    output=a.output or a.results/'independent_audit.json';output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print(json.dumps({'passed':result['passed'],'audited_runs':result['audited_runs'],
        'pending_runs':result['pending_runs'],'errors':result['errors']},ensure_ascii=False))
    raise SystemExit(0 if result['passed'] else 1)
