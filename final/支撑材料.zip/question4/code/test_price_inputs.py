import json
from pathlib import Path
import unittest
import numpy as np

from xgb_intraday import features_at_issue,training_arrays_at_issue,forecast_intraday
from price_inputs import assemble_arrays,extrapolate_last_node,read_attachment4,GATE_SLOTS

ROOT=Path(__file__).resolve().parents[1]


class TestIntradayPrices(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.raw=read_attachment4(ROOT/'data/attachment4.xlsx')
        cls.flat=cls.raw.ravel()
        cls.cfg=json.loads((ROOT/'data/xgboost_midnight_summary.json').read_text())['config']

    def test_features_cannot_see_future_after_release(self):
        for hour in (6,12,18):
            day=31;cutoff=day*144+hour*6
            expected,_,targets=features_at_issue(self.flat,day,hour)
            changed=self.flat.copy();changed[cutoff:]+=1000
            actual,_,_=features_at_issue(changed,day,hour)
            np.testing.assert_array_equal(expected,actual)
            self.assertEqual(targets[0],cutoff)
            self.assertEqual(targets[-1],(day+1)*144)
            self.assertEqual(expected[0,0],hour*6)
            self.assertEqual(expected[-1,0],0)
            self.assertEqual(expected[-1,2],6)  # Feb2, 2025 is Sunday

    def test_actual_xgboost_prediction_future_perturbation(self):
        day=31;hour=6;cutoff=day*144+hour*6
        expected,_=forecast_intraday(self.flat,day,hour,self.cfg)
        changed=self.flat.copy();changed[cutoff:]=-1000
        actual,_=forecast_intraday(changed,day,hour,self.cfg)
        np.testing.assert_array_equal(expected,actual)

    def test_past_issue_features_and_label_release_cutoff(self):
        for hour in (6,12,18):
            day=31;cutoff=day*144+hour*6
            X,y,a,diag=training_arrays_at_issue(self.flat,day,hour,28)
            self.assertTrue((diag['label_indices']<cutoff).all())
            self.assertTrue((diag['origin_days']<day).all())
            self.assertEqual(diag['first_training_origin_day'],7)
            self.assertEqual(diag['same_issue_hour'],hour)
            np.testing.assert_array_equal(y,self.flat[diag['label_indices']])
            changed=self.flat.copy();changed[cutoff:]=np.nan
            X2,y2,_,_=training_arrays_at_issue(changed,day,hour,28)
            np.testing.assert_array_equal(X,X2);np.testing.assert_array_equal(y,y2)
            # Historical issue-date price is its own known end point, not the
            # current day's latest actual injected into all past feature rows.
            issue_nodes=diag['origin_days']*144+hour*6-1
            np.testing.assert_array_equal(X[:,17],self.flat[issue_nodes])

    def test_zero_nodes_inherited_exactly_and_intervals_not_divided_by_six(self):
        with np.load(ROOT/'data/xgboost_midnight_predictions.npz') as z: midnight=z['predictions'].copy()
        updates={h:np.full((334,145-h*6),.5) for h in (6,12,18)}
        arrays=assemble_arrays(self.raw,midnight,updates)
        np.testing.assert_array_equal(arrays['nodes'][:,0],midnight)
        np.testing.assert_array_equal(arrays['predicted'][:,0],(midnight[:,:-1]+midnight[:,1:])/2)
        self.assertAlmostEqual(arrays['forecast_bridge'][0],(self.raw[30,143]+midnight[0,0])/2)
        self.assertAlmostEqual(arrays['actual_bridge'][0],(self.raw[30,143]+self.raw[31,0])/2)

    def test_release_node_and_old_intervals_not_available(self):
        midnight=np.full((334,145),.4)
        updates={h:np.full((334,145-h*6),.8) for h in (6,12,18)}
        arrays=assemble_arrays(self.raw,midnight,updates)
        for v,slot in enumerate(GATE_SLOTS[1:],1):
            self.assertTrue(np.isnan(arrays['predicted'][:,v,:slot]).all())
            np.testing.assert_array_equal(arrays['nodes'][:,v,slot],self.raw[31:,slot])
            np.testing.assert_allclose(arrays['predicted'][:,v,slot],(self.raw[31:,slot]+.8)/2)
        self.assertTrue(np.isnan(arrays['raw_actual_nodes'][-1,-1]))
        self.assertEqual(arrays['actual_estimated'].sum(),1)
        self.assertTrue(arrays['actual_estimated'][-1,-1])

    def test_boundary_methods_and_no_price_clipping(self):
        y=np.linspace(.1,.6,6)
        self.assertAlmostEqual(extrapolate_last_node(y,'hold'),.6)
        self.assertAlmostEqual(extrapolate_last_node(y,'linear2'),.7)
        self.assertAlmostEqual(extrapolate_last_node(y,'ols6'),.7)
        self.assertAlmostEqual(extrapolate_last_node(np.array([1,.8,.6,.4,.2,0]),'linear2'),-.2)
        midnight=np.full((334,145),-.1)
        updates={h:np.full((334,145-h*6),.8) for h in (6,12,18)}
        arrays=assemble_arrays(self.raw,midnight,updates)
        self.assertTrue((arrays['predicted'][:,0]==-.1).all())

    def test_midnight_cannot_be_refit_via_update_entry(self):
        with self.assertRaises(ValueError):forecast_intraday(self.flat,31,0,self.cfg)


if __name__=='__main__':unittest.main()
