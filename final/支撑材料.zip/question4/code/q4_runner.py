"""Q4 rolling policy: causal price information, delivery-price cash ledger.

Current load/PV interval means are fast-feedback execution approximations.
Only actual prices at or before the action timestamp may affect a decision.
All interval actual prices are used for settlement AFTER the action is chosen.
"""
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
import argparse,csv,datetime as dt,hashlib,importlib.metadata,itertools,json,time
import numpy as np
from q4_io import load_inputs,selected_pv
from q4_risk import HOURS,START,scenario_inputs,latest_hour,future_mask,current_block
from q4_optimizer import solve_dispatch,solve_fixed_control,LOW,HIGH,RATE,ETA_C,ETA_D

ROOT=Path(__file__).resolve().parents[1]
DEFAULT=dict(scenarios=8,history_days=28,min_history=14,seed=20260912,controller='mpc',
    pv_source='supplied',initial_soc=6000.,time_limit=10.,mip_gap=1e-4,price_mode='joint',
    price_hours=[0,6,12,18],terminal_multiplier=1.)
SCHEDULES=[(0,)+s for n in range(4) for s in itertools.combinations((6,12,18),n)]
CORE=('physical_io.py','q4_io.py','q4_optimizer.py','q4_risk.py','q4_runner.py','price_inputs.py','xgb_intraday.py')


def dump(path,value):
    Path(path).parent.mkdir(exist_ok=True,parents=True)
    Path(path).write_text(json.dumps(value,indent=2,ensure_ascii=False,default=str),encoding='utf-8')


def write_csv(path,rows):
    if not rows:return
    with open(path,'w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)


def signature(data_dir,config):
    h=hashlib.sha256(json.dumps(config,sort_keys=True).encode())
    for name in CORE:
        path=ROOT/'code'/name
        if path.exists():h.update(name.encode());h.update(path.read_bytes())
    for path in sorted(Path(data_dir).glob('*')):
        if path.is_file() and path.suffix in ('.xlsx','.npz'):
            h.update(path.name.encode());h.update(path.read_bytes())
    for name in ('numpy','scipy','pandas','openpyxl'):
        h.update((name+importlib.metadata.version(name)).encode())
    return h.hexdigest()


def validate_arguments(branch,trade_hours,forecast_hours,config,start_day,days):
    if branch not in ('4-2','4-3'):raise ValueError('Unknown question branch')
    for hours in (trade_hours,forecast_hours,config['price_hours']):
        if not hours or tuple(sorted(set(hours)))!=tuple(hours) or hours[0]!=0 or not set(hours)<=set(HOURS):
            raise ValueError('Release schedule must be a sorted subset of 0/6/12/18 containing 0')
    if branch=='4-2' and tuple(trade_hours)!=(0,):raise ValueError('Q4-2 cannot adjust ordinary orders')
    if not isinstance(start_day,int) or not 0<=start_day<334 or (days is not None and (not isinstance(days,int) or days<1)):
        raise ValueError('Invalid start or length')
    for key in ('scenarios','history_days','min_history'):
        if not isinstance(config[key],int) or config[key]<1:raise ValueError('Invalid history/scenario count')
    if config['history_days']<config['min_history']:raise ValueError('History shorter than minimum')
    if config['price_mode'] not in ('point','joint','mean','shuffled'):raise ValueError('Unknown price mode')
    if config['controller'] not in ('mpc','greedy'):raise ValueError('Unknown controller')
    if not np.isfinite(config['initial_soc']) or not LOW<=config['initial_soc']<=HIGH:raise ValueError('Invalid initial SOC')
    if not np.isfinite(config['terminal_multiplier']) or config['terminal_multiplier']<0:raise ValueError('Invalid terminal weight')


def make_record(data,day,t,name,branch,g,q,c,d,e,state,pv_hour,price_hour,pforecast,*,startup=False,price_issue_day=None):
    if startup:
        z=data['first_unexecuted_interval'];L=z['load_mean_kw'];G=z['pv_mean_kw']
        begin=dt.datetime.combine(data['dates'][0],dt.time())
        lf=float(data['load_f'][0,0]);pf=float(data['startup_pv_forecast'])
        p=float(data['startup_price_actual']);estimated=False
    else:
        L=float(data['load_a'][day,t]);G=float(data['pv_a'][day,t])
        begin=data['window_start'][day]+dt.timedelta(minutes=10*t)
        lf=float(data['load_f'][day,t]);pf=float(data['policy_pv'][day,HOURS.index(pv_hour),t])
        p=float(data['price_a'][day,t]);estimated=bool(data['actual_estimated'][day,t])
    waste=max(q+G/6+d+e-L/6-c,0.)
    v=min(q,waste);r=max(waste-v,0.)
    a=max(q-g,0.);b=max(g-q,0.)
    end_state=state+ETA_C*c-d/ETA_D
    # A bridge uses the NEW day's price release while preserving the old PV
    # version and old ordinary contract. Record the actual price release date.
    price_day=data['dates'][day] if price_issue_day is None else price_issue_day
    return dict(strategy=name,branch=branch,window_date=str(data['dates'][day]),
        interval_start=begin.isoformat(),interval_end=(begin+dt.timedelta(minutes=10)).isoformat(),
        forecast_issue_time=dt.datetime.combine(data['dates'][day],dt.time(pv_hour)).isoformat(),
        price_forecast_issue_time=dt.datetime.combine(price_day,dt.time(price_hour)).isoformat(),
        price_forecast_hour=price_hour,price_forecast_yuan_per_kwh=float(pforecast),price_yuan_per_kwh=p,
        load_forecast_kw=lf,pv_forecast_kw=pf,load_actual_kw=L,pv_actual_kw=G,
        actual_estimated=estimated,price_estimated=bool(False if startup else data['price_estimated'][day,t]),
        g_kwh=float(g),q_kwh=float(q),increase_kwh=float(a),decrease_kwh=float(b),
        charge_kwh=float(c),discharge_kwh=float(d),emergency_kwh=float(e),
        unused_paid_kwh=float(v),curtailed_pv_kwh=float(r),soc_start_kwh=float(state),soc_end_kwh=float(end_state),
        plan_cost_yuan=p*g,increase_cost_yuan=1.5*p*a,refund_yuan=p*b,penalty_yuan=.5*p*b,
        adjustment_net_cost_yuan=1.5*p*a-.5*p*b,emergency_cost_yuan=5*p*e,
        cash_cost_yuan=p*g+1.5*p*a-.5*p*b+5*p*e)


def run_strategy(data_dir,out_dir,trade_hours=(0,6,12,18),*,branch='4-3',forecast_hours=None,
                 config=None,start_day=0,days=None,name=None):
    config={**DEFAULT,**(config or {})};trade_hours=tuple(trade_hours)
    if forecast_hours is None:
        forecast_hours=(0,) if branch=='4-2' and config['pv_source']!='q3_all' else trade_hours
    forecast_hours=tuple(forecast_hours)
    validate_arguments(branch,trade_hours,forecast_hours,config,start_day,days)
    name=name or 'Q'+branch.replace('-','')+'_'+config['price_mode']+'_H'+'_'.join(map(str,trade_hours))
    config.update(branch=branch,trade_hours=list(trade_hours),forecast_hours=list(forecast_hours),
        start_day=start_day,days=days,strategy=name)
    target=Path(out_dir)/name;target.mkdir(exist_ok=True,parents=True)
    sig=signature(data_dir,config)
    if (target/'summary.json').exists():
        old=json.loads((target/'summary.json').read_text())
        if old.get('complete') and old.get('run_signature')==sig:return old
        raise RuntimeError(f'Incompatible cached run {target}; choose new output directory')
    data=load_inputs(data_dir)
    data['policy_pv']=selected_pv(data,branch,config['pv_source'])
    data['startup_pv_forecast']=float(data['q2_pv_f'][0,0] if branch=='4-2' and config['pv_source']!='q3_all'
        else data['pv_unused_first_mean_kw'][0])
    nu=data['inventory_value'];kappa=nu*config['terminal_multiplier']
    opts=dict(terminal_weight=kappa,time_limit=config['time_limit'],mip_gap=config['mip_gap'])
    stop=min(334,start_day+(days or 334));state=float(config['initial_soc'])
    rows=[];daily=[];events=[];g=q=None
    stats=dict(solves=0,milp_solves=0,lp_solves=0,seconds=0.,unproven=0,max_gap=0.,
        max_physical_error=0.,surplus_direct_steps=0)
    beginning=time.perf_counter()

    def solve(L,G,p,s,**kwargs):
        sol=solve_dispatch(L,G,p,s,**opts,**kwargs)
        stats['solves']+=1;stats['milp_solves']+=1;stats['seconds']+=sol['solve_seconds']
        stats['unproven']+=int(not sol['optimality_proven'])
        stats['max_gap']=max(stats['max_gap'],sol['gap'] or 0.)
        stats['max_physical_error']=max(stats['max_physical_error'],sol['checks']['max_violation_kwh'])
        return sol

    def log_event(day,h,kind,sol,meta,first,last,bridge=False):
        events.append(dict(window_date=str(data['dates'][day]),day_index=day,kind=kind,
            decision_at=dt.datetime.combine(data['dates'][day],dt.time(h)).isoformat(),
            **meta,commit_start=first,commit_end=last,locked_bridge=bridge,
            signed_q=sol['signed_q'].tolist(),status=sol['status'],gap=sol['gap'],
            solve_seconds=sol['solve_seconds'],objective=sol['objective'],objective_is_cash=False,
            max_violation_kwh=sol['checks']['max_violation_kwh']))

    def control(L,G,p,base,booked,future,actual_l,actual_pv):
        surplus=max(booked[0]+actual_pv-actual_l,0.)
        deficit=max(actual_l-booked[0]-actual_pv,0.)
        if surplus>1e-9:
            stats['surplus_direct_steps']+=1
            return min(surplus,RATE,max((HIGH-state)/ETA_C,0.)),0.,0.
        if config['controller']=='greedy':
            d=min(deficit,RATE,max((state-LOW)*ETA_D,0.))
            return 0.,d,max(deficit-d,0.)
        L=L.copy();G=G.copy();L[0]=actual_l;G[0]=actual_pv
        if not future.any():
            sol=solve_fixed_control(L,G,p,booked,state,terminal_weight=kappa,time_limit=config['time_limit'])
            stats['solves']+=1;stats['lp_solves']+=1;stats['seconds']+=sol['solve_seconds']
            stats['max_physical_error']=max(stats['max_physical_error'],sol['max_violation_kwh'])
            return float(sol['c'][0]),float(sol['d'][0]),float(sol['e'][0])
        sol=solve(L[None,:],G[None,:],p,state,mode='control',base_g=base,booked_q=booked,future_adjust_mask=future)
        return float(sol['c'][0,0]),float(sol['d'][0,0]),float(sol['e'][0,0])

    def execute(day,t,L,G,p,base,booked,future,fh,ph,price_issue_day=None):
        nonlocal state
        c,d,e=control(L,G,p,base,booked,future,data['load_a'][day,t]/6,data['pv_a'][day,t]/6)
        r=make_record(data,day,t,name,branch,float(base[0]),float(booked[0]),c,d,e,state,fh,ph,float(p[0]),price_issue_day=price_issue_day)
        rows.append(r);state=r['soc_end_kwh']
        if not LOW-1e-5<=state<=HIGH+1e-5:raise RuntimeError('Executed SOC violation')

    def finish_day(day):
        part=rows[-144:]
        if len(part)!=144 or any(r['window_date']!=str(data['dates'][day]) for r in part):
            raise RuntimeError('Incomplete contract window')
        cash=sum(r['cash_cost_yuan'] for r in part)
        daily.append(dict(strategy=name,window_date=str(data['dates'][day]),cash_cost_yuan=cash,
            soc_start_kwh=part[0]['soc_start_kwh'],soc_end_kwh=part[-1]['soc_end_kwh'],
            inventory_adjusted_cost_yuan=cash-nu*(part[-1]['soc_end_kwh']-part[0]['soc_start_kwh']),
            emergency_kwh=sum(r['emergency_kwh'] for r in part)))

    def point_prices(day,t,ph):
        p=data['price_f'][day,HOURS.index(ph),t:].copy()
        # Only the left endpoint is available at interval start. Never average
        # it with the unknown right ACTUAL endpoint inside a control objective.
        p[0]=(data['price_nodes_a'][day,t]+data['price_nodes_f'][day,HOURS.index(ph),t+1])/2
        return p

    for day in range(start_day,stop):
        L,G,P,meta=scenario_inputs(data,day,0,0,0,0,config)
        fm=future_mask(trade_hours,0);locked=np.zeros(144,bool)
        bridge=day>start_day
        if bridge:
            oldg,oldq=g.copy(),q.copy();oldfh=latest_hour(forecast_hours,143)
            oldL=float(data['load_f'][day-1,143]/6)
            oldG=float(data['policy_pv'][day-1,HOURS.index(oldfh),143]/6)
            bp=float(data['bridge_price_forecast'][day])
            L=np.column_stack((np.full(len(L),oldL),L));G=np.column_stack((np.full(len(G),oldG),G))
            P=np.column_stack((np.full(len(P),bp),P))
            locked=np.r_[True,locked];fm=np.r_[False,fm];booked=np.r_[oldq[-1],np.zeros(144)]
        else:booked=np.zeros(144)
        sol=solve(L,G,P,state,mode='dayahead',locked_mask=locked,booked_q=booked,future_adjust_mask=fm)
        g=sol['g'][-144:].copy();q=g.copy()
        log_event(day,0,'dayahead',sol,meta,0,144,bridge)
        if bridge:
            base=np.r_[oldg[-1],g];booked=np.r_[oldq[-1],q]
            lf=np.r_[oldL,data['load_f'][day]/6];pf=np.r_[oldG,data['policy_pv'][day,0]/6]
            pp=np.r_[bp,data['price_f'][day,0]]
            execute(day-1,143,lf,pf,pp,base,booked,fm,oldfh,0,price_issue_day=data['dates'][day])
            finish_day(day-1)
        for t in range(143):
            h=next((h for h in trade_hours if h and START[h]==t),None)
            fh=latest_hour(forecast_hours,t);ph=latest_hour(config['price_hours'],t)
            if h is not None:
                first,last=current_block(trade_hours,h)
                L,G,P,meta=scenario_inputs(data,day,fh,ph,h,t,config)
                current=np.arange(t,144)<last
                sol=solve(L,G,P,state,mode='adjust',base_g=g[t:],booked_q=q[t:],current_mask=current,
                    future_adjust_mask=future_mask(trade_hours,t))
                if not np.array_equal(sol['signed_mask'],current):raise RuntimeError('Wrong signed block')
                q[t:last]=sol['q'][:last-t]
                log_event(day,h,'adjust',sol,meta,first,last)
            execute(day,t,data['load_f'][day,t:]/6,data['policy_pv'][day,HOURS.index(fh),t:]/6,
                point_prices(day,t,ph),g[t:],q[t:],future_mask(trade_hours,t),fh,ph)
        if (day-start_day+1)%10==0 or day==stop-1:
            dump(target/'progress.json',dict(day=str(data['dates'][day]),days_started=day-start_day+1,
                total_days=stop-start_day,elapsed_seconds=time.perf_counter()-beginning,solver=stats))
            print(f'{name}: {day-start_day+1}/{stop-start_day}, {time.perf_counter()-beginning:.1f}s',flush=True)
    day=stop-1;fh=latest_hour(forecast_hours,143);ph=latest_hour(config['price_hours'],143)
    execute(day,143,data['load_f'][day,143:]/6,data['policy_pv'][day,HOURS.index(fh),143:]/6,
        point_prices(day,143,ph),g[143:],q[143:],np.zeros(1,bool),fh,ph)
    finish_day(day)
    write_csv(target/'trace.csv',rows);write_csv(target/'daily.csv',daily)
    dump(target/'event_log.json',dict(config=config,events=events))
    startup=[]
    if start_day==0:
        z=data['first_unexecuted_interval'];G=data['startup_pv_forecast']/6
        g0=max(float(data['load_f'][0,0]/6)-G,0.)
        e0=max(z['load_mean_kw']/6-g0-z['pv_mean_kw']/6,0.)
        startup=[make_record(data,0,0,name,branch,g0,g0,0.,0.,e0,config['initial_soc'],0,0,
            data['bridge_price_forecast'][0],startup=True)]
        write_csv(target/'startup.csv',startup)
    total=sum(r['cash_cost_yuan'] for r in rows)
    summary=dict(strategy=name,branch=branch,config=config,complete=True,run_signature=sig,
        intervals=len(rows),windows=stop-start_day,cash_cost_yuan=total,
        soc_start_kwh=config['initial_soc'],soc_end_kwh=state,common_inventory_value=nu,terminal_weight=kappa,
        inventory_adjusted_cost_yuan=total-nu*(state-config['initial_soc']),
        emergency_kwh=sum(r['emergency_kwh'] for r in rows),
        original_plan_cost_yuan=sum(r['plan_cost_yuan'] for r in rows),
        net_adjustment_cost_yuan=sum(r['adjustment_net_cost_yuan'] for r in rows),
        emergency_cost_yuan=sum(r['emergency_cost_yuan'] for r in rows),
        startup_cash_cost_yuan=sum(r['cash_cost_yuan'] for r in startup),
        natural_period_cash_cost_yuan=sum(r['cash_cost_yuan'] for r in rows if r['interval_start'][:10]<=str(data['dates'][stop-1]))+sum(r['cash_cost_yuan'] for r in startup),
        execution='Current 10-minute actual load/PV mean fast-feedback approximation; actual right-end prices never used for decisions.',
        elapsed_seconds=time.perf_counter()-beginning,solver=stats)
    dump(target/'summary.json',summary)
    return summary


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--data',type=Path,default=ROOT/'data')
    p.add_argument('--out',type=Path,required=True);p.add_argument('--branch',choices=('4-2','4-3'),default='4-3')
    p.add_argument('--price-mode',default='joint');p.add_argument('--schedule',default='0,6,12,18')
    p.add_argument('--days',type=int);p.add_argument('--start-day',type=int,default=0)
    a=p.parse_args()
    r=run_strategy(a.data,a.out,tuple(map(int,a.schedule.split(','))),branch=a.branch,
        config={'price_mode':a.price_mode},days=a.days,start_day=a.start_day)
    print(json.dumps(r,ensure_ascii=False,default=str))
