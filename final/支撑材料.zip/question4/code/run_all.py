"""Reproduce Q4 in the declared chronological order, with checked caches."""
from pathlib import Path
import argparse, datetime as dt, hashlib, json, subprocess, sys, time
from price_inputs import build_price_inputs
from audit_price_inputs import audit_prices
from q4_io import load_inputs
from q4_runner import ROOT, dump
from q4_study import run_jobs, jobs_for_calibration, freeze, main_jobs, sensitivity_jobs
from q4_audit import audit_all
from q4_causal_study import run_study as run_causal_study
from q4_causal_audit import audit_study as audit_causal_study
from q4_reports import build_reports
from q4_figures import build_figures
from q4_history_check import run_history_check
from q4_solver_check import run_solver_check
from q4_price_reports import build_price_report
from q4_four_day_review import review_four_days


def causal_jobs(selection):
    schedule=selection['branch_selections']['4-3']['trade_hours']
    suffix='_H'+'_'.join(map(str,schedule))
    selected={selection['selected_q42'],selection['selected_q43']}
    return [(name,(1.,.1) if name in selected else (1.,)) for name in
        ['Q42_point_H0','Q42_joint_H0','Q43_point'+suffix,'Q43_joint'+suffix]]


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data',type=Path,default=ROOT/'data')
    parser.add_argument('--out',type=Path,default=ROOT/'results/reproduced')
    parser.add_argument('--workers',type=int,default=4)
    parser.add_argument('--document',action='store_true',help='Also build Word/PDF using installed Pandoc/LibreOffice')
    args=parser.parse_args()
    if args.workers<1:parser.error('workers must be positive')
    data=args.data.resolve();out=args.out.resolve();out.mkdir(parents=True,exist_ok=True)
    manifest={'started_at':dt.datetime.now().isoformat(),'complete':False,'stages':[],
        'data_dir':str(data),'output_dir':str(out),'python':sys.version,
        'cache_policy':'Reuse completed numerical runs only with identical input bytes/core/config/numerical-library signatures.'}
    start=time.perf_counter()
    def stage(name,fn):
        print('Starting:',name,flush=True);t=time.perf_counter()
        result=fn()
        manifest['stages'].append({'name':name,'complete':True,'elapsed_seconds':time.perf_counter()-t})
        dump(out/'run_all_manifest.json',manifest)
        return result
    try:
        stage('price_inputs',lambda:build_price_inputs(data,min(3,args.workers)))
        stage('price_audit',lambda:audit_prices(data))
        info=stage('power_and_time_inputs',lambda:load_inputs(data))
        dump(out/'input_audit.json',info['metadata'])
        stage('tests',lambda:subprocess.run([sys.executable,'-m','unittest','discover',
            '-s',str(ROOT/'code'),'-p','test*.py'],check=True))
        stage('calibration',lambda:run_jobs(data,out/'calibration',jobs_for_calibration(),args.workers))
        selection=stage('freeze_selection',lambda:freeze(out,data))
        stage('main',lambda:run_jobs(data,out/'main',main_jobs(selection),args.workers))
        stage('sensitivity',lambda:run_jobs(data,out/'sensitivity',sensitivity_jobs(selection),args.workers))
        stage('mature_history_window_check',lambda:run_history_check(data,out,min(2,args.workers)))
        def audit():
            report=audit_all(data,out)
            dump(out/'independent_audit.json',report)
            if not report.get('passed',False):raise RuntimeError('Independent audit failed; see independent_audit.json')
            return report
        stage('independent_audit',audit)
        stage('solver_precision_check',lambda:run_solver_check(data,out))
        stage('causal_execution',lambda:run_causal_study(out,data))
        stage('causal_audit',lambda:audit_causal_study(out,data))
        stage('template_and_four_days',lambda:build_reports(data,out,selection['selected_q42'],selection['selected_q43']))
        stage('independent_four_day_review',lambda:review_four_days(out))
        stage('readable_price_versions',lambda:build_price_report(data,out))
        stage('figures',lambda:build_figures(out))
        from q4_analysis import build_analysis
        stage('analysis_and_boundaries',lambda:build_analysis(data,out))
        from q4_conclusions import build_conclusions
        stage('conclusions',lambda:build_conclusions(out))
        if args.document:
            from build_document import build_document
            stage('word_and_pdf',lambda:build_document(out))
        manifest['complete']=True;manifest['ended_at']=dt.datetime.now().isoformat()
        manifest['elapsed_seconds']=time.perf_counter()-start
        dump(out/'run_all_manifest.json',manifest)
        print('Complete:',out,flush=True)
    except Exception as error:
        manifest['failure']=repr(error);manifest['elapsed_seconds']=time.perf_counter()-start
        dump(out/'run_all_manifest.json',manifest)
        raise


if __name__=='__main__':main()
