"""Counterfactual information-barrier tests on real first-day inputs."""
import tempfile, unittest
from pathlib import Path
from unittest.mock import patch
import numpy as np
import pandas as pd
from q3_io import load_inputs
from q3_risk import available_history
from q3_runner import run_strategy

ROOT=Path(__file__).resolve().parents[1]

class ChronologyTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.data=load_inputs(ROOT/'data')

    def replay(self,data,schedule=(0,6),days=1):
        with tempfile.TemporaryDirectory() as tmp,patch('q3_runner.load_inputs',return_value=data):
            r=run_strategy(ROOT/'data',tmp,schedule,days=days,config={'scenarios':1})
            return pd.read_csv(Path(tmp)/r['strategy']/'trace.csv')

    def test_disabled_versions_cannot_change_plan_or_execution(self):
        a=self.replay(self.data)
        d={**self.data,'pv_f':self.data['pv_f'].copy()}
        d['pv_f'][:,2:,:]=np.nan_to_num(d['pv_f'][:,2:,:])*10+123456
        b=self.replay(d)
        np.testing.assert_allclose(a.select_dtypes('number'),b.select_dtypes('number'),atol=1e-8)

    def test_unobserved_afternoon_cannot_change_morning(self):
        a=self.replay(self.data)
        d={**self.data,'load_a':self.data['load_a'].copy()}
        d['load_a'][0,100:]*=1.5
        b=self.replay(d)
        cols=['g_kwh','q_kwh','charge_kwh','discharge_kwh','soc_end_kwh']
        np.testing.assert_allclose(a.loc[:99,cols],b.loc[:99,cols],atol=1e-8)

    def test_midnight_old_tail_not_seen_when_signing_new_day(self):
        a=self.replay(self.data,days=2)
        d={**self.data,'load_a':self.data['load_a'].copy()}
        d['load_a'][0,143]*=1.4
        b=self.replay(d,days=2)
        np.testing.assert_allclose(a.loc[144:,'g_kwh'],b.loc[144:,'g_kwh'],atol=1e-8)

    def test_history_release_boundary(self):
        self.assertNotIn(13,available_history(self.data,14,0))
        self.assertIn(13,available_history(self.data,14,6))
        self.assertEqual(len(available_history(self.data,40,0)),28)

if __name__=='__main__':unittest.main()
