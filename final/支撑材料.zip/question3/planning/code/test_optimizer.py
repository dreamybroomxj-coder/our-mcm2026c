"""Physical, contractual and settlement tests for the Q3 optimizer."""
import unittest
import numpy as np

from q3_optimizer import (solve_dispatch, cash_components, LOW, HIGH, RATE,
                          ETA_C, ETA_D)


class DispatchTests(unittest.TestCase):
    def solve(self, load, pv=None, p=None, s0=LOW, **kwargs):
        load = np.atleast_2d(np.asarray(load, float))
        pv = np.zeros_like(load) if pv is None else np.atleast_2d(pv)
        p = np.ones(load.shape[1]) if p is None else p
        return solve_dispatch(load, pv, p, s0, terminal_weight=0, **kwargs)

    def test_cancellation_refund_100_to_80_cost_90(self):
        r = self.solve([80], mode="adjust", base_g=[100], current_mask=[True])
        self.assertAlmostEqual(r["q"][0], 80, places=6)
        self.assertAlmostEqual(r["objective"], -10, places=6)
        cash = cash_components([1], [100], r["q"], r["e"][0])
        self.assertAlmostEqual(cash["total_cash_cost"], 90, places=6)
        self.assertAlmostEqual(cash["refund"], 20, places=6)
        self.assertAlmostEqual(cash["cancellation_penalty"], 10, places=6)

    def test_increase_100_to_120_cost_130(self):
        r = self.solve([120], mode="adjust", base_g=[100], current_mask=[True])
        self.assertAlmostEqual(r["q"][0], 120, places=6)
        self.assertAlmostEqual(r["objective"], 30, places=6)
        self.assertAlmostEqual(cash_components([1], [100], r["q"], r["e"][0])["total_cash_cost"], 130, places=6)

    def test_fixed_contract_does_not_receive_automatic_refund(self):
        r = self.solve([80], mode="control", base_g=[100], booked_q=[100], locked_mask=[True])
        self.assertEqual(r["q"][0], 100)
        self.assertEqual(r["signed_mask"].sum(), 0)
        self.assertEqual(r["a"].sum()+r["b"].sum(), 0)
        self.assertEqual(r["original_cost_in_objective"], 0)
        self.assertEqual(r["expected_adjustment_cost"], 0)
        self.assertAlmostEqual(cash_components([1], [100], r["q"], r["e"][0])["total_cash_cost"], 100)

    def test_current_q_is_shared_and_future_q_can_differ(self):
        r = self.solve([[0, 0], [100, 100]], mode="adjust", base_g=[0, 0],
                       current_mask=[True, False], future_adjust_mask=[False, True])
        self.assertAlmostEqual(r["q_scenarios"][0,0], r["q_scenarios"][1,0])
        self.assertGreater(r["q_scenarios"][1,1]-r["q_scenarios"][0,1], 1)
        np.testing.assert_array_equal(r["signed_mask"], [True, False])
        self.assertEqual(r["q"][1], 0)  # Future proposal is not signed.

    def test_future_control_can_plan_adjustment_but_signs_nothing(self):
        r = self.solve([10, 100], mode="control", base_g=[10, 0],
                       locked_mask=[True, False], future_adjust_mask=[False, True])
        self.assertEqual(r["signed_mask"].sum(), 0)
        np.testing.assert_array_equal(r["q"], [10, 0])
        np.testing.assert_allclose(r["q_scenarios"], [[10, 100]], atol=1e-6)
        self.assertAlmostEqual(r["objective"], 150, places=5)

    def test_locked_adjusted_bridge_is_honored_without_second_charge(self):
        r = self.solve([120, 80], mode="dayahead", booked_q=[120, 0],
                       base_g=[100, 0], locked_mask=[True, False])
        np.testing.assert_allclose(r["g"], [120,80], atol=1e-6)
        np.testing.assert_array_equal(r["signed_mask"], [False,True])
        self.assertAlmostEqual(r["new_plan_cost"], 80, places=6)
        self.assertAlmostEqual(r["objective"], 80, places=6)

    def test_dayahead_no_future_adjustments_is_q2_structure(self):
        r = self.solve([[10, 100], [20, 120]], p=[.5, 1.5])
        np.testing.assert_allclose(r["q_scenarios"], np.broadcast_to(r["g"], (2,2)), atol=1e-7)
        self.assertEqual(r["expected_adjustment_cost"], 0)
        self.assertAlmostEqual(r["objective"], np.array([.5,1.5]) @ r["g"]+r["expected_emergency_cost"], places=6)

    def test_dayahead_future_recourse_and_original_fee(self):
        r = self.solve([[0], [100]], future_adjust_mask=[True], probabilities=[.9,.1])
        self.assertAlmostEqual(r["g"][0], 0, places=6)
        np.testing.assert_allclose(r["q_scenarios"], [[0],[100]], atol=1e-7)
        self.assertAlmostEqual(r["objective"], 15, places=6)

    def test_storage_rate_and_efficiency(self):
        r = self.solve([0, 1000], pv=[[2000, 0]], mode="control", base_g=[0,0])
        self.assertAlmostEqual(r["c"][0,0], RATE, places=5)
        self.assertAlmostEqual(r["d"][0,1], RATE*ETA_C*ETA_D, places=5)
        self.assertAlmostEqual(r["e"][0,1], 1000-RATE*ETA_C*ETA_D, places=5)
        self.assertTrue(r["checks"]["passed"])
        self.assertAlmostEqual(r["s"][0,-1], LOW, places=5)

    def test_emergency_cannot_charge_and_upper_state_holds(self):
        r = self.solve([1000,0], pv=[[0,3000]], s0=HIGH, mode="control", base_g=[0,0])
        self.assertLessEqual(r["s"].max(), HIGH+1e-6)
        self.assertLessEqual(np.max(np.minimum(r["c"],r["e"])), 1e-7)
        self.assertLessEqual(np.max(np.minimum(r["c"],r["d"])), 1e-7)
        self.assertTrue(r["checks"]["passed"])

    def test_original_large_contract_above_sufficient_bound(self):
        r = self.solve([0], mode="control", base_g=[5000], booked_q=[5000], locked_mask=[True])
        self.assertEqual(r["q"][0], 5000)
        self.assertTrue(r["checks"]["passed"])

    def test_soft_terminal_penalty_is_not_cash(self):
        r = solve_dispatch([[0]], [[0]], [1], LOW, mode="control", base_g=[0],
                           terminal_weight=2, s_ref=6000)
        self.assertAlmostEqual(r["terminal_cost"], 9600)
        self.assertAlmostEqual(r["objective"], 9600)
        self.assertEqual(cash_components([1], [0], [0], [0])["total_cash_cost"], 0)

    def test_input_rejections(self):
        for kwargs in [{"mode":"bad"}, {"mode":"adjust"},
                       {"current_mask":[True]}, {"locked_mask":[True]},
                       {"future_adjust_mask":[True],"locked_mask":[True]},
                       {"probabilities":[.9]}, {"mip_gap":-1}]:
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                self.solve([1], **kwargs)

    def test_zero_price_degeneracy_is_verified(self):
        r = self.solve([[10],[20]], p=[0], mode="adjust", base_g=[100], current_mask=[True])
        self.assertEqual(r["objective"], 0)
        self.assertEqual(np.minimum(r["a"],r["b"]).sum(), 0)
        self.assertTrue(r["checks"]["passed"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
