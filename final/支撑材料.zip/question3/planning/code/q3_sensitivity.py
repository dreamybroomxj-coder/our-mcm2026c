"""Predeclared bounded robustness study; never tune on the test-period outcome."""
import argparse, json
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed
from q3_runner import run_strategy, dump

def jobs_for(stage):
    if stage=='development':
        return [(f'scenes_{m}',16,7,dict(scenarios=m)) for m in (4,8,16)]+[
            (f'seed_{seed}',16,7,dict(seed=seed)) for seed in (20260913,20260914)]
    if stage=='algorithms':
        return [('stochastic_mpc',24,60,{}),('deterministic_mpc',24,60,dict(scenarios=1)),
            ('stochastic_greedy',24,60,dict(controller='greedy')),
            ('initial_1200',24,60,dict(initial_soc=1200)),
            ('initial_10800',24,60,dict(initial_soc=10800)),
            ('linear_reconstruction',24,60,dict(pv_source='linear'))]
    raise ValueError(stage)

def run_study(data,out,stage,workers=2):
    target=Path(out)/stage;target.mkdir(parents=True,exist_ok=True)
    spec=jobs_for(stage)
    dump(target/'design.json',dict(schedule=[0,6,12,18],jobs=spec,
        purpose='preset rich schedule; sensitivity only, not parameter selection',
        local_initial_states=True,not_full_year=True,
        terminal_rule='same final one-step horizon in every matched run'))
    results=[]
    with ProcessPoolExecutor(max_workers=workers) as pool:
        futures=[pool.submit(run_strategy,data,target,(0,6,12,18),config=cfg,
            start_day=start,days=days,name=name) for name,start,days,cfg in spec]
        for future in as_completed(futures):
            r=future.result();results.append(r)
            print(stage,r['strategy'],r['cash_cost_yuan'],flush=True)
    dump(target/'comparison.json',results)
    return results

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--data',default=str(Path(__file__).resolve().parents[1]/'data'))
    ap.add_argument('--out',required=True);ap.add_argument('--stage',choices=['development','algorithms'],required=True)
    ap.add_argument('--workers',type=int,default=2);a=ap.parse_args()
    run_study(a.data,a.out,a.stage,a.workers)
