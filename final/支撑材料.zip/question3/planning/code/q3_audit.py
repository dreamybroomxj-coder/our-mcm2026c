"""Independent Q3 ledger, physical and information-availability checks.

This module reads CSV/JSON artifacts; it never invokes the optimizer or edits
the source ledger.  Flow columns are kWh and input/actual power columns kW.
Use ``audit_run(strategy_directory, input_data)`` after a complete run.
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import hashlib
import json
from pathlib import Path
import re

import numpy as np

FLOW_TOL = 1e-5
FEE_TOL = 1e-4
START = {0: 0, 6: 35, 12: 71, 18: 107}
HOURS = (0, 6, 12, 18)
REQUIRED = (
    'strategy', 'window_date', 'interval_start', 'interval_end',
    'forecast_issue_time', 'price_yuan_per_kwh',
    'load_forecast_kw', 'pv_forecast_kw', 'load_actual_kw', 'pv_actual_kw',
    'actual_estimated', 'g_kwh', 'q_kwh', 'increase_kwh', 'decrease_kwh',
    'charge_kwh', 'discharge_kwh', 'emergency_kwh', 'unused_paid_kwh',
    'curtailed_pv_kwh', 'soc_start_kwh', 'soc_end_kwh', 'plan_cost_yuan',
    'increase_cost_yuan', 'refund_yuan', 'penalty_yuan',
    'adjustment_net_cost_yuan', 'emergency_cost_yuan', 'cash_cost_yuan',
)
TEXT = {'strategy', 'window_date', 'interval_start', 'interval_end',
        'forecast_issue_time', 'actual_estimated'}
NUMERIC = tuple(x for x in REQUIRED if x not in TEXT)


def _date(value):
    if isinstance(value, dt.datetime):
        return value.date()
    if isinstance(value, dt.date):
        return value
    return dt.date.fromisoformat(str(value)[:10])


def _time(value):
    if isinstance(value, dt.datetime):
        return value.replace(tzinfo=None)
    return dt.datetime.fromisoformat(str(value).replace('Z', '+00:00')).replace(tzinfo=None)


def _bool(value):
    if isinstance(value, (bool, np.bool_)):
        return bool(value)
    if str(value).lower().strip() in {'true', '1', 'yes'}:
        return True
    if str(value).lower().strip() in {'false', '0', 'no'}:
        return False
    raise ValueError(f'Invalid Boolean flag: {value!r}')


def _json(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


class _Checks:
    def __init__(self):
        self.items = []
        self.skipped = []

    def record(self, name, passed, **details):
        self.items.append({'name': name, 'passed': bool(passed), **details})

    def residual(self, name, values, tol=FLOW_TOL):
        a = np.asarray(values, dtype=float)
        maximum = float(np.max(np.abs(a))) if a.size else 0.0
        self.record(name, np.isfinite(a).all() and maximum <= tol,
                    max_abs=maximum, tolerance=tol,
                    failed_rows=np.flatnonzero(~np.isfinite(a) | (np.abs(a) > tol))[:8].tolist())

    def mask(self, name, mask):
        a = np.asarray(mask, dtype=bool)
        self.record(name, a.all(), failed_count=int((~a).sum()),
                    failed_rows=np.flatnonzero(~a)[:8].tolist())


def _hours(config, names):
    for key in names:
        if key in config:
            value = config[key]
            if isinstance(value, str):
                value = re.findall(r'\d+', value)
            try:
                hours = sorted({int(v) for v in value})
            except (TypeError, ValueError):
                return None
            return hours
    return None


def _config(run, event_obj):
    result = {}
    for name in ('config.json', 'summary.json', 'run_config.json'):
        path = run / name
        if path.exists():
            obj = _json(path)
            if isinstance(obj, dict):
                result.update(obj.get('config', obj))
    if isinstance(event_obj, dict):
        for key in ('config', 'parameters', 'strategy_config'):
            if isinstance(event_obj.get(key), dict):
                result.update(event_obj[key])
        for key in ('trade_hours', 'forecast_hours', 'enabled_hours', 'enabled_forecast_hours'):
            if key in event_obj:
                result[key] = event_obj[key]
    return result


def _events(obj):
    if isinstance(obj, list):
        return obj
    if isinstance(obj, dict):
        for key in ('events', 'event_log', 'records', 'decisions'):
            if isinstance(obj.get(key), list):
                return obj[key]
    return []


def _risk_records(event):
    """Locate availability metadata without depending on one nesting label."""
    out = []
    if not isinstance(event, dict):
        return out
    if 'history_indices' in event or 'history_latest_end' in event:
        out.append(event)
    for value in event.values():
        if isinstance(value, dict):
            out.extend(_risk_records(value))
    return out


def _load_input(input_data):
    if input_data is None:
        default = Path(__file__).resolve().parents[1] / 'data' / 'q3_inputs.npz'
        if not default.exists():
            return None
        input_data = default
    if isinstance(input_data, (str, Path)):
        with np.load(input_data, allow_pickle=False) as bundle:
            result = {k: bundle[k].copy() for k in bundle.files}
        metadata_path = Path(input_data).parent/'input_audit.json'
        if metadata_path.exists():
            metadata = _json(metadata_path)
            first = metadata.get('actual',{}).get('first_unexecuted_interval')
            if first is not None:
                result['first_unexecuted_interval'] = first
        return result
    return input_data


def _audit_events(check, events, config, inputs, window_dates):
    trades = _hours(config, ('trade_hours', 'enabled_hours', 'allowed_trade_hours'))
    forecasts = _hours(config, ('forecast_hours', 'enabled_forecast_hours',
                                'allowed_forecast_hours', 'enabled_hours'))
    # A runner may store the entire enabled set only once, as trade_hours.
    if forecasts is None and trades is not None and not config.get('old_forecast_only', False):
        forecasts = trades
    check.record('trade_configuration_present', trades is not None, hours=trades)
    check.record('forecast_configuration_present', forecasts is not None, hours=forecasts)
    if trades is not None:
        check.record('trade_configuration_valid', 0 in trades and set(trades) <= set(HOURS))
    if forecasts is not None:
        check.record('forecast_configuration_valid', 0 in forecasts and set(forecasts) <= set(HOURS))
    check.record('event_log_nonempty', bool(events), events=len(events))
    history_count = 0
    commit_count = 0
    covered = {}
    for j, event in enumerate(events):
        if not isinstance(event, dict):
            check.record(f'event_{j}_object', False)
            continue
        now_value = event.get('decision_at', event.get('decision_time', event.get('time')))
        risks = _risk_records(event)
        if now_value is None and risks:
            now_value = risks[0].get('decision_at')
        if now_value is None:
            check.record(f'event_{j}_decision_timestamp_present', False)
            continue
        now = _time(now_value)
        for risk in risks:
            history_count += 1
            issue = risk.get('issued_at', risk.get('forecast_issue_time'))
            hour = risk.get('forecast_hour')
            if issue is not None:
                issue_time = _time(issue)
                check.record(f'event_{j}_forecast_released', issue_time <= now)
                if hour is None:
                    hour = issue_time.hour
            if forecasts is not None and hour is not None:
                check.record(f'event_{j}_forecast_enabled', int(hour) in forecasts,
                             forecast_hour=int(hour))
                check.record(f'event_{j}_forecast_hour_available',
                             int(hour) <= now.hour and int(hour) in HOURS)
            check.record(f'event_{j}_no_extra_margin', not risk.get('margin_added', False))
            indices = [int(x) for x in risk.get('history_indices', [])]
            draws = [int(x) for x in risk.get('draw_indices', [])]
            check.record(f'event_{j}_draw_from_available_history',
                         set(draws) <= set(indices) and len(draws) == len(set(draws)))
            latest = risk.get('history_latest_end')
            if latest is not None:
                check.record(f'event_{j}_latest_history_released', _time(latest) <= now,
                             latest=str(latest), decision_at=now.isoformat())
            if inputs is not None and indices:
                ends = inputs.get('window_end')
                if ends is None:
                    check.record(f'event_{j}_input_window_ends_present', False)
                else:
                    valid = all(0 <= i < len(ends) for i in indices)
                    check.record(f'event_{j}_history_indices_valid', valid)
                    if valid:
                        check.record(f'event_{j}_all_history_released',
                                     all(_time(ends[i]) <= now for i in indices))
                        if latest is not None:
                            check.record(f'event_{j}_history_latest_consistent',
                                         max(_time(ends[i]) for i in indices) == _time(latest))
            elif indices:
                check.skipped.append(f'event_{j}: all historical indices need input_data; latest timestamp only checked')

        mode = str(event.get('mode', event.get('kind', event.get('type', '')))).lower()
        begin = event.get('commit_start', event.get('block_start'))
        end = event.get('commit_end', event.get('block_end'))
        if isinstance(event.get('commit_block'), (list, tuple)) and len(event['commit_block']) == 2:
            begin, end = event['commit_block']
        if 'update' in mode or 'adjust' in mode or begin is not None:
            # Midnight commits all NEW g; only intraday q needs block validation.
            if now.hour == 0:
                continue
            commit_count += 1
            if trades is None:
                continue
            allowed = now.hour in trades and now.hour in START and now.minute == 0
            check.record(f'event_{j}_trade_enabled', allowed)
            if begin is None or end is None:
                check.record(f'event_{j}_commit_block_present', False)
                continue
            begin, end = int(begin), int(end)
            if allowed:
                expected_begin = START[now.hour]
                later = [START[h] for h in trades if h > now.hour and h in START]
                expected_end = min(later) if later else 144
                check.record(f'event_{j}_commit_block_correct',
                             (begin, end) == (expected_begin, expected_end),
                             actual=[begin, end], expected=[expected_begin, expected_end])
                day = str(event.get('window_date', now.date()))[:10]
                occupied = covered.setdefault(day, set())
                slots = set(range(begin, end))
                check.record(f'event_{j}_each_interval_adjusted_once', not (occupied & slots))
                occupied.update(slots)
    check.record('history_metadata_present', history_count > 0, records=history_count)
    if trades is not None:
        expected = len(window_dates) * (len(trades) - 1)
        check.record('all_scheduled_update_events_present', commit_count == expected,
                     actual=commit_count, expected=expected)
    return trades, forecasts


def _audit_startup(check, run, config, inputs, main_start, main_soc):
    path = run/'startup.csv'
    expected = int(config.get('start_day', 0)) == 0
    check.record('startup_presence', path.exists() == expected,
                 expected=expected, present=path.exists())
    if not path.exists():
        return 0.0
    with path.open(encoding='utf-8-sig', newline='') as stream:
        rows = list(csv.DictReader(stream))
    check.record('one_startup_interval', len(rows) == 1)
    if len(rows) != 1:
        return 0.0
    row = rows[0]
    values = {key: float(row[key]) for key in NUMERIC}
    t0, t1 = _time(row['interval_start']), _time(row['interval_end'])
    check.record('startup_immediately_precedes_main',
                 t1 == main_start and t1-t0 == dt.timedelta(minutes=10))
    p=values['price_yuan_per_kwh']; g=values['g_kwh']; q=values['q_kwh']
    e=values['emergency_kwh']; L=values['load_actual_kw']/6; G=values['pv_actual_kw']/6
    c=values['charge_kwh']; d=values['discharge_kwh']
    v=values['unused_paid_kwh']; r=values['curtailed_pv_kwh']
    check.residual('startup_idle_battery', [c,d])
    check.residual('startup_preserves_experiment_initial_soc',
                   [values['soc_start_kwh']-main_soc, values['soc_end_kwh']-main_soc])
    check.residual('startup_energy_balance', [q-v+G-r+d+e-L-c])
    check.residual('startup_contract_unchanged', [q-g,values['increase_kwh'],values['decrease_kwh']])
    check.residual('startup_emergency_deficit', [e-max(L-q-G,0)])
    check.residual('startup_cash', [values['cash_cost_yuan']-(p*g+5*p*e)], FEE_TOL)
    if inputs is not None:
        load0=float(np.asarray(inputs['load_f'])[0,0]); pv0=float(np.asarray(inputs['pv_unused_first_mean_kw'])[0])
        check.residual('startup_common_hold_forecast', [values['load_forecast_kw']-load0,
                         values['pv_forecast_kw']-pv0, g-max((load0-pv0)/6,0)])
        check.residual('startup_price', [p-float(np.asarray(inputs['price'])[-1])], FEE_TOL)
        # Full adapter dictionary contains observed midnight boundary metadata;
        # the compact NPZ does not, so the main trace source checks are separate.
        actual = inputs.get('first_unexecuted_interval')
        if actual is not None:
            check.residual('startup_actual_nodes_source',
                [values['load_actual_kw']-actual['load_mean_kw'],
                 values['pv_actual_kw']-actual['pv_mean_kw']])
    return values['cash_cost_yuan']


def audit_run(run_dir, input_data=None):
    """Audit one strategy directory containing trace.csv and event_log.json.

    Returns a serializable dictionary; does not mutate input artifacts. Missing
    evidence is not silently marked as passing. Optional input_data is the
    adapter dictionary or its q3_inputs.npz archive.
    """
    run = Path(run_dir)
    trace_path, events_path = run / 'trace.csv', run / 'event_log.json'
    check = _Checks()
    for p in (trace_path, events_path):
        if not p.exists():
            return {'passed': False, 'run_directory': str(run),
                    'errors': [f'Required artifact missing: {p.name}']}
    with trace_path.open(encoding='utf-8-sig', newline='') as stream:
        reader = csv.DictReader(stream)
        fields = reader.fieldnames or []
        missing = sorted(set(REQUIRED) - set(fields))
        if missing:
            return {'passed': False, 'run_directory': str(run),
                    'errors': ['Missing trace columns: ' + ', '.join(missing)]}
        rows = list(reader)
    if not rows:
        return {'passed': False, 'run_directory': str(run), 'errors': ['Empty trace']}
    try:
        a = {key: np.asarray([float(row[key]) for row in rows]) for key in NUMERIC}
        starts = [_time(r['interval_start']) for r in rows]
        ends = [_time(r['interval_end']) for r in rows]
        days = [_date(r['window_date']) for r in rows]
        issues = [_time(r['forecast_issue_time']) for r in rows]
        estimated = np.asarray([_bool(r['actual_estimated']) for r in rows])
    except (KeyError, TypeError, ValueError) as exc:
        return {'passed': False, 'run_directory': str(run), 'errors': [str(exc)]}
    event_obj = _json(events_path)
    config = _config(run, event_obj)
    inputs = _load_input(input_data)
    window_dates = sorted(set(days))
    check.record('single_strategy', len({r['strategy'] for r in rows}) == 1)
    for key, val in a.items():
        check.mask('finite_' + key, np.isfinite(val))
    nonnegative = ('price_yuan_per_kwh', 'load_forecast_kw', 'pv_forecast_kw',
        'load_actual_kw', 'pv_actual_kw', 'g_kwh', 'q_kwh', 'increase_kwh', 'decrease_kwh',
        'charge_kwh', 'discharge_kwh', 'emergency_kwh', 'unused_paid_kwh', 'curtailed_pv_kwh')
    for key in nonnegative:
        check.mask('nonnegative_' + key, a[key] >= -FLOW_TOL)
    check.mask('positive_price', a['price_yuan_per_kwh'] > 0)
    p = a['price_yuan_per_kwh']; g = a['g_kwh']; q = a['q_kwh']
    inc = a['increase_kwh']; dec = a['decrease_kwh']
    c = a['charge_kwh']; d = a['discharge_kwh']; e = a['emergency_kwh']
    v = a['unused_paid_kwh']; r = a['curtailed_pv_kwh']
    ss = a['soc_start_kwh']; se = a['soc_end_kwh']
    load = a['load_actual_kw'] / 6.; pv = a['pv_actual_kw'] / 6.
    check.residual('energy_balance_kwh', q-v+pv-r+d+e-load-c)
    check.residual('battery_recurrence_kwh', se-ss-.9*c+d/.9)
    check.residual('continuous_soc_kwh', ss[1:]-se[:-1])
    check.mask('soc_start_bounds', (ss >= 1200-FLOW_TOL) & (ss <= 10800+FLOW_TOL))
    check.mask('soc_end_bounds', (se >= 1200-FLOW_TOL) & (se <= 10800+FLOW_TOL))
    check.mask('charge_power_limit', c <= 5000/6 + FLOW_TOL)
    check.mask('discharge_power_limit', d <= 5000/6 + FLOW_TOL)
    check.mask('charge_discharge_exclusion', ~((c > FLOW_TOL) & (d > FLOW_TOL)))
    check.mask('emergency_does_not_charge', ~((c > FLOW_TOL) & (e > FLOW_TOL)))
    check.mask('emergency_load_bound', e <= load + FLOW_TOL)
    check.mask('curtailment_pv_bound', r <= pv + FLOW_TOL)
    check.mask('unused_paid_bound', v <= q + FLOW_TOL)
    surplus = np.maximum(q+pv-load,0)
    deficit = np.maximum(load-q-pv,0)
    check.mask('charging_only_from_ordinary_surplus', c <= surplus + FLOW_TOL)
    check.mask('discharging_only_to_ordinary_deficit', d <= deficit + FLOW_TOL)
    check.residual('emergency_deficit_after_discharge', e-deficit+d)
    check.residual('unused_surplus_after_charging', v+r-surplus+c)
    check.mask('cancel_original_bound', dec <= g + FLOW_TOL)
    check.residual('adjusted_contract_identity', q-g-inc+dec)
    check.residual('increase_direction', inc-np.maximum(q-g,0))
    check.residual('decrease_direction', dec-np.maximum(g-q,0))
    # refund_yuan is a positive refund AMOUNT; subtract it in the cash ledger.
    expected_fees = {'plan_cost_yuan':p*g, 'increase_cost_yuan':1.5*p*inc,
        'refund_yuan':p*dec, 'penalty_yuan':.5*p*dec,
        'adjustment_net_cost_yuan':1.5*p*inc-.5*p*dec,
        'emergency_cost_yuan':5*p*e,
        'cash_cost_yuan':p*g+1.5*p*inc-.5*p*dec+5*p*e}
    for key, expected in expected_fees.items():
        check.residual('fee_' + key, a[key]-expected, FEE_TOL)
    check.residual('fee_components_sum', a['cash_cost_yuan']-
        (a['plan_cost_yuan']+a['increase_cost_yuan']-a['refund_yuan']+
         a['penalty_yuan']+a['emergency_cost_yuan']), FEE_TOL)
    check.mask('interval_duration_10min', [b-a == dt.timedelta(minutes=10) for a,b in zip(starts,ends)])
    check.mask('interval_sequence_continuous', [b == c for b,c in zip(ends,starts[1:])])
    check.mask('forecast_released_for_execution', [f <= t for f,t in zip(issues,starts)])
    slot = []
    for day in window_dates:
        ix = np.flatnonzero(np.asarray([x == day for x in days]))
        origin = dt.datetime.combine(day, dt.time(0,10))
        check.record(f'window_{day}_144_slots', len(ix) == 144)
        check.record(f'window_{day}_correct_targets', len(ix) == 144 and
            all(starts[i] == origin + dt.timedelta(minutes=10*j) for j,i in enumerate(ix)))
        check.residual(f'window_{day}_inventory_identity',
            [se[ix[-1]]-ss[ix[0]]-.9*c[ix].sum()+d[ix].sum()/.9])
    for day,time in zip(days,starts):
        slot.append(int((time-dt.datetime.combine(day,dt.time(0,10))).total_seconds()/600))
    trades, forecasts = _audit_events(check, _events(event_obj), config, inputs, window_dates)
    if forecasts is not None and 0 in forecasts and set(forecasts) <= set(HOURS):
        check.mask('execution_uses_enabled_forecast', [f.hour in forecasts for f in issues])
        expected_issues = [dt.datetime.combine(day, dt.time(max(h for h in forecasts if START[h] <= k)))
                           for day,k in zip(days,slot) if 0 <= k < 144]
        if len(expected_issues) == len(issues):
            check.mask('execution_uses_latest_enabled_vintage', [a == b for a,b in zip(issues,expected_issues)])
    if trades is not None and set(trades) <= set(HOURS):
        first_update = min((START[h] for h in trades if h), default=144)
        before = np.asarray(slot) < first_update
        check.residual('no_adjustment_before_first_enabled_update', (q-g)[before])
    if inputs is not None:
        index = {_date(value): i for i,value in enumerate(inputs['dates'])}
        if all(day in index for day in days) and all(0 <= k < 144 for k in slot):
            ids = np.asarray([index[day] for day in days]); slots = np.asarray(slot)
            check.residual('input_actual_load_kw', a['load_actual_kw']-np.asarray(inputs['load_a'])[ids,slots])
            check.residual('input_actual_pv_kw', a['pv_actual_kw']-np.asarray(inputs['pv_a'])[ids,slots])
            check.residual('input_load_forecast_kw', a['load_forecast_kw']-np.asarray(inputs['load_f'])[ids,slots])
            check.residual('input_prices', p-np.asarray(inputs['price'])[slots], FEE_TOL)
            check.mask('input_estimated_flags', estimated == np.asarray(inputs['actual_estimated'])[ids,slots])
            pvkey = 'pv_linear_f' if config.get('pv_source') == 'linear' else 'pv_f'
            if pvkey in inputs and all(f.hour in HOURS for f in issues):
                vintage = np.asarray([HOURS.index(f.hour) for f in issues])
                check.residual('input_matching_pv_vintage_kw', a['pv_forecast_kw']-
                    np.asarray(inputs[pvkey])[ids,vintage,slots])
        else:
            check.record('trace_targets_present_in_input', False)
    else:
        check.skipped.append('Input identity and full history-index availability: input_data unavailable')
    sums = {key: float(a[key].sum()) for key in (
        'g_kwh','q_kwh','increase_kwh','decrease_kwh','charge_kwh','discharge_kwh',
        'emergency_kwh','unused_paid_kwh','curtailed_pv_kwh',*expected_fees.keys())}
    startup_cash = _audit_startup(check, run, config, inputs, starts[0], float(ss[0]))
    summary_path = run/'summary.json'
    if summary_path.exists():
        summary = _json(summary_path)
        for key, expected in {'cash_cost_yuan':sums['cash_cost_yuan'],
            'soc_start_kwh':float(ss[0]), 'soc_end_kwh':float(se[-1]),
            'original_plan_cost_yuan':sums['plan_cost_yuan'],
            'net_adjustment_cost_yuan':sums['adjustment_net_cost_yuan'],
            'emergency_cost_yuan':sums['emergency_cost_yuan'],
            'emergency_kwh':sums['emergency_kwh'], 'startup_cash_cost_yuan':startup_cash}.items():
            if key in summary:
                check.residual('summary_'+key, [float(summary[key])-expected], FEE_TOL)
        check.record('summary_row_window_counts', summary.get('intervals') == len(rows)
                     and summary.get('windows') == len(window_dates))
        last_day = window_dates[-1]
        natural_cash = float(a['cash_cost_yuan'][np.asarray([x.date()<=last_day for x in starts])].sum())+startup_cash
        if 'natural_period_cash_cost_yuan' in summary:
            check.residual('summary_natural_period_cash',
                [float(summary['natural_period_cash_cost_yuan'])-natural_cash], FEE_TOL)
    return {'passed': all(item['passed'] for item in check.items) and not check.skipped,
        'run_directory': str(run.resolve()), 'strategy': rows[0]['strategy'],
        'rows': len(rows), 'windows': len(window_dates),
        'first_interval': starts[0].isoformat(), 'last_interval_end': ends[-1].isoformat(),
        'initial_soc_kwh':float(ss[0]), 'final_soc_kwh':float(se[-1]),
        'estimated_intervals':int(estimated.sum()), 'sums':sums,
        'checks':check.items, 'skipped':check.skipped,
        'failed_checks':[item for item in check.items if not item['passed']],
        'trace_sha256':_sha(trace_path), 'events_sha256':_sha(events_path),
        'startup_cash_cost_yuan':startup_cash,
        'refund_convention':'refund_yuan is a positive amount subtracted from cash; penalty_yuan is positive',
        'scope':'existing artifact audit only; supplied forecast generation causality not certified',
        'evidence_limit':'event blocks and final g/q are checked; immutable signed quantities additionally rely on runner chronology tests because event logs do not archive each signed vector'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('run_dir', type=Path)
    parser.add_argument('--inputs', type=Path)
    parser.add_argument('--out', type=Path)
    args = parser.parse_args()
    result = audit_run(args.run_dir, args.inputs)
    output = args.out or args.run_dir/'independent_audit.json'
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2),encoding='utf-8')
    print(json.dumps({'passed':result['passed'], 'out':str(output),
                      'failed_checks':result.get('failed_checks',result.get('errors'))},
                     ensure_ascii=False))
    raise SystemExit(0 if result['passed'] else 1)


if __name__ == '__main__':
    main()
