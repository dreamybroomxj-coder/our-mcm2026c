"""Audit newly completed Q3 primary/ablation artifacts and frozen provenance.

Only completed summary.json files are read. --watch checks once per minute and
never changes a numerical model, input, contract, or execution trace.
"""
import argparse
import hashlib
import json
from pathlib import Path
import time

from q3_audit import audit_run


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def write(path,obj):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')


def verify_sources(project):
    project=Path(project);data=project/'data';provenance=project/'provenance'
    manifest=read(data/'source_manifest.json')
    checks=[]
    declared=read(data/'input_audit.json')['source_sha256']
    for source in manifest:
        filename=source['filename'];actual=sha(data/filename)
        checks.append({'file':filename,'actual_sha256':actual,
            'copy_manifest_sha256':source['sha256'],'input_audit_sha256':declared.get(filename),
            'passed':actual==source['sha256']==declared.get(filename)})
    core_manifest=read(provenance/'numerical_core_manifest.json')['files_sha256']
    snapshot=[]
    for filename,expected in core_manifest.items():
        frozen=sha(provenance/'numerical_core_used'/filename)
        current=sha(project/'code'/filename)
        snapshot.append({'file':filename,'manifest_sha256':expected,'snapshot_sha256':frozen,
            'current_sha256':current,'snapshot_matches_manifest':frozen==expected,
            'current_matches_snapshot':current==frozen})
    return {'passed':all(c['passed'] for c in checks) and all(c['snapshot_matches_manifest'] for c in snapshot),
        'input_files':checks,'numerical_core':snapshot,
        'current_code_note':'Historical runs are validated against frozen numerical_core_used; a documented later cache/validation guard change need not alter their results.'}


def historical_signature(project,config):
    """Reproduce the original batch fingerprint using its exact frozen code."""
    project=Path(project)
    digest=hashlib.sha256(json.dumps(config,sort_keys=True).encode())
    for path in sorted((project/'provenance'/'numerical_core_used').glob('q3_*.py')):
        digest.update(path.name.encode());digest.update(path.read_bytes())
    digest.update((project/'data'/'source_manifest.json').read_bytes())
    return digest.hexdigest()


def audit_completed(project,seen=None):
    project=Path(project);root=project/'results';seen={} if seen is None else seen
    sources=verify_sources(project)
    write(project/'provenance'/'batch_source_validation.json',sources)
    paths=list((root/'main').glob('*/summary.json'))
    paths += [root/'ablation'/name/'summary.json' for name in ('old_forecast_all_trades','all_trades_greedy')]
    for path in sorted(paths):
        if not path.exists():continue
        summary=read(path)
        if not summary.get('complete'):continue
        key=str(path.parent.relative_to(root));fingerprint=sha(path)
        if key in seen and seen[key].get('summary_sha256')==fingerprint:continue
        report=audit_run(path.parent,project/'data'/'q3_inputs.npz')
        expected=historical_signature(project,summary['config'])
        provenance={'passed':sources['passed'] and summary['run_signature']==expected,
            'recorded_run_signature':summary['run_signature'],'reconstructed_run_signature':expected,
            'frozen_code_path':'provenance/numerical_core_used','inputs_validated':sources['passed']}
        report['historical_provenance']=provenance
        report['passed']=report['passed'] and provenance['passed']
        write(path.parent/'independent_audit.json',report)
        seen[key]={'run':key,'passed':report['passed'],'rows':report.get('rows'),
            'windows':report.get('windows'),'checks':len(report.get('checks',[])),
            'trace_sha256':report.get('trace_sha256'),'summary_sha256':fingerprint,
            'cash_cost_yuan':report.get('sums',{}).get('cash_cost_yuan'),
            'historical_signature_valid':provenance['passed'],
            'failed_checks':report.get('failed_checks',report.get('errors'))}
        print(json.dumps(seen[key],ensure_ascii=False),flush=True)
    main=[v for k,v in seen.items() if k.startswith('main/')]
    ablation=[v for k,v in seen.items() if k.startswith('ablation/')]
    aggregate={'passed':sources['passed'] and bool(seen) and all(x['passed'] for x in seen.values()),
        'complete_main':len(main)==8 and all(x['windows']==334 for x in main),
        'complete_ablation':len(ablation)==2 and all(x['windows']==334 for x in ablation),
        'main_rows':sum(x['rows'] for x in main),'ablation_rows':sum(x['rows'] for x in ablation),
        'main':main,'ablation':ablation,'sources':sources,
        'scope':'Independent physics/cash/information checks and exact historical input/core hash verification; forecast generation itself not certified'}
    write(root/'audit_main_validation.json',aggregate)
    write(project/'notes'/'audit_main_validation.json',aggregate)
    return aggregate,seen


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project',type=Path,default=Path(__file__).resolve().parents[1])
    parser.add_argument('--watch',action='store_true')
    args=parser.parse_args();seen={}
    while True:
        result,seen=audit_completed(args.project,seen)
        if not args.watch or result['complete_main'] and result['complete_ablation']:
            break
        time.sleep(60)
    print(json.dumps({k:result[k] for k in ('passed','complete_main','complete_ablation','main_rows','ablation_rows')},ensure_ascii=False))
