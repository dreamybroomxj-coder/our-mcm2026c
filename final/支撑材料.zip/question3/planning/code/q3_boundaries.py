"""Transparent start/end boundary sensitivity, preserving every interior order.

The startup is outside the user-confirmed 00:10 contract experiment. Its
missing load forecast is estimated only from the already issued first forecast
row, and the battery is held idle. The final actual right endpoint is missing;
only the last executed slot is re-evaluated under the recorded alternatives.
Neither operation is a new full-year optimization or a new observation.
"""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np

from q3_io import load_inputs
from q3_optimizer import solve_dispatch, cash_components, ETA_C, ETA_D, RATE, LOW, HIGH


def _write_csv(path, rows):
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)


def startup_cases(data):
    """Common one-slot extension; forecast first, realized cash afterwards."""
    f=np.asarray(data["load_f"][0,:6],float)
    x=np.arange(1,7,dtype=float)
    slope=float((x-x.mean()) @ (f-f.mean()) / ((x-x.mean()) @ (x-x.mean())))
    candidates={"hold":float(f[0]),"linear2":float(max(2*f[0]-f[1],0)),
                "ols6":float(max(f.mean()-slope*x.mean(),0))}
    pv_forecast=float(data["pv_unused_first_mean_kw"][0])
    p=float(data["price"][-1])
    actual=data["first_unexecuted_interval"]
    load,pv=float(actual["load_mean_kw"]/6),float(actual["pv_mean_kw"]/6)
    rows=[]
    for method,load_forecast in candidates.items():
        g=max((load_forecast-pv_forecast)/6,0.)
        emergency=max(load-g-pv,0.)
        waste=max(g+pv-load,0.)
        unused=min(g,waste);curtail=max(waste-unused,0.)
        cash=p*g+5*p*emergency
        rows.append(dict(method=method,interval_start=actual["interval_start"],interval_end=actual["interval_end"],
            load_forecast_estimated_kw=load_forecast,pv_forecast_supplied_kw=pv_forecast,
            load_actual_mean_kw=load*6,pv_actual_mean_kw=pv*6,price_yuan_per_kwh=p,
            g_kwh=g,q_kwh=g,charge_kwh=0.,discharge_kwh=0.,emergency_kwh=emergency,
            unused_paid_kwh=unused,curtailed_pv_kwh=curtail,
            original_cost_yuan=p*g,emergency_cost_yuan=5*p*emergency,cash_cost_yuan=cash,
            change_from_hold_yuan=0.,battery_state_change_kwh=0.,common_to_all_strategies=True))
    for row in rows:
        row["change_from_hold_yuan"]=row["cash_cost_yuan"]-rows[0]["cash_cost_yuan"]
    return rows


def final_slot(g,q,state,p,load_mean_kw,pv_mean_kw,kappa):
    """Re-evaluate one frozen-contract slot, with the same soft terminal value."""
    r=solve_dispatch([[load_mean_kw/6]],[[pv_mean_kw/6]],[p],state,
                     mode="control",base_g=[g],booked_q=[q],locked_mask=[True],
                     terminal_weight=kappa,time_limit=10,mip_gap=1e-4)
    # Match the main runner's weakly dominant maximum-charge tie rule. Above
    # the soft reference, MILP can otherwise return a smaller free charge with
    # the same objective and create an artificial endpoint-state difference.
    surplus=max(q+(pv_mean_kw-load_mean_kw)/6,0.)
    if surplus > 1e-9:
        c=min(surplus,RATE,max((HIGH-state)/ETA_C,0.))
        r["c"][0,0]=c;r["d"][0,0]=r["e"][0,0]=0.
        r["s"][0,-1]=state+ETA_C*c
        r["terminal_cost"]=kappa*max(6000-r["s"][0,-1],0.)
    c,d,e=(float(r[key][0,0]) for key in ("c","d","e"))
    ending=float(r["s"][0,-1]);load,pv=load_mean_kw/6,pv_mean_kw/6
    waste=max(q+pv+d+e-load-c,0.);v=min(q,waste);curtail=max(waste-v,0.)
    physical=max(abs(q+pv+d+e-v-curtail-load-c),abs(ending-state-ETA_C*c+d/ETA_D),
                 c-RATE,d-RATE,LOW-ending,ending-HIGH,min(c,d),min(c,e),-min(c,d,e,v,curtail),0.)
    if physical>1e-5:
        raise RuntimeError("Canonical last-slot execution violates physical constraints.")
    bill=cash_components([p],[g],[q],r["e"][0])
    return {"charge_kwh":float(r["c"][0,0]),"discharge_kwh":float(r["d"][0,0]),
            "emergency_kwh":float(r["e"][0,0]),"soc_end_kwh":float(r["s"][0,-1]),
            "cash_cost_yuan":bill["total_cash_cost"],
            "terminal_penalty_yuan":r["terminal_cost"],
            "solver_status":r["status"],"solver_gap":r["gap"],
            "physical_max_violation_kwh":physical,
            "free_surplus_tie_rule":"Maximum feasible charge, matching the main execution rule"}


def run_boundary_study(data_dir,main_dir,outdir):
    data=load_inputs(data_dir)
    root,out=Path(main_dir),Path(outdir);out.mkdir(parents=True,exist_ok=True)
    paths=[root] if (root/"trace.csv").exists() else sorted(p.parent for p in root.glob("*/summary.json") if (p.parent/"trace.csv").exists())
    if not paths:
        raise ValueError("No completed main strategy traces were found.")
    startup=startup_cases(data)
    endpoint=data["metadata"]["actual"]["last_right_endpoint_candidates"]
    expected_end=data["window_end"][-1].isoformat()
    p=float(data["price"][-1]);kappa=float(np.min(data["price"])/ETA_C)
    terminal=[]
    for folder in paths:
        summary=json.loads((folder/"summary.json").read_text())
        if not summary.get("complete") or summary["windows"] != len(data["dates"]):
            raise ValueError(f"Full-horizon boundary study requires all {len(data['dates'])} windows: {folder}")
        with open(folder/"trace.csv",encoding="utf-8-sig",newline="") as f:
            trace=list(csv.DictReader(f))
        last=trace[-1]
        if len(trace)!=144*len(data["dates"]) or last["interval_end"]!=expected_end:
            raise ValueError("A strategy does not end at the missing final endpoint.")
        if str(last["actual_estimated"]).lower() not in ("true","1"):
            raise ValueError("Final trace does not label its actual endpoint as estimated.")
        if "terminal_weight" in summary["config"] and abs(summary["config"]["terminal_weight"]-kappa)>1e-12:
            raise ValueError("Main terminal weight differs from the common minimum-price/.9 basis.")
        g,q=float(last["g_kwh"]),float(last["q_kwh"])
        s=float(last["soc_start_kwh"]);cash0=float(last["cash_cost_yuan"]);end0=float(last["soc_end_kwh"])
        if abs(float(last["price_yuan_per_kwh"])-p)>1e-9:
            raise ValueError("The final tariff differs from the common data basis.")
        for method in ("hold","linear2","ols6"):
            load=endpoint["load"][method]["mean_kw"];pv=endpoint["pv"][method]["mean_kw"]
            r=final_slot(g,q,s,p,load,pv,kappa)
            delta=r["cash_cost_yuan"]-cash0;state_delta=r["soc_end_kwh"]-end0
            if method=="hold" and (abs(delta)>1e-5 or abs(state_delta)>1e-5):
                raise RuntimeError("Hold endpoint does not reproduce the main last-slot cash and state.")
            terminal.append(dict(strategy=summary["strategy"],method=method,
                interval_start=last["interval_start"],interval_end=last["interval_end"],
                load_actual_mean_estimated_kw=load,pv_actual_mean_estimated_kw=pv,
                g_fixed_kwh=g,q_fixed_kwh=q,soc_start_fixed_kwh=s,
                **r,terminal_state_delta_from_main_kwh=state_delta,
                last_slot_cash_delta_from_main_yuan=delta,
                main_contract_cash_total_yuan=summary["cash_cost_yuan"],
                revised_contract_cash_total_yuan=summary["cash_cost_yuan"]+delta,
                inventory_adjusted_total_delta_yuan=delta-kappa*state_delta,
                same_cash_basis=True))
    _write_csv(out/"startup_sensitivity.csv",startup)
    _write_csv(out/"final_endpoint_sensitivity.csv",terminal)
    result={"startup":startup,"final_endpoint":terminal,"terminal_weight":kappa,
        "startup_scope":"An optional idle-battery extension of the omitted first 00:00-00:10, separate from 334 contract-window totals",
        "startup_forecast_methods":{"hold":"first issued interval mean",
            "linear2":"max(2*f[0]-f[1],0)",
            "ols6":"OLS through the first six issued means at x=1..6, evaluated at x=0 and clipped nonnegative"},
        "startup_causality":"Only the already-issued first forecast row is used; actual first-interval means enter evaluation, not the order",
        "startup_state":"Battery idle; no change to the confirmed first 00:10 initial state or any later state",
        "final_endpoint_scope":"Freeze last original g, formally signed q and state; solve only the final slot",
        "same_cash_basis":True,
        "cash_basis":"Original fee + 1.5p increase - 0.5p cancellation + 5p emergency; terminal penalty excluded",
        "terminal_delta":"Separately report terminal state and cash-kappa*inventory comparisons",
        "limitations":"Endpoint alternatives are estimates; these calculations do not rerun or optimize the interior policy",
        "checks_passed":all(r["physical_max_violation_kwh"]<=1e-5 for r in terminal)}
    (out/"summary.json").write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding="utf-8")
    return result


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data",required=True);parser.add_argument("--main",required=True)
    parser.add_argument("--out",required=True);args=parser.parse_args()
    result=run_boundary_study(args.data,args.main,args.out)
    print(json.dumps({"checks_passed":result["checks_passed"],"strategy_cases":len(result["final_endpoint"])},ensure_ascii=False))
