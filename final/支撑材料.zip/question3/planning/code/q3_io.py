"""Q3 strict data adapter: interval means, forecast vintages and observed nodes.

User workbooks are read-only.  The returned power arrays are kW; optimization
must multiply them by 1/6 exactly once. The contract window is D 00:10 to
D+1 00:10. No actual value is implicitly substituted for a supplied forecast.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
from pathlib import Path
import re
import shutil

import numpy as np
from openpyxl import load_workbook

ROOT = Path(__file__).resolve().parents[1]
ISSUE_HOURS = (0, 6, 12, 18)
ISSUE_START = {0: 0, 6: 35, 12: 71, 18: 107}
WECHAT = Path('/Users/xzy/Library/Containers/com.tencent.xinWeChat/Data/Documents/xwechat_files/wxid_euf4op8bmams22_1b0d/temp/RWTemp/2026-09/a3bee7770c01c7d37f45899f94a1dcc5')
ATTACHMENTS = Path('/Users/xzy/Downloads/CUMCM2026Problems/C题/附件')
SOURCES = {
    'pv_forecasts.xlsx': WECHAT / '问题三_光伏区间预测.xlsx',
    'load_forecasts.xlsx': WECHAT / '问题二_标准化区间预测.xlsx',
    'attachment1.xlsx': ATTACHMENTS / '附件1.xlsx',
    'attachment2.xlsx': ATTACHMENTS / '附件2.xlsx',
    'attachment3.xlsx': ATTACHMENTS / '附件3.xlsx',
    'result3_template.xlsx': ATTACHMENTS / '附件5/result3.xlsx',
}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def as_date(value):
    if isinstance(value, dt.datetime):
        return value.date()
    if isinstance(value, dt.date):
        return value
    return dt.date(*map(int, str(value).split('-')))


def clock_minute(value):
    if isinstance(value, dt.time):
        return value.hour * 60 + value.minute
    s = str(value).strip().replace('：', ':')
    tomorrow = ('次日' in s) or ('+1' in s)
    s = s.replace('次日', '').replace('+1', '')
    m = re.fullmatch(r'(\d{1,2}):(\d{1,2})', s)
    if not m:
        raise ValueError(f'Invalid clock: {value!r}')
    h, minute = map(int, m.groups())
    if h > 24 or minute > 59 or (h == 24 and minute):
        raise ValueError(f'Invalid clock: {value!r}')
    return h * 60 + minute + (1440 if tomorrow and h < 24 else 0)


def interval_header(value):
    pieces = re.split(r'[—–～~\-]', str(value).strip())
    if len(pieces) != 2:
        raise ValueError(f'Explicit interval required: {value!r}')
    a, b = map(clock_minute, pieces)
    if a == 1430 and b == 0:
        b = 1440
    if b - a != 10:
        raise ValueError(f'Interval is not 10 minutes: {value!r}')
    return a, b


def validate_dates(values, label, *,expected=None):
    dates = [as_date(v) for v in values]
    if dates != sorted(set(dates)):
        raise ValueError(f'{label}: dates must be unique and ascending')
    if any(b - a != dt.timedelta(days=1) for a, b in zip(dates, dates[1:])):
        raise ValueError(f'{label}: missing interior date')
    if expected is not None and dates != expected:
        raise ValueError(f'{label}: forecast dates differ')
    return dates


def numeric_array(rows, shape, label):
    try:
        a = np.asarray(rows, dtype=float)
    except (ValueError, TypeError) as exc:
        raise ValueError(f'{label}: nonnumeric values') from exc
    if a.shape != shape or not np.isfinite(a).all() or (a < 0).any():
        raise ValueError(f'{label}: missing, negative, or invalid data; shape={a.shape}')
    return a


def read_load(path):
    w = load_workbook(path, read_only=True, data_only=True)
    try:
        rows = list(w['XGBoost_负载'].values)
    finally:
        w.close()
    if [interval_header(x) for x in rows[0][1:]] != [(t,t+10) for t in range(10,1441,10)]:
        raise ValueError('Load must cover 144 means from D 00:10 to D+1 00:10')
    dates = validate_dates([r[0] for r in rows[1:]], 'load')
    a = numeric_array([r[1:] for r in rows[1:]], (len(dates),144), 'load')
    return dates, a


def read_pv(path, dates):
    """Keep all supplied numerical values; crop only 00h's unused first mean.

    All four supplied sheets contain an isolated header typo at 23:50. It is
    explicitly repaired in this adapter only after verifying every other
    target, date and width. The source workbooks are never edited.
    """
    w = load_workbook(path, read_only=True, data_only=True)
    pv = np.full((len(dates),4,144), np.nan)
    valid = np.zeros((4,144), bool)
    corrections = []
    shapes = []
    first = None
    try:
        for k,h in enumerate(ISSUE_HOURS):
            sheet = f'{h:02d}时预报'
            rows = list(w[sheet].values)
            headers = list(rows[0][1:])
            expected = [(t,t+10) for t in range(h*60,1441,10)]
            if len(headers) != len(expected):
                raise ValueError(f'{sheet}: wrong forecast width')
            for j,(header,target) in enumerate(zip(headers,expected)):
                if header == '23:50—次日00:10' and target == (1430,1440):
                    headers[j] = '23:50—次日00:00'
                    corrections.append({'sheet':sheet,'excel_column':j+2,
                        'original':header,'normalized':headers[j],
                        'reason':'isolated 20-minute label overlaps the next explicit 10-minute interval; ordered 10-minute grid and supplied load format identify intended target',
                        'numerical_values_changed':False})
            if [interval_header(v) for v in headers] != expected:
                raise ValueError(f'{sheet}: target intervals differ from expected grid')
            validate_dates([r[0] for r in rows[1:]],sheet,expected=dates)
            a = numeric_array([r[1:] for r in rows[1:]], (len(dates),len(expected)), sheet)
            if h == 0:
                first = a[:,0].copy()
                a = a[:,1:]
            start = ISSUE_START[h]
            pv[:,k,start:] = a
            valid[k,start:] = True
            shapes.append({'sheet':sheet,'rows':len(rows),'columns':len(headers)+1,
                'source_intervals':len(expected),'used_intervals':144-start,
                'issued_hour':h,'target_first_minute':max(10,h*60),'target_last_end_minute':1450,
                'power_min_kw':float(a.min()),'power_max_kw':float(a.max())})
    finally:
        w.close()
    return pv,valid,first,{'sheets':shapes,'header_corrections':corrections,
        '00h_first_interval_cropped':True,'input_value_kind':'interval_mean_kw',
        'averaging_of_supplied_values_performed':False}


def read_actual_source(path):
    w = load_workbook(path, read_only=True, data_only=True)
    result = {}
    dates = None
    try:
        for sheet,key in [('小区负载','load'),('光伏发电实际功率','pv')]:
            rows = list(w[sheet].values)
            if [clock_minute(v) for v in rows[0][1:]] != list(range(10,1441,10)):
                raise ValueError(f'{sheet}: must contain 144 instantaneous nodes')
            ds = validate_dates([r[0] for r in rows[1:]],sheet,expected=dates)
            dates = ds
            vals = numeric_array([r[1:] for r in rows[1:]],(len(ds),144),sheet)
            result[key] = {day: vals[i] for i,day in enumerate(ds)}
    finally:
        w.close()
    return result,dates


def boundary_candidates(y):
    x = np.arange(6,dtype=float); z = y[-6:]
    slope = float(np.dot(x-x.mean(),z-z.mean()) / np.dot(x-x.mean(),x-x.mean()))
    return {'hold':float(y[-1]),'linear2':float(max(0,2*y[-1]-y[-2])),
            'ols6':float(max(0,z.mean()+slope*(6-x.mean())))}


def attach_actuals(data,path):
    raw,source_dates = read_actual_source(path)
    n = len(data['dates'])
    estimated = np.zeros((n,144),bool)
    boundaries = {}
    for key in ('load','pv'):
        nodes = np.empty((n,145))
        for i,day in enumerate(data['dates']):
            if day not in raw[key]:
                raise ValueError('Forecast date missing from observed nodes')
            y = raw[key][day]
            nodes[i,:144] = y
            tomorrow = day + dt.timedelta(days=1)
            if tomorrow in raw[key]:
                nodes[i,144] = raw[key][tomorrow][0]
            elif day == source_dates[-1]:
                candidates = boundary_candidates(y)
                nodes[i,144] = candidates['hold']
                estimated[i,143] = True
                boundaries[key] = {method:{'right_endpoint_kw':v,'mean_kw':float((y[-1]+v)/2)}
                    for method,v in candidates.items()}
            else:
                raise ValueError('Missing interior endpoint cannot be extrapolated')
        data[f'{key}_nodes'] = nodes
        data[f'{key}_a'] = (nodes[:,:-1]+nodes[:,1:])/2
    data['actual_estimated'] = estimated
    day0 = data['dates'][0]; prev = day0-dt.timedelta(days=1)
    if prev not in raw['load']:
        raise ValueError('Need observed previous midnight boundary for audit')
    data['first_unexecuted_interval'] = {
        'interval_start':f'{day0}T00:00:00','interval_end':f'{day0}T00:10:00',
        'status':'not part of the user-confirmed experiment; no automatic forecast/order/state invented',
        **{f'{key}_{label}_kw':float(v) for key in ('load','pv')
           for label,v in [('left_node',raw[key][prev][-1]),('right_node',raw[key][day0][0]),
                           ('mean',(raw[key][prev][-1]+raw[key][day0][0])/2)]}}
    data['metadata']['actual'] = {'source_kind':'instantaneous_kw',
        'mean_kind':'adjacent endpoint arithmetic mean (linear between-node approximation)',
        'cross_midnight':'last node of row D paired with first node of row D+1',
        'available_at':'interval_end for complete mean; node observation available at its timestamp',
        'estimated_interval_count':int(estimated.sum()),
        'last_right_endpoint_candidates':boundaries,
        'first_unexecuted_interval':data['first_unexecuted_interval']}
    return raw


def read_price(path):
    w=load_workbook(path,read_only=True,data_only=True)
    try:
        rows=list(w.active.values)
    finally:
        w.close()
    if len(rows)!=145 or tuple(rows[0][:2])!=('时间','电价'):
        raise ValueError('Attachment1 dimensions/headers invalid')
    if [clock_minute(r[0]) for r in rows[1:]]!=list(range(10,1441,10)):
        raise ValueError('Attachment1 must contain instantaneous 00:10..24:00')
    p=numeric_array([r[1] for r in rows[1:]],(144,),'price')
    if (p<=0).any():
        raise ValueError('Prices must be positive')
    natural_nodes=np.r_[p[-1],p]
    natural=(natural_nodes[:-1]+natural_nodes[1:])/2
    return np.r_[natural[1:],natural[0]],{'source_kind':'instantaneous_price',
        '00:00_boundary':'p(00:00)=p(24:00), periodic daily tariff',
        'settlement':'interval mean price approximation',
        'first_contract_price':float(natural[1]),'last_contract_price':float(natural[0])}


def read_hourly_source(path):
    w=load_workbook(path,read_only=True,data_only=True)
    try:
        rows=list(w.active.values)
    finally:
        w.close()
    if len(rows)!=1461 or len(rows[0])!=26 or list(rows[0][2:])!=[f'预报{i}小时' for i in range(1,25)]:
        raise ValueError('Attachment3 hourly source dimensions/headers invalid')
    raw={};date=None
    for r in rows[1:]:
        if r[0]: date=as_date(r[0])
        h=clock_minute(r[1])//60
        if h not in ISSUE_HOURS or (date,h) in raw:
            raise ValueError('Invalid or duplicate hourly forecast issuance')
        raw[date,h]=numeric_array(r[2:],(24,),'hourly forecast')
    return raw


def audit_linear_reconstruction(data,path,actual_source):
    raw=read_hourly_source(path)
    linear=np.full_like(data['pv_f'],np.nan)
    rows=[]
    for k,h in enumerate(ISSUE_HOURS):
        start=ISSUE_START[h]
        for i,day in enumerate(data['dates']):
            # Only the observation AT release time, not a later actual node.
            if h==0:
                observed=actual_source['pv'][day-dt.timedelta(days=1)][-1]
            else:
                observed=actual_source['pv'][day][h*6-1]
            hourly_nodes=np.r_[observed,raw[day,h]]
            minutes=np.arange(max(10,h*60),1451,10)
            fine=np.interp(minutes,np.arange(h,h+25)*60,hourly_nodes)
            linear[i,k,start:]=(fine[:-1]+fine[1:])/2
        supplied=data['pv_f'][:,k,start:]; ref=linear[:,k,start:]
        error=supplied-ref
        rows.append({'issue_hour':h,'compared_values':int(error.size),
            'mean_absolute_difference_kw':float(np.abs(error).mean()),
            'max_absolute_difference_kw':float(np.abs(error).max()),
            'match_fraction_at_1e-7_kw':float(np.mean(np.abs(error)<=1e-7))})
    data['pv_linear_f']=linear
    data['metadata']['pv_generation_audit']={
        'finding':'supplied values are not identical to direct piecewise-linear interpolation of the same issue hourly nodes followed by endpoint averaging',
        'comparison':rows,
        'main_input':'supplied interval means, unchanged',
        'alternative_input':'pv_linear_f reconstructed only from same-issue hourly forecast and release-time observation',
        'linear_00h_final_boundary':'hold forecast node at next 00:00 to next 00:10, without reading a future forecast',
        'causality_status':'supplied generator unavailable; causality not independently certified; discrepancy alone is not evidence of future-data leakage',
        'load_generator_status':'supplied midnight forecasts; training cutoff/provenance not independently certified'}


def inspect_template(path):
    w=load_workbook(path,read_only=True,data_only=True)
    try:
        shapes={s.title:{'rows':s.max_row,'columns':s.max_column} for s in w}
        for name in ('计划购电量','调整购电量'):
            s=w[name]; r=next(s.values)
            # The final source label 0:00-0:10+1 is a known template shorthand
            # for NEXT-day 00:00-00:10, not a 24h10m interval.
            for i,h in enumerate(r[1:145]):
                if i==143:
                    if h!='0:00-0:10+1': raise ValueError('Unexpected final template header')
                elif interval_header(h)!=(10*(i+1),10*(i+2)):
                    raise ValueError('Template contract intervals do not match')
    finally:
        w.close()
    return {'sheets':shapes,'purchase_sheets':'144 contract slots D 00:10 to D+1 00:10',
        'storage_sheet':'natural-day blocks and true 00:00/24:00 states; example rows include ellipsis and must be expanded for all dates',
        'emergency_sheet':'example rows include ellipsis; export all actual episodes, split at natural-day midnight',
        'final_purchase_header_alias':'0:00-0:10+1 means next-day 00:00-00:10',
        'first_natural_day_gap':'first 00:00-00:10 is outside this experiment; must be explicitly marked rather than filled with invented dispatch'}


def copy_sources(destination=ROOT/'data'):
    destination=Path(destination);destination.mkdir(parents=True,exist_ok=True)
    copied=[]
    for name,path in SOURCES.items():
        target=destination/name
        source_hash=sha(path)
        if target.exists() and sha(target)!=source_hash:
            raise ValueError(f'Refuse to overwrite a differing copied input: {target}')
        if not target.exists(): shutil.copy2(path,target)
        if sha(target)!=source_hash: raise AssertionError('Copy integrity failed')
        copied.append({'filename':name,'original_path':str(path),'sha256':source_hash,'bytes':path.stat().st_size})
    (destination/'source_manifest.json').write_text(json.dumps(copied,ensure_ascii=False,indent=2),encoding='utf-8')
    return copied


def load_inputs(data_dir=ROOT/'data'):
    """Return datetime-based metadata plus numerical arrays (all power in kW).

    pv_f[day, vintage_index, slot] uses vintage indices 0/1/2/3 for hours
    0/6/12/18. Values before that vintage is released are deliberately NaN;
    downstream code must select only the released vintage's valid tail.
    """
    data_dir=Path(data_dir)
    dates,load=read_load(data_dir/'load_forecasts.xlsx')
    pv,valid,pv_first,pm=read_pv(data_dir/'pv_forecasts.xlsx',dates)
    price,price_meta=read_price(data_dir/'attachment1.xlsx')
    starts=[dt.datetime.combine(d,dt.time(0,10)) for d in dates]
    data={'dates':dates,'window_start':starts,
        'window_end':[a+dt.timedelta(days=1) for a in starts],
        'issued_at':[a-dt.timedelta(minutes=10) for a in starts],
        'issue_hours':ISSUE_HOURS,'issue_start':ISSUE_START.copy(),
        'load_f':load,'pv_f':pv,'pv_valid':valid,
        'pv_unused_first_mean_kw':pv_first,'price':price,
        'metadata':{'window':'D 00:10 to D+1 00:10, 144 intervals',
            'time_zone':'Asia/Shanghai','value_kind':'interval_mean_kw',
            'energy_conversion':'multiply kW by 1/6 h exactly once; never re-average supplied means',
            'initial_soc_kwh':6000.,'initial_soc_basis':'user-prescribed common experimental state at first 00:10; not derived February state',
            'forecast':pm,'price':price_meta,
            'source_sha256':{name:sha(data_dir/name) for name in SOURCES},
            'disabled_forecast_vintages':'must not be read by policy or residual generator for a disabled issuance',
            'history_availability':'require all actual interval endpoints used by a history track <= current decision timestamp'}}
    actual_source=attach_actuals(data,data_dir/'attachment2.xlsx')
    audit_linear_reconstruction(data,data_dir/'attachment3.xlsx',actual_source)
    data['metadata']['template']=inspect_template(data_dir/'result3_template.xlsx')
    if dates[0]!=dt.date(2025,2,1) or dates[-1]!=dt.date(2025,12,31) or len(dates)!=334:
        raise ValueError('Current experiment expects 2025-02-01..2025-12-31, 334 windows')
    # Compatibility conveniences; these are views, never additional inputs.
    data['pv_f_by_hour']={h:pv[:,k,:] for k,h in enumerate(ISSUE_HOURS)}
    data['pv0_f']=pv[:,0,:]
    return data


def save_bundle(data,out=ROOT/'data'):
    out=Path(out);out.mkdir(exist_ok=True,parents=True)
    arrays={key:value for key,value in data.items() if isinstance(value,np.ndarray)}
    arrays.update(dates=np.array([str(d) for d in data['dates']]),
        window_start=np.array([x.isoformat() for x in data['window_start']]),
        window_end=np.array([x.isoformat() for x in data['window_end']]),
        issued_at=np.array([x.isoformat() for x in data['issued_at']]),
        issue_hours=np.asarray(ISSUE_HOURS),issue_start_indices=np.asarray([ISSUE_START[h] for h in ISSUE_HOURS]))
    np.savez_compressed(out/'q3_inputs.npz',**arrays)
    (out/'input_audit.json').write_text(json.dumps(data['metadata'],ensure_ascii=False,indent=2),encoding='utf-8')
    return out/'q3_inputs.npz'


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data',type=Path,default=ROOT/'data')
    parser.add_argument('--copy-originals',action='store_true')
    args=parser.parse_args()
    if args.copy_originals: copy_sources(args.data)
    bundle=load_inputs(args.data)
    artifact=save_bundle(bundle,args.data)
    print(json.dumps({'bundle':str(artifact),'windows':len(bundle['dates']),
        'load_shape':list(bundle['load_f'].shape),'pv_shape':list(bundle['pv_f'].shape),
        'estimated_actual_intervals':int(bundle['actual_estimated'].sum()),
        'header_corrections':len(bundle['metadata']['forecast']['header_corrections'])},ensure_ascii=False))
