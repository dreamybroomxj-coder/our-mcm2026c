"""Independent evidence for IO/cache guard changes, without annual re-solving."""
import ast
import copy
import csv
import hashlib
import json
from pathlib import Path
import shutil
import tempfile

import numpy as np
from openpyxl import load_workbook

from q3_audit import NUMERIC, audit_run
from q3_runner import run_strategy, signature

ROOT=Path(__file__).resolve().parents[1]


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):return json.loads(Path(path).read_text(encoding='utf-8'))
def rows(path):
    with Path(path).open(encoding='utf-8-sig',newline='') as stream:return list(csv.DictReader(stream))


def review(project=ROOT):
    project=Path(project);data=project/'data';prov=project/'provenance';code=project/'code'
    before=project/'results/guard_regression/before/guard_rich'
    after=project/'results/guard_regression/after/guard_rich'
    bs,ns=read(before/'summary.json'),read(after/'summary.json')
    bt,nt=rows(before/'trace.csv'),rows(after/'trace.csv')
    if bs['config']!=ns['config'] or len(bt)!=432 or len(nt)!=432:
        raise RuntimeError('Regression requires identical settings and 3 complete windows')
    columns={key:float(np.max(np.abs(np.asarray([float(r[key]) for r in bt])-
                                   np.asarray([float(r[key]) for r in nt])))) for key in NUMERIC}
    text_keys=set(bt[0])-set(NUMERIC)
    texts=all(all(a[k]==b[k] for k in text_keys) for a,b in zip(bt,nt))
    equivalent=texts and max(columns.values())<=1e-7
    hashes={name:{'before':sha(prov/'numerical_core_used'/name),'after':sha(code/name)}
            for name in ('q3_io.py','q3_optimizer.py','q3_risk.py','q3_runner.py')}
    def functions(path):
        return {n.name:n for n in ast.parse(Path(path).read_text()).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
    old=functions(prov/'numerical_core_used/q3_runner.py');new=functions(code/'q3_runner.py')
    changed=[name for name in old if name not in new or ast.dump(old[name],include_attributes=False)!=ast.dump(new[name],include_attributes=False)]
    additions=sorted(set(new)-set(old))
    stripped=copy.deepcopy(new['run_strategy'])
    stripped.body=[node for node in stripped.body if not(isinstance(node,ast.Expr) and isinstance(node.value,ast.Call)
        and isinstance(node.value.func,ast.Name) and node.value.func.id=='validate_run_arguments')]
    run_unchanged=ast.dump(stripped,include_attributes=False)==ast.dump(old['run_strategy'],include_attributes=False)
    other_cores_same=all(hashes[name]['before']==hashes[name]['after'] for name in hashes if name!='q3_runner.py')
    ba,na=audit_run(before),audit_run(after)
    for directory,result in ((before,ba),(after,na)):
        (directory/'independent_audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    source_names=('attachment1.xlsx','attachment2.xlsx','attachment3.xlsx',
                  'load_forecasts.xlsx','pv_forecasts.xlsx','result3_template.xlsx','source_manifest.json')
    original_hashes={name:sha(data/name) for name in source_names}
    target_before=sha(after/'summary.json')
    with tempfile.TemporaryDirectory(prefix='q3-cache-proof-') as temporary:
        copied=Path(temporary)
        for name in source_names:shutil.copy2(data/name,copied/name)
        sig_before=signature(copied,ns['config'])
        cached=run_strategy(copied,after.parent,(0,6,12,18),start_day=16,days=3,name='guard_rich')
        original_cache_reused=cached['run_signature']==ns['run_signature']==sig_before
        book=load_workbook(copied/'pv_forecasts.xlsx')
        sheet=book['00时预报'];previous=float(sheet['B2'].value);sheet['B2']=previous+123.45
        book.save(copied/'pv_forecasts.xlsx');book.close()
        manifest_unchanged=sha(copied/'source_manifest.json')==original_hashes['source_manifest.json']
        sig_after=signature(copied,ns['config'])
        rejected=False;message=None
        try:
            run_strategy(copied,after.parent,(0,6,12,18),start_day=16,days=3,name='guard_rich')
        except RuntimeError as exc:
            message=str(exc);rejected='Incompatible existing run' in message
        cache={'identical_copied_xlsx_reused_existing_result':original_cache_reused,
            'actual_modified_workbook':'temporary pv_forecasts.xlsx, 00时预报!B2',
            'old_cell_value':previous,'new_cell_value':previous+123.45,
            'manifest_bytes_unchanged':manifest_unchanged,
            'fingerprint_changed':sig_before!=sig_after,
            'cached_result_reuse_rejected':rejected,'rejection_message':message,
            'original_result_summary_unchanged':sha(after/'summary.json')==target_before,
            'private_mutation_fixture_removed':True}
    inputs_unchanged=all(sha(data/name)==digest for name,digest in original_hashes.items())
    manifest_snapshot=sha(data/'source_manifest.json')==sha(prov/'source_manifest.json')
    result={'passed':equivalent and other_cores_same and run_unchanged and ba['passed'] and na['passed']
        and all(cache[k] for k in ('identical_copied_xlsx_reused_existing_result','manifest_bytes_unchanged',
             'fingerprint_changed','cached_result_reuse_rejected','original_result_summary_unchanged'))
        and inputs_unchanged and manifest_snapshot,
        'change_scope':'Only input/cache guards; no optimization equations, price rules, scenarios or execution equations changed',
        'core_hashes':hashes,'changed_existing_runner_functions':changed,
        'added_runner_functions':additions,'run_strategy_same_after_removing_validation_call':run_unchanged,
        'other_three_numerical_modules_byte_identical':other_cores_same,
        'regression':{'strategy':'all 0/6/12/18 enabled; 8 scenarios; MPC','start_day':16,'windows':3,
            'intervals':432,'start':bt[0]['interval_start'],'end':bt[-1]['interval_end'],
            'config':bs['config'],'same_text_fields':texts,'max_numeric_difference_by_column':columns,
            'max_numeric_difference':max(columns.values()),'comparison_tolerance':1e-7,
            'before_cash_yuan':bs['cash_cost_yuan'],'after_cash_yuan':ns['cash_cost_yuan'],
            'before_final_soc_kwh':bs['soc_end_kwh'],'after_final_soc_kwh':ns['soc_end_kwh'],
            'before_signature':bs['run_signature'],'after_signature':ns['run_signature'],
            'before_trace_sha256':sha(before/'trace.csv'),'after_trace_sha256':sha(after/'trace.csv'),
            'both_independent_ledger_audits_passed':ba['passed'] and na['passed']},
        'cache_rejection_test':cache,'original_input_files_unchanged':inputs_unchanged,
        'original_source_manifest_exact_snapshot_matches':manifest_snapshot,
        'full_primary_calculation_rerun':False,
        'why_no_annual_resolve':'The valid-input numerical path is structurally unchanged, the optimizer/risk/adapter bytes match, and the 3-window regression is equivalent; only cache key and rejection of invalid arguments changed.',
        'reproduction_note':'Use the original numerical_core_used snapshot for historical code replay, or the guarded current entrypoint into a NEW output directory. Time-limited MILP can vary with runtime load.'}
    (prov/'io_guard_change.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    text=f'''# 代码版本与复现说明

本次全年主结果使用的原始数值核心已经完整保存于`provenance/numerical_core_used`，对应四个文件的SHA256写在`numerical_core_manifest.json`；参与原运行签名的`source_manifest.json`也保存了精确字节副本。

全年主计算和两个消融均已结束后，只对当前入口增加了两类保护：实际六个XLSX文件的字节加入缓存指纹；非法时刻、配置和初态在计算前被拒绝。原来的缓存仅包含来源清单，单独替换预测XLSX而不改清单可能错误复用旧结果，这次已经修复。小时标签必须为真正整数，浮点和布尔值不再混入。

## 数学与数值过程是否改变

`q3_io.py`、`q3_risk.py`、`q3_optimizer.py`与原快照逐字节相同。`q3_runner.py`只改了缓存签名、增加参数校验函数，并在入口调用它。移除这一校验调用后，运行主函数的抽象语法树与原版相同；没有改变MILP方程、风险场景、调单费用、电池动作或时间循环。

采用0/6/12/18全部启用、8场景、相同初态，从2月17日00:10起分别用原快照和新入口独立运行3个合同、432段。两版现金费均为 **{bs['cash_cost_yuan']:.9f}元**，末态均为 **{bs['soc_end_kwh']:.9f} kWh**；全部数值列的最大差为 **{max(columns.values()):.12g}**，文本时间与版本字段也相同。两份轨迹均通过独立物理与账本检查。

另外复制真实PV工作簿到临时目录，修改其中一个预测单元格，同时保持来源清单字节不变。原样副本能够正确使用缓存；修改后的副本触发新指纹，程序明确拒绝复用旧结果。原始六个XLSX及既有结果没有被修改，临时错误输入已经清理。

## 既有全年结果的适用状态

**这次只做了上述3窗对照与缓存反例，没有重新计算334窗主结果。**合法输入下数值路径未变，因而缓存保护修复不要求对未受影响的全年数学结果重算。主结果仍应标注其原始核心版本，不冒称由修复后的入口重新跑出。

8条主轨迹共384768段、2条消融共96192段的逐段审计已完成；原始输入哈希、冻结核心哈希及历史运行签名均可追溯。详见`results/audit_main_validation.json`。具体补丁、逐列回归差异和缓存拒绝证据见`provenance/io_guard_change.json`。

## 怎样复现

核对这次保存结果的原始代码时，使用`provenance/numerical_core_used`内的四个原文件。它们保留当时行为，只用于历史来源与数值复核；旧缓存不足也一并保留，不建议作为日常替换预测后的入口。

日常复算使用当前`code/run_all.py`。默认输出目录已经改为`results/reproduced`；也可以显式选择一个新目录：

```bash
python code/run_all.py --out results/reproduced_01
```

当前代码的版本与缓存指纹有意发生变化。不要把既有`results/main`当成新入口可以原样继承的缓存；出现“不兼容的既有结果”时，应选新目录，而不是修改原结果以绕过检查。

固定随机种子控制的是历史场景抽样，不保证含求解时限的MILP在所有机器上逐位一致。复现时还要记录求解器版本、时间预算、可行性与Gap；并发负载可能影响截止时已经找到的可行解。上述3窗对照是本机同环境下的等价验证，不承诺所有年度输出在所有硬件上完全一致。
'''
    (project/'notes/代码版本与复现.md').write_text(text,encoding='utf-8')
    print(json.dumps({'passed':result['passed'],'max_difference':max(columns.values()),
        'cash':bs['cash_cost_yuan'],'cache_rejected':cache['cached_result_reuse_rejected']},ensure_ascii=False))
    return result


if __name__=='__main__':
    raise SystemExit(0 if review()['passed'] else 1)
