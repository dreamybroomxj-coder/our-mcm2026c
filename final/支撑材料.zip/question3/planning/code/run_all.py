"""Complete reproducible Q3 study. All outputs stay under the chosen directory."""
import argparse,json,subprocess,sys
from pathlib import Path
from q3_runner import run_strategy
from q3_sensitivity import run_study
from q3_audit import audit_run
from q3_reports import build_reports
from q3_boundaries import run_boundary_study
from q3_causal_replay import run_replay
from q3_figures import build_figures

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--data',default=str(Path(__file__).resolve().parents[1]/'data'))
    parser.add_argument('--out',default=str(Path(__file__).resolve().parents[1]/'results/reproduced'))
    parser.add_argument('--workers',type=int,default=4)
    args=parser.parse_args();root=Path(args.out);code=Path(__file__).resolve().parent
    if args.workers<1:parser.error('--workers must be positive')
    subprocess.run([sys.executable,str(code/'q3_io.py'),'--data',args.data],check=True)
    subprocess.run([sys.executable,'-m','unittest','discover','-s',str(code),'-p','test*.py'],check=True)
    subprocess.run([sys.executable,str(code/'q3_runner.py'),'--data',args.data,'--out',str(root/'main'),
                    '--workers',str(args.workers)],check=True)
    for stage in ('development','algorithms'):
        run_study(args.data,root/'sensitivity',stage,min(2,args.workers))
    run_strategy(args.data,root/'ablation',(0,6,12,18),forecast_hours=(0,),name='old_forecast_all_trades')
    run_strategy(args.data,root/'ablation',(0,6,12,18),config={'controller':'greedy'},name='all_trades_greedy')
    audits={}
    for folder in (root/'main',root/'ablation',root/'sensitivity/development',root/'sensitivity/algorithms'):
        for p in sorted(folder.glob('*/summary.json')):
            result=audit_run(p.parent,Path(args.data)/'q3_inputs.npz')
            audits[str(p.parent.relative_to(root))]=result
            if not result['passed']:
                raise RuntimeError(f'Independent audit failed: {p.parent}: {result.get("failed_checks")}')
    (root/'audit_all.json').write_text(json.dumps(audits,ensure_ascii=False,indent=2,default=str))
    selected=json.loads((root/'main/selection.json').read_text())['selected_strategy']
    run_replay(args.data,root/'main'/selected,root/'causal_selected',24,7)
    run_replay(args.data,root/'main'/'H0',root/'causal_H0',24,7)
    run_replay(args.data,root/'ablation'/'old_forecast_all_trades',root/'causal_old_forecast',24,7)
    run_boundary_study(args.data,root/'main',root/'boundaries')
    build_reports(root/'main',args.data,root/'reports')
    build_figures(args.data,root,root/'figures')
    from q3_conclusions import build_conclusions
    build_conclusions(root,root/'reports/问题三_结果与评价.md')
    print('Complete:',root)

if __name__=='__main__':main()
