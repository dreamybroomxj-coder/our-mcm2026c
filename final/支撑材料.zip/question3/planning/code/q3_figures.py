"""Reproducible plots from frozen ledgers; never reruns or changes dispatch."""
import os
os.environ.setdefault('MPLCONFIGDIR','/tmp/cumcm_q3_matplotlib')
import argparse,json
from pathlib import Path
import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from q3_io import load_inputs
from q3_risk import HOURS,START

def build_figures(data_dir,results_dir,out_dir):
    out=Path(out_dir);out.mkdir(parents=True,exist_ok=True);root=Path(results_dir)
    plt.rcParams.update({'font.sans-serif':['Arial Unicode MS','Heiti TC','DejaVu Sans'],
       'axes.unicode_minus':False,'font.size':10,'axes.spines.top':False,'axes.spines.right':False,
       'figure.dpi':130,'savefig.dpi':180})
    meta=[]
    def save(fig,name,caption):
        fig.tight_layout();fig.savefig(out/(name+'.png'),bbox_inches='tight')
        fig.savefig(out/(name+'.pdf'),bbox_inches='tight');plt.close(fig)
        meta.append(dict(file=name+'.png',caption=caption))
    data=load_inputs(data_dir)
    fig,ax=plt.subplots(figsize=(8,3.8));positions=np.arange(3);old=[];new=[]
    for k,h in enumerate(HOURS[1:],1):
        start=START[h];actual=data['pv_a'][:,start:]
        old.append(np.abs(data['pv_f'][:,0,start:]-actual).mean())
        new.append(np.abs(data['pv_f'][:,k,start:]-actual).mean())
    ax.bar(positions-.17,old,.34,label='仍使用0点预报',color='#829bb1')
    ax.bar(positions+.17,new,.34,label='使用该时刻新预报',color='#168a87')
    ax.set(xticks=positions,xticklabels=['6点至合同末','12点至合同末','18点至合同末'],ylabel='同一目标范围光伏MAE（kW）')
    ax.legend();save(fig,'01_新旧预报同范围误差','每组柱子比较完全相同的目标时段；三组覆盖范围不同，不能直接按柱高比较发布时间优劣。')
    selection=json.loads((root/'main/selection.json').read_text());chosen=selection['selected_strategy']
    summaries=json.loads((root/'main/comparison.json').read_text())
    s=pd.DataFrame(summaries).sort_values('cash_cost_yuan');labels=s.strategy.str.replace('H','',regex=False).str.replace('_','＋',regex=False)
    fig,ax=plt.subplots(figsize=(9,4));colors=['#168a87' if x==chosen else '#9caebb' for x in s.strategy]
    bars=ax.barh(labels,s.cash_cost_yuan/1e4,color=colors);ax.invert_yaxis();ax.set_xlabel('334个合同窗口实际现金费用（万元）')
    for b,v in zip(bars,s.cash_cost_yuan):ax.text(b.get_width()+1,b.get_y()+b.get_height()/2,f'{v/1e4:.2f}',va='center',fontsize=9)
    ax.set_xlim(0,s.cash_cost_yuan.max()/1e4*1.12)
    save(fig,'02_八组合完整费用','绿色为开发期选定组合；全年最低仅作回溯排名。334窗从2月1日00:10至次年1月1日00:10。')
    daily={x['strategy']:pd.read_csv(root/'main'/x['strategy']/'daily.csv',parse_dates=['window_date']) for x in summaries}
    fig,ax=plt.subplots(figsize=(9,3.8))
    for name,col in [('H0','#7f91a5'),(chosen,'#168a87')]:
        ds=daily[name].set_index('window_date').cash_cost_yuan.resample('MS').sum()/1e4
        ax.plot(ds.index.month,ds.values,'o-',label=name.replace('H','').replace('_','＋'),color=col)
    ax.set(xlabel='合同开始月份',ylabel='合同窗口费用（万元）',xticks=range(2,13));ax.legend()
    save(fig,'03_逐月费用','同一输入、初始SOC、物理条件；每条策略的SOC独立连续。月份按合同开始日归属。')
    fig,ax=plt.subplots(figsize=(9,3.8));order=s.strategy.tolist();x=np.arange(len(order))
    ordinary=[next(v for v in summaries if v['strategy']==n)['original_plan_cost_yuan']+next(v for v in summaries if v['strategy']==n)['net_adjustment_cost_yuan'] for n in order]
    emergency=[next(v for v in summaries if v['strategy']==n)['emergency_cost_yuan'] for n in order]
    ax.bar(x,np.array(ordinary)/1e4,label='普通电结算（含退款、违约及增购）',color='#8fa6b4')
    ax.bar(x,np.array(emergency)/1e4,bottom=np.array(ordinary)/1e4,label='紧急购电',color='#dc8a50')
    ax.set(xticks=x,xticklabels=[n.replace('H','').replace('_','＋') for n in order],ylabel='实际现金费用（万元）');ax.legend(fontsize=8)
    save(fig,'04_实际电费组成','未来暂定调单及终端库存软惩罚不计入现金账单。')
    trace=pd.read_csv(root/'main'/chosen/'trace.csv',parse_dates=['interval_start','interval_end'])
    dates=['2025-03-20','2025-06-21','2025-09-23','2025-12-21']
    fig,axes=plt.subplots(2,2,figsize=(11,6),sharex=True,sharey=True)
    for ax,date in zip(axes.flat,dates):
        d=trace[trace.interval_start.dt.strftime('%Y-%m-%d')==date];hours=d.interval_start.dt.hour+d.interval_start.dt.minute/60
        ax.plot(np.r_[hours.values,24],np.r_[d.soc_start_kwh.values,d.soc_end_kwh.iloc[-1]],color='#168a87')
        ax.axhline(1200,c='#dc8a50',ls='--',lw=.8);ax.axhline(10800,c='#dc8a50',ls='--',lw=.8)
        ax.set(title=date,xlabel='自然日时间（h）',ylabel='储电量（kWh）',xticks=[0,6,12,18,24],ylim=(0,12000))
    save(fig,'05_四日真实储电轨迹','自然日00:00首段接前一合同，连续至24:00；不存在每日重置6000。')
    fig,axes=plt.subplots(2,2,figsize=(11,6),sharex=True)
    for ax,date in zip(axes.flat,dates):
        d=trace[trace.interval_start.dt.strftime('%Y-%m-%d')==date];hours=d.interval_start.dt.hour+d.interval_start.dt.minute/60
        ax.plot(hours,d.g_kwh*6,label='0点原计划',lw=1,color='#a4afb8')
        ax.plot(hours,d.q_kwh*6,label='正式普通购电',lw=1,color='#168a87')
        ax.fill_between(hours,d.emergency_kwh*6,color='#dc8a50',alpha=.7,label='紧急电')
        ax.set(title=date,xlabel='自然日时间（h）',ylabel='等效平均功率（kW）',xticks=[0,6,12,18,24])
    axes.flat[0].legend(fontsize=8);save(fig,'06_四日购电与应急','电量乘6仅为画等效平均功率；账本仍保存kWh，不重复换算费用。')
    path=root/'sensitivity/algorithms/comparison.json'
    if path.exists():
        ss={r['strategy']:r for r in json.loads(path.read_text())}
        keys=['deterministic_mpc','stochastic_greedy','stochastic_mpc'];names=['点预测＋MPC','场景＋贪心','场景＋MPC']
        fig,ax=plt.subplots(figsize=(8,3.8));xx=np.arange(3)
        ax.bar(xx-.18,[ss[k]['cash_cost_yuan']/1e4 for k in keys],.36,label='真实现金费',color='#8fa6b4')
        ax.bar(xx+.18,[ss[k]['inventory_adjusted_cost_yuan']/1e4 for k in keys],.36,label='附库存调整比较值',color='#168a87')
        ax.set(xticks=xx,xticklabels=names,ylabel='60合同窗口（万元）');ax.legend()
        save(fig,'07_场景层与控制层对照','预设全时刻更新、2月25日起60窗、共同局部初态6000；只作60窗算法检验，不冒称全年。')
    path=root/'sensitivity/development/comparison.json'
    if path.exists():
        ss={r['strategy']:r for r in json.loads(path.read_text())};keys=['scenes_4','scenes_8','scenes_16']
        fig,axs=plt.subplots(1,2,figsize=(9,3.5));xx=[4,8,16]
        axs[0].plot(xx,[ss[k]['inventory_adjusted_cost_yuan']/1e4 for k in keys],'o-',c='#168a87')
        axs[0].set(xlabel='请求场景数',ylabel='开发7窗库存调整费用（万元）',xticks=xx)
        axs[1].plot(xx,[ss[k]['elapsed_seconds'] for k in keys],'o-',c='#dc8a50')
        axs[1].set(xlabel='请求场景数',ylabel='7窗计算耗时（秒）',xticks=xx)
        save(fig,'08_场景数敏感性','16条不足时按可用历史数计算；8为预设主参数，本图不用于回头按测试结果选参。耗时受同机并行负载影响。')
    (out/'figure_manifest.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2))
    return meta

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--data',required=True);a.add_argument('--results',required=True);a.add_argument('--out',required=True);args=a.parse_args()
    build_figures(args.data,args.results,args.out)
