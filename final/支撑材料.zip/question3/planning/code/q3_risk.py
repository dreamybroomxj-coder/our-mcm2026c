"""Causal, paired full-remaining-window residual scenarios for Q3.

No risk margin is added. A scenario samples one historical date for BOTH load
and the matching PV forecast vintage. All its target intervals must have ended
before the current decision. Excluded forecast vintages are never read.
"""
import datetime as dt
import numpy as np

START = {0: 0, 6: 35, 12: 71, 18: 107}
HOURS = (0, 6, 12, 18)


def available_history(data, day, decision_hour, window=28):
    decision = dt.datetime.combine(data['dates'][day], dt.time(decision_hour))
    return [j for j in range(day) if data['window_end'][j] <= decision][-window:]


def scenario_inputs(data, day, forecast_hour, decision_hour, begin, config):
    if forecast_hour > decision_hour or forecast_hour not in HOURS:
        raise ValueError('Forecast vintage is not available at decision time')
    if begin < START[forecast_hour]:
        raise ValueError('Forecast vintage does not cover the requested beginning')
    source = config.get('pv_source', 'supplied')
    pv = data['pv_f'] if source == 'supplied' else data['pv_linear_f']
    k = HOURS.index(forecast_hour)
    lf = data['load_f'][day, begin:].copy()
    pf = pv[day, k, begin:].copy()
    if not np.isfinite(lf).all() or not np.isfinite(pf).all():
        raise ValueError('Missing issued forecast')
    history = available_history(data, day, decision_hour, config.get('history_days', 28))
    meta = {'forecast_hour': forecast_hour, 'decision_hour': decision_hour,
            'issued_at': str(dt.datetime.combine(data['dates'][day], dt.time(forecast_hour))),
            'decision_at': str(dt.datetime.combine(data['dates'][day], dt.time(decision_hour))),
            'history_indices': history, 'history_days': len(history),
            'history_latest_end': None if not history else data['window_end'][history[-1]].isoformat(),
            'pv_source': source, 'margin_added': False}
    count = config.get('scenarios', 8)
    if count == 1 or len(history) < config.get('min_history', 14):
        meta.update(scenarios=1, fallback=count != 1, draw_indices=[])
        return lf[None,:]/6, pf[None,:]/6, meta
    lr = data['load_a'][history, begin:] - data['load_f'][history, begin:]
    pr = data['pv_a'][history, begin:] - pv[history, k, begin:]
    rng = np.random.default_rng(config.get('seed', 20260912) + 1009*day + 59*forecast_hour)
    m = min(count, len(history))
    draw = rng.choice(len(history), m, replace=False)
    loads = np.maximum(lf + lr[draw], 0)
    pvs = np.maximum(pf + pr[draw], 0)
    meta.update(scenarios=m, fallback=False, draw_indices=np.asarray(history)[draw].tolist(),
                sampling='paired complete residual paths, without replacement, uniform weights')
    return loads/6, pvs/6, meta


def latest_hour(enabled_hours, target_index):
    return max(h for h in enabled_hours if START[h] <= target_index)


def future_mask(trade_hours, target_index, *,include_current=False):
    later = [START[h] for h in trade_hours if h and
             (START[h] >= target_index if include_current else START[h] > target_index)]
    return np.arange(target_index, 144) >= min(later) if later else np.zeros(144-target_index, bool)


def current_block(trade_hours, hour):
    start = START[hour]
    later = [START[h] for h in trade_hours if h > hour]
    return start, min(later) if later else 144
