"""Build audited Q3 workbooks and the four required paper tables from ledgers.

This module never optimizes dispatch or modifies source ledgers/templates.
Call build_reports(results_dir, data_dir, out_dir) after the main replay.
"""
from __future__ import annotations

import argparse
import csv
from datetime import datetime, timedelta
import hashlib
import json
import math
from pathlib import Path
import shutil

from openpyxl import Workbook, load_workbook
from openpyxl.chart import BarChart, Reference
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

DATES=('2025-03-20','2025-06-21','2025-09-23','2025-12-21')
SLOTS=('10:00','12:00','14:00','16:00','18:00','20:00')
EPS=1e-5
NUMERIC=('price_yuan_per_kwh','load_forecast_kw','pv_forecast_kw','load_actual_kw',
    'pv_actual_kw','g_kwh','q_kwh','increase_kwh','decrease_kwh','charge_kwh',
    'discharge_kwh','emergency_kwh','unused_paid_kwh','curtailed_pv_kwh',
    'soc_start_kwh','soc_end_kwh','plan_cost_yuan','increase_cost_yuan','refund_yuan',
    'penalty_yuan','adjustment_net_cost_yuan','emergency_cost_yuan','cash_cost_yuan')
SUM_FIELDS=('g_kwh','q_kwh','increase_kwh','decrease_kwh','charge_kwh','discharge_kwh',
    'emergency_kwh','unused_paid_kwh','curtailed_pv_kwh','plan_cost_yuan',
    'increase_cost_yuan','refund_yuan','penalty_yuan','adjustment_net_cost_yuan',
    'emergency_cost_yuan','cash_cost_yuan')
LABELS={'strategy':'策略','date':'日期','g_kwh':'零点原计划量(kWh)',
    'q_kwh':'调整后普通购电量(kWh)','increase_kwh':'增购量(kWh)',
    'decrease_kwh':'取消量(kWh)','charge_kwh':'充电量(kWh)',
    'discharge_kwh':'放电量(kWh)','emergency_kwh':'紧急购电量(kWh)',
    'unused_paid_kwh':'已付未用电量(kWh)','curtailed_pv_kwh':'弃光量(kWh)',
    'plan_cost_yuan':'原计划费(元)','increase_cost_yuan':'增购费(元)',
    'refund_yuan':'取消退原费(元，正数)','penalty_yuan':'取消违约费(元)',
    'adjustment_net_cost_yuan':'调整净费用(元)','emergency_cost_yuan':'紧急费(元)',
    'cash_cost_yuan':'总现金费(元)','ordinary_cost_yuan':'普通购电结算费(元)',
    'soc_start_kwh':'起点储电量(kWh)','soc_end_kwh':'终点储电量(kWh)',
    'startup_cost_yuan':'首日初始化段费(元)','cash_including_startup_yuan':'含首段总费(元)',
    'inventory_adjusted_cost_yuan':'库存修正评价(元，非电费)',
    'natural_period_cash_cost_yuan':'2月1日至12月31日自然日期间费(元)',
    'intervals':'区间数','selected':'事先规则选定','retrospective_best':'全期回溯最低(库存修正)'}


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def total(rows,key):return math.fsum(r[key] for r in rows)
def as_bool(v):return str(v).strip().lower() in ('true','1','yes')
def near(a,b,label,tol=EPS):
    error=abs(a-b)
    if error>tol:raise AssertionError(f'{label}: {a} vs {b}, error={error}')
    return error


def read_trace(path,*,strategy=None):
    with Path(path).open(encoding='utf-8-sig',newline='') as f:raw=list(csv.DictReader(f))
    if not raw:raise ValueError(f'Empty ledger: {path}')
    rows=[]
    for r in raw:
        if strategy is not None and r.get('strategy') and r['strategy']!=strategy:
            # A shared startup file can contain all strategy rows; select exact.
            continue
        v=dict(r)
        for k in NUMERIC:
            if k not in r or r[k] in ('',None):raise ValueError(f'{path}: missing {k}')
            v[k]=float(r[k])
            if not math.isfinite(v[k]):raise ValueError(f'{path}: nonfinite {k}')
        v['actual_estimated']=as_bool(r.get('actual_estimated',False))
        for key in ('interval_start','interval_end'):
            v[key]=datetime.fromisoformat(r[key]).isoformat()
        if strategy is not None:v['strategy']=strategy
        rows.append(v)
    rows.sort(key=lambda r:r['interval_start'])
    return rows


def audit_trace(rows,*,label,require_contiguous=True):
    """Verify ledger algebra. Finer execution causality remains runner-tested."""
    max_balance=max_soc=max_cash=max_components=0.
    starts=set();prev=None
    for r in rows:
        a=datetime.fromisoformat(r['interval_start']);b=datetime.fromisoformat(r['interval_end'])
        if b-a!=timedelta(minutes=10) or a.minute%10:raise AssertionError('Bad interval')
        if a in starts:raise AssertionError('Duplicate execution interval')
        starts.add(a)
        if prev is not None and require_contiguous:
            if prev['interval_end']!=r['interval_start']:raise AssertionError('Noncontiguous ledger')
            near(prev['soc_end_kwh'],r['soc_start_kwh'],'cross-interval SOC')
        p=r['price_yuan_per_kwh'];g=r['g_kwh'];q=r['q_kwh'];up=r['increase_kwh'];down=r['decrease_kwh']
        c=r['charge_kwh'];d=r['discharge_kwh'];e=r['emergency_kwh']
        v=r['unused_paid_kwh'];curtail=r['curtailed_pv_kwh']
        load=r['load_actual_kw']/6;pv=r['pv_actual_kw']/6
        if min(p,g,q,up,down,c,d,e,v,curtail)<-EPS:raise AssertionError('Negative physical value')
        if min(up,down)>EPS:raise AssertionError('Simultaneous increase/cancellation')
        if max(c,d)>5000/6+EPS:raise AssertionError('Battery power limit')
        if v>q+EPS or curtail>pv+EPS:raise AssertionError('Waste exceeds available source')
        for s in ('soc_start_kwh','soc_end_kwh'):
            if not 1200-EPS<=r[s]<=10800+EPS:raise AssertionError('SOC bound')
        max_balance=max(max_balance,near(q-v+pv-curtail+d+e,load+c,'AC energy balance'))
        max_soc=max(max_soc,near(r['soc_end_kwh'],r['soc_start_kwh']+.9*c-d/.9,'SOC equation'))
        values=((q,g+up-down,'q=g+increase-decrease'),
            (r['plan_cost_yuan'],p*g,'original cost'),
            (r['increase_cost_yuan'],1.5*p*up,'increase cost'),
            (r['refund_yuan'],p*down,'refund positive magnitude'),
            (r['penalty_yuan'],.5*p*down,'penalty'),
            (r['adjustment_net_cost_yuan'],1.5*p*up-.5*p*down,'net adjustment'),
            (r['emergency_cost_yuan'],5*p*e,'emergency cost'))
        for x,y,name in values:max_components=max(max_components,near(x,y,name))
        max_cash=max(max_cash,near(r['cash_cost_yuan'],p*g+1.5*p*up-.5*p*down+5*p*e,'cash'))
        prev=r
    return {'label':label,'intervals':len(rows),'first_interval':rows[0]['interval_start'] if rows else None,
        'last_interval_end':rows[-1]['interval_end'] if rows else None,
        'max_balance_error_kwh':max_balance,'max_soc_error_kwh':max_soc,
        'max_component_error':max_components,'max_cash_error_yuan':max_cash,
        'actual_estimated_intervals':sum(r['actual_estimated'] for r in rows),
        'scope':'aggregate physical/transaction ledger; within-interval mode/causality checked separately in runner tests'}


def summarize(rows,strategy,date=None):
    out={k:total(rows,k) for k in SUM_FIELDS}
    out.update(strategy=strategy,date=date,intervals=len(rows),soc_start_kwh=rows[0]['soc_start_kwh'],
        soc_end_kwh=rows[-1]['soc_end_kwh'],ordinary_cost_yuan=out['plan_cost_yuan']+out['adjustment_net_cost_yuan'])
    near(out['cash_cost_yuan'],out['ordinary_cost_yuan']+out['emergency_cost_yuan'],'summary cash')
    return out


def day_groups(rows,*,full_only=True):
    groups={}
    for r in rows:groups.setdefault(r['interval_start'][:10],[]).append(r)
    out={}
    for date,rs in sorted(groups.items()):
        start=datetime.fromisoformat(date)
        full=len(rs)==144 and all(datetime.fromisoformat(r['interval_start'])==start+timedelta(minutes=10*i) for i,r in enumerate(rs))
        if full:out[date]=rs
        elif not full_only:out[date]=rs
    return out


def episodes(rows):
    """Merge positive e intervals; never join across a calendar midnight."""
    out=[];active=None
    for r in rows:
        same=active is not None and active['end']==r['interval_start'] and active['date']==r['interval_start'][:10]
        if r['emergency_kwh']>EPS:
            if not same:
                if active is not None:out.append(active)
                active={'date':r['interval_start'][:10],'start':r['interval_start'],'end':r['interval_end'],
                    'parts':[r['emergency_kwh']]}
            else:
                active['end']=r['interval_end'];active['parts'].append(r['emergency_kwh'])
        elif active is not None:
            out.append(active);active=None
    if active is not None:out.append(active)
    for e in out:
        e['kwh']=math.fsum(e.pop('parts'))
        end='24:00' if e['end'][:10]!=e['date'] else e['end'][11:16]
        e['label']=e['start'][11:16]+'—'+end
    near(math.fsum(e['kwh'] for e in out)+math.fsum(r['emergency_kwh'] for r in rows if r['emergency_kwh']<=EPS),
         total(rows,'emergency_kwh'),'episode sum')
    return out


def style(ws,*,width=20,header_rows=(1,)):
    ws.sheet_view.showGridLines=False
    ws.freeze_panes='B2'
    ws.sheet_properties.pageSetUpPr.fitToPage=True
    ws.page_setup.orientation='landscape';ws.page_setup.paperSize=ws.PAPERSIZE_A4
    ws.page_setup.fitToWidth=1;ws.page_setup.fitToHeight=0
    for col in range(1,ws.max_column+1):ws.column_dimensions[get_column_letter(col)].width=width
    for row in ws:
        ws.row_dimensions[row[0].row].height=27
        for c in row:
            c.font=Font(name='微软雅黑',size=10,color='25354A')
            c.alignment=Alignment(horizontal='center',vertical='center',wrap_text=True)
            if isinstance(c.value,(int,float)):c.number_format='#,##0.0000'
            if c.value is not None:c.border=Border(bottom=Side(style='hair',color='D5DFE7'))
            if c.row in header_rows:
                c.fill=PatternFill('solid',fgColor='213C56');c.font=Font(name='微软雅黑',size=10,bold=True,color='FFFFFF')
            elif c.row%2==0:c.fill=PatternFill('solid',fgColor='F1F6F8')
    ws.print_area=ws.dimensions


def table_sheet(book,name,rows,fields):
    ws=book.create_sheet(name);ws.append([LABELS.get(k,k) for k in fields])
    for r in rows:ws.append([r.get(k) for k in fields])
    style(ws)
    ws.auto_filter.ref=ws.dimensions
    for i,k in enumerate(fields,1):
        if k.endswith('_yuan'):
            for j in range(2,ws.max_row+1):ws.cell(j,i).number_format='#,##0.00'
    return ws


def add_notes(book,selected,selection,*,startup_present):
    ws=book.create_sheet('口径说明',0)
    ws.append(['事项','说明'])
    notes=[('选择策略',selected),('选择规则',json.dumps(selection,ensure_ascii=False)),
        ('回溯最低含义','retrospective_best按主程序库存修正费用选择，不一定是纯现金最低；现金和库存修正评价分别显示。'),
        ('合同窗口','本日00:10至次日00:10，144段；原计划g与调整后最终量q分别保存。'),
        ('取消结算','取消部分退原费用再收50%违约费。退费列按正数展示；净调整费=增购费−退费＋违约费。'),
        ('原计划购电表','填原g，全天量Σg，全天费Σp·g。'),
        ('调整购电表','填调整后的普通购电总量q，不填差额；全天量Σq，全天购电费填总现金费Σp·g＋调整净费用＋Σ5p·e，紧急费仅计一次。普通结算费另列现金明细。'),
        ('总现金费','原计划费＋增购费−取消退原费＋取消违约费＋紧急费。未成交展望、控制目标和库存软惩罚不计入账单。'),
        ('论文表1','指定10分钟量使用最终普通q；日总普通量Σq；日购电费包含紧急费。另列原计划、净调整与紧急费用以免混淆。'),
        ('自然日储能','按实际interval_start选00:00—24:00；首段来自前一合同，不按window_date整行汇总。'),
        ('首日初始化段','使用startup.csv单列的00:00—00:10共同初始化假设，并入自然日报表；不修改首合同00:10的6000kWh初态。' if startup_present else '未提供startup.csv；首个自然日缺00:00—00:10，相关自然日表不伪造完整值。'),
        ('末尾跨年段','12月31日合同包含次年1月1日00:00—00:10；该段在合同费中只记一次，单列跨年运行，不并入12月31日自然日储能。'),
        ('单位','功率kW，账本电量kWh，费用元。导出程序不再乘1/6处理已经是kWh的购电/充放电量。'),
        ('紧急事件','合并连续e>1e−5kWh的区间，跨自然日拆分；原紧急表仅列合同日期范围内的自然日，次年1月1日尾段只保留在跨年明细；低于阈值量保留在精确汇总中。'),
        ('预测来源','使用用户交付的已插值并端点平均后的光伏；不再平均。生成过程的信息集未独立完整认证，主结果以该输入为条件。'),
        ('范围','更换预测器后需重建场景误差并重评。回溯最低与依据事先规则选定的策略分别标记。')]
    for row in notes:ws.append(row)
    style(ws);ws.column_dimensions['A'].width=22;ws.column_dimensions['B'].width=110
    for i in range(2,ws.max_row+1):ws.row_dimensions[i].height=45
    return ws


def save_verified(book,path):
    expected={(ws.title,c.coordinate):c.value for ws in book for row in ws for c in row if c.value is not None}
    book.save(path)
    wb=load_workbook(path,data_only=False,read_only=True)
    errors=0;checked=0
    try:
        for ws in wb:
            for row in ws:
                for c in row:
                    if c.data_type=='e':raise AssertionError(f'Excel error {ws.title}!{c.coordinate}')
                    if c.value is None:continue
                    want=expected[(ws.title,c.coordinate)]
                    if isinstance(want,(int,float)) and not isinstance(want,bool):
                        if abs(float(c.value)-want)>max(1e-8,abs(want)*1e-12):raise AssertionError('Workbook numeric drift')
                    elif isinstance(want,datetime):
                        if c.value!=want:raise AssertionError('Workbook datetime drift')
                    elif c.value!=want:raise AssertionError(f'Workbook text drift: {want!r} -> {c.value!r}')
                    checked+=1
    finally:wb.close()
    return {'path':str(path),'cells_checked':checked,'excel_errors':errors,'sha256':sha(path)}


def export_result3(template,path,rows,startup,selected,selection):
    book=load_workbook(template)
    contracts={}
    for r in rows:contracts.setdefault(r['window_date'],[]).append(r)
    for name in ('计划购电量','调整购电量','充放电量','紧急购电量'):
        ws=book[name]
        for merged in list(ws.merged_cells.ranges):
            if merged.min_row>=2:ws.unmerge_cells(str(merged))
        if ws.max_row>=2:ws.delete_rows(2,ws.max_row-1)
    daily_financial=[]
    for day,rs in sorted(contracts.items()):
        if len(rs)!=144:raise AssertionError('Incomplete contract in result3')
        zero=datetime.fromisoformat(day)
        if rs[0]['interval_start']!=(zero+timedelta(minutes=10)).isoformat():raise AssertionError('Contract start')
        s=summarize(rs,selected,day);daily_financial.append(s)
        book['计划购电量'].append([zero]+[r['g_kwh'] for r in rs]+[s['g_kwh'],s['plan_cost_yuan']])
        book['调整购电量'].append([zero]+[r['q_kwh'] for r in rs]+[s['q_kwh'],s['cash_cost_yuan']])
    natural=day_groups(startup+rows)
    for day in contracts:
        ws=book['充放电量']
        if day not in natural:
            for k in range(6):ws.append([datetime.fromisoformat(day) if k==0 else None,
                f'{4*k}:00-{4*(k+1)}:00','缺初始段，未编造' if k==0 else None,None,
                '0:00' if k==0 else ('24:00' if k==1 else None),None])
            continue
        rs=natural[day]
        for k in range(6):
            block=rs[k*24:(k+1)*24]
            ws.append([datetime.fromisoformat(day) if k==0 else None,f'{4*k}:00-{4*(k+1)}:00',
                total(block,'charge_kwh'),total(block,'discharge_kwh'),
                '0:00' if k==0 else ('24:00' if k==1 else None),
                rs[0]['soc_start_kwh'] if k==0 else (rs[-1]['soc_end_kwh'] if k==1 else None)])
    all_episodes=episodes(startup+rows)
    e_by_day={}
    for e in all_episodes:e_by_day.setdefault(e['date'],[]).append(e)
    # The original sheet covers only the requested calendar dates. The final
    # next-year interval stays in the contract cash and separate tail ledger.
    for day in sorted(contracts):
        es=e_by_day.get(day,[])
        if es:
            for j,e in enumerate(es):book['紧急购电量'].append([datetime.fromisoformat(day) if j==0 else None,e['label'],e['kwh']])
        else:book['紧急购电量'].append([datetime.fromisoformat(day),'无紧急购电',0.])
    for name in ('计划购电量','调整购电量'):
        ws=book[name];style(ws,width=14)
        ws.column_dimensions['A'].width=16;ws.freeze_panes='B2'
        for row in range(2,ws.max_row+1):
            ws.cell(row,1).number_format='yyyy-mm-dd';ws.cell(row,147).number_format='#,##0.00'
    for name in ('充放电量','紧急购电量'):
        ws=book[name];style(ws,width=22)
        for row in range(2,ws.max_row+1):
            if isinstance(ws.cell(row,1).value,datetime):ws.cell(row,1).number_format='yyyy-mm-dd'
    add_notes(book,selected,selection,startup_present=bool(startup))
    table_sheet(book,'逐合同现金明细',daily_financial,('date',)+SUM_FIELDS+('ordinary_cost_yuan','soc_start_kwh','soc_end_kwh'))
    nat=[summarize(rs,selected,day) for day,rs in natural.items()]
    table_sheet(book,'逐自然日现金明细',nat,('date',)+SUM_FIELDS+('ordinary_cost_yuan','soc_start_kwh','soc_end_kwh'))
    if startup:
        table_sheet(book,'首日初始化假设',startup,('interval_start','interval_end')+SUM_FIELDS+('soc_start_kwh','soc_end_kwh'))
    tail=[r for r in rows if r['interval_start'][:10]>max(contracts)]
    if tail:table_sheet(book,'跨年合同末段',tail,('interval_start','interval_end')+SUM_FIELDS+('soc_start_kwh','soc_end_kwh'))
    return save_verified(book,path),natural


def paper_tables(path,md_path,natural,selected):
    book=Workbook();book.remove(book.active)
    summaries={}
    s1=book.create_sheet('表1_指定购电');s2=book.create_sheet('表2_充放储电')
    heads1=[];heads2=[];md=['# 第三问指定四日论文表格','',f'方案：`{selected}`。日期按00:00—24:00自然日，电量kWh，费用元。',
        '表1购电量是调整后的普通总量q，全天购电费包括紧急费；原计划费与调整净费用另列。数值按全精度汇总后显示。','']
    for date in DATES:
        if date not in natural:raise AssertionError(f'Missing required full calendar day {date}')
        rs=natural[date];s=summarize(rs,selected,date);summaries[date]=s
        for ws,heads,title in ((s1,heads1,'表1 购电量及费用'),(s2,heads2,'表2 实际充放电量')):
            ws.append([f'{date}｜{selected}｜{title}']);heads.extend([ws.max_row,ws.max_row+1])
            ws.merge_cells(start_row=ws.max_row,start_column=1,end_row=ws.max_row,end_column=6)
        s1.append(['时间段','购电量q','时间段','购电量q','时间段','购电量q'])
        md.extend([f'## {date}','', '表1：购电量及费用','', '| 时间段 | 购电量 | 时间段 | 购电量 | 时间段 | 购电量 |','|---|---:|---|---:|---|---:|'])
        for ts in (SLOTS[:3],SLOTS[3:]):
            row=[]
            for t in ts:
                ix=int(t[:2])*6;row.extend([f'{t}—{t[:3]}10',rs[ix]['q_kwh']])
            s1.append(row);md.append('| '+' | '.join(f'{x:.4f}' if isinstance(x,(int,float)) else x for x in row)+' |')
        s1.append(['全天普通购电量',s['q_kwh'],'全天购电费(含紧急)',s['cash_cost_yuan'],'全天紧急量',s['emergency_kwh']])
        s1.append(['原计划费',s['plan_cost_yuan'],'调整净费用',s['adjustment_net_cost_yuan'],'紧急费',s['emergency_cost_yuan']]);s1.append([])
        md.extend(['',f"全天普通购电量 **{s['q_kwh']:.4f} kWh**；全天购电费（含紧急）**{s['cash_cost_yuan']:.2f}元**。",
            f"原计划费{s['plan_cost_yuan']:.2f}元，调整净费用{s['adjustment_net_cost_yuan']:.2f}元，紧急费{s['emergency_cost_yuan']:.2f}元；紧急电量{s['emergency_kwh']:.4f} kWh。",'',
            '表2：实际充放电量','', '| 时间段 | 充电量 | 放电量 | 时间段 | 充电量 | 放电量 |','|---|---:|---:|---|---:|---:|'])
        s2.append(['时间段','充电量','放电量','时间段','充电量','放电量'])
        for i in (0,2,4):
            row=[]
            for j in (i,i+1):
                block=rs[j*24:(j+1)*24]
                row.extend([f'{4*j:02d}:00—{4*(j+1):02d}:00',total(block,'charge_kwh'),total(block,'discharge_kwh')])
            s2.append(row);md.append('| '+' | '.join(f'{x:.4f}' if isinstance(x,(int,float)) else x for x in row)+' |')
        s2.append(['00:00储电量',s['soc_start_kwh'],None,'24:00储电量',s['soc_end_kwh'],None]);s2.append([])
        md.extend(['',f"00:00储电量：**{s['soc_start_kwh']:.4f} kWh**；24:00储电量：**{s['soc_end_kwh']:.4f} kWh**。",''])
    style(s1,header_rows=heads1);style(s2,header_rows=heads2)
    s3=book.create_sheet('表3_连续紧急购电')
    s3.append([f'{selected}｜表3 指定四日紧急购电量(kWh)']);s3.merge_cells('A1:H1')
    s3.append([v for d in DATES for v in (d,None)])
    for col in (1,3,5,7):s3.merge_cells(start_row=2,start_column=col,end_row=2,end_column=col+1)
    s3.append(['时间段','购电量']*4)
    es={date:episodes(natural[date]) for date in DATES}
    md.extend(['## 表3：连续紧急购电','', '| '+' | '.join(d+'时段 | 电量' for d in DATES)+' |','|---|---:|---|---:|---|---:|---|---:|'])
    for i in range(max(1,max(map(len,es.values())))):
        row=[]
        for date in DATES:
            ee=es[date]
            row.extend([ee[i]['label'],ee[i]['kwh']] if i<len(ee) else (['无紧急购电',0.] if not ee and i==0 else [None,None]))
        s3.append(row);md.append('| '+' | '.join('' if x is None else (f'{x:.4f}' if isinstance(x,(int,float)) else x) for x in row)+' |')
    style(s3,header_rows=(1,2,3));s3.page_setup.fitToHeight=1
    table_sheet(book,'四日现金汇总',list(summaries.values()),('date',)+SUM_FIELDS+('ordinary_cost_yuan','soc_start_kwh','soc_end_kwh'))
    md.extend(['','连续事件合并阈值为1e−5 kWh。跨午夜事件拆开；低于阈值量仍保留在每日精确总量中。',
        '四个展示日均由真实时间戳重组：00:00—00:10取前一合同，其余143段取当日合同，不重签、不重复计费。'])
    md_path.write_text('\n'.join(md)+'\n',encoding='utf-8')
    return save_verified(book,path),summaries


def build_reports(results_dir,data_dir,out_dir):
    results_dir=Path(results_dir);data_dir=Path(data_dir);out_dir=Path(out_dir)
    out_dir.mkdir(parents=True,exist_ok=True)
    selection=json.loads((results_dir/'selection.json').read_text(encoding='utf-8'))
    selected=selection['selected_strategy'];retrospective=selection.get('retrospective_best')
    if isinstance(retrospective,dict):retrospective=retrospective.get('strategy',retrospective.get('name'))
    paths=sorted(results_dir.glob('H*/trace.csv'))
    if not paths:raise ValueError('No H*/trace.csv files')
    by_strategy={};startup_by_strategy={};audits=[];summary=[];source_hashes={};monthly=[]
    for path in paths:
        strategy=path.parent.name
        rows=read_trace(path,strategy=strategy)
        if not rows:raise ValueError(f'No rows for {strategy}')
        by_strategy[strategy]=rows
        source_hashes[str(path)]=sha(path)
        audits.append(audit_trace(rows,label=strategy))
        sp=path.parent/'startup.csv'
        if not sp.exists():sp=results_dir/'startup.csv'
        startup=read_trace(sp,strategy=strategy) if sp.exists() else []
        startup_by_strategy[strategy]=startup
        if startup:
            source_hashes[str(sp)]=sha(sp)
            audits.append(audit_trace(startup+rows,label=strategy+' plus common startup'))
        s=summarize(rows,strategy)
        summary_path=path.parent/'summary.json'
        source_summary=json.loads(summary_path.read_text(encoding='utf-8')) if summary_path.exists() else {}
        kappa=source_summary.get('config',{}).get('terminal_weight',min(r['price_yuan_per_kwh'] for r in rows)/.9)
        s['inventory_adjusted_cost_yuan']=s['cash_cost_yuan']-kappa*(s['soc_end_kwh']-s['soc_start_kwh'])
        if summary_path.exists():
            source_hashes[str(summary_path)]=sha(summary_path)
            near(s['cash_cost_yuan'],source_summary['cash_cost_yuan'],'main summary cash',tol=1e-4)
            near(s['inventory_adjusted_cost_yuan'],source_summary['inventory_adjusted_cost_yuan'],'main summary inventory score',tol=1e-4)
        s.update(startup_cost_yuan=total(startup,'cash_cost_yuan') if startup else 0.,
            selected=strategy==selected,retrospective_best=strategy==retrospective)
        s['cash_including_startup_yuan']=s['cash_cost_yuan']+s['startup_cost_yuan']
        last_day=max(r['window_date'] for r in rows)
        s['natural_period_cash_cost_yuan']=math.fsum(r['cash_cost_yuan'] for r in rows if r['interval_start'][:10]<=last_day)+s['startup_cost_yuan']
        summary.append(s)
        groups={}
        for r in rows:groups.setdefault(r['window_date'][:7],[]).append(r)
        monthly.extend(summarize(rs,strategy,month) for month,rs in groups.items())
    if selected not in by_strategy:raise ValueError('Selected strategy ledger unavailable')
    summary.sort(key=lambda s:s['cash_cost_yuan'])
    book=Workbook();book.remove(book.active)
    add_notes(book,selected,selection,startup_present=bool(startup_by_strategy[selected]))
    fields=('strategy','selected','retrospective_best','cash_cost_yuan','inventory_adjusted_cost_yuan','plan_cost_yuan',
        'increase_cost_yuan','refund_yuan','penalty_yuan','adjustment_net_cost_yuan',
        'emergency_cost_yuan','q_kwh','emergency_kwh','soc_end_kwh','startup_cost_yuan','cash_including_startup_yuan','natural_period_cash_cost_yuan')
    ws=table_sheet(book,'八策略费用比较',summary,fields)
    chart=BarChart();chart.title='各组合合同窗口实际现金费';chart.y_axis.title='元';chart.x_axis.title='策略'
    chart.add_data(Reference(ws,min_col=4,min_row=1,max_row=len(summary)+1),titles_from_data=True)
    chart.set_categories(Reference(ws,min_col=1,min_row=2,max_row=len(summary)+1));chart.height=9;chart.width=20
    ws.add_chart(chart,f'A{len(summary)+4}')
    table_sheet(book,'分月合同费用',monthly,('strategy','date','cash_cost_yuan','plan_cost_yuan',
        'adjustment_net_cost_yuan','emergency_cost_yuan','emergency_kwh','soc_end_kwh'))
    comp_verify=save_verified(book,out_dir/'问题三_策略比较.xlsx')
    template=data_dir/'result3_template.xlsx'
    source_hashes[str(template)]=sha(template)
    template_verify,natural=export_result3(template,out_dir/'result3.xlsx',by_strategy[selected],
        startup_by_strategy[selected],selected,selection)
    paper_verify,chosen_days=paper_tables(out_dir/'问题三_指定四日填表.xlsx',out_dir/'问题三_指定四日论文表格.md',natural,selected)
    shutil.copy2(results_dir/selected/'trace.csv',out_dir/f'{selected}_完整逐段账本.csv')
    for source,digest in source_hashes.items():
        if sha(source)!=digest:raise AssertionError('Report export changed an input')
    report={'selected_strategy':selected,'retrospective_best':retrospective,'strategy_count':len(summary),
        'strategy_summaries':summary,'trace_audits':audits,
        'four_day_summary':chosen_days,'workbook_checks':[comp_verify,template_verify,paper_verify],
        'source_sha256':source_hashes,'source_files_unchanged':True,
        'cash_coverage':'main summary is 334 shifted contracts; common first natural-day startup is separately listed and included only in the explicit including-startup column',
        'natural_days_exported':len(natural),'first_day_complete':min(r['window_date'] for r in by_strategy[selected]) in natural}
    (out_dir/'报表与账本核验.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    with (out_dir/'策略费用比较.csv').open('w',newline='',encoding='utf-8-sig') as f:
        writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader();writer.writerows({k:r.get(k) for k in fields} for r in summary)
    (out_dir/'阅读说明.md').write_text(f'# 第三问结果报表\n\n选定策略：**{selected}**；全期回溯最低：**{retrospective}**。\n\n'
        '原result3模板的计划表保存原g及原计划费Σpg，调整表保存最终普通量q；调整表全天购电费填最终总现金费Σpg＋调整净费用＋Σ5pe。'
        '紧急费只计一次，普通结算费与紧急费仍在现金明细中分列。论文四日表1全天购电费同样包含紧急费。\n\n'
        '充放电与紧急事件按自然日时间戳汇总。共同初始化首段单独来自startup.csv；跨年末段单独列出，账单不重复。'
        '所有电量保持原始kWh精度，显示四位小数；费用显示两位小数，显示数相加可能有舍入差。\n\n'
        '报表程序只读取执行账本，不再次求解、不修改计划或电池状态。报表与账本核验.json保存逐段物理/费用检查及工作簿重开核验结果。\n',encoding='utf-8')
    return report


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--results',type=Path,required=True)
    parser.add_argument('--data',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args()
    report=build_reports(args.results,args.data,args.out)
    print(json.dumps({'selected_strategy':report['selected_strategy'],'strategy_count':report['strategy_count'],
        'natural_days_exported':report['natural_days_exported'],'output':str(args.out)},ensure_ascii=False))
