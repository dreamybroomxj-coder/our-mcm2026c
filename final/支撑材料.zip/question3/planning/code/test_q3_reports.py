"""Accounting and natural-calendar-day regression tests for Q3 reporting."""
import copy
from datetime import datetime,timedelta
from pathlib import Path
import tempfile
import unittest

from openpyxl import load_workbook
from q3_reports import (NUMERIC,DATES,audit_trace,day_groups,episodes,export_result3,
    paper_tables,summarize)


def record(a,*,g=100.,q=80.,emergency=0.,soc=6000.):
    up=max(q-g,0.);down=max(g-q,0.)
    r={k:0. for k in NUMERIC}
    r.update(strategy='H0',window_date=(a-timedelta(minutes=10)).date().isoformat(),
        interval_start=a.isoformat(),interval_end=(a+timedelta(minutes=10)).isoformat(),
        forecast_issue_time=a.replace(hour=0,minute=0).isoformat(),price_yuan_per_kwh=1.,
        load_forecast_kw=6*(q+emergency),load_actual_kw=6*(q+emergency),actual_estimated=False,
        g_kwh=g,q_kwh=q,increase_kwh=up,decrease_kwh=down,emergency_kwh=emergency,
        soc_start_kwh=soc,soc_end_kwh=soc,plan_cost_yuan=g,increase_cost_yuan=1.5*up,
        refund_yuan=down,penalty_yuan=.5*down,adjustment_net_cost_yuan=1.5*up-.5*down,
        emergency_cost_yuan=5*emergency,cash_cost_yuan=g+1.5*up-.5*down+5*emergency)
    return r


class ReportTests(unittest.TestCase):
    def test_cancel_twenty_costs_ninety(self):
        r=record(datetime(2025,2,1))
        audit_trace([r],label='cancel')
        self.assertEqual(r['cash_cost_yuan'],90.)

    def test_increase_twenty_costs_one_thirty(self):
        r=record(datetime(2025,2,1),q=120.)
        audit_trace([r],label='increase')
        self.assertEqual(r['cash_cost_yuan'],130.)

    def test_wrong_double_charged_emergency_fails(self):
        r=record(datetime(2025,2,1),emergency=20.)
        r['cash_cost_yuan']+=100.
        with self.assertRaises(AssertionError):audit_trace([r],label='bad')

    def test_natural_day_first_slot_belongs_previous_contract(self):
        zero=datetime(2025,3,20)
        rows=[record(zero+timedelta(minutes=10*i)) for i in range(144)]
        group=day_groups(rows)['2025-03-20']
        self.assertEqual(group[0]['window_date'],'2025-03-19')
        self.assertEqual(group[1]['window_date'],'2025-03-20')
        self.assertEqual(summarize(group,'H0')['q_kwh'],144*80.)

    def test_emergency_episode_split_midnight(self):
        zero=datetime(2025,3,20,23,50)
        rows=[record(zero+timedelta(minutes=10*i),emergency=2.) for i in range(3)]
        event=episodes(rows)
        self.assertEqual(len(event),2)
        self.assertEqual(event[0]['label'],'23:50—24:00')
        self.assertEqual(event[1]['label'],'00:00—00:20')
        self.assertEqual(event[1]['kwh'],4.)

    def test_numerical_dust_does_not_create_event(self):
        rows=[record(datetime(2025,3,20),emergency=1e-8)]
        self.assertEqual(episodes(rows),[])
        self.assertEqual(summarize(rows,'H0')['emergency_kwh'],1e-8)

    def test_template_keeps_original_g_and_adjusted_q(self):
        zero=datetime(2025,2,1)
        rows=[record(zero+timedelta(minutes=10*(i+1))) for i in range(144)]
        template=Path(__file__).resolve().parents[1]/'data/result3_template.xlsx'
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'result3.xlsx'
            export_result3(template,p,rows,[record(zero)],'H0',{'selected_strategy':'H0'})
            w=load_workbook(p,data_only=True)
            self.assertEqual(w['计划购电量']['B2'].value,100.)
            self.assertEqual(w['调整购电量']['B2'].value,80.)
            self.assertEqual(w['调整购电量'].cell(2,147).value,90.*144)
            self.assertEqual(w['充放电量'].max_row,7)
            self.assertEqual(w['充放电量']['F2'].value,6000.)
            w.close()

    def test_template_final_fee_includes_emergency_exactly_once(self):
        zero=datetime(2025,2,1)
        rows=[record(zero+timedelta(minutes=10*(i+1))) for i in range(144)]
        # Include cancellation, increase and nonzero emergency in one ledger.
        rows[0]=record(zero+timedelta(minutes=10),emergency=20.)
        rows[1]=record(zero+timedelta(minutes=20),q=120.,emergency=3.)
        audit_trace(rows,label='export cash')
        template=Path(__file__).resolve().parents[1]/'data/result3_template.xlsx'
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'result3.xlsx'
            export_result3(template,p,rows,[record(zero,emergency=7.)],'H0',{'selected_strategy':'H0'})
            w=load_workbook(p,data_only=True)
            ordinary=144*90.+40.;emergency=5.*23.
            self.assertEqual(w['计划购电量'].cell(2,147).value,144*100.)
            self.assertEqual(w['调整购电量'].cell(2,147).value,ordinary+emergency)
            detail=w['逐合同现金明细']
            headers={c.value:c.column for c in detail[1]}
            self.assertEqual(detail.cell(2,headers['普通购电结算费(元)']).value,ordinary)
            self.assertEqual(detail.cell(2,headers['紧急费(元)']).value,emergency)
            self.assertEqual(detail.cell(2,headers['总现金费(元)']).value,ordinary+emergency)
            # The separate startup emergency belongs to the natural-day view,
            # never to this shifted contract's final fee.
            self.assertNotEqual(w['调整购电量'].cell(2,147).value,ordinary+emergency+35.)
            w.close()

    def test_final_next_year_emergency_only_in_tail_details(self):
        zero=datetime(2025,12,31)
        rows=[record(zero+timedelta(minutes=10*(i+1))) for i in range(144)]
        rows[-2]=record(zero+timedelta(hours=23,minutes=50),emergency=2.)
        rows[-1]=record(datetime(2026,1,1),emergency=3.)
        audit_trace(rows,label='year boundary')
        template=Path(__file__).resolve().parents[1]/'data/result3_template.xlsx'
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'result3.xlsx'
            export_result3(template,p,rows,[record(zero)],'H0',{'selected_strategy':'H0'})
            w=load_workbook(p,data_only=True)
            emergency=w['紧急购电量']
            self.assertEqual(emergency.max_row,2)
            self.assertEqual(emergency['A2'].value,zero)
            self.assertEqual(emergency['B2'].value,'23:50—24:00')
            self.assertEqual(emergency['C2'].value,2.)
            tail=w['跨年合同末段'];headers={c.value:c.column for c in tail[1]}
            self.assertEqual(tail.max_row,2)
            self.assertEqual(tail.cell(2,headers['紧急购电量(kWh)']).value,3.)
            self.assertEqual(tail.cell(2,headers['紧急费(元)']).value,15.)
            # Contract cash includes both sides of midnight, with no duplication.
            self.assertEqual(w['调整购电量'].cell(2,147).value,144*90.+25.)
            w.close()

    def test_all_four_paper_dates_written(self):
        natural={date:[record(datetime.fromisoformat(date)+timedelta(minutes=10*i)) for i in range(144)] for date in DATES}
        with tempfile.TemporaryDirectory() as tmp:
            tmp=Path(tmp)
            check,summaries=paper_tables(tmp/'paper.xlsx',tmp/'paper.md',natural,'H0')
            self.assertEqual(set(summaries),set(DATES))
            self.assertEqual(check['excel_errors'],0)
            txt=(tmp/'paper.md').read_text()
            self.assertTrue(all(date in txt for date in DATES))


if __name__=='__main__':unittest.main()
