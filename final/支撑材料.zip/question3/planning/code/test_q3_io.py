"""Meaningful checks of supplied Q3 data boundaries and vintage causality."""
import copy
import datetime as dt
from pathlib import Path
import tempfile
import unittest

import numpy as np
from openpyxl import load_workbook

from q3_io import (ROOT, ISSUE_HOURS, ISSUE_START, load_inputs, read_pv,
    read_actual_source, audit_linear_reconstruction, interval_header,
    clock_minute, save_bundle, sha)


class InputTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.data=load_inputs()

    def test_confirmed_contract_span(self):
        d=self.data
        self.assertEqual(d['window_start'][0],dt.datetime(2025,2,1,0,10))
        self.assertEqual(d['window_end'][-1],dt.datetime(2026,1,1,0,10))
        self.assertEqual(len(d['dates'])*144,48096)

    def test_vintage_release_mask(self):
        for k,h in enumerate(ISSUE_HOURS):
            s=ISSUE_START[h]
            self.assertTrue(np.isnan(self.data['pv_f'][:,k,:s]).all())
            self.assertTrue(np.isfinite(self.data['pv_f'][:,k,s:]).all())
            self.assertEqual(self.data['pv_valid'][k].sum(),144-s)

    def test_six_am_column_no_time_shift(self):
        self.assertAlmostEqual(self.data['pv_f'][0,1,35],18.16377916666667)
        self.assertEqual(self.data['window_start'][0]+dt.timedelta(minutes=35*10),dt.datetime(2025,2,1,6))

    def test_midnight_prefix_kept_separate(self):
        self.assertEqual(self.data['pv_unused_first_mean_kw'].shape,(334,))
        self.assertEqual(self.data['load_f'].shape,(334,144))
        self.assertEqual(self.data['first_unexecuted_interval']['load_mean_kw'],2537.9711)

    def test_observed_cross_midnight_identity(self):
        for key in ('load','pv'):
            n=self.data[f'{key}_nodes']
            np.testing.assert_array_equal(n[:-1,-1],n[1:,0])
            np.testing.assert_array_equal(self.data[f'{key}_a'],(n[:,:-1]+n[:,1:])/2)

    def test_only_final_actual_estimated(self):
        mask=self.data['actual_estimated']
        self.assertEqual(mask.sum(),1)
        self.assertTrue(mask[-1,-1])

    def test_price_endpoints_averaged_and_rotated_once(self):
        w=load_workbook(ROOT/'data/attachment1.xlsx',read_only=True,data_only=True)
        rows=list(w.active.values);w.close()
        node=np.array([r[1] for r in rows[1:]])
        self.assertAlmostEqual(self.data['price'][0],(node[0]+node[1])/2)
        self.assertAlmostEqual(self.data['price'][-1],(node[-1]+node[0])/2)

    def test_supplied_values_not_reinterpolated(self):
        w=load_workbook(ROOT/'data/pv_forecasts.xlsx',read_only=True,data_only=True)
        for k,h in enumerate(ISSUE_HOURS):
            a=np.array([r[1:] for r in list(w[f'{h:02d}时预报'].values)[1:]])
            if h==0:a=a[:,1:]
            np.testing.assert_array_equal(a,self.data['pv_f'][:,k,ISSUE_START[h]:])
        w.close()

    def test_bad_other_header_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'bad.xlsx'
            w=load_workbook(ROOT/'data/pv_forecasts.xlsx')
            w['06时预报']['B1']='06:00—06:20'
            w.save(p);w.close()
            with self.assertRaises(ValueError):read_pv(p,self.data['dates'])

    def test_linearly_reconstructed_06_does_not_read_0610_actual(self):
        source,_=read_actual_source(ROOT/'data/attachment2.xlsx')
        source['pv'][self.data['dates'][0]][36]+=100000  # 06:10, unavailable at 06:00
        clone={'dates':self.data['dates'],'pv_f':self.data['pv_f'],'metadata':{}}
        audit_linear_reconstruction(clone,ROOT/'data/attachment3.xlsx',source)
        np.testing.assert_array_equal(clone['pv_linear_f'][:,1,:],self.data['pv_linear_f'][:,1,:])

    def test_npz_roundtrip_no_pickle(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=save_bundle(self.data,tmp)
            with np.load(path,allow_pickle=False) as a:
                np.testing.assert_array_equal(a['load_f'],self.data['load_f'])
                np.testing.assert_array_equal(a['pv_f'],self.data['pv_f'])
                self.assertEqual(str(a['dates'][0]),'2025-02-01')

    def test_typo_repairs_are_four_explicit_metadata_entries(self):
        edits=self.data['metadata']['forecast']['header_corrections']
        self.assertEqual(len(edits),4)
        self.assertTrue(all(not e['numerical_values_changed'] for e in edits))
        self.assertTrue(all(e['normalized']=='23:50—次日00:00' for e in edits))


if __name__=='__main__':unittest.main()
