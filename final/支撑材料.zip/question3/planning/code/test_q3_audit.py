"""Independent negative controls for the exported-ledger audit (no optimizer)."""
import csv
import datetime as dt
import json
from pathlib import Path
import tempfile
import unittest

import numpy as np

from q3_audit import REQUIRED, audit_run


class LedgerAuditTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.run = Path(self.tmp.name)
        self.day = dt.date(2025,2,2)
        self.origin = dt.datetime(2025,2,2,0,10)
        self.rows = []
        for i in range(144):
            row = {k:0.0 for k in REQUIRED}
            row.update(strategy='H0_6', window_date=str(self.day),
                interval_start=(self.origin+dt.timedelta(minutes=10*i)).isoformat(),
                interval_end=(self.origin+dt.timedelta(minutes=10*(i+1))).isoformat(),
                forecast_issue_time=dt.datetime(2025,2,2,0 if i<35 else 6).isoformat(),
                price_yuan_per_kwh=1.,load_forecast_kw=600.,load_actual_kw=600.,
                actual_estimated=False,g_kwh=100.,q_kwh=100.,soc_start_kwh=6000.,
                soc_end_kwh=6000.,plan_cost_yuan=100.,cash_cost_yuan=100.)
            self.rows.append(row)
        self.events = {'config':{'trade_hours':[0,6], 'forecast_hours':[0,6], 'start_day':1},
                       'events':[]}
        for h,kind,begin,end in ((0,'dayahead',0,144),(6,'adjust',35,144)):
            self.events['events'].append(dict(kind=kind,window_date=str(self.day),
                decision_at=dt.datetime(2025,2,2,h).isoformat(),forecast_hour=h,
                history_indices=[],draw_indices=[],history_latest_end=None,
                commit_start=begin,commit_end=end,scenarios=1))
        self.inputs = {'dates':[self.day], 'window_end':[self.origin+dt.timedelta(days=1)],
            'load_f':np.full((1,144),600.), 'load_a':np.full((1,144),600.),
            'pv_f':np.zeros((1,4,144)), 'pv_a':np.zeros((1,144)),
            'price':np.ones(144), 'actual_estimated':np.zeros((1,144),bool)}

    def tearDown(self):
        self.tmp.cleanup()

    def audit(self):
        with (self.run/'trace.csv').open('w',newline='',encoding='utf-8') as f:
            writer=csv.DictWriter(f,fieldnames=REQUIRED)
            writer.writeheader();writer.writerows(self.rows)
        (self.run/'event_log.json').write_text(json.dumps(self.events))
        return audit_run(self.run,self.inputs)

    def assertFails(self,result,name):
        self.assertFalse(result['passed'])
        self.assertTrue(any(c['name']==name for c in result['failed_checks']),result['failed_checks'])

    def test_balanced_ledger_passes(self):
        result=self.audit()
        self.assertTrue(result['passed'],result['failed_checks'])
        self.assertEqual(result['sums']['cash_cost_yuan'],14400.)

    def cancel_example(self):
        self.rows[35].update(q_kwh=80.,decrease_kwh=20.,load_actual_kw=480.,
            refund_yuan=20.,penalty_yuan=10.,adjustment_net_cost_yuan=-10.,cash_cost_yuan=90.)
        self.inputs['load_a'][0,35]=480.

    def test_refund_then_half_penalty_is_ninety(self):
        self.cancel_example()
        result=self.audit()
        self.assertTrue(result['passed'],result['failed_checks'])
        self.assertEqual(result['sums']['cash_cost_yuan'],14390.)

    def test_wrong_refund_sign_rejected(self):
        self.cancel_example()
        self.rows[35]['refund_yuan']=-20.
        self.assertFails(self.audit(),'fee_refund_yuan')

    def test_energy_conversion_error_rejected(self):
        self.rows[0]['load_actual_kw']=100.
        self.assertFails(self.audit(),'energy_balance_kwh')

    def test_soc_reset_rejected(self):
        self.rows[72]['soc_start_kwh']=5000.
        self.assertFails(self.audit(),'continuous_soc_kwh')

    def test_emergency_charging_rejected(self):
        self.rows[50].update(charge_kwh=1.,emergency_kwh=1.,soc_end_kwh=6000.9,
                             emergency_cost_yuan=5.,cash_cost_yuan=105.)
        self.assertFails(self.audit(),'emergency_does_not_charge')

    def test_missing_contract_interval_rejected(self):
        self.rows.pop()
        self.assertFails(self.audit(),'window_2025-02-02_144_slots')

    def test_disabled_future_forecast_rejected(self):
        self.rows[35]['forecast_issue_time']='2025-02-02T12:00:00'
        self.assertFails(self.audit(),'execution_uses_enabled_forecast')

    def test_unrealized_history_rejected(self):
        self.events['events'][1].update(history_indices=[0],draw_indices=[0],
            history_latest_end='2025-02-03T00:10:00')
        self.assertFails(self.audit(),'event_1_all_history_released')

    def test_wrong_six_hour_commit_block_rejected(self):
        self.events['events'][1]['commit_end']=71
        self.assertFails(self.audit(),'event_1_commit_block_correct')

    def test_unscheduled_early_adjustment_rejected(self):
        self.rows[10].update(q_kwh=90.,decrease_kwh=10.,emergency_kwh=10.,
            refund_yuan=10.,penalty_yuan=5.,adjustment_net_cost_yuan=-5.,
            emergency_cost_yuan=50.,cash_cost_yuan=145.)
        self.assertFails(self.audit(),'no_adjustment_before_first_enabled_update')


if __name__=='__main__':
    unittest.main()
