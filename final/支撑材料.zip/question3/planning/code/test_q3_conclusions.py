"""Guard report direction and prevent absent experiments becoming conclusions."""
import json
from pathlib import Path
import tempfile
import unittest

from q3_conclusions import build_conclusions, comparison_sentence, savings


class ConclusionTests(unittest.TestCase):
    def test_cheaper_candidate_reports_saving(self):
        self.assertEqual(savings(90,100),{'saving_yuan':10.,'saving_percent':10.})
        self.assertIn('减少10.00元',comparison_sentence('甲','乙',90,100))

    def test_costlier_mpc_is_not_called_better(self):
        text=comparison_sentence('MPC','贪心',2006593.253,2006577.520)
        self.assertIn('增加15.73元',text)
        self.assertNotIn('减少',text)

    def test_equal_and_zero_reference_have_no_false_percentage(self):
        self.assertIn('相同',comparison_sentence('甲','乙',0,0))
        self.assertIsNone(savings(1,0)['saving_percent'])

    def test_missing_artifacts_are_explicitly_pending(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)/'results';root.mkdir()
            out=Path(directory)/'report.md'
            result=build_conclusions(root,out)
            self.assertFalse(result['complete_main'])
            self.assertIsNone(result['selected_strategy'])
            self.assertGreater(len(result['pending']),0)
            self.assertIn('不能据此宣布',out.read_text())
            self.assertEqual(json.loads((out.parent/'analysis_summary.json').read_text())['main'],[])


if __name__=='__main__':
    unittest.main()
