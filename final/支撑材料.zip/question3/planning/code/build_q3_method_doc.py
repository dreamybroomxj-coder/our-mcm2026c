"""Prepare the Chinese reference DOCX and presentation-only Markdown copy.

The source method text stays intact. Pandoc/equations.py performs the final
conversion so all mathematical expressions become native editable OMML.
"""
from pathlib import Path
import re
import json
import hashlib

from docx import Document
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Cm,Pt,RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'notes/docx_build'


def font(style,east='Songti SC',western='Times New Roman',size=11,bold=False):
    style.font.name=western;style.font.size=Pt(size);style.font.bold=bold
    rpr=style.element.get_or_add_rPr();rf=rpr.find(qn('w:rFonts'))
    if rf is None:rf=OxmlElement('w:rFonts');rpr.insert(0,rf)
    for attr,value in [('ascii',western),('hAnsi',western),('eastAsia',east),('cs',western)]:rf.set(qn('w:'+attr),value)


def ensure_style(doc,name,typ=WD_STYLE_TYPE.PARAGRAPH):
    return doc.styles[name] if name in doc.styles else doc.styles.add_style(name,typ)


def reference(path):
    doc=Document();section=doc.sections[0]
    section.page_width=Cm(21);section.page_height=Cm(29.7)
    section.top_margin=Cm(1.9);section.bottom_margin=Cm(1.8)
    section.left_margin=section.right_margin=Cm(2.0)
    section.header_distance=Cm(.75);section.footer_distance=Cm(.8)
    for name in ('Normal','Body Text','First Paragraph','Compact'):
        s=ensure_style(doc,name);font(s)
        s.paragraph_format.line_spacing=1.25;s.paragraph_format.space_after=Pt(5)
        s.paragraph_format.widow_control=True
        s.paragraph_format.alignment=WD_ALIGN_PARAGRAPH.JUSTIFY
    for name,size in [('Title',21),('Subtitle',11),('Heading 1',14),('Heading 2',12)]:
        s=ensure_style(doc,name);font(s,east='Heiti SC',size=size,bold=name!='Subtitle')
        s.font.color.rgb=RGBColor.from_string('18384A' if name!='Subtitle' else '63717A')
        s.paragraph_format.space_before=Pt(13 if name.startswith('Heading') else 6)
        s.paragraph_format.space_after=Pt(7)
        s.paragraph_format.keep_with_next=True
        s.paragraph_format.line_spacing=1.12
        if name in ('Title','Subtitle'):s.paragraph_format.alignment=WD_ALIGN_PARAGRAPH.CENTER
    for name in ('Source Code','Verbatim Char'):
        s=ensure_style(doc,name,WD_STYLE_TYPE.CHARACTER if name=='Verbatim Char' else WD_STYLE_TYPE.PARAGRAPH)
        font(s,western='Courier New',size=8.5)
        if name=='Source Code':
            s.paragraph_format.line_spacing=1.05;s.paragraph_format.space_after=Pt(6)
            s.paragraph_format.left_indent=Cm(.15);s.paragraph_format.right_indent=Cm(.15)
    for name in ('Hyperlink','Footnote Text'):
        if name in doc.styles:font(doc.styles[name],size=10)
    table=ensure_style(doc,'Table',WD_STYLE_TYPE.TABLE)
    font(table,size=9.5)
    ppr=OxmlElement('w:pPr')
    spacing=OxmlElement('w:spacing');spacing.set(qn('w:after'),'25');spacing.set(qn('w:line'),'250');spacing.set(qn('w:lineRule'),'auto');ppr.append(spacing)
    table.element.insert(list(table.element).index(table.element.find(qn('w:rPr'))),ppr)
    tblpr=OxmlElement('w:tblPr')
    borders=OxmlElement('w:tblBorders')
    for name,val,sz,color in [('top','single','10','264B61'),('left','nil','0','FFFFFF'),
        ('bottom','single','10','264B61'),('right','nil','0','FFFFFF'),
        ('insideH','single','3','CBD7DD'),('insideV','nil','0','FFFFFF')]:
        b=OxmlElement('w:'+name);b.set(qn('w:val'),val);b.set(qn('w:sz'),sz);b.set(qn('w:color'),color);borders.append(b)
    tblpr.append(borders)
    margins=OxmlElement('w:tblCellMar')
    for name,val in [('top','65'),('left','70'),('bottom','65'),('right','70')]:
        n=OxmlElement('w:'+name);n.set(qn('w:w'),val);n.set(qn('w:type'),'dxa');margins.append(n)
    tblpr.append(margins);table.element.append(tblpr)
    trpr=OxmlElement('w:trPr');trpr.append(OxmlElement('w:cantSplit'));table.element.append(trpr)
    first=OxmlElement('w:tblStylePr');first.set(qn('w:type'),'firstRow')
    rpr=OxmlElement('w:rPr');rpr.append(OxmlElement('w:b'));first.append(rpr)
    tcpr=OxmlElement('w:tcPr');shd=OxmlElement('w:shd');shd.set(qn('w:fill'),'EAF0F4');shd.set(qn('w:val'),'clear');tcpr.append(shd);first.append(tcpr)
    table.element.append(first)
    header=section.header.paragraphs[0]
    header.alignment=WD_ALIGN_PARAGRAPH.RIGHT
    run=header.add_run('第三问  /  模型与操作说明');run.font.name='Heiti SC';run.font.size=Pt(9);run.font.color.rgb=RGBColor.from_string('687C88')
    footer=section.footer.paragraphs[0];footer.alignment=WD_ALIGN_PARAGRAPH.CENTER
    r=footer.add_run('— ');r.font.size=Pt(9)
    field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');footer._p.append(field)
    r=footer.add_run(' —');r.font.size=Pt(9)
    settings=doc.settings.element
    zoom=settings.find(qn('w:zoom'))
    if zoom is None:zoom=OxmlElement('w:zoom');settings.insert(0,zoom)
    zoom.set(qn('w:percent'),'100')
    math=settings.find(qn('m:mathPr'))
    if math is None:math=OxmlElement('m:mathPr');settings.append(math)
    mf=math.find(qn('m:mathFont'))
    if mf is None:mf=OxmlElement('m:mathFont');math.append(mf)
    mf.set(qn('m:val'),'STIX Two Math')
    doc.add_paragraph('参考模板占位：最终转换仅继承样式，不包含此行。')
    doc.save(path)


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    src=ROOT/'notes/问题三_模型与复现说明.md'
    text=src.read_text(encoding='utf-8')
    text=text.split('\n',1)[1].lstrip()
    text=re.sub(r'^### ', '## ',text,flags=re.M)
    # Main headings were ##; avoid shifting the just-created subheadings by
    # matching their original numbered section pattern only.
    text=re.sub(r'^## (\d+\. [^\n]+)$',r'# \1',text,flags=re.M)
    text=text.replace(r'\[','$$').replace(r'\]','$$').replace(r'\(','$').replace(r'\)','$')
    text=text.replace('I_{D,t}=[D\\ 00{:}10+10t\\text{分钟},\\ D\\ 00{:}10+10(t+1)\\text{分钟}).',
        'I_{D,t}=[\\tau_D+t\\Delta t,\\tau_D+(t+1)\\Delta t),\\quad \\Delta t=10\\mathrm{min}.')
    text=text.replace('因此0、6、12、18时版本', '式中$\\tau_D$表示D日00:10。因此0、6、12、18时版本')
    # Long displays are split without changing any coefficients or equations.
    old=r'\boxed{J=\sum_t\left[p_tg_t+1.5p_ta_t-p_tb_t+0.5p_tb_t+5p_te_t\right]'+'\n'+r'=\sum_t\left[p_tg_t+1.5p_ta_t-0.5p_tb_t+5p_te_t\right].}'
    new=r'J=\sum_t[p_tg_t+1.5p_ta_t-p_tb_t+0.5p_tb_t+5p_te_t].'+'\n$$\n\n$$\n'+r'J=\sum_t[p_tg_t+1.5p_ta_t-0.5p_tb_t+5p_te_t].'
    text=text.replace(old,new)
    text=text.replace(r'0\le c_{t,s}\le\frac{5000}{6}u_{t,s},\qquad'+'\n'+r'0\le d_{t,s}\le\frac{5000}{6}(1-u_{t,s}),\qquad u_{t,s}\in\{0,1\},',
        r'0\le c_{t,s}\le\frac{5000}{6}u_{t,s}.'+'\n$$\n\n$$\n'+r'0\le d_{t,s}\le\frac{5000}{6}(1-u_{t,s}),\quad u_{t,s}\in\{0,1\}.')
    text=text.replace(r'$\text{历史窗口结束时刻}\le\text{当前决策时刻}$','“历史窗口结束时刻不晚于当前决策时刻”')
    # Explicit example label prevents the command from being read as a winner.
    text=text.replace('局部因果执行对照的命令如下，目录H0_6_12_18可换为实际要检查的主策略：',
        '以下H0_6_12_18为操作示例，最终选择结果已另册提供；使用时将目录替换为实际要检查的主策略：')
    text=text.replace('q3_sensitivity.py`预设的有界设计','q3_sensitivity.py`预设的有界设计')
    # Pandoc honors proportional pipe-table widths when the separator exceeds
    # its default text width; allocate room to meanings and long descriptions.
    text=text.replace('| 代码 | 启用时刻 | 日内正式调整块 |\n|---|---|---|',
        '| 代码 | 启用时刻 | 日内正式调整块 |\n|------------------|----------------|----------------------------------------------------|')
    text=text.replace('| 符号 | 含义 | 单位 |\n|---|---|---|',
        '| 符号 | 含义 | 单位 |\n|--------------|--------------------------------------------------------------|----------|')
    text=text.replace('| 参数 | 主设置 | 性质 |\n|---|---:|---|',
        '| 参数 | 主设置 | 性质 |\n|--------------------------|-------------------------------------------|----------------------------|')
    text=text.replace('| 试验 | 日期范围与初态 | 变体 | 回答的问题 |\n|---|---|---|---|',
        '| 试验 | 日期范围与初态 | 变体 | 回答的问题 |\n|----------------|-----------------------|--------------------------------|------------------------------|')
    text=text.replace('# 14. 资料来源',
        '```{=openxml}\n<w:p><w:r><w:br w:type="page"/></w:r></w:p>\n```\n\n# 14. 资料来源')
    # Narrower operational code for A4. Each continuation is runnable shell.
    lines=text.splitlines();code=False;wrapped=[]
    for line in lines:
        if line.startswith('```'):code=not code;wrapped.append(line);continue
        if code and line.startswith('python ') and len(line)>86:
            tokens=line.split(' ');parts=[];cur=''
            for token in tokens:
                if len(cur)+len(token)+1>76 and cur:
                    parts.append(cur+' \\');cur='  '+token
                else:cur+=((' ' if cur else '')+token)
            if cur:parts.append(cur)
            wrapped.extend(parts)
        else:wrapped.append(line)
    meta='---\ntitle: "第三问：模型与操作说明"\nsubtitle: "方法章节 · 交易时序 · 可复现验证｜费用及选型结果另册"\n---\n\n'
    rendered=meta+'\n'.join(wrapped)+'\n'
    (OUT/'方法说明_排版源.md').write_text(rendered,encoding='utf-8')
    reference(OUT/'中文A4参考模板.docx')
    manifest={'original_markdown':str(src),'original_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),
        'presentation_markdown':str(OUT/'方法说明_排版源.md'),
        'changes':['reference styles, heading levels and page geometry','equivalent display line breaks',
                   'short equivalent interval notation with its definition','shell continuation wrapping',
                   'explicit H0_6_12_18 example label','proportional table widths and non-splitting table rows'],
        'math_method_changed':False,'document_scope':'Q3 methods chapter, not a complete contest paper',
        'fonts':{'body_east_asian':'Songti SC','headings_east_asian':'Heiti SC','latin':'Times New Roman','math':'STIX Two Math'}}
    (OUT/'排版来源.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    print(str(OUT/'方法说明_排版源.md'))


if __name__=='__main__':main()
