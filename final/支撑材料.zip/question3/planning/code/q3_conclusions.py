"""Build Chinese conclusions from completed Q3 artifacts, never assumed wins.

The report distinguishes development-selected policies, retrospective rankings,
local algorithm comparisons, and fixed-contract execution sensitivities.
Missing experiments remain explicitly pending; this file does not optimize.
"""
from __future__ import annotations

import argparse
import csv
from collections import defaultdict
import json
from pathlib import Path


def read_json(path, default=None):
    path=Path(path)
    return json.loads(path.read_text(encoding='utf-8')) if path.exists() else default


def money(x):
    return '待完成' if x is None else f'{float(x):,.2f}'


def number(x,places=3):
    return '待完成' if x is None else f'{float(x):,.{places}f}'


def schedule(row):
    hours=row.get('config',{}).get('trade_hours')
    return '、'.join(f'{int(h):02d}:00' for h in hours) if hours else row['strategy']


def savings(candidate,base):
    delta=float(base)-float(candidate)
    return {'saving_yuan':delta,'saving_percent':None if abs(base)<1e-12 else 100*delta/float(base)}


def comparison_sentence(candidate_label,base_label,candidate,base):
    result=savings(candidate,base)
    delta=result['saving_yuan'];pct=result['saving_percent']
    if abs(delta)<1e-5:
        return f'{candidate_label}与{base_label}现金费用在0.00001元容差内相同。'
    word='减少' if delta>0 else '增加'
    tail='' if pct is None else f'（{abs(pct):.6f}%）'
    return f'{candidate_label}相对{base_label}，现金费用{word}{money(abs(delta))}元{tail}。'


def completed_rows(folder):
    folder=Path(folder)
    obj=read_json(folder/'comparison.json')
    if isinstance(obj,list):
        return [x for x in obj if x.get('complete')]
    rows=[]
    for path in sorted(folder.glob('*/summary.json')):
        row=read_json(path)
        if row.get('complete'):
            rows.append(row)
    return rows


def daily_rows(folder):
    path=Path(folder)/'daily.csv'
    if not path.exists():
        return []
    with path.open(encoding='utf-8-sig',newline='') as stream:
        return list(csv.DictReader(stream))


def table(headers,rows):
    return ['| '+' | '.join(headers)+' |','| '+' | '.join('---' for _ in headers)+' |',
            *['| '+' | '.join(str(x) for x in row)+' |' for row in rows],'']


def _first_json(paths):
    for path in paths:
        if Path(path).exists():
            return read_json(path),str(Path(path))
    return None,None


def _alg_table(rows):
    labels={'stochastic_mpc':'场景MILP＋MPC','deterministic_mpc':'点预测MILP＋MPC',
            'stochastic_greedy':'场景MILP＋贪心','scenes_4':'4场景','scenes_8':'8场景',
            'scenes_16':'16场景','initial_1200':'初态1200','initial_10800':'初态10800',
            'linear_reconstruction':'直接线性复原PV'}
    return table(['方案','合同数','现金费用（元）','库存修正指标（元）','紧急电量（kWh）',
                  '初态→末态（kWh）','总求解秒数'],
        [[labels.get(r['strategy'],r['strategy'].replace('seed_','种子')),r['windows'],money(r['cash_cost_yuan']),money(r['inventory_adjusted_cost_yuan']),
          number(r['emergency_kwh']),f"{number(r['soc_start_kwh'])}→{number(r['soc_end_kwh'])}",
          number(r.get('solver',{}).get('seconds'))] for r in rows])


def build_conclusions(results_root,out_md):
    root=Path(results_root);out=Path(out_md)
    main=root/'main'
    rows=completed_rows(main)
    by_name={r['strategy']:r for r in rows}
    selection=read_json(main/'selection.json',{})
    selected=selection.get('selected_strategy')
    hindsight=selection.get('retrospective_best')
    complete=len(rows)==8 and all(r.get('windows')==334 for r in rows)
    development={r['strategy']:r for r in selection.get('development',[])}
    tests={r['strategy']:r for r in selection.get('test',[])}
    analysis={'complete_main':complete,'completed_main_strategies':len(rows),
        'selected_strategy':selected,'retrospective_best':hindsight,
        'main':rows,'selection':selection,'pending':[],
        'cash_basis':'334 D00:10–D+1 00:10 contract windows; startup is separate; terminal soft penalty excluded',
        'refund_convention':'positive refund amount is subtracted; 50% cancellation penalty is added',
        'execution_assumption':'current ten-minute actual mean as fast-feedback approximation',
        'scope_limitations':['supplied forecast generator causality not independently certified',
            'rolling two-stage scenario recourse is not a strict nonanticipative multistage optimum',
            'local sensitivity results do not establish global or annual dominance']}
    lines=['# 第三问计算结论与模型评价','']
    if not complete:
        lines += [f'**阶段性文件：主计算目前完成{len(rows)}/8个组合，不能据此宣布完整年度最优组合。**','']
        analysis['pending'].append('全部8组334合同主计算及开发选择记录')
    elif selected in by_name:
        lines += [f'按预先规定的开发期选择规则，选定组合为 **{schedule(by_name[selected])}**。'
                  '下面分别报告该组合的后续测试结果和八个组合的全年回溯比较；两者不混为一谈。','']
    lines += ['主实验统一使用用户提供的区间光伏预测与第二问负载预测，比较0点必选、6/12/18点可选的8个组合。'
              '每个组合从共同6000 kWh初态独立连续运行，之后不每天重置。合同从本日00:10到次日00:10，功率只乘1/6转为电量一次。',
              '', '## 一、八个组合的实际费用','']
    lines += table(['组合','合同数','合同现金总费（元）','初态（kWh）','末态（kWh）','紧急电（kWh）','开发期指标（元）','测试期现金（元）'],
        [[schedule(r),r['windows'],money(r['cash_cost_yuan']),number(r['soc_start_kwh']),number(r['soc_end_kwh']),
          number(r['emergency_kwh']),money(development.get(r['strategy'],{}).get('score')),
          money(tests.get(r['strategy'],{}).get('cash_cost_yuan'))]
         for r in sorted(rows,key=lambda r:(len(r['config']['trade_hours']),r['config']['trade_hours']))])
    lines += ['现金费用=原计划费+1.5倍增购费−取消退款+50%违约费+5倍紧急费。开发指标另用统一库存价值修正，'
              '用于避免靠消耗更多库存获得不公平优势；它不是另一个电费账单。表中合同总费不包含共同启动段，也不包含库存软惩罚。','']
    if selected in by_name:
        s=by_name[selected]
        lines += [f"选定组合的原计划费为{money(s['original_plan_cost_yuan'])}元，调整净费为{money(s['net_adjustment_cost_yuan'])}元，"
                  f"紧急费为{money(s['emergency_cost_yuan'])}元。共同启动段另计{money(s.get('startup_cash_cost_yuan'))}元；"
                  f"按自然日2月1日00:00至次年1月1日00:00汇总为{money(s.get('natural_period_cash_cost_yuan'))}元。",'']
        if 'H0' in by_name:
            b=by_name['H0']
            analysis['selected_vs_H0']=savings(s['cash_cost_yuan'],b['cash_cost_yuan'])
            lines += [comparison_sentence('选定组合','只启用0点',s['cash_cost_yuan'],b['cash_cost_yuan'])+
                      f" 两者末态分别为{number(s['soc_end_kwh'])}和{number(b['soc_end_kwh'])} kWh。",'']
            if selected in tests and 'H0' in tests:
                st,bt=tests[selected],tests['H0']
                analysis['selected_test_vs_H0']=savings(st['cash_cost_yuan'],bt['cash_cost_yuan'])
                lines += [f"冻结后的测试期分别含{st['windows']}和{bt['windows']}个完整合同。"+
                          comparison_sentence('选定组合','只启用0点',st['cash_cost_yuan'],bt['cash_cost_yuan']),'']
    lines += ['## 二、开发选择与全年回溯排名','',
        '主设置在比较前预设：最多8场景、最近28个已兑现历史合同、至少14条历史才启用场景、固定随机种子20260912。'
        '场景误差按发行版本配对，不额外叠加分位数裕量。开发窗口为2月17–23日，2月25日零点前冻结组合；'
        '2月24日合同末段尚未在25日零点兑现，因此不进入选择。后续测试从2月25日开始。','']
    if selected in by_name and hindsight in by_name:
        relation='相同' if selected==hindsight else '不同'
        lines += [f"开发期选定{schedule(by_name[selected])}，全年回溯库存修正指标最低为{schedule(by_name[hindsight])}，两者{relation}。"
                  '后者使用了全年结果，只能称回溯最佳，不能替换开发选择后继续冒称完全独立测试。','']
        cash_best=min(rows,key=lambda r:r['cash_cost_yuan'])
        analysis['retrospective_cash_best']=cash_best['strategy']
        lines += [f"若只按未修正的现金总费排序，最低组合是{schedule(cash_best)}，费用{money(cash_best['cash_cost_yuan'])}元。",'']
    else:
        lines += ['开发选择或完整回溯记录尚未齐备，本节暂不宣布胜出组合。','']

    monthly={}
    for r in rows:
        sums=defaultdict(float)
        for row in daily_rows(main/r['strategy']):
            sums[row['window_date'][:7]]+=float(row['cash_cost_yuan'])
        monthly[r['strategy']]=dict(sums)
    analysis['monthly_contract_cash']=monthly
    if complete and monthly and all(monthly.values()):
        months=sorted(set.intersection(*(set(x) for x in monthly.values())))
        winners={month:min(rows,key=lambda r:monthly[r['strategy']][month])['strategy'] for month in months}
        analysis['monthly_winner']=winners
        lines += ['## 三、分月稳定性','']
        lines += table(['合同月份','当月现金最低组合','最低费用（元）','开发选定费用（元）','选定相对H0节省（元）'],
            [[month,schedule(by_name[winners[month]]),money(monthly[winners[month]][month]),
              money(monthly.get(selected,{}).get(month)),
              money(monthly['H0'][month]-monthly[selected][month]) if selected in monthly and 'H0' in monthly else '待完成']
             for month in months])
        if selected in monthly and 'H0' in monthly:
            diff=[monthly['H0'][m]-monthly[selected][m] for m in months]
            lower=sum(d>1e-5 for d in diff);higher=sum(d< -1e-5 for d in diff);tie=len(diff)-lower-higher
            analysis['monthly_selected_vs_H0_counts']={'lower':lower,'higher':higher,'tie':tie}
            lines += [f'选定组合相对H0，在{lower}个月费用较低、{higher}个月较高、{tie}个月相同。'
                      '这里按合同起始日期所属月汇总，不把单个展示日当作全年选型依据。','']

    lines += ['## 四、新预报本身的价值','']
    old=read_json(root/'ablation'/'old_forecast_all_trades'/'summary.json')
    rich=by_name.get('H0_6_12_18')
    if old and old.get('complete') and rich and old['windows']==rich['windows']:
        analysis['new_forecast_ablation']={'old':old,'new':rich,
            **savings(rich['cash_cost_yuan'],old['cash_cost_yuan'])}
        lines += table(['PV信息','调单时刻','现金费用（元）','紧急电量（kWh）','期末库存（kWh）'],
            [['保持0点版本','0、6、12、18',money(old['cash_cost_yuan']),number(old['emergency_kwh']),number(old['soc_end_kwh'])],
             ['使用当时新版本','0、6、12、18',money(rich['cash_cost_yuan']),number(rich['emergency_kwh']),number(rich['soc_end_kwh'])]])
        lines += [comparison_sentence('使用新版光伏','相同调单权限但只用0点版',rich['cash_cost_yuan'],old['cash_cost_yuan'])+
                  ' 这是同权限的信息消融，分别随各自真实库存重新规划，并非强制整年使用同一份g。','']
    else:
        analysis['pending'].append('同权限旧预报全年对照')
        lines += ['相同调单权限、仅保留0点PV版本的全年对照尚未完成，暂不量化信息带来的费用收益。','']
    forecast=read_json(root.parent/'notes'/'forecast_comparison.json')
    if isinstance(forecast,list):
        analysis['forecast_accuracy_comparison']=forecast
        lines += table(['更新时刻','同目标区间数/日','旧版MAE（kW）','新版MAE（kW）','旧版RMSE（kW）','新版RMSE（kW）'],
            [[f"{r['hour']:02d}:00",r['intervals'],number(r['old_mae_kw']),number(r['new_mae_kw']),
              number(r['old_rmse_kw']),number(r['new_rmse_kw'])] for r in forecast])
        lines += ['预测误差比较按同一时刻以后的同一批目标区间进行。MAE/RMSE改善不自动等于费用改善，仍需上面的运行费用验证。'
                  '18点后的剩余光伏整体较少，其绝对误差不能直接与中午版本横向判断信息价值。','']

    algorithms=completed_rows(root/'sensitivity'/'algorithms')
    alg={r['strategy']:r for r in algorithms}
    analysis['algorithm_sensitivity']=alg
    lines += ['## 五、场景模型和MPC是否都值得保留','']
    target_names=('stochastic_mpc','deterministic_mpc','stochastic_greedy')
    present=[alg[n] for n in target_names if n in alg]
    if present:
        lines += _alg_table(present)
        lines += ['这组试验固定丰富组合0/6/12/18，自2月25日开始各自连续回放60个合同，共用局部初态和终点规则。'
                  '它没有强制三组原计划g相同：不同控制动作会改变后续真实状态，继而影响下一次订电。'
                  '因此它是完整算法策略的短窗比较，不能把差额全称为纯MPC在同g下的因果收益，也不能把60窗费用冒称全年费用。','']
    else:
        analysis['pending'].append('60窗算法对照')
        lines += ['预定60窗算法对照尚未产生完整结果。','']
    if all(n in alg for n in target_names):
        st,det,gr=(alg[n] for n in target_names)
        analysis['stochastic_vs_deterministic']=savings(st['cash_cost_yuan'],det['cash_cost_yuan'])
        analysis['mpc_vs_greedy']=savings(st['cash_cost_yuan'],gr['cash_cost_yuan'])
        lines += [comparison_sentence('场景MILP+MPC','点预测MILP+MPC',st['cash_cost_yuan'],det['cash_cost_yuan']),
                  '',comparison_sentence('场景MILP+MPC','场景MILP+贪心反馈',st['cash_cost_yuan'],gr['cash_cost_yuan']),'']
        if st['cash_cost_yuan']>=gr['cash_cost_yuan']-1e-5:
            lines += ['本段数据没有证明MPC比贪心更省电费。若差额很小，应把两者视为接近，并考虑贪心的简洁与运行时间；'
                      '保留MPC主要是为了远期库存与调单机会的可解释规划能力，不能用此前推荐代替当前证据。','']
        else:
            lines += ['MPC在本段完整策略比较中费用更低；是否全年仍成立，需要更长或跨季对照，不能从局部试验直接推广。','']
    counterfactuals=read_json(root.parent/'notes'/'control_difference_counterfactuals.json')
    if isinstance(counterfactuals,list) and counterfactuals:
        analysis['controller_difference_counterfactual_count']=len(counterfactuals)
        lines += [f'另对短窗中{len(counterfactuals)}个“段初状态相同但首步放电开始分歧”的时点进行了严格重解与强制贪心反事实。'
                  '该审查区分预测目标上的库存取舍和实际兑现后的现金差异；不能把预测内更优直接解释成实际必然更省。'
                  '详细数字和原轨迹校验见《控制器差异审查》。','']
    annual_greedy=read_json(root/'ablation'/'all_trades_greedy'/'summary.json')
    if annual_greedy and annual_greedy.get('complete') and rich and annual_greedy['windows']==rich['windows']==334:
        comparison=savings(rich['cash_cost_yuan'],annual_greedy['cash_cost_yuan'])
        comparison.update(mpc=rich,greedy=annual_greedy,
                          emergency_difference_mpc_minus_greedy_kwh=rich['emergency_kwh']-annual_greedy['emergency_kwh'],
                          final_inventory_difference_mpc_minus_greedy_kwh=rich['soc_end_kwh']-annual_greedy['soc_end_kwh'])
        analysis['annual_mpc_vs_greedy']=comparison
        lines += ['**全部时刻启用下的全年控制器补充对照：**','']
        lines += table(['控制器','合同数','现金费（元）','库存修正指标（元）','紧急电（kWh）','初态→末态（kWh）','总求解秒数'],
            [[name,r['windows'],money(r['cash_cost_yuan']),money(r['inventory_adjusted_cost_yuan']),
              number(r['emergency_kwh']),f"{number(r['soc_start_kwh'])}→{number(r['soc_end_kwh'])}",
              number(r.get('solver',{}).get('seconds'))]
             for name,r in [('场景MILP＋MPC',rich),('场景MILP＋贪心',annual_greedy)]])
        lines += [comparison_sentence('全年MPC策略','全年贪心策略',rich['cash_cost_yuan'],annual_greedy['cash_cost_yuan']),
                  '',f"MPC减贪心的紧急电量差为{number(comparison['emergency_difference_mpc_minus_greedy_kwh'])} kWh，"
                  f"期末库存差为{number(comparison['final_inventory_difference_mpc_minus_greedy_kwh'])} kWh。"
                  '两组都从6000开始，但各自按真实状态重新签订后续订单，因此全年比较仍是完整闭环策略差异，不是强制同g的纯电池控制实验。','']
        percent=comparison['saving_percent']
        if percent is not None and abs(percent)<.1:
            lines += ['两者现金相对差不到千分之一，现有证据不足以宣称某控制器有明显经济优势。'
                      '应同时考虑计算时间、库存和控制解释需要，不把微小差额夸大为模型压倒性优势，也没有进行统计显著性检验。','']
        else:
            lines += ['上述数值描述本次全年回放的实际差异，尚不能称为对其他年份、预测器或误差分布的普遍优势。','']
        lines += ['全年贪心是控制器追加验证，不重写此前开发期已经冻结的预报组合选择；如果据这次全年对照更换最终控制器，应明确属于追加回溯选型。','']
    else:
        analysis['pending'].append('全启用组合的334窗贪心/MPC补充对照')
        lines += ['全启用组合的334窗贪心/MPC补充对照尚未齐备，暂不把60窗近乎持平的结论扩大为全年结论。','']
    if 'linear_reconstruction' in alg and 'stochastic_mpc' in alg:
        alt=alg['linear_reconstruction'];base=alg['stochastic_mpc']
        analysis['pv_reconstruction_sensitivity']=savings(alt['cash_cost_yuan'],base['cash_cost_yuan'])
        lines += ['用户交付文件与同发行版本直接线性复原不完全相同，因此另做PV输入来源敏感性。'+
            comparison_sentence('直接线性复原PV','用户交付PV',alt['cash_cost_yuan'],base['cash_cost_yuan'])+
            ' 该对照保持其他条件一致，不擅自替换主输入，也不能仅凭费用差异认定哪份预测生成过程有未来信息泄漏。','']

    dev_rows=completed_rows(root/'sensitivity'/'development');dev={r['strategy']:r for r in dev_rows}
    analysis['development_sensitivity']=dev
    lines += ['## 六、场景数、随机种子与初态','']
    scenes=[dev[n] for n in ('scenes_4','scenes_8','scenes_16') if n in dev]
    if scenes:
        lines += _alg_table(scenes)
        lines += ['场景数试验只用2月17–23日七个开发合同，三组初态与末端规则一致。表中4/8/16为请求上限，'
                  '有效历史不足时使用可用数量；不重复同一轨迹伪造更多独立信息。时间为签单、MPC和精修合计，受并发负载影响，不是隔离硬件基准。','']
        if 'scenes_8' in dev:
            for n in ('scenes_4','scenes_16'):
                if n in dev:
                    lines += [comparison_sentence(n.replace('scenes_','')+'场景','8场景',dev[n]['cash_cost_yuan'],dev['scenes_8']['cash_cost_yuan'])+
                              f" 总求解时间分别为{number(dev[n]['solver']['seconds'])}和{number(dev['scenes_8']['solver']['seconds'])}秒。",'']
    else:
        analysis['pending'].append('场景数开发敏感性');lines+=['场景数敏感性尚未完成。','']
    seeds=[r for r in dev_rows if r['strategy'].startswith('seed_')]
    if 'scenes_8' in dev and seeds:
        sample=[dev['scenes_8'],*seeds]
        lines += _alg_table(sample)
        cash=[r['cash_cost_yuan'] for r in sample]
        span=max(cash)-min(cash)
        analysis['seed_cash_range_yuan']=span
        lines += [f'同为8场景的{len(sample)}个种子，七窗现金费用跨度为{money(span)}元。'
                  '该结果用于检验抽样稳定性，没有按事后费用挑种子；它不证明全年结果对所有随机种子不敏感。','']
    initial=[alg[n] for n in ('initial_1200','stochastic_mpc','initial_10800') if n in alg]
    if len(initial)==3:
        lines += _alg_table(initial)
        analysis['initial_soc_sensitivity']=initial
        lines += ['三种初态各自独立运行相同60窗，期末规则相同；不能直接把全年主轨迹截前60窗替代局部6000基线。'
                  '比较初态时应同时看现金与库存修正指标。这只检查同一丰富组合的初态影响，没有证明所有初态下八组合冠军不变。','']
    else:
        analysis['pending'].append('三初态60窗对照');lines+=['三种初态的完整匹配对照尚未齐备。','']

    boundaries,bpath=_first_json([root/'boundaries'/'summary.json',root/'sensitivity'/'boundaries'/'summary.json'])
    lines += ['## 七、首尾边界与执行近似','']
    if boundaries:
        analysis['boundaries']=boundaries
        starts=boundaries.get('startup',[]);final=boundaries.get('final_endpoint',[])
        if starts:
            lines += table(['启动段负载补法','预测负载（kW）','启动段费用（元）','相对持平变化（元）'],
                [[r['method'],number(r['load_forecast_estimated_kw']),money(r['cash_cost_yuan']),money(r['change_from_hold_yuan'])] for r in starts])
            lines += ['启动段电池静置，因而这些补法不改变已确认的首合同00:10初态，也不改变其后的任何订单；差额是八组相同的共同边界费用。','']
        if final:
            groups=defaultdict(list)
            for row in final:groups[row['strategy']].append(row)
            lines += table(['组合','末端三补法现金跨度（元）','末态跨度（kWh）'],
                [[name,money(max(r['revised_contract_cash_total_yuan'] for r in rr)-min(r['revised_contract_cash_total_yuan'] for r in rr)),
                  number(max(r['soc_end_kwh'] for r in rr)-min(r['soc_end_kwh'] for r in rr))] for name,rr in sorted(groups.items())])
            ranks={m:[r['strategy'] for r in sorted((r for r in final if r['method']==m),key=lambda r:r['revised_contract_cash_total_yuan'])]
                   for m in ('hold','linear2','ols6')}
            stable=all(rank==ranks['hold'] for rank in ranks.values())
            analysis['endpoint_cash_ranks']=ranks;analysis['endpoint_cash_ranks_unchanged']=stable
            if complete and len(groups)==8:
                lines += [('三种末端补法下，八组合现金排名保持相同。' if stable else '末端补法改变了至少部分现金排名，应对接近的组合保留排序不确定性。'), '']
            lines += ['最后缺失端点仍是估计。敏感性固定原g、正式q和末段初态，只重新执行末段；它不是另一轮全年优化。','']
    else:
        analysis['pending'].append('首尾边界敏感性');lines+=['首尾持平、线性和OLS边界敏感性尚待完整主轨迹后生成。','']
    causal,cpath=_first_json([root/'causal'/'summary.json',root/'causal_selected'/'summary.json',
        root/'sensitivity'/'causal'/'summary.json',root/'causal_pilot'/'summary.json'])
    if causal:
        analysis['causal_execution']=causal;analysis['causal_source']=cpath
        cs=causal.get('summary',{})
        if '10min_mean' in cs and '1min_causal' in cs:
            oldc,newc=cs['10min_mean'],cs['1min_causal']
            lines += table(['执行方法','区间数','现金费用（元）','紧急电量（kWh）','期末库存（kWh）'],
                [[name,r['intervals'],money(r['cash_cost_yuan']),number(r['emergency_kwh']),number(r['soc_end_kwh'])]
                 for name,r in [('10分钟均值快反馈',oldc),('1分钟因果仿真',newc)]])
            lines += [f"此对照来自{causal.get('source_strategy')}的固定合同局部{causal.get('days')}窗，"
                      '只在原来的正式签单时刻揭示相应订单，两种执行方法共用同一组g/q及相同局部末端规则。'+
                      comparison_sentence('1分钟因果仿真','10分钟均值快反馈',newc['cash_cost_yuan'],oldc['cash_cost_yuan']),
                      '', '分钟曲线是按原始端点线性构造的仿真，采用一分钟左端功率保持，存在离散化能量差异。'
                      '因此差额同时反映执行规则与离散近似，不是高频实测验证，更不能据这几个窗口宣布全年组合排名已经被因果分钟回放证明。','']
            if newc['cash_cost_yuan']>oldc['cash_cost_yuan']+1e-5:
                lines += ['该对照提示10分钟均值反馈费用可能偏乐观，报告主费用时必须保留执行近似说明。','']
        if 'causal_pilot' in str(cpath):analysis['pending'].append('选定组合的预定较长因果分钟对照（目前只有pilot）')
    else:
        analysis['pending'].append('因果分钟执行敏感性');lines+=['因果分钟执行敏感性尚未完成，当前主费用仍属于10分钟均值快反馈仿真口径。','']

    timing=[]
    for dirname,label in [('causal_H0','只启用0点'),('causal_old_forecast','全时刻调单但只读0点版'),('causal_selected','开发选定组合')]:
        item=read_json(root/dirname/'summary.json',{})
        if item:
            ss=item['summary'];a=ss['10min_mean'];b=ss['1min_causal']
            timing.append([label,money(a['cash_cost_yuan']),money(b['cash_cost_yuan']),
                           number(a['soc_start_kwh']),number(b['soc_end_kwh'])])
    if len(timing)==3:
        analysis['timing_comparison']=timing
        lines += ['**同一七窗的执行时序补充比较：**','']
        lines += table(['策略','10分钟快反馈费（元）','1分钟因果仿真费（元）','局部初态（kWh）','分钟末态（kWh）'],timing)
        lines += ['各策略固定自己的正式合同，局部初态取各自主轨迹该日起点，未把未来签单提前透露给控制器。'
                  '该表是从各自历史状态开始的条件敏感性，初态并不完全相同；它不是三条全年分钟级闭环重新优化，'
                  '也不把七窗差额外推成全年费用。','']

    lines += ['## 八、求解状态与结论边界','']
    if rows:
        stats=[]
        for r in rows:
            ss=r.get('solver',{})
            events=read_json(main/r['strategy']/'event_log.json',{}).get('events',[])
            unproven=sum(e.get('status')!='optimal_within_requested_gap' for e in events)
            stats.append([schedule(r),ss.get('solves','待完成'),ss.get('unproven','待完成'),
                len(events),unproven,number(float(ss.get('max_gap',0))*100,6),number(ss.get('seconds'))])
        lines += table(['组合','总求解次数','未证请求精度次数','签单事件数','其中未证次数','最大相对Gap（%）','总求解秒数'],stats)
        lines += ['总求解统计包含日前、日内签单和电池控制，未证次数不是“未证最优的天数”。每次接受的解经过整数模式精修和物理核验；'
                  '相对Gap使用原MILP全局下界，不能把固定模式LP的最优当原MILP全局最优。','']
    lines += ['这是一套在给定输入、合同窗口、退款解释、实验初态和执行近似下的可复现策略。'
              '随机规划中的未来补救含两阶段预见性近似，用户预测生成的训练因果性也尚待队伍代码佐证。'
              '四个指定日期应从连续账本按自然日提取，不单独重置电池求解；原模板、费用与结果图必须使用同一版轨迹。','']
    if analysis['pending']:
        lines += ['本文件仍待补充的结果：','',*[f'- {item}。' for item in analysis['pending']],'']
    out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text('\n'.join(lines),encoding='utf-8')
    result_path=out.parent/'analysis_summary.json'
    result_path.write_text(json.dumps(analysis,ensure_ascii=False,indent=2),encoding='utf-8')
    return analysis


if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--results',required=True,type=Path)
    ap.add_argument('--out',required=True,type=Path)
    args=ap.parse_args()
    result=build_conclusions(args.results,args.out)
    print(json.dumps({'complete_main':result['complete_main'],'selected':result['selected_strategy'],
                       'pending':result['pending'],'output':str(args.out)},ensure_ascii=False))
