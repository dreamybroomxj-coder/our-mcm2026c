"""Continuous Q3 replay. Only release events sign orders; MPC only executes.

The main 10-minute execution uses the current interval mean as a fast-feedback
approximation. Historical means enter scenario fitting only after interval end.
No daily SOC reset. At midnight new orders are signed before the old tail is
observed, using a locked one-interval bridge. Future scene orders are tentative.
"""
from __future__ import annotations
import argparse, csv, datetime as dt, hashlib, itertools, json, os, time
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed
import numpy as np
from q3_io import load_inputs
from q3_risk import HOURS, START, scenario_inputs, latest_hour, future_mask, current_block
from q3_optimizer import solve_dispatch, LOW, HIGH, RATE, ETA_C, ETA_D

DEFAULT = dict(scenarios=8, history_days=28, min_history=14, seed=20260912,
               controller='mpc', pv_source='supplied', initial_soc=6000.,
               time_limit=10., mip_gap=1e-4)
SCHEDULES = [(0,)+s for n in range(4) for s in itertools.combinations((6,12,18),n)]

def dump(path, value):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2,default=str))

def write_csv(path, rows):
    if not rows: return
    with open(path,'w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def signature(data_dir, config):
    h=hashlib.sha256(json.dumps(config,sort_keys=True).encode())
    for p in sorted(Path(__file__).parent.glob('q3_*.py')):
        if p.name in ('q3_runner.py','q3_optimizer.py','q3_io.py','q3_risk.py'):
            h.update(p.name.encode());h.update(p.read_bytes())
    h.update((Path(data_dir)/'source_manifest.json').read_bytes())
    # The source manifest is historical provenance, not a substitute for
    # hashing the files currently being supplied. A user can replace a forecast
    # workbook without editing that manifest; such replacement must invalidate
    # every cached result.
    for name in ('attachment1.xlsx','attachment2.xlsx','attachment3.xlsx',
                 'load_forecasts.xlsx','pv_forecasts.xlsx','result3_template.xlsx'):
        h.update(name.encode());h.update((Path(data_dir)/name).read_bytes())
    return h.hexdigest()

def validate_run_arguments(trade_hours,forecast_hours,config,start_day,days):
    for label,hours in [('trade_hours',trade_hours),('forecast_hours',forecast_hours)]:
        if not hours or any(type(h) is not int for h in hours) or tuple(sorted(set(hours)))!=tuple(hours) or hours[0]!=0 or not set(hours)<=set(HOURS):
            raise ValueError(f'{label} must be a sorted unique subset of (0,6,12,18), including 0')
    if type(start_day) is not int or not 0<=start_day<334:
        raise ValueError('start_day must be an integer in 0..333')
    if days is not None and (type(days) is not int or days<=0):
        raise ValueError('days must be a positive integer or None')
    for key in ('scenarios','history_days','min_history'):
        if type(config[key]) is not int or config[key]<1:raise ValueError(f'{key} must be positive integer')
    if config['history_days']<config['min_history']:raise ValueError('history_days must cover min_history')
    if config['controller'] not in ('mpc','greedy'):raise ValueError('Unknown controller')
    if config['pv_source'] not in ('supplied','linear'):raise ValueError('Unknown PV source')
    if not np.isfinite(config['initial_soc']) or not LOW<=config['initial_soc']<=HIGH:
        raise ValueError('Initial SOC outside physical bounds')

def make_record(data, day, t, name, g, q, c, d, e, state, forecast_hour, *, startup=False):
    if startup:
        z=data['first_unexecuted_interval']; L=z['load_mean_kw'];G=z['pv_mean_kw']
        begin=dt.datetime.combine(data['dates'][0],dt.time())
        lf=float(data['load_f'][0,0]);pf=float(data['pv_unused_first_mean_kw'][0]);p=float(data['price'][-1])
    else:
        L=float(data['load_a'][day,t]);G=float(data['pv_a'][day,t])
        begin=data['window_start'][day]+dt.timedelta(minutes=10*t)
        lf=float(data['load_f'][day,t]);pf=float(data['pv_f'][day,HOURS.index(forecast_hour),t]);p=float(data['price'][t])
    waste=max(q+G/6+d+e-L/6-c,0.)
    # Bookkeeping allocation: use PV first, then paid contract; neither refund.
    v=min(q,waste);r=max(waste-v,0.)
    a=max(q-g,0.);b=max(g-q,0.);end_state=state+ETA_C*c-d/ETA_D
    return dict(strategy=name,window_date=str(data['dates'][day]),interval_start=begin.isoformat(),
       interval_end=(begin+dt.timedelta(minutes=10)).isoformat(),
       forecast_issue_time=dt.datetime.combine(data['dates'][day],dt.time(forecast_hour)).isoformat(),
       price_yuan_per_kwh=p,load_forecast_kw=lf,pv_forecast_kw=pf,load_actual_kw=L,pv_actual_kw=G,
       actual_estimated=bool(False if startup else data['actual_estimated'][day,t]),
       g_kwh=float(g),q_kwh=float(q),increase_kwh=a,decrease_kwh=b,
       charge_kwh=float(c),discharge_kwh=float(d),emergency_kwh=float(e),
       unused_paid_kwh=v,curtailed_pv_kwh=r,soc_start_kwh=float(state),soc_end_kwh=float(end_state),
       plan_cost_yuan=p*g,increase_cost_yuan=1.5*p*a,refund_yuan=p*b,penalty_yuan=.5*p*b,
       adjustment_net_cost_yuan=1.5*p*a-.5*p*b,emergency_cost_yuan=5*p*e,
       cash_cost_yuan=p*g+1.5*p*a-.5*p*b+5*p*e)

def run_strategy(data_dir, out_dir, trade_hours=(0,6,12,18), *, forecast_hours=None,
                 config=None, start_day=0, days=None, name=None, force=False):
    config={**DEFAULT,**(config or {})}; trade_hours=tuple(trade_hours)
    forecast_hours=tuple(trade_hours if forecast_hours is None else forecast_hours)
    validate_run_arguments(trade_hours,forecast_hours,config,start_day,days)
    name=name or 'H'+'_'.join(map(str,trade_hours))
    config.update(trade_hours=list(trade_hours),forecast_hours=list(forecast_hours),
                  start_day=start_day,days=days,strategy=name)
    if 0 not in trade_hours or 0 not in forecast_hours or not set(forecast_hours)<=set(HOURS):
        raise ValueError('Bad schedule')
    target=Path(out_dir)/name;target.mkdir(parents=True,exist_ok=True)
    sig=signature(data_dir,config)
    if (target/'summary.json').exists() and not force:
        old=json.loads((target/'summary.json').read_text())
        if old.get('run_signature')==sig and old.get('complete'): return old
        raise RuntimeError(f'Incompatible existing run: {target}. Use new output or --force.')
    data=load_inputs(data_dir)
    if config['pv_source']!='supplied':
        data['pv_f']=data['pv_linear_f'].copy()
    stop=min(len(data['dates']),start_day+(days or len(data['dates'])))
    p=data['price']; kappa=config.get('terminal_weight',float(np.min(p)/ETA_C))
    opts=dict(terminal_weight=kappa,time_limit=config['time_limit'],mip_gap=config['mip_gap'])
    state=float(config['initial_soc']);events=[];rows=[];daily=[];g=q=None
    stats=dict(solves=0,seconds=0.,unproven=0,max_gap=0.,max_physical_error=0.,surplus_direct_steps=0)
    beginning=time.perf_counter()

    def solve(L,G,prices,s,**kwargs):
        sol=solve_dispatch(L,G,prices,s,**opts,**kwargs)
        stats['solves']+=1;stats['seconds']+=sol['solve_seconds']
        stats['unproven']+=int(not sol['optimality_proven'])
        stats['max_gap']=max(stats['max_gap'],sol['gap'] or 0.)
        stats['max_physical_error']=max(stats['max_physical_error'],sol['checks']['max_violation_kwh'])
        return sol

    def log_event(day,h,kind,sol,meta,first,last,bridge=False):
        events.append(dict(window_date=str(data['dates'][day]),day_index=day,kind=kind,
            decision_at=dt.datetime.combine(data['dates'][day],dt.time(h)).isoformat(),
            forecast_hour=meta['forecast_hour'],history_indices=meta['history_indices'],
            draw_indices=meta['draw_indices'],history_latest_end=meta['history_latest_end'],
            scenarios=meta['scenarios'],commit_start=first,commit_end=last,locked_bridge=bridge,
            status=sol['status'],gap=sol['gap'],solve_seconds=sol['solve_seconds'],
            objective=sol['objective'],objective_is_cash=False,
            max_violation_kwh=sol['checks']['max_violation_kwh']))

    def control(L,G,prices,base,booked,future,actual_l,actual_pv):
        nonlocal state
        surplus=max(booked[0]+actual_pv-actual_l,0.)
        deficit=max(actual_l-booked[0]-actual_pv,0.)
        if surplus>1e-9:
            stats['surplus_direct_steps']+=1
            c=min(surplus,RATE,max((HIGH-state)/ETA_C,0.));d=e=0.
        elif config['controller']=='greedy':
            c=0.;d=min(deficit,RATE,max((state-LOW)*ETA_D,0.));e=max(deficit-d,0.)
        else:
            L=L.copy();G=G.copy();L[0]=actual_l;G[0]=actual_pv
            sol=solve(L[None,:],G[None,:],prices,state,mode='control',base_g=base,
                      booked_q=booked,future_adjust_mask=future)
            c=float(sol['c'][0,0]);d=float(sol['d'][0,0]);e=float(sol['e'][0,0])
        return c,d,e

    def execute(day,t,L,G,prices,base,booked,future,fh):
        nonlocal state
        c,d,e=control(L,G,prices,base,booked,future,data['load_a'][day,t]/6,data['pv_a'][day,t]/6)
        row=make_record(data,day,t,name,float(base[0]),float(booked[0]),c,d,e,state,fh)
        rows.append(row);state=row['soc_end_kwh']
        if not LOW-1e-5<=state<=HIGH+1e-5: raise RuntimeError('Executed SOC violation')

    def finish_day(day):
        part=rows[-144:]
        if len(part)!=144 or len(set(r['window_date'] for r in part))!=1: raise RuntimeError('Incomplete window')
        cash=sum(r['cash_cost_yuan'] for r in part)
        daily.append(dict(strategy=name,window_date=str(data['dates'][day]),cash_cost_yuan=cash,
            soc_start_kwh=part[0]['soc_start_kwh'],soc_end_kwh=part[-1]['soc_end_kwh'],
            inventory_adjusted_cost_yuan=cash-kappa*(part[-1]['soc_end_kwh']-part[0]['soc_start_kwh']),
            emergency_kwh=sum(r['emergency_kwh'] for r in part)))

    for day in range(start_day,stop):
        # 00:00: old last interval is not known; sign new 144 intervals now.
        L,G,meta=scenario_inputs(data,day,0,0,0,config)
        fm=future_mask(trade_hours,0); locked=np.zeros(144,bool)
        bridge=day>start_day
        if bridge:
            oldg,oldq=g.copy(),q.copy();oldfh=latest_hour(forecast_hours,143)
            oldL=float(data['load_f'][day-1,143]/6)
            # Only already issued forecasts; do not read the unexecuted actual.
            oldG=float(data['pv_f'][day-1,HOURS.index(oldfh),143]/6)
            L=np.column_stack((np.full(len(L),oldL),L));G=np.column_stack((np.full(len(G),oldG),G))
            locked=np.r_[True,locked];fm=np.r_[False,fm];prices=np.r_[p[-1],p]
            booked=np.r_[oldq[-1],np.zeros(144)]
        else: prices=p;booked=np.zeros(144)
        sol=solve(L,G,prices,state,mode='dayahead',locked_mask=locked,booked_q=booked,future_adjust_mask=fm)
        g=sol['g'][-144:].copy();q=g.copy()
        log_event(day,0,'dayahead',sol,meta,0,144,bridge)
        if bridge:
            base=np.r_[oldg[-1],g];booked=np.r_[oldq[-1],q]
            lf=np.r_[oldL,data['load_f'][day]/6];pf=np.r_[oldG,data['pv_f'][day,0]/6]
            execute(day-1,143,lf,pf,prices,base,booked,fm,oldfh)
            finish_day(day-1)
        for t in range(143):
            h=next((h for h in trade_hours if h and START[h]==t),None)
            fh=latest_hour(forecast_hours,t)
            if h is not None:
                first,last=current_block(trade_hours,h)
                L,G,meta=scenario_inputs(data,day,fh,h,t,config)
                current=np.arange(t,144)<last
                sol=solve(L,G,p[t:],state,mode='adjust',base_g=g[t:],booked_q=q[t:],
                          current_mask=current,future_adjust_mask=future_mask(trade_hours,t))
                if not np.array_equal(sol['signed_mask'],current): raise RuntimeError('Wrong signed block')
                q[t:last]=sol['q'][:last-t]
                log_event(day,h,'adjust',sol,meta,first,last)
            lf=data['load_f'][day,t:]/6;pf=data['pv_f'][day,HOURS.index(fh),t:]/6
            execute(day,t,lf,pf,p[t:],g[t:],q[t:],future_mask(trade_hours,t),fh)
        if (day-start_day+1)%10==0 or day==stop-1:
            dump(target/'progress.json',dict(day=str(data['dates'][day]),days_started=day-start_day+1,
                total_days=stop-start_day,elapsed_seconds=time.perf_counter()-beginning,solver=stats))
            print(f'{name}: {day-start_day+1}/{stop-start_day}, {time.perf_counter()-beginning:.1f}s',flush=True)
    # No next-day contract/forecast exists at the end of the selected experiment.
    day=stop-1;fh=latest_hour(forecast_hours,143)
    execute(day,143,data['load_f'][day,143:]/6,data['pv_f'][day,HOURS.index(fh),143:]/6,
            p[143:],g[143:],q[143:],np.zeros(1,bool),fh)
    finish_day(day)
    write_csv(target/'trace.csv',rows);write_csv(target/'daily.csv',daily)
    dump(target/'event_log.json',dict(config=config,events=events))
    startup=[]
    if start_day==0:
        z=data['first_unexecuted_interval'];G=float(data['pv_unused_first_mean_kw'][0]/6)
        g0=max(float(data['load_f'][0,0]/6)-G,0.)
        e0=max(z['load_mean_kw']/6-g0-z['pv_mean_kw']/6,0.)
        startup=[make_record(data,0,0,name,g0,g0,0.,0.,e0,config['initial_soc'],0,startup=True)]
        write_csv(target/'startup.csv',startup)
    total=sum(r['cash_cost_yuan'] for r in rows)
    summary=dict(strategy=name,config=config,complete=True,run_signature=sig,intervals=len(rows),
        windows=stop-start_day,cash_cost_yuan=total,soc_start_kwh=config['initial_soc'],soc_end_kwh=state,
        inventory_adjusted_cost_yuan=total-kappa*(state-config['initial_soc']),
        emergency_kwh=sum(r['emergency_kwh'] for r in rows),
        original_plan_cost_yuan=sum(r['plan_cost_yuan'] for r in rows),
        net_adjustment_cost_yuan=sum(r['adjustment_net_cost_yuan'] for r in rows),
        emergency_cost_yuan=sum(r['emergency_cost_yuan'] for r in rows),
        startup_cash_cost_yuan=sum(r['cash_cost_yuan'] for r in startup),
        natural_period_cash_cost_yuan=sum(r['cash_cost_yuan'] for r in rows if r['interval_start'][:10]<=str(data['dates'][stop-1]))+sum(r['cash_cost_yuan'] for r in startup),
        execution='current 10-min actual mean fast-feedback approximation; future means unavailable',
        elapsed_seconds=time.perf_counter()-beginning,solver=stats)
    dump(target/'summary.json',summary)
    return summary

def select_and_compare(out_dir):
    import pandas as pd
    root=Path(out_dir);table=[];dev=[];test=[]
    for path in sorted(root.glob('H*/summary.json')):
        s=json.loads(path.read_text());table.append(s)
        d=pd.read_csv(path.parent/'daily.csv')
        v=d[d.window_date.between('2025-02-17','2025-02-23')]
        w=d[d.window_date>='2025-02-25']
        dev.append(dict(strategy=s['strategy'],windows=len(v),score=float(v.inventory_adjusted_cost_yuan.sum())))
        test.append(dict(strategy=s['strategy'],windows=len(w),cash_cost_yuan=float(w.cash_cost_yuan.sum()),
            score=float(w.inventory_adjusted_cost_yuan.sum())))
    if not table:return
    selected=min(dev,key=lambda x:x['score'])['strategy']
    hindsight=min(table,key=lambda x:x['inventory_adjusted_cost_yuan'])['strategy']
    dump(root/'selection.json',dict(selected_strategy=selected,retrospective_best=hindsight,
        freeze_time='2025-02-25T00:00:00',development_windows='2025-02-17 through 2025-02-23',
        score='cash minus minimum-price inventory change; not an electricity bill',
        parameters='8 scenes,28 history days,min14,seed20260912 preset before comparison',
        selection_is_historical_simulation=True,development=dev,test=test))
    dump(root/'comparison.json',table)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--data',default=str(Path(__file__).resolve().parent.parent/'data'))
    ap.add_argument('--out',required=True);ap.add_argument('--days',type=int);ap.add_argument('--workers',type=int,default=4)
    ap.add_argument('--schedule',default='all');ap.add_argument('--scenarios',type=int,default=8)
    ap.add_argument('--force',action='store_true');args=ap.parse_args()
    schedules=SCHEDULES if args.schedule=='all' else [tuple(map(int,args.schedule.split(',')))]
    with ProcessPoolExecutor(max_workers=min(args.workers,len(schedules))) as pool:
        jobs=[pool.submit(run_strategy,args.data,args.out,s,config={'scenarios':args.scenarios},days=args.days,force=args.force) for s in schedules]
        for job in as_completed(jobs):
            r=job.result();print(r['strategy'],r['cash_cost_yuan'],flush=True)
    select_and_compare(args.out)

if __name__=='__main__':main()
