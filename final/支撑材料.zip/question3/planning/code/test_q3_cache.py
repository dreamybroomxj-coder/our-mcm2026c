import tempfile,unittest
from pathlib import Path
from q3_runner import signature,validate_run_arguments,DEFAULT,SCHEDULES

class CacheGuardTests(unittest.TestCase):
    def test_actual_forecast_change_invalidates_cache_with_same_manifest(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            names=['source_manifest.json','attachment1.xlsx','attachment2.xlsx','attachment3.xlsx',
                   'load_forecasts.xlsx','pv_forecasts.xlsx','result3_template.xlsx']
            for name in names:(root/name).write_bytes(b'unchanged fixture')
            old=signature(root,DEFAULT)
            (root/'pv_forecasts.xlsx').write_bytes(b'replacement forecasts')
            self.assertNotEqual(old,signature(root,DEFAULT))
            self.assertEqual((root/'source_manifest.json').read_bytes(),b'unchanged fixture')

    def test_eight_schedules_remain_accepted(self):
        for schedule in SCHEDULES:validate_run_arguments(schedule,schedule,DEFAULT,0,None)
        validate_run_arguments((0,6,12,18),(0,),DEFAULT,24,60)

    def test_invalid_configuration_rejected_before_computation(self):
        for hours in [(0,7),(0,6,6),(6,0),(6,),(0.0,6.0),(False,6)]:
            with self.assertRaises(ValueError):validate_run_arguments(hours,(0,),DEFAULT,0,3)
        for cfg in [{'pv_source':'typo'},{'controller':'typo'},{'scenarios':0},{'initial_soc':0}]:
            with self.assertRaises(ValueError):validate_run_arguments((0,),(0,),{**DEFAULT,**cfg},0,3)
        with self.assertRaises(ValueError):validate_run_arguments((0,),(0,),DEFAULT,0,0)

if __name__=='__main__':unittest.main()
