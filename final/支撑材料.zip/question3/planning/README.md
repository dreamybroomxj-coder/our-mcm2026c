# 第三问：预报更新、付费调单和储能控制

本工程直接接收队伍的区间平均负载和0、6、12、18时光伏预测，比较8个更新时间组合。每个组合独立连续运行同一套场景随机MILP与电池MPC，保留原计划、正式调整、实际执行和费用账本。

本轮计算已完成。先阅读`results/reports/问题三_结果与评价.md`了解费用与验证结论，再阅读`notes/问题三_模型与操作说明.docx`或同名PDF了解完整公式、参数与操作。Markdown方法稿为`notes/问题三_模型与复现说明.md`；`notes/输入审计与时间接口.md`解释原表标签、边界和数据来源。

开发段选择、后续测试和全期回溯均支持启用0、6、12、18点。主模型为滚动两阶段场景随机MILP＋电池MPC，不另叠加分位数裕量。334个合同现金合计13,173,959.97元，比仅启用0点少729,664.54元（5.248%）。完整期MPC仅比贪心少3,558.59元（0.027%），经济差异很小，贪心可作简化备选；不宣称全局最优或对其他预测输入普遍最优。

## 先看哪些结果

已提供的文件：

| 文件 | 用途 |
|---|---|
| `results/main/selection.json` | 开发段选定组合及全期回溯最低组合，二者分开记录 |
| `results/main/comparison.json` | 八个完整策略的费用、库存及求解记录 |
| `results/reports/问题三_策略比较.xlsx` | 中文费用比较和分月表 |
| `results/reports/result3.xlsx` | 题给原模板展开后的完整购电、储能和紧急结果 |
| `results/reports/问题三_指定四日填表.xlsx` | 3月20日、6月21日、9月23日、12月21日论文表1—3 |
| `results/reports/问题三_指定四日论文表格.md` | 可复制到论文的四日表格 |
| `results/reports/报表与账本核验.json` | 逐段账本、现金分项和工作簿重开检查 |
| `results/sensitivity/` | 场景数、种子、控制方法、初态及还原方式敏感性 |
| `results/ablation/` | 334窗旧版预报对照、334窗贪心控制对照 |
| `results/causal_selected/`、`causal_H0/`、`causal_old_forecast/` | 同一7窗的执行时序敏感性，不能外推为全年分钟级结果 |
| `results/figures/` | 8张中文PNG和矢量PDF图 |
| `notes/代码版本与复现.md`、`provenance/` | 计算原版代码、输入摘要及后续缓存保护改动的验证 |

每个主策略文件夹保存`trace.csv`、`daily.csv`、`event_log.json`、`summary.json`和`startup.csv`。所有真实电费由已签订单及实际紧急电产生；不能将各次求解器显示的滚动目标值相加。

## 必须保持的口径

- 一个合同包含D日00:10至D+1日00:10的144段。论文储能表使用00:00—24:00自然日，按时间戳重新分组。
- 队伍预测已经是区间平均kW，不再次平均；乘1/6一次得到kWh。附件2实际值按瞬时节点两端平均。
- 日初实验库存6000kWh，随后连续承接，不每天恢复6000，不设每日首末SOC硬相等。
- 原计划量`g`不覆盖；正式调整后总量是`q`。增量按1.5倍价格，取消部分退原费再收50%违约费，紧急电按5倍价格。
- 已付但未使用的普通电不自动退款；电池容量和5000kW功率限制、充放效率及紧急电不充电在全部组合一致。
- 场景使用当时已完整兑现的连续配对残差，不额外叠加分位数裕量。被屏蔽的预报版本不能偷偷供MPC或场景库使用。
- 首个自然日00:00—00:10使用单列的共同静置初始化假设。跨年末段和startup分别保存，不能重复或混淆全年费用范围。
- 主执行的当前10分钟均值反馈是近似；1分钟因果反馈是局部敏感性，人工插值分钟值并非新增实测。

## 环境和操作步骤

从本工程根目录运行。需要Python及`numpy`、`scipy`、`pandas`、`openpyxl`；模型实际调用SciPy/HiGHS。文献引用PySP和do-mpc的方法说明，但无需安装这两个包。

建议使用Python 3.11及以上；本次运行环境为Python 3.13.9、SciPy 1.16.3。安装依赖：

```bash
python -m pip install -r requirements.txt
```

**完整重算的统一入口：**

```bash
python code/run_all.py --out results/reproduced --workers 4
```

入口依次执行数据检查、58项测试、8个主策略、11个局部敏感性、2个完整期消融、账本审计、3条7窗分钟回放、边界复核、Excel与图表和结论导出。本轮这些组成步骤均已实际运行；统一入口是在最终整合时加入并完成导入/命令行检查，没有在整合之后再重复运行整套334窗计算。

**包内`results/main`等目录是本次已经核验的冻结结果。**最终交付代码增加了“真实XLSX内容变更使旧缓存失效”和非法参数拒绝保护，未修改数学与控制公式。完整结果来自`provenance/numerical_core_used/`，新旧入口另经3个随机规划窗口逐列等价检查，见版本说明。默认重算到`results/reproduced`，避免新签名覆盖或冒充旧计算；不要用`--force`无意删除已验证结果。

固定种子并不保证不同机器在MILP限时条件下逐位相同。复现应同时比较物理与费用核验、可行状态、Gap和策略排名，不能只检查最后一位小数。以下为分步运行方式，均使用新的输出目录：

第一步，检查并标准化工程内已复制的数据：

```bash
python code/q3_io.py --data data
python -m unittest discover -s code -p 'test*.py' -v
```

第二步，运行完整八组合：

```bash
python code/q3_runner.py --data data --out results/reproduced/main --workers 4
```

`--workers 4`是四个并行进程。已有同签名完整结果可复用；代码/参数与旧结果签名不一致时默认拒绝覆盖。修改参数重新比较时宜使用新的输出目录，保留原结果来源，不为省时间跳过失败核验。

只调试单个组合，可以先使用独立目录短运行：

```bash
python code/q3_runner.py --data data --out results/smoke --schedule 0,6 --days 3 --workers 1
```

短运行没有完整开发段和四个题定日期，不能代替正式选型及填表。

第三步，审计全部主策略并导出结果。下面的H0示范同样适用于其他七个策略目录：

```bash
python code/q3_audit.py results/reproduced/main/H0 --inputs data/q3_inputs.npz
python code/q3_reports.py --results results/reproduced/main --data data --out results/reproduced/reports
```

第四步，预设敏感性：

```bash
python code/q3_sensitivity.py --data data --out results/reproduced/sensitivity --stage development --workers 2
python code/q3_sensitivity.py --data data --out results/reproduced/sensitivity --stage algorithms --workers 2
```

第五步，按需对指定主策略进行局部执行时序复核：

```bash
python code/q3_causal_replay.py --data data --main-run results/reproduced/main/H0_6_12_18 \
  --out results/reproduced/causal_selected --start-day 24 --days 7
```

它固定主结果已经签订的订单，按原发布时间逐步让控制器看到订单，对比10分钟均值反馈和1分钟因果反馈。局部日期为2月25日至3月3日，不能将此7日试验称为八组合全年高频复核。

## 程序结构

| 模块 | 作用 |
|---|---|
| `q3_io.py` | 输入复制、显式时间映射、节点平均、预报版本与输入审计 |
| `q3_risk.py` | 当时可用历史、成对残差场景、版本与正式提交块 |
| `q3_optimizer.py` | 零点、日内调单、控制三模式共享MILP；固定模式LP精修 |
| `q3_runner.py` | 八组合独立连续回放、午夜桥接、真实交易账本与开发段选型 |
| `q3_sensitivity.py` | 预设局部模型与参数敏感性，不用于追逐后续段最低费用 |
| `q3_audit.py` | 独立读取结果核对物理、现金、交易范围和信息时间 |
| `q3_causal_replay.py` | 固定正式订单下的局部执行时序敏感性 |
| `q3_reports.py` | 原result3模板、四日论文表及费用比较，不重新优化 |
| `run_all.py` | 按上述实验顺序执行计算、审计和导出 |
| `q3_figures.py`、`q3_conclusions.py` | 从已完成的账本导出图与有范围限定的结论 |
| `test*.py` | 数据、数学边界、结算、时序、模板与填表测试 |

`data/source_manifest.json`保存原件路径、文件大小和SHA256。读原件的默认绝对路径仅用于原始电脑首次`--copy-originals`复制；其他电脑复现使用工程内`data/`，无需原电脑微信或下载目录。

## 怎样理解比较结果

开发段固定为2月17—23日，2月25日零点冻结组合选择，后续310窗口另报告。主参数是预设8场景、最多28个完整历史窗口、至少14条历史、种子20260912；不声称经过全空间最优调参。

真实现金费用和库存修正评价分开。末态评价为“现金−最低价库存估值×库存增量”，不是另一张电费账单。`selected_strategy`是开发规则选择；`retrospective_best`是查看完整历史后的库存修正最低。八组合同时改变新预报和调单机会，不能仅凭它们的差额把全部收益解释成预报本身的价值。

场景内未来补救具有两阶段预见性，模型目标不等于实际回放费；正式当前订单仍必须跨场景共享。接受限时可行解时保留状态与Gap，固定整数模式LP精修通过也不冒称整个MILP已经全局最优。

队伍光伏表的完整生成信息集尚未独立认证。主结果以输入预测为条件；替换预测器、场景规则、时间解释或初始状态后，需要重新构造历史误差并重新评估。

算法资料与原题依据见`notes/问题三_模型与复现说明.md`末尾。8主策略＋2完整期消融共480,960段、11项局部敏感性共56,880段均完成独立账本审计。指定四日按真实自然日从连续轨迹提取，未单独重置电池。完整`result3.xlsx`的“调整后购电费”包括紧急费，普通结算费另列明细；跨年尾段另表，不塞入下一年1月1日的全年模板行。

所有费用以当前输入、6000 kWh统一实验初态、目标供电时段价格结算约定及10分钟平均功率反馈近似为条件。局部一分钟因果执行费用高于主近似，因此这是一套有明确误差边界的历史回放，不能当作未来实际账单保证。更换预测后需重建历史残差并重新评估。
