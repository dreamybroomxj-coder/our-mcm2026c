"""Synthetic tests of instantaneous actuals and shifted-window history timing."""

import copy
import datetime as dt
from pathlib import Path
import tempfile
import unittest

import numpy as np
from openpyxl import Workbook

from window_io import attach_actuals, risk_inputs


class WindowActualTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.root=Path(self.temp.name)
        self.days=[dt.date(2025,12,29)+dt.timedelta(days=i) for i in range(3)]

    def tearDown(self):
        self.temp.cleanup()

    def data(self,days=None):
        days=self.days if days is None else days
        starts=[dt.datetime.combine(d,dt.time(0,10)) for d in days]
        return {
            'dates':list(days),'window_start':starts,
            'window_end':[a+dt.timedelta(days=1) for a in starts],
            'issued_at':[dt.datetime.combine(d,dt.time()) for d in days],
            'load_f':np.full((len(days),144),100.),
            'pv_f':np.full((len(days),144),10.),
            'metadata':{},
        }

    def workbook(self,days=None,filename='actual.xlsx'):
        days=self.days if days is None else days
        load=np.asarray([10+1000*i+np.arange(144) for i in range(len(days))],float)
        pv=np.asarray([1+i+np.arange(144)/100 for i in range(len(days))],float)
        # Distinct extrapolation candidates with exact analytical values.
        load[-1,-6:]=[0,0,0,0,0,60]
        pv[-1,-6:]=[5,4,3,2,1,0]
        header=[f'{(t*10)//60:02d}:{(t*10)%60:02d}' for t in range(1,144)]+['00:00+1']
        book=Workbook()
        book.remove(book.active)
        for name,values in [('小区负载',load),('光伏发电实际功率',pv)]:
            sheet=book.create_sheet(name)
            sheet.append(['日期']+header)
            for d,values_row in zip(days,values):
                sheet.append([dt.datetime.combine(d,dt.time())]+values_row.tolist())
        path=self.root/filename
        book.save(path)
        return path,load,pv

    def test_first_143_means_use_adjacent_nodes_and_last_uses_next_calendar_row(self):
        path,load,pv=self.workbook()
        out=attach_actuals(self.data(),path,confirmed_instantaneous=True)
        np.testing.assert_allclose(out['load_a'][0,:143],(load[0,:143]+load[0,1:])/2)
        np.testing.assert_allclose(out['pv_a'][0,:143],(pv[0,:143]+pv[0,1:])/2)
        self.assertAlmostEqual(out['load_a'][0,143],(load[0,-1]+load[1,0])/2)
        self.assertAlmostEqual(out['load_a'][1,143],(load[1,-1]+load[2,0])/2)
        self.assertNotAlmostEqual(out['load_a'][0,143],(load[0,-1]+load[0,0])/2)
        self.assertEqual(out['metadata']['actual_source_kind'],'instantaneous_power_kw')

    def test_exactly_one_final_interval_is_estimated_and_default_is_hold_last(self):
        path,load,pv=self.workbook()
        out=attach_actuals(self.data(),path,confirmed_instantaneous=True)
        self.assertEqual(out['actual_estimated'].dtype,np.dtype(bool))
        self.assertEqual(out['actual_estimated'].shape,(3,144))
        np.testing.assert_array_equal(np.argwhere(out['actual_estimated']),[[2,143]])
        np.testing.assert_array_equal(out['actual_observed_endpoints'],~out['actual_estimated'])
        self.assertAlmostEqual(out['load_a'][-1,-1],load[-1,-1])
        self.assertAlmostEqual(out['pv_a'][-1,-1],pv[-1,-1])
        self.assertEqual(out['metadata']['estimated_actual_interval_count'],1)
        interval=out['metadata']['estimated_actual_intervals'][0]
        self.assertEqual(interval['missing_node_at'],'2026-01-01T00:10:00')
        self.assertIn('not observed',interval['status'])

    def test_boundary_candidates_are_endpoint_extrapolations_then_means(self):
        path,_,_=self.workbook()
        out=attach_actuals(self.data(),path,confirmed_instantaneous=True)
        candidates=out['last_boundary_candidates']
        self.assertEqual(set(candidates),{'hold','linear2','ols6'})
        self.assertAlmostEqual(candidates['hold']['load_right_endpoint_kw'],60)
        self.assertAlmostEqual(candidates['hold']['load_mean_kw'],60)
        self.assertAlmostEqual(candidates['linear2']['load_right_endpoint_kw'],120)
        self.assertAlmostEqual(candidates['linear2']['load_mean_kw'],90)
        self.assertAlmostEqual(candidates['ols6']['load_right_endpoint_kw'],40)
        self.assertAlmostEqual(candidates['ols6']['load_mean_kw'],50)
        for method in candidates:
            self.assertAlmostEqual(candidates[method]['pv_right_endpoint_kw'],0)
            self.assertAlmostEqual(candidates[method]['pv_mean_kw'],0)
            self.assertEqual(candidates[method]['interval_start'],'2026-01-01T00:00:00')
            self.assertEqual(candidates[method]['interval_end'],'2026-01-01T00:10:00')
            self.assertTrue(candidates[method]['estimated'])

    def test_available_later_source_row_means_no_estimation_for_shorter_requested_range(self):
        path,load,_=self.workbook()
        out=attach_actuals(self.data(self.days[:2]),path,confirmed_instantaneous=True)
        self.assertEqual(int(out['actual_estimated'].sum()),0)
        self.assertEqual(out['last_boundary_candidates'],{})
        self.assertAlmostEqual(out['load_a'][-1,-1],(load[1,-1]+load[2,0])/2)

    def test_instantaneous_confirmation_required_and_interior_missing_day_rejected(self):
        path,_,_=self.workbook()
        with self.assertRaises(ValueError):
            attach_actuals(self.data(),path)
        with self.assertRaises(TypeError):
            attach_actuals(self.data(),path,confirmed_start_means=True)
        gap_path,_,_=self.workbook([self.days[0],self.days[2]],'gap.xlsx')
        with self.assertRaises(ValueError):
            attach_actuals(self.data([self.days[0],self.days[2]]),gap_path,confirmed_instantaneous=True)

    def test_incomplete_previous_window_and_future_actuals_are_excluded_from_risk(self):
        days=[dt.date(2025,12,28)+dt.timedelta(days=i) for i in range(4)]
        path,_,_=self.workbook(days,'four_days.xlsx')
        data=attach_actuals(self.data(days),path,confirmed_instantaneous=True)
        altered=copy.deepcopy(data)
        # At Dec31 00:00, the Dec30 forecast window is not complete until
        # Dec31 00:10. Changing it and all later actuals must not change risk.
        altered['load_a'][2:]+=100000
        altered['pv_a'][2:]+=50000
        config={'window':28,'min_history':2,'seed':1984,'scenarios':6}
        for method in ('C','D'):
            before=risk_inputs(data,3,method,config,.8)
            after=risk_inputs(altered,3,method,config,.8)
            self.assertEqual(before[4]['history_indices'],[0,1])
            self.assertTrue(before[4]['previous_incomplete_window_excluded'])
            for a,b in zip(before[:4],after[:4]):
                if a is None:
                    self.assertIsNone(b)
                else:
                    np.testing.assert_array_equal(a,b)
            self.assertEqual(before[4],after[4])
            if method=='D':
                self.assertTrue(all(i<=1 for i in before[4]['scenario_history_indices']))


if __name__=='__main__':
    unittest.main()
