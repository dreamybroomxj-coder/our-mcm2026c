"""Reproduce Q2 computation, independent checks, Chinese workbooks and figures."""
import argparse
import os
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, default=ROOT / 'results/final_team')
    parser.add_argument('--reports-only', action='store_true',
                        help='Verify and render an existing completed calculation.')
    args = parser.parse_args()
    out = args.out.resolve()
    env = dict(os.environ)
    env.setdefault('MPLCONFIGDIR', str(Path(tempfile.gettempdir()) / 'q2-matplotlib'))
    commands = []
    if not args.reports_only:
        commands.append(['window_study.py', '--out', str(out)])
    commands.extend([
        ['evaluate_reports.py', str(out)],
        ['audit_window_results.py', str(out), '--figures'],
        ['build_window_report.py', '--results', str(out), '--out', str(out / '中文报表')],
        ['build_conclusion.py', str(out)],
    ])
    for name, *arguments in commands:
        subprocess.run([sys.executable, str(ROOT / 'code' / name), *arguments],
                       cwd=ROOT, env=env, check=True)


if __name__ == '__main__':
    main()
