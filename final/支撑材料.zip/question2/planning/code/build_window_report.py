"""Build checked Chinese workbooks from a completed supplied-data window run.

Run only after window_study.py has finished and summary.json exists. This
builder never fits a model, changes a contract, or fabricates missing outputs.
Large interval traces are streamed one method at a time. They are copied as CSV
companions; purchase workbooks use openpyxl's write-only mode.
"""

from __future__ import annotations

import argparse
import csv
import datetime as dt
import hashlib
import json
import math
from pathlib import Path
import shutil
from time import perf_counter

from openpyxl import Workbook, load_workbook
from openpyxl.cell import WriteOnlyCell
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter


ROOT = Path(__file__).resolve().parents[1]
MONEY_TOL = 1e-4
ENERGY_TOL = 1e-5
NAVY = "17365D"
TEAL = "176B87"
PALE = "EEF5FA"
AMBER = "FFF2CC"
WHITE = "FFFFFF"
ERROR_VALUES = {"#VALUE!", "#DIV/0!", "#REF!", "#NAME?", "#NULL!", "#NUM!", "#N/A"}
METHODS = {
    "A": "点预测MILP＋贪心电池控制",
    "B": "点预测MILP＋改进滚动LP控制",
    "C": "净负载分位数裕量MILP＋同一滚动控制",
    "D": "成对历史残差场景随机MILP＋同一滚动控制",
}
PHASES = {
    "same_contract_local": "同购电计划A/B：各窗独立同初态",
    "dayahead_local": "同滚动控制B/C/D：各窗独立同初态",
    "continuous_all": "连续执行：全部334个窗口",
    "continuous_test": "连续执行：参数冻结后的测试窗口",
}
SUM_FIELDS = (
    "cash_cost_yuan", "planned_cost_yuan", "emergency_cost_yuan",
    "inventory_adjusted_cost_yuan", "emergency_kwh", "unused_paid_kwh", "curtailed_pv_kwh",
)
DAILY_COLUMNS = [
    ("date", "窗口归属日期"), ("method", "方案"), ("stage", "阶段"),
    ("window_start", "窗口开始"), ("window_end", "窗口结束"),
    ("planned_cost_yuan", "计划购电费(元)"), ("emergency_cost_yuan", "紧急购电费(元)"),
    ("cash_cost_yuan", "现金总费用(元)"), ("inventory_adjusted_cost_yuan", "库存修正比较费用(元)"),
    ("planned_kwh", "计划购电量(kWh)"), ("emergency_kwh", "紧急购电量(kWh)"),
    ("initial_soc_kwh", "窗口开始储电量(kWh)"), ("final_soc_kwh", "窗口结束储电量(kWh)"),
    ("unused_paid_kwh", "未用已付合同电量(kWh)"), ("curtailed_pv_kwh", "弃光量(kWh)"),
    ("emergency_intervals", "紧急购电时段数"), ("historical_residual_days", "可用完整残差窗口数"),
    ("fallback_to_point", "是否回退点预测"), ("dayahead_solver_status", "日前求解状态"),
    ("dayahead_mip_gap", "日前相对Gap"), ("actual_estimated_intervals", "含估计端点时段数"),
    ("estimated_interval_emergency_yuan", "估计端点时段紧急费(元)"),
]
SUMMARY_COLUMNS = [
    ("phase_label", "比较范围"), ("method", "方案"), ("method_name", "模型与控制器"), ("days", "窗口数"),
    ("planned_cost_yuan", "计划购电费(元)"), ("emergency_cost_yuan", "紧急购电费(元)"),
    ("cash_cost_yuan", "现金总费用(元)"), ("inventory_adjusted_cost_yuan", "库存修正比较费用(元)"),
    ("emergency_kwh", "紧急购电量(kWh)"), ("unused_paid_kwh", "未用合同电量(kWh)"),
    ("curtailed_pv_kwh", "弃光量(kWh)"), ("p95_daily_cash_cost_yuan", "窗口费用95%分位数(元)"),
    ("maximum_daily_cash_cost_yuan", "最高单窗费用(元)"), ("initial_soc_kwh", "首窗初态(kWh)"),
    ("final_soc_kwh", "末窗终态(kWh)"), ("fallback_days", "回退点预测窗口数"),
    ("unproven_plan_days", "未证达到请求Gap窗口数"), ("all_constraints_passed", "约束均通过"),
]
METRICS = [
    ("g_kwh", "计划购电量", "kWh/时段", "零点确定的新窗口普通购电合同；日内固定，未用也付费。"),
    ("charge_kwh", "充电量", "kWh/时段", "微网侧进入电池的电量；内部增加0.9倍，不再除以6。"),
    ("discharge_kwh", "放电量", "kWh/时段", "电池对微网提供的电量；内部减少放电量÷0.9。"),
    ("emergency_kwh", "紧急购电量", "kWh/时段", "普通供应与电池仍不能满足的负载缺口，价格为5倍。"),
    ("unused_paid_kwh", "未用已付合同电量", "kWh/时段", "合同仍按原计划量计费，不退款。"),
    ("curtailed_pv_kwh", "弃光量", "kWh/时段", "未被负载或电池利用的光伏电量；执行分摊遵循光伏优先消纳。"),
    ("planned_cost_yuan", "计划购电费", "元", "各时段区间电价×固定合同量之和；旧前缀合同不重复计费。"),
    ("emergency_cost_yuan", "紧急购电费", "元", "各时段5×区间电价×紧急购电量之和。"),
    ("cash_cost_yuan", "现金总费用", "元", "计划购电费＋紧急购电费；包括明确标记的最后估计时段。"),
    ("inventory_adjusted_cost_yuan", "库存修正比较费用", "元", "现金费用＋固定库存估值×(起始储电量−结束储电量)，只作策略比较。"),
    ("initial_soc_kwh / final_soc_kwh", "窗口首末储电量", "kWh", "对应D日00:10和D+1日00:10，不是自然日00:00/24:00。"),
    ("actual_estimated", "端点估计标记", "布尔", "True：本段右端点缺失并估计。False：两端瞬时值已观测，但区间均值仍是端点平均近似。"),
    ("dayahead_mip_gap", "日前相对最优间隙", "比例", "求解器上下界的相对差。可行超时解不能称精确最优；按原状态保留。"),
    ("dayahead_objective_not_real_bill", "日前规划目标", "元", "含场景预见回补及软末态惩罚的规划值，不是真实MPC电费。"),
    ("historical_residual_days", "完整历史残差窗口数", "窗口", "只用零点前已经完整结束的预测窗口，上一未完窗口被排除。"),
]


def typed(value):
    if value is None or value == "":
        return None
    if value in ("True", "False"):
        return value == "True"
    try:
        number = float(value)
    except (TypeError, ValueError):
        return value
    if not math.isfinite(number):
        raise ValueError(f"Nonfinite CSV value: {value}")
    return number


def read_csv(path):
    with Path(path).open(encoding="utf-8-sig", newline="") as handle:
        return [{key: typed(value) for key, value in row.items()} for row in csv.DictReader(handle)]


def read_json(path):
    with Path(path).open(encoding="utf-8") as handle:
        return json.load(handle)


def close(actual, expected, description, tol=MONEY_TOL):
    error = abs(float(actual) - float(expected))
    if error > tol:
        raise AssertionError(f"{description}: {actual} != {expected}; error={error}")
    return error


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024*1024), b""):
            h.update(chunk)
    return h.hexdigest()


def clean_sheet(workbook, name, columns, rows):
    sheet = workbook.create_sheet(name)
    sheet.append([label for _, label in columns])
    for row in rows:
        sheet.append([row.get(key) for key, _ in columns])
    sheet.freeze_panes = "A2"
    sheet.auto_filter.ref = sheet.dimensions
    sheet.sheet_view.showGridLines = False
    sheet.row_dimensions[1].height = 34
    for cell in sheet[1]:
        cell.fill = PatternFill("solid", fgColor=NAVY)
        cell.font = Font(name="微软雅黑", color=WHITE, bold=True)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    for col, (key, label) in enumerate(columns, start=1):
        width = 14 if key in ("method", "date") else 22
        if key in ("method_name", "phase_label", "dayahead_solver_status", "status"):
            width = 32
        if key in ("window_start", "window_end", "issued_at", "interval_start", "interval_end"):
            width = 23
        sheet.column_dimensions[get_column_letter(col)].width = width
        for cells in sheet.iter_rows(min_row=2, min_col=col, max_col=col):
            cell = cells[0]
            cell.font = Font(name="微软雅黑", size=10)
            cell.alignment = Alignment(vertical="center", wrap_text=isinstance(cell.value, str))
            if cell.row % 2 == 0:
                cell.fill = PatternFill("solid", fgColor=PALE)
            if isinstance(cell.value, (float, int)) and not isinstance(cell.value, bool):
                if "gap" in key:
                    cell.number_format = "0.000000%"
                elif "yuan" in key or key == "new_contract_cost":
                    cell.number_format = '#,##0.00'
                elif "kwh" in key or key.endswith("_kw"):
                    cell.number_format = '#,##0.0000'
                elif "seconds" in key:
                    cell.number_format = '0.000'
                else:
                    cell.number_format = '0'
            if ("status" in key and cell.value not in (None, "optimal_within_requested_gap")) or (key == "all_constraints_passed" and cell.value is False):
                cell.fill = PatternFill("solid", fgColor=AMBER)
    return sheet


def notes_sheet(workbook, notes):
    sheet = workbook.create_sheet("阅读说明")
    sheet.append(["事项", "说明"])
    for label, text in notes:
        sheet.append([label, text])
    sheet.column_dimensions["A"].width = 26
    sheet.column_dimensions["B"].width = 115
    sheet.freeze_panes = "B2"
    sheet.sheet_view.showGridLines = False
    for row in sheet:
        for cell in row:
            cell.font = Font(name="微软雅黑", size=11, bold=cell.row == 1, color=WHITE if cell.row == 1 else "25354A")
            cell.alignment = Alignment(vertical="top", wrap_text=True)
            cell.fill = PatternFill("solid", fgColor=NAVY if cell.row == 1 else (PALE if cell.row % 2 == 0 else WHITE))
        sheet.row_dimensions[row[0].row].height = 48 if row[0].row > 1 else 28
    return sheet


def verify_summaries(summaries, stage1, stage2, stage3):
    source = {
        "same_contract_local": stage1,
        "dayahead_local": stage2,
        "continuous_all": stage3,
        "continuous_test": [r for r in stage3 if r["stage"] == "test"],
    }
    max_error = 0.0
    for row in summaries:
        group = [r for r in source[row["phase"]] if r["method"] == row["method"]]
        if not group or int(row["days"]) != len(group):
            raise AssertionError("Summary row count does not agree with daily source")
        for key in SUM_FIELDS:
            max_error = max(max_error, close(math.fsum(r[key] for r in group), row[key], f'{row["phase"]}/{row["method"]}/{key}'))
        expected_unproven = sum(r["dayahead_solver_status"] != "optimal_within_requested_gap" for r in group)
        if int(row["unproven_plan_days"]) != expected_unproven:
            raise AssertionError("Unproven solver count differs from daily source")
        if not all(r["planner_checks_passed"] and r["controller_checks_passed"] for r in group):
            raise AssertionError("A daily trajectory has failed recorded checks")
    return max_error


def aggregate_initial(rows, expected_windows=28):
    groups = {}
    for row in rows:
        groups.setdefault((row["method"], float(row["experiment_initial_soc"])), []).append(row)
    output = []
    for (method, initial), group in sorted(groups.items()):
        group.sort(key=lambda r: r["date"])
        if len(group) != expected_windows:
            raise AssertionError("Initial-state sensitivity is not exactly the declared 28 windows")
        close(group[0]["initial_soc_kwh"], initial, "Sensitivity first state", ENERGY_TOL)
        for a, b in zip(group, group[1:]):
            close(a["final_soc_kwh"], b["initial_soc_kwh"], "Sensitivity state continuity", ENERGY_TOL)
        output.append({
            "method": method, "experiment_initial_soc": initial, "windows": len(group),
            "window_start": group[0]["window_start"], "window_end": group[-1]["window_end"],
            **{key: math.fsum(r[key] for r in group) for key in SUM_FIELDS},
            "final_soc_kwh": group[-1]["final_soc_kwh"],
            "unproven_plan_days": sum(r["dayahead_solver_status"] != "optimal_within_requested_gap" for r in group),
        })
    reference = {r["method"]: r for r in output if r["experiment_initial_soc"] == 6000}
    for row in output:
        base = reference[row["method"]]
        row["cash_change_vs_6000_yuan"] = row["cash_cost_yuan"] - base["cash_cost_yuan"]
        row["inventory_adjusted_change_vs_6000_yuan"] = row["inventory_adjusted_cost_yuan"] - base["inventory_adjusted_cost_yuan"]
    return output


def collect_solver_logs(results, daily_index):
    rows = []
    for method in METHODS:
        logs = read_json(results / "continuous" / f"{method}_solver.json")
        for log in logs:
            day = daily_index[(method, log["date"])]
            close(log["new_contract_cost"], day["planned_cost_yuan"], "New-contract solver/daily fee")
            if not log["checks"]["passed"]:
                raise AssertionError("A solver log has failed checks")
            predicted = log.get("forecast_soc_at_window_start")
            if predicted is None:
                predicted = []
            rows.append({
                "method": method, "date": log["date"], "issued_at": day["issued_at"],
                "decision_soc_kwh": log["midnight_observed_soc"],
                "forecast_start_min_kwh": min(predicted) if predicted else None,
                "forecast_start_max_kwh": max(predicted) if predicted else None,
                "actual_start_kwh": log.get("executed_soc_at_window_start"),
                "old_prefix_g_kwh": log.get("fixed_prefix_kwh"),
                "new_contract_kwh": log["new_contract_kwh"], "new_contract_cost": log["new_contract_cost"],
                "status": log["status"], "gap": log["gap"],
                "checks_passed": log["checks"]["passed"],
                "max_violation_kwh": log["checks"]["max_violation_kwh"],
                "history_days": log["risk"]["history_days"],
                "fallback": log["risk"].get("fallback", False),
                "solve_seconds": day["dayahead_solve_seconds"],
            })
    return rows


def stream_trace(path, method, daily_rows, expected_windows):
    """Keep just one 144-row day in memory, not the full interval dataframe."""
    day_index = {r["date"]: r for r in daily_rows}
    plans, stats, episodes = [], [], []
    current_date, current_rows, episode = None, [], None
    previous_end = None
    previous_soc = None
    estimated_locations = []
    count = 0
    max_money_error = 0.0

    def finish_day(date, rows):
        nonlocal max_money_error
        if len(rows) != 144 or date not in day_index:
            raise AssertionError(f"{method}/{date}: expected exactly 144 trace rows")
        daily = day_index[date]
        start = dt.datetime.fromisoformat(rows[0]["interval_start"])
        end = dt.datetime.fromisoformat(rows[-1]["interval_end"])
        if start.time() != dt.time(0, 10) or end - start != dt.timedelta(days=1):
            raise AssertionError("Trace is not a 00:10 to next 00:10 window")
        amounts = {
            "planned_cost_yuan": math.fsum(r["price_yuan_per_kwh"] * r["g_kwh"] for r in rows),
            "emergency_cost_yuan": math.fsum(5*r["price_yuan_per_kwh"] * r["emergency_kwh"] for r in rows),
            "cash_cost_yuan": math.fsum(r["cash_cost_yuan"] for r in rows),
            "planned_kwh": math.fsum(r["g_kwh"] for r in rows),
            "emergency_kwh": math.fsum(r["emergency_kwh"] for r in rows),
            "unused_paid_kwh": math.fsum(r["unused_paid_kwh"] for r in rows),
            "curtailed_pv_kwh": math.fsum(r["curtailed_pv_kwh"] for r in rows),
        }
        for key, value in amounts.items():
            max_money_error = max(max_money_error, close(value, daily[key], f"{method}/{date}/{key}"))
        close(rows[0]["soc_start_kwh"], daily["initial_soc_kwh"], "Window start SOC", ENERGY_TOL)
        close(rows[-1]["soc_end_kwh"], daily["final_soc_kwh"], "Window end SOC", ENERGY_TOL)
        plans.append([date] + [r["g_kwh"] for r in rows])
        stats.append({
            "date": date, "window_start": start.isoformat(sep=" "), "window_end": end.isoformat(sep=" "),
            **amounts, "charge_kwh": math.fsum(r["charge_kwh"] for r in rows),
            "discharge_kwh": math.fsum(r["discharge_kwh"] for r in rows),
            "initial_soc_kwh": rows[0]["soc_start_kwh"], "final_soc_kwh": rows[-1]["soc_end_kwh"],
            "actual_estimated_intervals": sum(r["actual_estimated"] for r in rows),
            "dayahead_solver_status": daily["dayahead_solver_status"], "dayahead_mip_gap": daily["dayahead_mip_gap"],
        })

    with Path(path).open(encoding="utf-8-sig", newline="") as handle:
        for source in csv.DictReader(handle):
            row = {k: typed(v) for k, v in source.items()}
            if row["method"] != method:
                raise AssertionError("Method label differs from trace filename")
            a = dt.datetime.fromisoformat(row["interval_start"])
            b = dt.datetime.fromisoformat(row["interval_end"])
            if b-a != dt.timedelta(minutes=10):
                raise AssertionError("Trace interval has wrong duration")
            if previous_end is not None:
                if a != previous_end:
                    raise AssertionError("Trace timestamps have a gap/overlap")
                close(row["soc_start_kwh"], previous_soc, "Continuous trace SOC", ENERGY_TOL)
            close(row["cash_cost_yuan"], row["price_yuan_per_kwh"]*(row["g_kwh"]+5*row["emergency_kwh"]), "Trace single-slot fee")
            if row["actual_estimated"]:
                estimated_locations.append(row["interval_start"])
            if current_date is not None and row["plan_date"] != current_date:
                finish_day(current_date, current_rows)
                current_rows = []
            current_date = row["plan_date"]
            current_rows.append(row)
            if row["emergency_kwh"] > ENERGY_TOL:
                if episode is None:
                    episode = {"interval_start": a.isoformat(sep=" "), "interval_end": b.isoformat(sep=" "),
                               "intervals": 0, "duration_minutes": 0, "emergency_kwh": 0.,
                               "emergency_cost_yuan": 0., "peak_equivalent_kw": 0., "estimated_intervals": 0}
                episode["interval_end"] = b.isoformat(sep=" ")
                episode["intervals"] += 1
                episode["duration_minutes"] += 10
                episode["emergency_kwh"] += row["emergency_kwh"]
                episode["emergency_cost_yuan"] += 5*row["price_yuan_per_kwh"]*row["emergency_kwh"]
                episode["peak_equivalent_kw"] = max(episode["peak_equivalent_kw"], row["emergency_kwh"]*6)
                episode["estimated_intervals"] += int(row["actual_estimated"])
            elif episode is not None:
                episodes.append(episode)
                episode = None
            previous_end, previous_soc = b, row["soc_end_kwh"]
            count += 1
    if current_rows:
        finish_day(current_date, current_rows)
    if episode is not None:
        episodes.append(episode)
    if len(plans) != expected_windows or count != expected_windows*144:
        raise AssertionError("Incomplete full-period trace")
    close(stats[0]["initial_soc_kwh"], 6000, "User-prescribed experiment initial SOC", ENERGY_TOL)
    final_interval_start = (dt.datetime.fromisoformat(stats[-1]["window_end"]) - dt.timedelta(minutes=10)).isoformat()
    if estimated_locations != [final_interval_start]:
        raise AssertionError("Exactly the final interval must be marked estimated")
    return plans, stats, episodes, {
        "method": method, "windows": len(plans), "trace_rows": count,
        "estimated_intervals": len(estimated_locations), "max_daily_reconciliation_error": max_money_error,
        "planned_kwh": math.fsum(r["planned_kwh"] for r in stats),
        "cash_cost_yuan": math.fsum(r["cash_cost_yuan"] for r in stats),
        "source_sha256": digest(path),
    }


def write_only_sheet(book, name, headers, rows, widths=None):
    sheet = book.create_sheet(name)
    sheet.freeze_panes = "B2" if name == "购电计划_kWh" else "A2"
    sheet.sheet_view.showGridLines = False
    sheet.row_dimensions[1].height = 34
    for i in range(1, len(headers)+1):
        sheet.column_dimensions[get_column_letter(i)].width = widths[i-1] if widths else (15 if i == 1 else 21)
    cells = []
    for value in headers:
        cell = WriteOnlyCell(sheet, value)
        cell.font = Font(name="微软雅黑", bold=True, color=WHITE)
        cell.fill = PatternFill("solid", fgColor=NAVY)
        cell.alignment = Alignment(wrap_text=True, vertical="center", horizontal="center")
        cells.append(cell)
    sheet.append(cells)
    count = 0
    for row in rows:
        cells = []
        for column_index, value in enumerate(row):
            cell = WriteOnlyCell(sheet, value)
            cell.font = Font(name="微软雅黑", size=10)
            if isinstance(value, (float, int)) and not isinstance(value, bool):
                cell.number_format = '#,##0.0000'
            cell.alignment = Alignment(vertical="center", wrap_text=isinstance(value, str))
            if count % 2 == 0:
                cell.fill = PatternFill("solid", fgColor=PALE)
            if name == "阅读说明" and row[0] == "完整逐段策略" and column_index == 1:
                cell.hyperlink = str(value)
                cell.font = Font(name="微软雅黑", size=10, color="0563C1", underline="single")
            cells.append(cell)
        if name == "阅读说明":
            sheet.row_dimensions[count+2].height = 48
        sheet.append(cells)
        count += 1
    sheet.auto_filter.ref = f"A1:{get_column_letter(len(headers))}{count+1}"
    return sheet


def plan_headers():
    def clock(minutes):
        prefix = "次日" if minutes >= 1440 else ""
        minutes %= 1440
        return f"{prefix}{minutes//60:02d}:{minutes%60:02d}"
    return ["窗口归属日期"] + [f"{clock(t*10)}—{clock(t*10+10)}" for t in range(1,145)]


def write_strategy(path, method, plans, stats, episodes, companion, notes):
    book = Workbook(write_only=True)
    write_only_sheet(book, "阅读说明", ["事项", "说明"], notes + [("方案", f"{method}：{METHODS[method]}"),
        ("完整逐段策略", str(companion)), ("完整CSV字段", "每10分钟购电、充放电、应急、弃光、未用合同、SOC、费用和估计标记。")], widths=[25,115])
    write_only_sheet(book, "购电计划_kWh", plan_headers(), plans)
    columns = [x for x in DAILY_COLUMNS if x[0] in stats[0]] + [("charge_kwh", "实际充电量(kWh)"), ("discharge_kwh", "实际放电量(kWh)")]
    write_only_sheet(book, "逐日执行与SOC", [v for _,v in columns], [[r.get(k) for k,_ in columns] for r in stats])
    episode_columns = [
        ("interval_start", "连续应急开始"), ("interval_end", "连续应急结束"),
        ("intervals", "连续十分钟段数"), ("duration_minutes", "持续分钟"),
        ("emergency_kwh", "紧急购电量(kWh)"), ("emergency_cost_yuan", "紧急购电费(元)"),
        ("peak_equivalent_kw", "最高段等效功率(kW)"), ("estimated_intervals", "含估计端点段数"),
    ]
    write_only_sheet(book, "连续应急时段", [v for _,v in episode_columns], [[r[k] for k,_ in episode_columns] for r in episodes])
    book.save(path)


def inspect_workbook(path, expected_plan_windows=None, expected_g=None):
    book = load_workbook(path, read_only=True, data_only=False)
    counts = {}
    plan_sum = 0.0
    try:
        for sheet in book:
            count = 0
            for row in sheet.iter_rows(values_only=True):
                for value in row:
                    if isinstance(value, str) and (value in ERROR_VALUES or value.startswith("=")):
                        raise AssertionError(f"Unexpected formula/error in {path.name}/{sheet.title}")
                if sheet.title == "购电计划_kWh" and count > 0:
                    if len(row) != 145:
                        raise AssertionError("Purchase wide table must have one date and 144 energy columns")
                    plan_sum += math.fsum(float(x) for x in row[1:])
                count += 1
            counts[sheet.title] = count
        if expected_plan_windows is not None:
            if counts.get("购电计划_kWh") != expected_plan_windows+1:
                raise AssertionError("Purchase workbook has wrong window count")
            close(plan_sum, expected_g, "Workbook purchase total", 1e-3)
    finally:
        book.close()
    return counts


def build(results, out, expected_windows=334):
    started = perf_counter()
    results, out = Path(results), Path(out)
    required = ["summary.json", "comparison_summary.csv", "stage1_same_contract_daily.csv",
                "stage2_dayahead_daily.csv", "stage3_continuous_daily.csv",
                "initial_soc_sensitivity_daily.csv", "final_interval_sensitivity.csv", "frozen_parameters.json"]
    for name in required:
        if not (results/name).exists():
            raise FileNotFoundError(f"Completed run required; missing {results/name}")
    summary = read_json(results/"summary.json")
    if summary.get("data_role") != "supplied_forecasts_with_endpoint_averaged_actuals":
        raise ValueError("This report requires supplied forecasts, not synthetic experiment outputs")
    start, end = map(dt.datetime.fromisoformat, summary["dates"])
    if end-start != dt.timedelta(days=expected_windows):
        raise ValueError("Summary does not cover the expected complete window horizon")
    if summary["estimated_actual_intervals"] != 1:
        raise AssertionError("Expected only the final missing-endpoint interval to be estimated")
    stage1 = read_csv(results/"stage1_same_contract_daily.csv")
    stage2 = read_csv(results/"stage2_dayahead_daily.csv")
    stage3 = read_csv(results/"stage3_continuous_daily.csv")
    summaries = read_csv(results/"comparison_summary.csv")
    json_periods = {(r["phase"], r["method"]): r for r in summary["periods"]}
    for row in summaries:
        counterpart = json_periods[(row["phase"], row["method"])]
        for field in SUM_FIELDS:
            close(row[field], counterpart[field], f"CSV/JSON summary agreement: {field}")
    for row in summaries:
        row["phase_label"] = PHASES[row["phase"]]
        row["method_name"] = METHODS[row["method"]]
    reconciliation = verify_summaries(summaries, stage1, stage2, stage3)
    daily_index = {(r["method"], r["date"]): r for r in stage3}
    if len(daily_index) != 4*expected_windows or len(stage3) != len(daily_index):
        raise AssertionError("Continuous daily rows are incomplete or duplicated")
    solver_rows = collect_solver_logs(results, daily_index)
    if len(solver_rows) != 4*expected_windows:
        raise AssertionError("Continuous solver logs are incomplete")
    initial = aggregate_initial(read_csv(results/"initial_soc_sensitivity_daily.csv"))
    boundary = read_csv(results/"final_interval_sensitivity.csv")
    frozen = read_json(results/"frozen_parameters.json")
    for method in METHODS:
        candidates = [r for r in boundary if r["method"] == method]
        if {r["boundary_method"] for r in candidates} != {"hold", "linear2", "ols6"}:
            raise AssertionError("Boundary sensitivity must contain all three declared methods")
        hold = next(r for r in candidates if r["boundary_method"] == "hold")
        method_summary = next(r for r in summaries if r["phase"] == "continuous_all" and r["method"] == method)
        close(hold["total_cash_yuan"], method_summary["cash_cost_yuan"], "Hold boundary/full-period bill")
        for row in candidates:
            row["cash_change_vs_hold_yuan"] = row["total_cash_yuan"] - hold["total_cash_yuan"]
    notes = [
        ("数据性质", "本次使用用户提供的负载与光伏预测、附件2原始数据；不是合成数据。预测生成过程仍以团队来源声明为条件。"),
        ("覆盖范围", f"{start:%Y-%m-%d %H:%M} 至 {end:%Y-%m-%d %H:%M}，共{expected_windows}个00:10至次日00:10窗口。"),
        ("预测口径", "本日00:00—00:10预测列已删除；每窗保留144个区间平均功率，包含次日00:00—00:10。预测均值不再相邻平均。"),
        ("实际口径", "附件2为瞬时节点：本行前143个区间取相邻端点均值，最后区间跨到下一日首00:10节点；不是把原单点当区间均值。"),
        ("最后一段", "2026-01-01 00:10右端节点缺失，主结果用末节点保持估计；仅最后10分钟标estimated，另列2点线性与6点OLS敏感性。"),
        ("初始储电量", "6000 kWh是用户指定的首个00:10窗口统一实验初态，不冒称题目给定2月1日00:10观测值；另做前28窗初态敏感性。"),
        ("零点决策", "继续在00:00定新合同。规划联算旧合同00:00—00:10前缀与新144段，只用该前缀预测；先固定新合同再执行前缀，旧合同仅付一次。"),
        ("功率与费用", "区间平均功率×1/6得到kWh；g、充放电量已是kWh不再除以6。费用=计划购电费＋5倍电价紧急购电费。"),
        ("电价近似", "附件1瞬时电价先周期补00:00节点，再取相邻端点均价；采用区间均价结算近似。"),
        ("日内反馈", "当前区间均值用于模拟段内快速反馈，不等于零点或段初已知未来十分钟实值。"),
        ("比较范围", "同g A/B和同MPC B/C/D为各窗独立同初态实验；连续执行才把SOC逐窗传递。不能把前者累计当连续年运行。"),
        ("参数冻结", f"裕量分位数={frozen['selected_quantile']}；生效日={frozen['effective_from']}。场景数={frozen['config']['scenarios']}为预设值，不声称已优化。"),
        ("优化目标与现金", "库存修正费用只作可比性评价；随机MILP的整日场景回补具有预见性近似，规划目标不能替代实际滚动现金费用。"),
        ("提交模板", "本工作簿是00:10窗口策略与研究结果，不是自然日0:00/24:00的result2提交模板。请勿把窗口SOC/账目直接贴成自然日指标。"),
        ("数值核验", "金额从逐段CSV重新累加，逐日对账并核对阶段汇总；保留求解Gap和未证最优状态，未加入隐藏平局成本。"),
    ]
    out.mkdir(parents=True, exist_ok=True)
    companions = out/"逐段策略CSV"
    companions.mkdir(exist_ok=True)
    trace_audits = []
    workbook_checks = {}
    for method in METHODS:
        source = results/"continuous"/f"{method}_trace.csv"
        days = sorted([r for r in stage3 if r["method"] == method], key=lambda r:r["date"])
        plans, stats, episodes, audit = stream_trace(source, method, days, expected_windows)
        companion = companions/f"方案{method}_完整逐段策略.csv"
        shutil.copy2(source, companion)
        path = out/f"方案{method}_完整策略.xlsx"
        write_strategy(path, method, plans, stats, episodes, companion.relative_to(out), notes)
        workbook_checks[path.name] = inspect_workbook(path, expected_windows, audit["planned_kwh"])
        audit["emergency_episode_count"] = len(episodes)
        trace_audits.append(audit)
        print(f"Checked strategy workbook: {method}; {len(plans)} windows", flush=True)

    book = Workbook()
    book.remove(book.active)
    notes_sheet(book, notes)
    clean_sheet(book, "方法汇总", SUMMARY_COLUMNS, summaries)
    clean_sheet(book, "连续逐日", DAILY_COLUMNS, stage3)
    clean_sheet(book, "同g_AB", DAILY_COLUMNS, stage1)
    clean_sheet(book, "同MPC_BCD", DAILY_COLUMNS, stage2)
    initial_columns = [
        ("method", "方案"), ("experiment_initial_soc", "实验初态(kWh)"), ("windows", "敏感性连续窗口数"),
        ("window_start", "开始"), ("window_end", "结束"),
        ("planned_cost_yuan", "计划费(元)"), ("emergency_cost_yuan", "紧急费(元)"),
        ("cash_cost_yuan", "28窗现金费用(元)"), ("inventory_adjusted_cost_yuan", "库存修正费用(元)"),
        ("final_soc_kwh", "第28窗末SOC(kWh)"),
        ("cash_change_vs_6000_yuan", "相对6000初态现金差(元)"),
        ("inventory_adjusted_change_vs_6000_yuan", "相对6000库存修正差(元)"),
        ("unproven_plan_days", "未证达到请求Gap窗口数"),
    ]
    clean_sheet(book, "初SOC敏感性_前28窗", initial_columns, initial)
    boundary_columns = [
        ("method", "方案"), ("boundary_method", "边界估计方法"),
        ("interval_start", "末段开始"), ("interval_end", "末段结束"),
        ("load_right_endpoint_kw", "估计右端负载(kW)"), ("pv_right_endpoint_kw", "估计右端光伏(kW)"),
        ("load_mean_kw", "末段平均负载(kW)"), ("pv_mean_kw", "末段平均光伏(kW)"),
        ("last_interval_cash_yuan", "最后一段现金费(元)"),
        ("last_interval_emergency_yuan", "最后一段紧急费(元)"),
        ("total_cash_yuan", "全周期现金费(元)"), ("cash_change_vs_hold_yuan", "相对hold费用差(元)"),
        ("final_soc_kwh", "末段后SOC(kWh)"), ("estimated", "该段使用估计端点"),
    ]
    clean_sheet(book, "末段估计敏感性", boundary_columns, boundary)
    gap_columns = [
        ("method", "方案"), ("date", "新窗口归属日期"), ("issued_at", "决策时间"),
        ("decision_soc_kwh", "决策所用SOC(kWh)"),
        ("forecast_start_min_kwh", "预测00:10SOC最小值(kWh)"), ("forecast_start_max_kwh", "预测00:10SOC最大值(kWh)"),
        ("actual_start_kwh", "执行到00:10实际SOC(kWh)"), ("old_prefix_g_kwh", "前缀已付合同(kWh)"),
        ("new_contract_kwh", "新合同电量(kWh)"), ("new_contract_cost", "新合同费用(元)"),
        ("status", "日前求解状态"), ("gap", "相对Gap"), ("checks_passed", "物理检查通过"),
        ("max_violation_kwh", "最大约束误差(kWh)"), ("history_days", "完整历史窗口数"),
        ("fallback", "回退点预测"), ("solve_seconds", "日前求解秒数"),
    ]
    clean_sheet(book, "求解Gap", gap_columns, solver_rows)
    metric_rows = [dict(zip(("key","name","unit","meaning"), row)) for row in METRICS]
    dictionary = clean_sheet(book, "指标字典", [("key","原始字段"),("name","中文名称"),("unit","单位"),("meaning","含义与边界")], metric_rows)
    dictionary.column_dimensions["A"].width = 45
    dictionary.column_dimensions["B"].width = 25
    dictionary.column_dimensions["D"].width = 85
    summary_path = out/"问题二_计算结果.xlsx"
    book.save(summary_path)
    workbook_checks[summary_path.name] = inspect_workbook(summary_path)
    with (out/"中文指标字典.csv").open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["原始字段","中文名称","单位","含义与边界"])
        writer.writerows(METRICS)
    with (out/"阅读说明.md").open("w", encoding="utf-8") as handle:
        handle.write("# 第二问计算结果与完整策略\n\n")
        for label, text in notes:
            handle.write(f"**{label}：**{text}\n\n")
        handle.write("`问题二_计算结果.xlsx`汇总方法、逐日执行、两类公平对照、敏感性及Gap。\n\n")
        handle.write("每份`方案A/B/C/D_完整策略.xlsx`包含144段购电宽表、实际逐日SOC与连续应急段；同名完整逐段CSV位于`逐段策略CSV`文件夹。\n")
    audit = {
        "source_role": summary["data_role"], "synthetic": False,
        "source_summary_sha256": digest(results/"summary.json"),
        "window_start": start.isoformat(), "window_end": end.isoformat(),
        "expected_windows": expected_windows, "cash_reconciliation_tolerance_yuan": MONEY_TOL,
        "max_summary_daily_reconciliation_error": reconciliation,
        "trace_checks": trace_audits, "workbook_row_counts": workbook_checks,
        "all_checks_passed": True,
        "expense_basis": "window accounting; final estimated interval retained and labelled; not a natural-day result2 template",
        "elapsed_seconds": perf_counter()-started,
    }
    with (out/"报表核验.json").open("w", encoding="utf-8") as handle:
        json.dump(audit, handle, ensure_ascii=False, indent=2)
    print(json.dumps(audit, ensure_ascii=False, indent=2))
    return audit


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT/"results/final_team")
    parser.add_argument("--out", type=Path, default=ROOT/"results/final_team/中文报表")
    parser.add_argument("--expected-windows", type=int, default=334)
    args = parser.parse_args()
    build(args.results, args.out, args.expected_windows)


if __name__ == "__main__":
    main()
