"""Explicitly synthetic engineering fixture; never a competition cost result."""
import datetime as dt
from pathlib import Path
import json
import numpy as np
from input_io import write_csv,FORECAST_FIELDS,ACTUAL_FIELDS

def generate(out,days=40,seed=20260911):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    rng=np.random.default_rng(seed)
    hours=np.arange(145)/6
    solar=np.maximum(np.sin(np.pi*(hours-6)/12),0)
    solar[hours>=18]=0
    forecast,actual=[],[]
    for i in range(days):
        zero=dt.datetime(2030,1,1)+dt.timedelta(days=i)
        load_f=4400+450*np.sin(2*np.pi*(hours-8)/24)+700*np.exp(-((hours-19)/2.5)**2)
        load_f+=250*np.cos(2*np.pi*i/7)
        pv_f=(8200+500*np.sin(i/3))*solar
        # Forecast is defined before generating the realized disturbances.
        load_bias=rng.normal(70,230)
        cloud_error=rng.normal(-.025,.20)
        ar=np.zeros(145)
        for t in range(1,145):ar[t]=.85*ar[t-1]+rng.normal(0,80)
        load_a=np.maximum(load_f+load_bias+ar,0)
        pv_a=np.maximum(pv_f*(1+cloud_error)+solar*rng.normal(0,80,145),0)
        for t in range(145):
            a=zero+dt.timedelta(minutes=10*t);b=a+dt.timedelta(minutes=10)
            forecast.append(dict(plan_date=zero.date().isoformat(),issued_at=zero.isoformat(),
                interval_start=a.isoformat(),interval_end=b.isoformat(),
                load_forecast_kw=float(load_f[t]),pv_forecast_kw=float(pv_f[t])))
            if t<144:
                actual.append(dict(interval_start=a.isoformat(),interval_end=b.isoformat(),
                    load_actual_kw=float(load_a[t]),pv_actual_kw=float(pv_a[t])))
    write_csv(out/'synthetic_forecasts.csv',forecast,FORECAST_FIELDS)
    write_csv(out/'synthetic_actuals.csv',actual,ACTUAL_FIELDS)
    (out/'synthetic_manifest.json').write_text(json.dumps({
        'role':'synthetic_engineering_fixture_not_competition_results','seed':seed,'days':days,
        'dates':'fictional 2030 dates','data_generation':'fixed known mean profiles, then sampled correlated disturbances',
        'disclaimer':'Tests code and experiment order only; no real model ranking or monetary savings claim.'},indent=2),encoding='utf-8')
    return out/'synthetic_forecasts.csv',out/'synthetic_actuals.csv'
