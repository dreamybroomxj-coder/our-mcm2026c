"""Fixed-contract battery dispatch, with causal receding-horizon control.

All time-slot quantities (g, load, pv, c, d, e, v, r, w) are kWh.
Prices are yuan/kWh; battery state is internal stored energy in kWh.
An input slot represents ten minutes. This module never infers timestamps,
generates a contract, adds a forecast margin, or learns parameters from actuals.

``simulate_day`` reveals only the current actual observation to the controller.
Future inputs remain the forecast supplied at midnight. Real-time observation
within each slot is an explicit simulation assumption. ``offline_oracle`` is a
separate, noncausal benchmark that may access the entire actual trajectory.
"""

from __future__ import annotations

from dataclasses import dataclass
import os
from time import perf_counter
from typing import Literal

import numpy as np
from scipy.optimize import linprog
from scipy.sparse import coo_matrix


Terminal = Literal["shortfall", "value", "none"]
Method = Literal["greedy", "mpc_soft", "mpc_value", "mpc_none"]


@dataclass(frozen=True)
class Battery:
    """Battery parameters. The power rating applies on the microgrid side."""

    low: float = 1200.0
    high: float = 10800.0
    power_kw: float = 5000.0
    eta_c: float = float(os.environ.get("MCM_BATTERY_ETA", "0.9"))
    eta_d: float = float(os.environ.get("MCM_BATTERY_ETA", "0.9"))

    def __post_init__(self) -> None:
        values = (self.low, self.high, self.power_kw, self.eta_c, self.eta_d)
        if not all(np.isfinite(v) for v in values):
            raise ValueError("Battery parameters must be finite.")
        if not 0 <= self.low < self.high:
            raise ValueError("Require 0 <= low < high.")
        if self.power_kw <= 0:
            raise ValueError("power_kw must be positive.")
        if not 0 < self.eta_c <= 1 or not 0 < self.eta_d <= 1:
            raise ValueError("Charge/discharge efficiency must be in (0, 1].")

    @property
    def rate(self) -> float:
        """Maximum external charge or discharge energy per ten-minute slot."""
        return self.power_kw / 6.0


DEFAULT_BATTERY = Battery()
PHYSICAL_TOL = 1e-5
LP_TOL = 1e-8


def _vector(value, name: str, n: int | None = None) -> np.ndarray:
    a = np.asarray(value, dtype=float)
    if a.ndim != 1 or a.size == 0:
        raise ValueError(f"{name} must be a nonempty one-dimensional array.")
    if n is not None and a.size != n:
        raise ValueError(f"{name} has {a.size} entries, expected {n}.")
    if not np.isfinite(a).all() or np.any(a < 0):
        raise ValueError(f"{name} must contain only finite nonnegative values.")
    return a.copy()


def _initial_state(s0: float, b: Battery) -> float:
    s0 = float(s0)
    if not np.isfinite(s0) or not b.low - PHYSICAL_TOL <= s0 <= b.high + PHYSICAL_TOL:
        raise ValueError("Initial battery state is outside operating bounds.")
    # Repeated solves can leave boundary deviations at machine precision.
    return float(np.clip(s0, b.low, b.high))


def _terminal_parameters(terminal: str, weight: float, s_ref: float) -> None:
    if terminal not in ("shortfall", "value", "none"):
        raise ValueError(f"Unknown terminal mode: {terminal}")
    if not np.isfinite(weight) or weight < 0:
        raise ValueError("Terminal weight must be finite and nonnegative.")
    if not np.isfinite(s_ref):
        raise ValueError("s_ref must be finite.")


def _account_surplus(g, pv, load, c, d):
    """PV-first bookkeeping: unused paid energy first, then PV curtailment."""
    surplus = np.maximum(g + pv - load, 0.0)
    deficit = np.maximum(load - g - pv, 0.0)
    e = np.maximum(deficit - d, 0.0)
    w = np.maximum(surplus - c, 0.0)
    v = np.minimum(w, g)
    r = w - v
    return e, v, r, w


def solve_horizon(
    g,
    load,
    pv,
    price,
    s0: float,
    b: Battery = DEFAULT_BATTERY,
    terminal: Terminal = "shortfall",
    weight: float = 0.0,
    s_ref: float = 6000.0,
) -> dict:
    """Solve a remaining-horizon dispatch LP for a fixed purchase contract.

    There are n charges, n discharges, n end-of-slot states, and optionally one
    terminal shortfall variable. Emergency purchase satisfies e = D - d and is
    eliminated algebraically. Simultaneous charge/discharge is prevented by the
    disjoint surplus/deficit bounds, rather than binary variables.

    ``shortfall`` objective: sum(5 * price * e) + weight * max(s_ref - s[-1], 0).
    ``value`` objective: sum(5 * price * e) - weight * s[-1].
    ``none`` objective: sum(5 * price * e).
    The returned objective includes the emergency-cost constant eliminated in
    the LP. No tie-breaking cost is added. An unsuccessful solver raises an
    exception instead of silently using an unverified or altered policy.
    """
    g = _vector(g, "g")
    n = len(g)
    load = _vector(load, "load", n)
    pv = _vector(pv, "pv", n)
    price = _vector(price, "price", n)
    s0 = _initial_state(s0, b)
    _terminal_parameters(terminal, weight, s_ref)

    surplus = np.maximum(g + pv - load, 0.0)
    deficit = np.maximum(load - g - pv, 0.0)
    c_upper = np.minimum(surplus, b.rate)
    d_upper = np.minimum(deficit, b.rate)
    has_shortfall = terminal == "shortfall"
    nvar = 3 * n + int(has_shortfall)
    cost = np.zeros(nvar)
    cost[n : 2 * n] = -5.0 * price
    if terminal == "value":
        cost[3 * n - 1] = -weight
    elif has_shortfall:
        cost[-1] = weight

    # -eta_c*c_t + d_t/eta_d + S_(t+1) - S_t = 0.
    # The initial S_0 is a known RHS rather than an optimization variable.
    slots = np.arange(n)
    rows = np.concatenate((slots, slots, slots, slots[1:]))
    cols = np.concatenate((slots, n + slots, 2 * n + slots, 2 * n + slots[:-1]))
    vals = np.concatenate((
        np.full(n, -b.eta_c), np.full(n, 1.0 / b.eta_d),
        np.ones(n), -np.ones(max(n - 1, 0)),
    ))
    a_eq = coo_matrix((vals, (rows, cols)), shape=(n, nvar)).tocsc()
    rhs = np.zeros(n)
    rhs[0] = s0
    bounds = (
        [(0.0, float(cap)) for cap in c_upper]
        + [(0.0, float(cap)) for cap in d_upper]
        + [(b.low, b.high)] * n
    )
    a_ub = None
    rhs_ub = None
    if has_shortfall:
        # xi >= s_ref - S_N.
        bounds.append((0.0, None))
        a_ub = coo_matrix(
            ([-1.0, -1.0], ([0, 0], [3 * n - 1, nvar - 1])),
            shape=(1, nvar),
        ).tocsc()
        rhs_ub = np.array([-s_ref])

    started = perf_counter()
    result = linprog(
        cost,
        A_eq=a_eq,
        b_eq=rhs,
        A_ub=a_ub,
        b_ub=rhs_ub,
        bounds=bounds,
        method="highs",
        options={
            "primal_feasibility_tolerance": LP_TOL,
            "dual_feasibility_tolerance": LP_TOL,
        },
    )
    seconds = perf_counter() - started
    if not result.success:
        raise RuntimeError(f"Dispatch LP failed ({result.status}): {result.message}")

    # Remove only numerical excursions beyond the explicit per-slot bounds.
    c = np.clip(result.x[:n], 0.0, c_upper)
    d = np.clip(result.x[n : 2 * n], 0.0, d_upper)
    s = np.concatenate(([s0], s0 + np.cumsum(b.eta_c * c - d / b.eta_d)))
    if s.min() < b.low - PHYSICAL_TOL or s.max() > b.high + PHYSICAL_TOL:
        raise RuntimeError("LP actions fail the independently accumulated SOC check.")
    e, v, r, w = _account_surplus(g, pv, load, c, d)
    emergency_cost = float(5.0 * price @ e)
    terminal_shortfall = max(float(s_ref - s[-1]), 0.0)
    terminal_objective = (
        weight * terminal_shortfall if terminal == "shortfall"
        else -weight * float(s[-1]) if terminal == "value"
        else 0.0
    )
    objective = emergency_cost + terminal_objective
    solver_objective = float(result.fun + 5.0 * price @ deficit)
    if abs(objective - solver_objective) > 1e-5 * max(1.0, abs(objective)):
        raise RuntimeError("Recomputed objective does not agree with the LP objective.")
    return {
        "c": c, "d": d, "e": e, "v": v, "r": r, "w": w, "s": s,
        "objective": objective,
        "fees_emergency": emergency_cost,
        "terminal": terminal,
        "weight": float(weight),
        "s_ref": float(s_ref),
        "terminal_shortfall": terminal_shortfall,
        "terminal_objective": float(terminal_objective),
        "success": True,
        "status_code": int(result.status),
        "message": str(result.message),
        "solve_seconds": seconds,
        "iterations": int(result.nit),
    }


def greedy_step(
    g: float,
    load: float,
    pv: float,
    s0: float,
    b: Battery = DEFAULT_BATTERY,
) -> dict:
    """Charge maximum available surplus or discharge maximum feasible deficit."""
    for name, value in (("g", g), ("load", load), ("pv", pv)):
        if not np.isfinite(value) or value < 0:
            raise ValueError(f"{name} must be finite and nonnegative.")
    s0 = _initial_state(s0, b)
    surplus = max(g + pv - load, 0.0)
    deficit = max(load - g - pv, 0.0)
    c = min(surplus, b.rate, max((b.high - s0) / b.eta_c, 0.0))
    d = min(deficit, b.rate, max((s0 - b.low) * b.eta_d, 0.0))
    s_next = s0 + b.eta_c * c - d / b.eta_d
    e, v, r, w = _account_surplus(g, pv, load, c, d)
    return {
        "c": float(c), "d": float(d), "e": float(e),
        "v": float(v), "r": float(r), "w": float(w),
        "s_next": float(s_next),
    }


def simulate_day(
    g,
    load_actual,
    pv_actual,
    load_forecast,
    pv_forecast,
    price,
    s0: float,
    method: Method = "greedy",
    weight: float = 0.0,
    s_ref: float = 6000.0,
    b: Battery = DEFAULT_BATTERY,
) -> dict:
    """Execute fixed purchases under greedy or receding-horizon control.

    In every solve, only position zero of a fresh forecast suffix is replaced
    with the current actual observation. The optimizer receives no future actual
    values. The contract array is copied and never changed. A general length is
    accepted to support small verification examples; a full day has 144 slots.
    """
    terminal_for_method = {
        "greedy": "none", "mpc_soft": "shortfall",
        "mpc_value": "value", "mpc_none": "none",
    }
    if method not in terminal_for_method:
        raise ValueError(f"Unknown control method: {method}")
    terminal = terminal_for_method[method]
    _terminal_parameters(terminal, weight, s_ref)
    g = _vector(g, "g")
    n = len(g)
    load_actual = _vector(load_actual, "load_actual", n)
    pv_actual = _vector(pv_actual, "pv_actual", n)
    load_forecast = _vector(load_forecast, "load_forecast", n)
    pv_forecast = _vector(pv_forecast, "pv_forecast", n)
    price = _vector(price, "price", n)
    s = np.empty(n + 1)
    s[0] = _initial_state(s0, b)
    actions = {key: np.empty(n) for key in ("c", "d", "e", "v", "r", "w")}
    solve_seconds = 0.0
    solve_count = 0
    for t in range(n):
        if method == "greedy":
            step = greedy_step(g[t], load_actual[t], pv_actual[t], s[t], b)
            for key in actions:
                actions[key][t] = step[key]
            s[t + 1] = step["s_next"]
        else:
            remaining_load = load_forecast[t:].copy()
            remaining_pv = pv_forecast[t:].copy()
            remaining_load[0] = load_actual[t]
            remaining_pv[0] = pv_actual[t]
            horizon = solve_horizon(
                g[t:], remaining_load, remaining_pv, price[t:], s[t],
                b=b, terminal=terminal, weight=weight, s_ref=s_ref,
            )
            for key in actions:
                actions[key][t] = horizon[key][0]
            s[t + 1] = horizon["s"][1]
            solve_seconds += horizon["solve_seconds"]
            solve_count += 1

    fees_plan = float(price @ g)
    fees_emergency = float(5.0 * price @ actions["e"])
    out = {
        **actions, "s": s, "g": g, "price": price,
        "load": load_actual, "pv": pv_actual,
        "load_forecast": load_forecast, "pv_forecast": pv_forecast,
        "method": method, "terminal": terminal, "weight": float(weight),
        "s_ref": float(s_ref), "fees_plan": fees_plan,
        "fees_emergency": fees_emergency, "fees_total": fees_plan + fees_emergency,
        "solve_count": solve_count, "solve_seconds": solve_seconds,
        "success": True, "status_code": 0,
    }
    out["checks"] = check_trajectory(out, b)
    return out


def offline_oracle(
    g,
    load_actual,
    pv_actual,
    price,
    s0: float,
    b: Battery = DEFAULT_BATTERY,
    terminal: Terminal = "none",
    weight: float = 0.0,
    s_ref: float = 6000.0,
) -> dict:
    """Noncausal benchmark using all supplied future actuals in one LP.

    Compare its objective only with the same initial state, horizon, and terminal
    valuation/constraint. With terminal='none', its emergency cash cost is a
    lower bound for causal controllers on exactly this fixed-contract horizon.
    It must never be presented as an implementable online control policy.
    """
    g = _vector(g, "g")
    n = len(g)
    load_actual = _vector(load_actual, "load_actual", n)
    pv_actual = _vector(pv_actual, "pv_actual", n)
    price = _vector(price, "price", n)
    out = solve_horizon(
        g, load_actual, pv_actual, price, s0, b, terminal, weight, s_ref,
    )
    fees_plan = float(price @ g)
    out.update({
        "g": g, "price": price, "load": load_actual, "pv": pv_actual,
        "fees_plan": fees_plan,
        "fees_total": fees_plan + out["fees_emergency"],
        "method": "offline_oracle", "noncausal": True, "solve_count": 1,
    })
    out["checks"] = check_trajectory(out, b)
    return out


def check_trajectory(out: dict, b: Battery = DEFAULT_BATTERY) -> dict:
    """Independently check slot energy accounting and battery constraints."""
    g, load, pv, s = (np.asarray(out[key]) for key in ("g", "load", "pv", "s"))
    c, d, e, v, r, w = (np.asarray(out[key]) for key in ("c", "d", "e", "v", "r", "w"))
    surplus = np.maximum(g + pv - load, 0.0)
    deficit = np.maximum(load - g - pv, 0.0)
    violations = {
        "energy_balance_kwh": float(np.max(np.abs(g - v + pv - r + d + e - load - c))),
        "soc_recursion_kwh": float(np.max(np.abs(np.diff(s) - b.eta_c * c + d / b.eta_d))),
        "soc_lower_kwh": float(max(b.low - np.min(s), 0.0)),
        "soc_upper_kwh": float(max(np.max(s) - b.high, 0.0)),
        "charge_power_kwh": float(max(np.max(c) - b.rate, 0.0)),
        "discharge_power_kwh": float(max(np.max(d) - b.rate, 0.0)),
        "charge_surplus_kwh": float(max(np.max(c - surplus), 0.0)),
        "discharge_deficit_kwh": float(max(np.max(d - deficit), 0.0)),
        "simultaneous_charge_discharge_kwh": float(np.max(np.minimum(c, d))),
        "unused_contract_bound_kwh": float(max(np.max(v - g), 0.0)),
        "curtailment_bound_kwh": float(max(np.max(r - pv), 0.0)),
        "w_split_kwh": float(np.max(np.abs(w - v - r))),
        "emergency_deficit_kwh": float(np.max(np.abs(e - deficit + d))),
        "negative_energy_kwh": float(max(-np.min(np.concatenate((c, d, e, v, r, w))), 0.0)),
    }
    worst = max(violations.values())
    return {**violations, "max_violation_kwh": worst, "tolerance_kwh": PHYSICAL_TOL, "passed": bool(worst <= PHYSICAL_TOL)}
