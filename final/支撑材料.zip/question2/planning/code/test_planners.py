"""Synthetic-only planner verification; no claimed contest-data performance."""

import unittest
from unittest.mock import patch

import numpy as np
from scipy.optimize import Bounds, LinearConstraint, milp as scipy_milp

from control import Battery
from planners import solve_plan


def direct_deterministic_model(load, pv, price, initial, battery, kappa, target):
    """Independent Q1-style deterministic MILP, with soft rather than fixed end.

    It has no emergency/unused-contract variables and no scenario formulation.
    Positive prices should make its objective match the one-scenario planner.
    """
    n = len(load)
    size = 6 * n + 1
    a = np.zeros((4 * n + 1, size))
    lower = np.zeros(size)
    upper = np.full(size, np.inf)
    integer = np.zeros(size)
    cost = np.zeros(size)
    row_lower = np.full(4 * n + 1, -np.inf)
    row_upper = np.zeros(4 * n + 1)
    for t in range(n):
        g, c, d, r, s, u = range(6 * t, 6 * t + 6)
        cost[g] = price[t]
        upper[c] = upper[d] = battery.rate
        upper[r] = pv[t]
        lower[s], upper[s] = battery.low, battery.high
        upper[u], integer[u] = 1, 1
        a[4 * t, [g, c, d, r]] = [1, -1, 1, -1]
        row_lower[4 * t] = row_upper[4 * t] = load[t] - pv[t]
        a[4 * t + 1, [c, d, s]] = [-battery.eta_c, 1 / battery.eta_d, 1]
        if t:
            a[4 * t + 1, s - 6] = -1
        row_lower[4 * t + 1] = row_upper[4 * t + 1] = initial if t == 0 else 0
        a[4 * t + 2, [c, u]] = [1, -battery.rate]
        a[4 * t + 3, [d, u]] = [1, battery.rate]
        row_upper[4 * t + 3] = battery.rate
    a[-1, [-3, -1]] = [-1, -1]
    row_upper[-1] = -target
    cost[-1] = kappa
    result = scipy_milp(
        cost, integrality=integer, bounds=Bounds(lower, upper),
        constraints=LinearConstraint(a, row_lower, row_upper),
        options={"mip_rel_gap": 1e-9, "time_limit": 30},
    )
    if not result.success:
        raise AssertionError(result.message)
    return result


class PlannerTests(unittest.TestCase):
    def setUp(self):
        self.b = Battery(low=0, high=100, power_kw=600, eta_c=1, eta_d=1)

    def test_interval_energy_is_not_divided_twice(self):
        # A caller converts 600 kW over ten minutes to 100 kWh exactly once.
        result = solve_plan([600 / 6], [0], [2], 0, b=self.b, terminal_weight=0, s_ref=0)
        self.assertAlmostEqual(result["g"][0], 100)
        self.assertAlmostEqual(result["plan_cost"], 200)
        self.assertAlmostEqual(self.b.rate, 600 / 6)

    def test_emergency_cost_is_five_times_price(self):
        # High load occurs with probability .1. Each extra ordinary kWh costs 1,
        # but saves only .1*5=.5 expected yuan, so the optimal contract is zero.
        result = solve_plan(
            [10], [0], [1], 0, b=self.b, terminal_weight=0, s_ref=0,
            scenario_load_kwh=[[0], [100]], scenario_pv_kwh=[[0], [0]],
            probabilities=[.9, .1], mip_rel_gap=1e-9,
        )
        self.assertAlmostEqual(result["g"][0], 0)
        np.testing.assert_allclose(result["e"].ravel(), [0, 100], atol=1e-6)
        self.assertAlmostEqual(result["expected_emergency_cost"], 50)
        self.assertAlmostEqual(result["objective"], 50)

    def test_initial_state_is_shared_and_terminal_is_not_a_hard_reset(self):
        result = solve_plan([50], [0], [1], 50, b=self.b, terminal_weight=0, s_ref=0)
        self.assertEqual(result["s"].shape, (1, 2))
        self.assertAlmostEqual(result["s"][0, 0], 50)
        self.assertAlmostEqual(result["s"][0, -1], 0)
        self.assertAlmostEqual(result["plan_cost"], 0)

    def test_soft_terminal_penalty_is_separate_from_cash(self):
        # A target above the physical maximum makes unavoidable penalty obvious.
        result = solve_plan([0], [0], [1], 100, b=self.b, terminal_weight=2, s_ref=150)
        self.assertAlmostEqual(result["plan_cost"], 0)
        self.assertAlmostEqual(result["expected_emergency_cost"], 0)
        self.assertAlmostEqual(result["terminal_cost"], 100)
        self.assertAlmostEqual(result["objective"], 100)

    def test_single_scenario_matches_independent_direct_model(self):
        rng = np.random.default_rng(12091)
        for seed in range(10):
            with self.subTest(seed=seed):
                n = 8
                load = rng.uniform(10, 170, n)
                pv = rng.uniform(0, 140, n)
                price = rng.uniform(.2, 2, n)
                battery = Battery(low=0, high=220, power_kw=600, eta_c=.9, eta_d=.9)
                initial = 80
                kappa = .7
                unified = solve_plan(load, pv, price, initial, b=battery, terminal_weight=kappa, s_ref=100, mip_rel_gap=1e-9)
                independent = direct_deterministic_model(load, pv, price, initial, battery, kappa, 100)
                self.assertLess(abs(unified["objective"] - independent.fun), 1e-5)
                self.assertLess(np.max(unified["e"]), 1e-5)
                self.assertTrue(unified["checks"]["passed"])

    def test_shared_contract_beats_average_of_per_scenario_optima(self):
        demands = np.array([0., 100.])
        probabilities = np.array([.5, .5])
        combined = solve_plan(
            [50], [0], [1], 0, b=self.b, terminal_weight=0, s_ref=0,
            scenario_load_kwh=demands[:, None], scenario_pv_kwh=np.zeros((2, 1)),
            probabilities=probabilities, mip_rel_gap=1e-9,
        )
        # Enumerate all integer contracts; this one-slot example has no initial
        # stored energy, so its expected expense has this independent formula.
        grid = np.arange(101.)
        costs = grid + 5 * np.maximum(demands[:, None] - grid[None, :], 0).T @ probabilities
        self.assertAlmostEqual(combined["objective"], float(np.min(costs)))
        separate = [solve_plan([x], [0], [1], 0, b=self.b, terminal_weight=0, s_ref=0) for x in demands]
        mean_contract = float(sum(p * r["g"][0] for p, r in zip(probabilities, separate)))
        averaged_cost = mean_contract + 5 * float(probabilities @ np.maximum(demands - mean_contract, 0))
        self.assertAlmostEqual(mean_contract, 50)
        self.assertAlmostEqual(averaged_cost, 175)
        self.assertAlmostEqual(combined["objective"], 100)
        self.assertLess(combined["objective"], averaged_cost)

    def test_scenarios_obey_execution_rules_and_all_balances(self):
        rng = np.random.default_rng(38217)
        scenarios_load = rng.uniform(0, 180, (3, 8))
        scenarios_pv = rng.uniform(0, 140, (3, 8))
        result = solve_plan(
            scenarios_load.mean(axis=0), scenarios_pv.mean(axis=0),
            rng.uniform(.2, 2, 8), 55, b=self.b, terminal_weight=5, s_ref=100,
            scenario_load_kwh=scenarios_load, scenario_pv_kwh=scenarios_pv,
            probabilities=[.2, .3, .5], mip_rel_gap=1e-8,
        )
        self.assertEqual(result["g"].shape, (8,))
        self.assertEqual(result["c"].shape, (3, 8))
        np.testing.assert_allclose(result["s"][:, 0], 55)
        surplus = np.maximum(result["g"] + scenarios_pv - scenarios_load, 0)
        deficit = np.maximum(scenarios_load - result["g"] - scenarios_pv, 0)
        self.assertLessEqual(np.max(result["c"] - surplus), 1e-5)
        self.assertLessEqual(np.max(result["d"] - deficit), 1e-5)
        self.assertLess(np.max(np.minimum(result["e"], result["c"])), 1e-5)
        np.testing.assert_allclose(result["e"], deficit - result["d"], atol=1e-5)
        np.testing.assert_allclose(result["v"] + result["r"], surplus - result["c"], atol=1e-5)
        self.assertTrue(result["checks"]["passed"])

    def test_feasible_limit_solution_is_not_reported_as_proven(self):
        def limited(*args, **kwargs):
            result = scipy_milp(*args, **kwargs)
            result.status = 1
            result.success = False
            result.message = "Synthetic limit-status fixture with a valid incumbent"
            result.mip_gap = .25
            return result
        with patch("planners.milp", side_effect=limited):
            result = solve_plan([100], [0], [1], 0, b=self.b, terminal_weight=0, s_ref=0)
        self.assertEqual(result["status"], "feasible_unproven")
        self.assertFalse(result["optimality_proven"])
        self.assertTrue(result["checks"]["passed"])

    def test_invalid_scenarios_and_probabilities_fail_explicitly(self):
        with self.assertRaises(ValueError):
            solve_plan([1], [0], [1], 0, b=self.b, scenario_load_kwh=[[1]])
        with self.assertRaises(ValueError):
            solve_plan([1], [0], [1], 0, b=self.b, scenario_load_kwh=[[1], [2]], scenario_pv_kwh=[[0], [0]], probabilities=[.2, .5])
        with self.assertRaises(ValueError):
            solve_plan([1], [0], [1], 101, b=self.b)


if __name__ == "__main__":
    unittest.main()
