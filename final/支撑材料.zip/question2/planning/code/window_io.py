"""Confirmed shifted windows: issue at 00:00, cover 00:10 to next 00:10."""
import datetime as dt
import json
from pathlib import Path
import numpy as np
from openpyxl import load_workbook
from input_io import interval_header,clock_minute,timestamp,read_price,sha,write_csv

ROOT=Path(__file__).resolve().parents[1]


def read_team_forecasts(path):
    w=load_workbook(path,read_only=True,data_only=True)
    out={};meta=[];dates_ref=None
    try:
        for sheet,key in [('XGBoost_负载','load_f'),('自适应加权_光伏','pv_f')]:
            s=w[sheet];rows=list(s.values)
            bounds=[interval_header(x) for x in rows[0][1:]]
            if bounds!=[(i*10,i*10+10) for i in range(1,145)]:
                raise ValueError('Expected 144 intervals from 00:10 through next-day 00:10')
            dates=[timestamp(r[0]).date() for r in rows[1:]]
            if dates!=sorted(set(dates)) or any(b-a!=dt.timedelta(days=1) for a,b in zip(dates,dates[1:])):
                raise ValueError('Forecast dates must be unique and consecutive')
            if dates_ref is not None and dates!=dates_ref:raise ValueError('Load/PV dates differ')
            dates_ref=dates
            v=np.asarray([r[1:] for r in rows[1:]],float)
            if v.shape!=(len(dates),144) or not np.isfinite(v).all() or (v<0).any():
                raise ValueError('Missing/invalid forecast power')
            out[key]=v;meta.append({'sheet':sheet,'days':len(dates),'intervals':144})
    finally:w.close()
    out['dates']=dates_ref
    out['window_start']=[dt.datetime.combine(d,dt.time(0,10)) for d in dates_ref]
    out['window_end']=[a+dt.timedelta(days=1) for a in out['window_start']]
    out['issued_at']=[a-dt.timedelta(minutes=10) for a in out['window_start']]
    out['metadata']={'forecast_sha256':sha(path),'sheets':meta,'value_kind':'interval_mean_kw',
        'issue_basis':'user-declared midnight issuance; forecast generator not independently audited',
        'window':'D 00:10 to D+1 00:10, 144 intervals',
        'current_day_00_00_column_deleted':True,'next_day_first_interval_retained':True,
        'actual_feedback':'current interval mean is fast intra-interval feedback approximation'}
    return out


def _last_endpoint_candidates(last_nodes):
    """Estimate the one unavailable next ten-minute instantaneous endpoint.

    The returned endpoint is clipped nonnegative before averaging. Every method
    uses only the final observed nodes: hold-last, two-node linear extrapolation,
    or an OLS line through the final six equally spaced instantaneous samples.
    These estimates are not measured data or a claim of midnight periodicity.
    """
    y=np.asarray(last_nodes,float)
    if y.shape!=(144,) or not np.isfinite(y).all() or (y<0).any():
        raise ValueError('Boundary extrapolation requires 144 valid instantaneous nodes')
    x=np.arange(6,dtype=float)
    recent=y[-6:]
    slope=float(np.sum((x-x.mean())*(recent-recent.mean()))/np.sum((x-x.mean())**2))
    return {
        'hold':float(y[-1]),
        'linear2':float(max(2*y[-1]-y[-2],0.)),
        'ols6':float(max(recent.mean()+slope*(6-x.mean()),0.)),
    }


def attach_actuals(data,path,*,confirmed_instantaneous=False):
    """Convert confirmed instantaneous nodes to shifted-window interval means.

    Source row D contains 144 instantaneous nodes from D 00:10 through D+1
    00:00. The first 143 interval means use adjacent nodes in that row. The
    final interval is (D+1 00:00 + next row's D+1 00:10)/2. The next row is
    selected by its true date; the first row of a year is never recycled.

    Only the source file's final missing right endpoint may be estimated. Its
    default is hold-last, with linear2/ols6 retained for a separately labelled
    boundary sensitivity. actual_estimated marks intervals containing an
    estimated endpoint. Even unmarked interval means use the declared linear
    interpolation approximation between measured instantaneous endpoints.
    """
    if not confirmed_instantaneous:
        raise ValueError('Explicit confirmed_instantaneous=True is required for instantaneous actual nodes')
    wanted=list(data['dates'])
    if not wanted:
        raise ValueError('No forecast windows supplied for actual alignment')
    w=load_workbook(path,read_only=True,data_only=True)
    source={}
    source_dates=None
    try:
        for sheet,key in [('小区负载','load_a'),('光伏发电实际功率','pv_a')]:
            rows=list(w[sheet].values)
            if len(rows)<2 or [clock_minute(v) for v in rows[0][1:]]!=list(range(10,1441,10)):
                raise ValueError('Actual source must contain 00:10 through next 00:00 instantaneous nodes')
            dates=[timestamp(r[0]).date() for r in rows[1:]]
            if dates!=sorted(set(dates)):
                raise ValueError('Actual source dates must be unique and sorted')
            if any(b-a!=dt.timedelta(days=1) for a,b in zip(dates,dates[1:])):
                raise ValueError('Missing interior day in instantaneous actual source')
            if source_dates is not None and dates!=source_dates:
                raise ValueError('Load and PV instantaneous source dates differ')
            source_dates=dates
            values=np.asarray([r[1:] for r in rows[1:]],float)
            if values.shape!=(len(dates),144) or not np.isfinite(values).all() or (values<0).any():
                raise ValueError('Missing or invalid instantaneous actual powers')
            source[key]={day:values[i] for i,day in enumerate(dates)}
    finally:
        w.close()
    if any(day not in source['load_a'] for day in wanted):
        raise ValueError('Forecast window date missing from actual instantaneous source')
    estimated=np.zeros((len(wanted),144),dtype=bool)
    converted={key:np.empty((len(wanted),144)) for key in ('load_a','pv_a')}
    boundary_candidates={}
    estimated_intervals=[]
    last_source_day=source_dates[-1]
    for i,day in enumerate(wanted):
        following_day=day+dt.timedelta(days=1)
        endpoint_missing=following_day not in source['load_a']
        if endpoint_missing and day!=last_source_day:
            raise ValueError('A missing interior right endpoint cannot be replaced by a year-boundary estimate')
        for key in ('load_a','pv_a'):
            nodes=source[key][day]
            converted[key][i,:143]=(nodes[:-1]+nodes[1:])/2
            if not endpoint_missing:
                right_endpoint=float(source[key][following_day][0])
            else:
                estimates=_last_endpoint_candidates(nodes)
                right_endpoint=estimates['hold']
                label='load' if key=='load_a' else 'pv'
                for method,endpoint in estimates.items():
                    candidate=boundary_candidates.setdefault(method,{})
                    candidate[f'{label}_right_endpoint_kw']=float(endpoint)
                    candidate[f'{label}_mean_kw']=float((nodes[-1]+endpoint)/2)
                    candidate['interval_start']=dt.datetime.combine(following_day,dt.time()).isoformat()
                    candidate['interval_end']=dt.datetime.combine(following_day,dt.time(0,10)).isoformat()
                    candidate['estimated']=True
                    candidate['value_kind']='interval_mean_kw_from_observed_left_and_estimated_right_endpoint'
            converted[key][i,143]=(nodes[-1]+right_endpoint)/2
        if endpoint_missing:
            estimated[i,143]=True
            estimated_intervals.append({
                'window_date':str(day),'window_index':i,'interval_index':143,
                'interval_start':dt.datetime.combine(following_day,dt.time()).isoformat(),
                'interval_end':dt.datetime.combine(following_day,dt.time(0,10)).isoformat(),
                'missing_node_at':dt.datetime.combine(following_day,dt.time(0,10)).isoformat(),
                'default_method':'hold','status':'estimated, not observed',
            })
    data.update(converted)
    data['actual_estimated']=estimated
    data['actual_observed_endpoints']=~estimated
    data['last_boundary_candidates']=boundary_candidates
    metadata=data.setdefault('metadata',{})
    metadata.update({
        'actual_sha256':sha(path),
        'actual_source_kind':'instantaneous_power_kw',
        'actual_value_kind':'interval_mean_kw_from_adjacent_instantaneous_nodes',
        'actual_mapping':'first 143 adjacent-node means; last mean crosses to next calendar row first 00:10 node',
        'actual_mean_assumption':'linear interpolation/trapezoidal mean between ten-minute instantaneous endpoints',
        'actual_available_at':'interval_end when both endpoint observations exist (no reporting latency assumed)',
        'actual_estimated_mask_field':'actual_estimated: bool[windows,144]; true means a right endpoint was estimated',
        'actual_observed_mask_field':'actual_observed_endpoints: inverse mask; both endpoints observed, interval mean remains an interpolation approximation',
        'estimated_actual_interval_count':int(estimated.sum()),
        'estimated_actual_intervals':estimated_intervals,
        'last_boundary_default':'hold last observed instantaneous node; not a periodic copy from year start',
        'last_boundary_candidates':boundary_candidates,
    })
    return data


def prices(path):
    natural,meta=read_price(path)
    # Price endpoints already averaged; rotate once, never rotate values alone.
    return np.r_[natural[1:],natural[0]],meta


def write_canonical(data,out):
    out=Path(out);out.mkdir(exist_ok=True,parents=True)
    records=[]
    for i,date in enumerate(data['dates']):
        for t in range(144):
            a=data['window_start'][i]+dt.timedelta(minutes=10*t)
            r={'plan_date':str(date),'issued_at':data['issued_at'][i].isoformat(),
                'interval_start':a.isoformat(),'interval_end':(a+dt.timedelta(minutes=10)).isoformat(),
                'load_forecast_kw':data['load_f'][i,t],'pv_forecast_kw':data['pv_f'][i,t]}
            if 'load_a' in data:r.update(load_actual_kw=data['load_a'][i,t],pv_actual_kw=data['pv_a'][i,t],
                actual_estimated=bool(data['actual_estimated'][i,t]))
            records.append(r)
    write_csv(out/'canonical_intervals.csv',records)
    (out/'input_audit.json').write_text(json.dumps(data['metadata'],ensure_ascii=False,indent=2),encoding='utf-8')


def risk_inputs(data,i,method,config,q):
    issued=data['issued_at'][i]
    history=[j for j in range(i) if data['window_end'][j]<=issued][-config['window']:]
    lf,pf=data['load_f'][i].copy(),data['pv_f'][i].copy()
    meta={'method':method,'history_indices':history,'history_days':len(history),
        'issued_at':str(issued),'fallback':False,'previous_incomplete_window_excluded':i>0}
    if method in ('A','B'):return lf,pf,None,None,meta
    if len(history)<config['min_history']:
        meta.update(fallback=True,fallback_reason='insufficient fully completed forecast windows')
        return lf,pf,None,None,meta
    lr=data['load_a'][history]-data['load_f'][history]
    pr=data['pv_a'][history]-data['pv_f'][history]
    if method=='C':
        margin=np.zeros(144) if q==0 else np.maximum(np.quantile(lr-pr,q,axis=0),0)
        meta.update(quantile=q,margin_kwh=float(margin.sum()/6))
        return lf+margin,pf,None,None,meta
    if method!='D':raise ValueError('Unknown method')
    rng=np.random.default_rng(config['seed']+1009*i)
    draw=rng.integers(len(history),size=config['scenarios'])
    sl=np.maximum(lf+lr[draw],0);sp=np.maximum(pf+pr[draw],0)
    dark=(pf==0)&np.all(data['pv_f'][history]==0,axis=0)&np.all(data['pv_a'][history]==0,axis=0)
    sp[:,dark]=0
    meta.update(scenario_history_indices=np.asarray(history)[draw].tolist(),
                scenarios=config['scenarios'],oracle_recourse_approximation=True)
    return lf,pf,sl,sp,meta
