"""Calibration scores become available only after their 00:10 window end."""
import datetime as dt
import unittest

from window_study import calibration_indices


def timeline(days=30):
    origin = dt.datetime(2025, 2, 1)
    issues = [origin + dt.timedelta(days=i) for i in range(days)]
    return {
        "issued_at": issues,
        "window_end": [x + dt.timedelta(days=1, minutes=10) for x in issues],
    }


class CalibrationCutoffTests(unittest.TestCase):
    def test_incomplete_previous_window_cannot_select_test_parameter(self):
        data = timeline()
        selected = calibration_indices(data, cut=24, minimum=14, tail=7)
        self.assertEqual(selected, [16, 17, 18, 19, 20, 21, 22])
        self.assertNotIn(23, selected)
        self.assertEqual(data["window_end"][23] - data["issued_at"][24],
                         dt.timedelta(minutes=10))
        self.assertTrue(all(data["window_end"][i] <= data["issued_at"][24]
                            for i in selected))

    def test_first_risk_enabled_day_is_not_yet_a_complete_score(self):
        data = timeline()
        # Window 15 can use 14 completed historical windows, but its own
        # score is unavailable at window 16's midnight decision.
        self.assertEqual(calibration_indices(data, cut=16, minimum=14, tail=7), [])
        self.assertEqual(calibration_indices(data, cut=17, minimum=14, tail=7), [15])


if __name__ == "__main__":
    unittest.main()
