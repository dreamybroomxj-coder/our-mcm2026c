"""Execute an observed prefix while retaining the full fixed-contract horizon.

All flows are kWh per ten-minute interval. Actual arrays contain exactly the
executed prefix, never padded future observations. At each step only its current
actual mean enters the LP; all later inputs remain the supplied forecast. This
is the explicitly declared fast within-interval feedback approximation.

The module has no timestamp rules. In the midnight-issue Q2 workflow a caller
can execute 143 old-window slots, formulate the next contract at midnight using
the measured state and old final contract slot, then execute that one old slot
against a 145-slot horizon consisting of old prefix plus the new 144 slots.
"""
from __future__ import annotations

from numbers import Integral
from time import perf_counter

import numpy as np

from control import (
    Battery, DEFAULT_BATTERY, PHYSICAL_TOL, _initial_state, _vector,
    check_trajectory, greedy_step,
)
from control_refined import solve_refined_horizon


def execute_prefix(
    method, g, load_actual, pv_actual, load_forecast, pv_forecast, price, s0,
    steps, terminal_weight=None, s_ref=6000., b: Battery = DEFAULT_BATTERY,
) -> dict:
    """Execute ``steps`` slots, considering all ``n`` forecast/contract slots.

    Require 1 <= steps <= n. g/forecasts/price have length n; each actual vector
    has exactly steps entries. ``mpc`` optimizes the full remaining suffix and
    implements only its first action. ``greedy`` maximizes feasible current
    charging/discharging. Both keep every supplied ordinary purchase fixed.

    The default kappa is min(full supplied price)/eta_c, held constant during
    the call. Its soft SOC target belongs to the *full* horizon end, which may
    lie after the executed prefix. Reported fees include only executed slots
    and never include terminal penalties or the unexecuted ordinary contract.

    Return g,c,d,e,v,r,w,price/load/pv with steps entries, s with steps+1 entries,
    the prefix cash fees, independent physical checks and solver timing.
    The caller connects subsequent execution by passing result['s'][-1].
    """
    if method not in ("greedy", "mpc"):
        raise ValueError("method must be 'greedy' or 'mpc'.")
    g = _vector(g, "g")
    n = len(g)
    if isinstance(steps, bool) or not isinstance(steps, Integral) or not 1 <= steps <= n:
        raise ValueError("steps must be an integer with 1 <= steps <= horizon length.")
    steps = int(steps)
    lf = _vector(load_forecast, "load_forecast", n)
    pf = _vector(pv_forecast, "pv_forecast", n)
    p = _vector(price, "price", n)
    # Exact prefix length is intentional: no future actuals are needed or used.
    la = _vector(load_actual, "load_actual", steps)
    pa = _vector(pv_actual, "pv_actual", steps)
    weight = float(np.min(p) / b.eta_c if terminal_weight is None else terminal_weight)
    if not np.isfinite(weight) or weight < 0 or not np.isfinite(s_ref):
        raise ValueError("Terminal weight/reference must be finite; weight >= 0.")
    fixed_contract = g.copy()
    s = np.empty(steps + 1)
    s[0] = _initial_state(s0, b)
    actions = {key: np.empty(steps) for key in ("c", "d", "e", "v", "r", "w")}
    solve_seconds = 0.
    solve_count = 0
    surplus_steps = 0
    primary_errors = []
    start = perf_counter()
    for t in range(steps):
        net = g[t] + pa[t] - la[t]
        if method == "greedy" or net >= 0:
            step = greedy_step(g[t], la[t], pa[t], s[t], b)
            for key in actions:
                actions[key][t] = step[key]
            if method == "mpc" and net > 0:
                surplus_steps += 1
        else:
            remaining_load = lf[t:].copy()
            remaining_pv = pf[t:].copy()
            remaining_load[0] = la[t]
            remaining_pv[0] = pa[t]
            horizon = solve_refined_horizon(
                g[t:], remaining_load, remaining_pv, p[t:], s[t],
                b=b, terminal="shortfall", weight=weight, s_ref=s_ref,
            )
            for key in actions:
                actions[key][t] = horizon[key][0]
            solve_seconds += horizon["solve_seconds"]
            solve_count += horizon["solve_count"]
            primary_errors.append(horizon["primary_cost_error_yuan"])
        # Independent accumulation from the actually executed first action.
        s[t + 1] = s[t] + b.eta_c * actions["c"][t] - actions["d"][t] / b.eta_d
        if s[t + 1] < b.low - PHYSICAL_TOL or s[t + 1] > b.high + PHYSICAL_TOL:
            raise RuntimeError("Executed prefix action violates battery state bounds.")
    prefix_price, prefix_g = p[:steps].copy(), g[:steps].copy()
    fees_plan = float(prefix_price @ prefix_g)
    fees_emergency = float(5. * prefix_price @ actions["e"])
    out = {
        **actions, "g": prefix_g, "s": s, "price": prefix_price,
        "load": la, "pv": pa, "load_forecast": lf[:steps].copy(),
        "pv_forecast": pf[:steps].copy(), "method": method,
        "fees_plan": fees_plan, "fees_emergency": fees_emergency,
        "fees_total": fees_plan + fees_emergency,
        "solve_seconds": solve_seconds, "solve_count": solve_count,
        "execution_seconds": perf_counter() - start,
        "horizon_steps": n, "executed_steps": steps,
        "unexecuted_steps": n - steps,
        "terminal": "shortfall" if method == "mpc" else "none",
        "terminal_weight": weight if method == "mpc" else 0.,
        "weight": weight if method == "mpc" else 0.,
        "s_ref": float(s_ref), "terminal_reference_boundary": n,
        "forced_surplus_charge_steps": surplus_steps,
        "max_primary_cost_error_yuan": max([abs(e) for e in primary_errors] or [0.]),
        "input_flow_units": "kWh_per_10min_interval",
        "observation_assumption": "current_interval_mean_as_fast_feedback_proxy",
        "future_inputs": "forecast_only_no_padded_actuals",
        "fee_scope": "executed_prefix_only_no_terminal_penalty",
        "success": True, "status_code": 0,
    }
    out["checks"] = check_trajectory(out, b)
    unchanged = bool(np.array_equal(g, fixed_contract))
    out["checks"]["full_fixed_contract_unchanged"] = unchanged
    out["checks"]["passed"] = bool(out["checks"]["passed"] and unchanged)
    if not out["checks"]["passed"]:
        raise RuntimeError(f"Prefix execution checks failed: {out['checks']}")
    return out
