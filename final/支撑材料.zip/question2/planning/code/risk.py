"""Historical same-origin residuals only; full-day paired bootstrap scenarios."""
import numpy as np

def historical_residuals(data,i,window=28):
    if not isinstance(window,int) or window<1 or not 0<=i<len(data['dates']):
        raise ValueError('History window must be positive and day index in range')
    first=max(0,i-window)
    # Each earlier target day has ended by this day's decision time.
    if any(day>=data['dates'][i] for day in data['dates'][first:i]):
        raise ValueError('Current/future day in residual history')
    return (data['load_a'][first:i]-data['load_f'][first:i],
            data['pv_a'][first:i]-data['pv_f'][first:i])

def build_risk_inputs(data,i,method,*,quantile=.8,window=28,min_history=14,
                      scenarios=8,seed=20260911):
    if method not in ('A','B','C','D'):
        raise ValueError('Unknown method')
    if not isinstance(min_history,int) or not 1<=min_history<=window:
        raise ValueError('Require 1 <= min_history <= window')
    if not 0<=quantile<1 or not isinstance(scenarios,int) or scenarios<1:
        raise ValueError('Invalid quantile or scenario count')
    lf,pf=data['load_f'][i].copy(),data['pv_f'][i].copy()
    lr,pr=historical_residuals(data,i,window)
    count=len(lr)
    meta={'method':method,'history_days':count,'window_days':window,'fallback':False,
          'residual_last_day':str(data['dates'][i-1]) if i else None}
    if method in ('A','B'):
        return lf,pf,None,None,meta
    if count<min_history:
        meta.update(fallback=True,fallback_reason='insufficient completed paired forecast days')
        return lf,pf,None,None,meta
    if method=='C':
        if not 0<=quantile<1:
            raise ValueError('quantile must be in [0,1)')
        margin=np.maximum(np.quantile(lr-pr,quantile,axis=0),0) if quantile else np.zeros_like(lf)
        meta.update(quantile=quantile,margin_kwh=float(margin.sum()/6))
        return lf+margin,pf,None,None,meta
    if method=='D':
        if scenarios<1:
            raise ValueError('Need at least one scenario')
        rng=np.random.default_rng(seed+i*1009)
        draw=rng.integers(0,count,size=scenarios)
        sl=np.maximum(lf[None,:]+lr[draw],0)
        sp=np.maximum(pf[None,:]+pr[draw],0)
        # Only impose a nighttime zero at slots which every available PV actual
        # and forecast marks zero. Do not infer a seasonal sunrise from the future.
        first=max(0,i-window)
        dark=(pf==0)&np.all(data['pv_a'][first:i]==0,axis=0)&np.all(data['pv_f'][first:i]==0,axis=0)
        sp[:,dark]=0
        meta.update(scenarios=scenarios,seed=seed+i*1009,
                    historical_day_indices=(draw+first).tolist(),
                    generation='paired whole-day residual bootstrap; clipped nonnegative',
                    oracle_recourse_approximation=True)
        return lf,pf,sl,sp,meta
    raise ValueError('Unknown method')
