"""Supplement the SOC sensitivity with an independent 6000-kWh, 28-window run.

The long main replay and its sensitivity CSV are never overwritten. All four
methods run sequentially with the frozen main-experiment parameters. Their last
interval uses the same one-step ending as the existing 1200/10800 experiments.
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import hashlib
import json
from pathlib import Path
import time

import window_study as study
from input_io import write_csv
from window_io import attach_actuals, prices, read_team_forecasts


ROOT = Path(__file__).resolve().parents[1]
WINDOWS = 28
INITIAL_SOC = 6000.


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def verify_output(out, method, daily, data):
    """Re-read actual output boundaries, cash and SOC continuity independently."""
    with (out / f"{method}_trace.csv").open(encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))
    if len(daily) != WINDOWS or len(rows) != WINDOWS * 144:
        raise AssertionError("The baseline must contain exactly 28 complete windows")
    if float(rows[0]["soc_start_kwh"]) != INITIAL_SOC:
        raise AssertionError("Wrong prescribed first state")
    if dt.datetime.fromisoformat(rows[0]["interval_start"]) != data["window_start"][0]:
        raise AssertionError("Wrong first interval")
    if dt.datetime.fromisoformat(rows[-1]["interval_end"]) != data["window_end"][WINDOWS - 1]:
        raise AssertionError("Wrong final interval")
    for left, right in zip(rows, rows[1:]):
        if left["interval_end"] != right["interval_start"]:
            raise AssertionError("Time discontinuity")
        if abs(float(left["soc_end_kwh"]) - float(right["soc_start_kwh"])) > 1e-5:
            raise AssertionError("State discontinuity")
    cash = sum(float(r["price_yuan_per_kwh"]) *
               (float(r["g_kwh"]) + 5 * float(r["emergency_kwh"])) for r in rows)
    stored_cash = sum(float(r["cash_cost_yuan"]) for r in rows)
    daily_cash = sum(float(r["cash_cost_yuan"]) for r in daily)
    if max(abs(cash - stored_cash), abs(cash - daily_cash)) > 1e-5:
        raise AssertionError("Trace/daily cash mismatch")
    if not all(r["planner_checks_passed"] and r["controller_checks_passed"] for r in daily):
        raise AssertionError("Physical check failed")
    logs = json.loads((out / f"{method}_solver.json").read_text(encoding="utf-8"))
    if len(logs) != WINDOWS or logs[-1]["date"] != str(data["dates"][WINDOWS - 1]):
        raise AssertionError("A 29th-window contract must not enter this experiment")
    return {"method": method, "windows": WINDOWS, "intervals": len(rows),
            "cash_cost_yuan": cash, "final_soc_kwh": float(rows[-1]["soc_end_kwh"]),
            "time_state_and_cash_checks_passed": True,
            "all_planner_and_controller_checks_passed": True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "results/final_team")
    parser.add_argument("--forecasts", type=Path, default=ROOT / "data/team_forecasts.xlsx")
    parser.add_argument("--actuals", type=Path, default=ROOT / "data/attachment2_original.xlsx")
    args = parser.parse_args()
    frozen_path = args.results / "frozen_parameters.json"
    frozen = json.loads(frozen_path.read_text(encoding="utf-8"))
    config = frozen["config"].copy()
    if float(config["initial_soc"]) != INITIAL_SOC:
        raise ValueError("This correction is specifically for the prescribed 6000-kWh baseline")
    q = float(frozen["selected_quantile"])
    data = attach_actuals(read_team_forecasts(args.forecasts), args.actuals,
                          confirmed_instantaneous=True)
    if len(data["dates"]) < WINDOWS:
        raise ValueError("At least 28 forecast windows are required")
    p, pm = prices(ROOT / "data/attachment1.xlsx")
    audit = json.loads((args.results / "input_audit.json").read_text(encoding="utf-8"))
    for key in ("forecast_sha256", "actual_sha256"):
        if data["metadata"][key] != audit[key]:
            raise ValueError(f"Input differs from main experiment: {key}")
    if pm["sha256"] != audit["price"]["sha256"]:
        raise ValueError("Price source differs from the main experiment")
    out = args.results / "initial_soc_6000_common_horizon"
    out.mkdir(parents=True, exist_ok=True)
    manifest = {
        "purpose": "Replace the long-replay slice with an independent 28-window 6000-kWh sensitivity baseline",
        "status": "running", "config": config, "selected_quantile": q,
        "windows": WINDOWS, "initial_soc_kwh": INITIAL_SOC,
        "window_start": str(data["window_start"][0]),
        "window_end": str(data["window_end"][WINDOWS - 1]),
        "terminal_rule": "Last interval is one-step execution, without a 29th-window contract or forecast horizon",
        "parameter_rule": "Use frozen main parameters; retain preset q before its original effective date; no retuning",
        "execution": "A, B, C, D sequentially in a single process",
        "main_334_window_results_modified": False,
        "main_initial_soc_sensitivity_csv_modified": False,
        "frozen_parameters_sha256": sha(frozen_path),
        "inputs": {"forecast_sha256": data["metadata"]["forecast_sha256"],
                   "actual_sha256": data["metadata"]["actual_sha256"], "price_sha256": pm["sha256"]},
        "code_sha256": {name: sha(ROOT / "code" / name) for name in
                        ("window_study.py", "window_io.py", "window_control.py",
                         "planners.py", "control.py", "control_refined.py")},
        "completed_methods": [], "verification": [],
    }
    started = time.perf_counter()
    study.json_write(out / "correction_manifest.json", manifest)
    study.initialize(data, p, config)
    supplemental = []
    for method in ("A", "B", "C", "D"):
        manifest["current_method"] = method
        study.json_write(out / "correction_manifest.json", manifest)
        print(f"Independent common-horizon baseline: {method}, S0=6000, 28 windows", flush=True)
        result = study.continuous_job((method, q, str(out), WINDOWS, INITIAL_SOC))
        manifest["verification"].append(verify_output(out, method, result["daily"], data))
        manifest["completed_methods"].append(method)
        supplemental.extend(dict(row, experiment_initial_soc=INITIAL_SOC) for row in result["daily"])
        study.json_write(out / "correction_manifest.json", manifest)
    supplemental.sort(key=lambda r: (r["date"], r["method"]))
    supplement_path = args.results / "initial_soc_6000_common_horizon_daily.csv"
    write_csv(supplement_path, supplemental)
    manifest.update(status="complete", current_method=None,
                    elapsed_seconds=time.perf_counter() - started,
                    supplemental_csv=str(supplement_path),
                    supplemental_rows=len(supplemental),
                    merge_status="Not merged: wait for the main run to finish before replacing its 6000-kWh sensitivity rows")
    study.json_write(out / "correction_manifest.json", manifest)
    print(json.dumps({"status": "complete", "rows": len(supplemental),
                      "supplement": str(supplement_path)}, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
