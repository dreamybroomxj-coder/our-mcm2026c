"""Unified day-ahead MILP for point forecasts, margins and finite scenarios.

All supplied and returned flows are interval ENERGY (kWh), not power. The caller
must align actual intervals and convert interval-average kW to kWh once. This
module does not handle timestamps, estimate forecast residuals, choose margins,
or access actual future data. It accepts an already constructed scenario set.

The ordinary purchase vector g is shared by every scenario. Scenario recourse
can foresee that scenario's entire day, so its expected cost is a two-stage
approximation, not the cash expense of a causal intraday controller. Ordinary
energy may be unused without refund; emergency energy may only fill a deficit.
"""

from __future__ import annotations

from time import perf_counter
import warnings

import numpy as np
from scipy.optimize import Bounds, LinearConstraint, linprog, milp
from scipy.sparse import coo_matrix, vstack

from control import Battery, DEFAULT_BATTERY


PHYSICAL_TOL_KWH = 1e-5
INTEGRALITY_TOL = 1e-5
OBJECTIVE_TOL_YUAN = 1e-4
MIP_FEASIBILITY_TOL = 1e-9
LP_FEASIBILITY_TOL = 1e-9


def _fixed_mode_polish(objective, matrix, row_lower, row_upper, lower, upper,
                       integer, incumbent, time_limit):
    """Reoptimize continuous variables with exact rounded incumbent modes.

    The original objective, rows and continuous-variable bounds are retained.
    In particular g stays optimizable except for an inherited fixed prefix.
    This removes big-M leakage caused by almost-integral binary values; it does
    not weaken physical tolerances or round charge/discharge flows by hand.
    """
    mask = integer.astype(bool)
    rounded = np.rint(incumbent[mask])
    integer_error = float(np.max(np.abs(incumbent[mask] - rounded)))
    if (integer_error > INTEGRALITY_TOL or np.any(rounded < lower[mask])
            or np.any(rounded > upper[mask])):
        raise RuntimeError(f"MILP incumbent has unacceptable integrality error: {integer_error}")
    fixed_lower, fixed_upper = lower.copy(), upper.copy()
    fixed_lower[mask] = fixed_upper[mask] = rounded
    equal = np.isfinite(row_lower) & np.isfinite(row_upper) & (row_lower == row_upper)
    hi = np.isfinite(row_upper) & ~equal
    lo = np.isfinite(row_lower) & ~equal
    a_ub = vstack((matrix[hi], -matrix[lo]), format="csc")
    b_ub = np.r_[row_upper[hi], -row_lower[lo]]
    started = perf_counter()
    polished = linprog(
        c=objective, A_ub=a_ub, b_ub=b_ub,
        A_eq=matrix[equal], b_eq=row_lower[equal],
        bounds=np.column_stack((fixed_lower, fixed_upper)), method="highs-ds",
        options={"time_limit": float(time_limit), "disp": False,
                 "primal_feasibility_tolerance": LP_FEASIBILITY_TOL,
                 "dual_feasibility_tolerance": LP_FEASIBILITY_TOL},
    )
    seconds = perf_counter() - started
    if (polished.status != 0 or not polished.success or polished.x is None
            or not np.isfinite(polished.x).all() or polished.fun is None
            or not np.isfinite(polished.fun)):
        raise RuntimeError(
            "Fixed-mode LP polishing failed; no unpolished plan is accepted: "
            f"status={polished.status}, message={polished.message}, "
            f"solve_seconds={seconds}, original_integrality_error={integer_error}"
        )
    return polished, seconds, integer_error


def _vector(value, name, n=None):
    out = np.asarray(value, dtype=float).copy()
    if out.ndim != 1 or len(out) == 0 or (n is not None and len(out) != n):
        raise ValueError(f"{name} must be a nonempty vector with the expected length.")
    if not np.isfinite(out).all() or np.any(out < 0):
        raise ValueError(f"{name} must contain only finite nonnegative values.")
    return out


def _scenario_array(value, name, n):
    out = np.asarray(value, dtype=float).copy()
    if out.ndim != 2 or out.shape[0] == 0 or out.shape[1] != n:
        raise ValueError(f"{name} must have shape (scenario_count, {n}).")
    if not np.isfinite(out).all() or np.any(out < 0):
        raise ValueError(f"{name} must contain finite nonnegative interval energies.")
    return out


def solve_plan(
    load_kwh,
    pv_kwh,
    price,
    s0,
    *,
    scenario_load_kwh=None,
    scenario_pv_kwh=None,
    probabilities=None,
    fixed_prefix_g=None,
    b: Battery | None = None,
    terminal_weight=None,
    s_ref=6000.0,
    time_limit=30.0,
    mip_rel_gap=1e-5,
) -> dict:
    """Solve a shared-contract point/scenario MILP with soft terminal inventory.

    Point forecasts (or caller-supplied risk-adjusted point forecasts) become one
    scenario when both scenario arguments are absent. Otherwise load and PV
    scenarios must both be supplied with matching (m, n) shapes. Supplied
    probabilities must sum to one; omitted probabilities are uniform.

    fixed_prefix_g optionally fixes the first k ordinary-purchase entries to an
    already paid contract. The supplied horizon can therefore contain that
    prefix followed by a new 144-slot window (145 slots for a one-slot prefix).
    The input s0 is the observed state at the beginning of the full horizon;
    prefix load/PV must still be forecasts/scenarios, not future actuals. Prefix
    end states remain scenario-dependent planned states, not observations.

    plan_cost and objective include the whole horizon's ordinary purchase cost,
    including the fixed-prefix constant. fixed_prefix_plan_cost and
    new_plan_cost expose the exact split so the caller can avoid billing an
    already paid prefix a second time. All flow/state arrays retain the prefix.

    Objective = price@g + E[5*price@emergency + kappa*max(s_ref-S_end, 0)].
    kappa defaults to min(price)/charge_efficiency. The terminal penalty is not
    cash electricity expense. States are continuous across days through s0; no
    daily terminal equality is imposed.

    A feasible time-limited solution may be returned only after all physical
    constraints have been checked. Read status/optimality_proven/mip_gap before
    describing its optimization accuracy. Failure without a usable incumbent
    raises RuntimeError.

    Every accepted MILP incumbent is followed by an LP with its rounded binary
    modes fixed exactly. Each solver gets time_limit separately; solve_seconds
    includes both stages. Final gap uses the polished objective and the original
    MILP global dual bound, never the restricted LP's dual objective.
    """
    battery = DEFAULT_BATTERY if b is None else b
    load = _vector(load_kwh, "load_kwh")
    n = len(load)
    pv = _vector(pv_kwh, "pv_kwh", n)
    p = _vector(price, "price", n)
    prefix = np.asarray([] if fixed_prefix_g is None else fixed_prefix_g, dtype=float).copy()
    if prefix.ndim != 1 or len(prefix) > n or not np.isfinite(prefix).all() or np.any(prefix < 0):
        raise ValueError("fixed_prefix_g must be a finite nonnegative vector no longer than the horizon.")
    prefix_length = len(prefix)
    if (scenario_load_kwh is None) != (scenario_pv_kwh is None):
        raise ValueError("Supply both scenario_load_kwh and scenario_pv_kwh, or neither.")
    if scenario_load_kwh is None:
        scenario_load, scenario_pv = load[None, :], pv[None, :]
    else:
        scenario_load = _scenario_array(scenario_load_kwh, "scenario_load_kwh", n)
        scenario_pv = _scenario_array(scenario_pv_kwh, "scenario_pv_kwh", n)
        if scenario_load.shape != scenario_pv.shape:
            raise ValueError("Load and PV scenarios must have identical shapes.")
    m = scenario_load.shape[0]
    if probabilities is None:
        probability = np.full(m, 1.0 / m)
    else:
        probability = _vector(probabilities, "probabilities", m)
        if abs(float(probability.sum()) - 1.0) > 1e-8:
            raise ValueError("Scenario probabilities must sum to one.")
        probability /= probability.sum()
    s0 = float(s0)
    if not np.isfinite(s0) or not battery.low - PHYSICAL_TOL_KWH <= s0 <= battery.high + PHYSICAL_TOL_KWH:
        raise ValueError("s0 is outside the battery operating range.")
    s0 = float(np.clip(s0, battery.low, battery.high))
    s_ref = float(s_ref)
    kappa = float(np.min(p) / battery.eta_c if terminal_weight is None else terminal_weight)
    if not np.isfinite(s_ref) or s_ref < 0 or not np.isfinite(kappa) or kappa < 0:
        raise ValueError("Terminal reference and terminal weight must be finite and nonnegative.")
    if not np.isfinite(time_limit) or time_limit <= 0:
        raise ValueError("time_limit must be finite and positive.")
    if not np.isfinite(mip_rel_gap) or not 0 <= mip_rel_gap < 1:
        raise ValueError("mip_rel_gap must be in [0, 1).")

    rate = float(battery.rate)
    # Proven sufficient cap: buying max scenario load plus full possible charge
    # can serve every scenario; additional ordinary energy would only be wasted.
    # Nonnegative purchase prices and no reward for wasting energy justify this
    # finite cap. It is a modelling bound, not an assumed grid-connection limit.
    g_upper = np.max(scenario_load, axis=0) + rate
    # An inherited contract may exceed today's sufficient optimization bound.
    # Honor it in full, and enlarge disposal bounds/mode coefficients as well.
    # Unused contracted energy is allowed, so excess is feasible and not refunded.
    if prefix_length:
        g_upper[:prefix_length] = np.maximum(g_upper[:prefix_length], prefix)
    scene_width = 7 * n + 1
    nvar = n + m * scene_width
    objective = np.zeros(nvar)
    objective[:n] = p
    lower = np.zeros(nvar)
    upper = np.full(nvar, np.inf)
    upper[:n] = g_upper
    lower[:prefix_length] = prefix
    upper[:prefix_length] = prefix
    integer = np.zeros(nvar, dtype=np.uint8)
    row_indices, column_indices, coefficients = [], [], []
    constraint_lower, constraint_upper = [], []

    def add_row(entries, lo=-np.inf, hi=np.inf):
        row = len(constraint_lower)
        for column, value in entries:
            if value:
                row_indices.append(row)
                column_indices.append(column)
                coefficients.append(value)
        constraint_lower.append(lo)
        constraint_upper.append(hi)

    for scenario in range(m):
        base = n + scenario * scene_width
        # Scenario blocks: c, d, e, v, r, S_1..S_n, u, then xi.
        upper[base : base + 2 * n] = rate
        upper[base + 2 * n : base + 3 * n] = scenario_load[scenario]
        upper[base + 3 * n : base + 4 * n] = g_upper
        upper[base + 4 * n : base + 5 * n] = scenario_pv[scenario]
        lower[base + 5 * n : base + 6 * n] = battery.low
        upper[base + 5 * n : base + 6 * n] = battery.high
        upper[base + 6 * n : base + 7 * n] = 1.0
        integer[base + 6 * n : base + 7 * n] = 1
        xi = base + 7 * n
        upper[xi] = max(s_ref - battery.low, 0.0)
        objective[base + 2 * n : base + 3 * n] = probability[scenario] * 5.0 * p
        objective[xi] = probability[scenario] * kappa
        for t in range(n):
            c, d, e, v, r, s, u = (base + block * n + t for block in range(7))
            L, G = float(scenario_load[scenario, t]), float(scenario_pv[scenario, t])
            # g + PV - v - r + d + e = load + c.
            add_row([(t, 1.), (c, -1.), (d, 1.), (e, 1.), (v, -1.), (r, -1.)], L - G, L - G)
            soc_entries = [(c, -battery.eta_c), (d, 1.0 / battery.eta_d), (s, 1.)]
            if t:
                soc_entries.append((s - 1, -1.))
            soc_rhs = s0 if t == 0 else 0.0
            add_row(soc_entries, soc_rhs, soc_rhs)
            add_row([(c, 1.), (u, -rate)], hi=0.)
            add_row([(d, 1.), (u, rate)], hi=rate)
            # e <= load*(1-u); no emergency energy in charging mode.
            add_row([(e, 1.), (u, L)], hi=L)
            # v+r <= (g_upper+PV)*u; no disposal in deficit mode.
            # Together with balance this makes charging require an ordinary
            # surplus, and discharging require an ordinary supply deficit.
            add_row([(v, 1.), (r, 1.), (u, -(g_upper[t] + G))], hi=0.)
            add_row([(v, 1.), (t, -1.)], hi=0.)
        last_state = base + 6 * n - 1
        add_row([(last_state, -1.), (xi, -1.)], hi=-s_ref)

    matrix = coo_matrix(
        (coefficients, (row_indices, column_indices)),
        shape=(len(constraint_lower), nvar),
    ).tocsc()
    row_lower, row_upper = np.asarray(constraint_lower), np.asarray(constraint_upper)
    started = perf_counter()
    with warnings.catch_warnings():
        # SciPy forwards this supported HiGHS option. Suppress only its exact
        # forwarding notice; retain every other solver warning.
        warnings.filterwarnings(
            "ignore", category=RuntimeWarning,
            message=r"Unrecognized options detected: \{'mip_feasibility_tolerance'\}\. These will be passed to HiGHS verbatim\.",
        )
        result = milp(
            c=objective, integrality=integer, bounds=Bounds(lower, upper),
            constraints=LinearConstraint(matrix, row_lower, row_upper),
            options={"time_limit": float(time_limit), "mip_rel_gap": float(mip_rel_gap),
                     "mip_feasibility_tolerance": MIP_FEASIBILITY_TOL, "disp": False},
        )
    mip_seconds = perf_counter() - started
    if result.x is None or not np.isfinite(result.x).all():
        raise RuntimeError(f"No usable MILP incumbent: status={result.status}, message={result.message}")
    if result.status not in (0, 1):
        raise RuntimeError(f"MILP terminated without accepted success/limit status: {result.status}, {result.message}")
    if result.fun is None or not np.isfinite(result.fun):
        raise RuntimeError("MILP incumbent has no finite objective.")

    polished, polish_seconds, original_integer_error = _fixed_mode_polish(
        objective, matrix, row_lower, row_upper, lower, upper, integer,
        np.asarray(result.x, dtype=float), time_limit,
    )
    seconds = perf_counter() - started
    raw = polished.x
    g = np.maximum(raw[:n], 0.)
    flows = {name: np.empty((m, n)) for name in ("c", "d", "e", "v", "r")}
    modes_raw = np.empty((m, n))
    raw_s = np.empty((m, n))
    raw_xi = np.empty(m)
    for scenario in range(m):
        base = n + scenario * scene_width
        for block, name in enumerate(flows):
            flows[name][scenario] = np.maximum(raw[base + block * n : base + (block + 1) * n], 0.)
        raw_s[scenario] = raw[base + 5 * n : base + 6 * n]
        modes_raw[scenario] = raw[base + 6 * n : base + 7 * n]
        raw_xi[scenario] = raw[base + 7 * n]
    modes = np.rint(modes_raw).astype(int)
    c, d, e, v, r = (flows[name] for name in ("c", "d", "e", "v", "r"))
    s = np.concatenate((np.full((m, 1), s0), s0 + np.cumsum(battery.eta_c * c - d / battery.eta_d, axis=1)), axis=1)
    surplus = np.maximum(g[None, :] + scenario_pv - scenario_load, 0.)
    deficit = np.maximum(scenario_load - g[None, :] - scenario_pv, 0.)
    violations = {
        "energy_balance_kwh": float(np.max(np.abs(g + scenario_pv - v - r + d + e - scenario_load - c))),
        "soc_recursion_kwh": float(np.max(np.abs(np.diff(s, axis=1) - battery.eta_c * c + d / battery.eta_d))),
        "solver_soc_agreement_kwh": float(np.max(np.abs(s[:, 1:] - raw_s))),
        "soc_initial_error_kwh": float(np.max(np.abs(s[:, 0] - s0))),
        "soc_lower_kwh": float(max(battery.low - np.min(s), 0.)),
        "soc_upper_kwh": float(max(np.max(s) - battery.high, 0.)),
        "ordinary_purchase_cap_kwh": float(max(np.max(g - g_upper), 0.)),
        "fixed_prefix_error_kwh": float(np.max(np.abs(g[:prefix_length] - prefix))) if prefix_length else 0.,
        "charge_rate_kwh": float(max(np.max(c) - rate, 0.)),
        "discharge_rate_kwh": float(max(np.max(d) - rate, 0.)),
        "charge_mode_kwh": float(max(np.max(c - rate * modes), 0.)),
        "discharge_mode_kwh": float(max(np.max(d - rate * (1 - modes)), 0.)),
        "charge_exceeds_ordinary_surplus_kwh": float(max(np.max(c - surplus), 0.)),
        "discharge_exceeds_ordinary_deficit_kwh": float(max(np.max(d - deficit), 0.)),
        "emergency_deficit_equation_kwh": float(np.max(np.abs(e - deficit + d))),
        "unused_surplus_equation_kwh": float(np.max(np.abs(v + r - surplus + c))),
        "emergency_bound_kwh": float(max(np.max(e - scenario_load * (1 - modes)), 0.)),
        "emergency_during_charging_kwh": float(np.max(np.minimum(c, e))),
        "simultaneous_charge_discharge_kwh": float(np.max(np.minimum(c, d))),
        "unused_contract_bound_kwh": float(max(np.max(v - g), 0.)),
        "curtailment_bound_kwh": float(max(np.max(r - scenario_pv), 0.)),
        "terminal_shortfall_constraint_kwh": float(max(np.max(s_ref - s[:, -1] - raw_xi), 0.)),
        "nonnegative_energy_kwh": float(max(-np.min(np.r_[g, c.ravel(), d.ravel(), e.ravel(), v.ravel(), r.ravel()]), 0.)),
    }
    plan_cost = float(p @ g)
    fixed_prefix_plan_cost = float(p[:prefix_length] @ g[:prefix_length])
    new_plan_cost = float(p[prefix_length:] @ g[prefix_length:])
    scenario_emergency_cost = 5.0 * (e @ p)
    shortfall = np.maximum(s_ref - s[:, -1], 0.)
    scenario_terminal_cost = kappa * shortfall
    expected_emergency_cost = float(probability @ scenario_emergency_cost)
    terminal_cost = float(probability @ scenario_terminal_cost)
    recomputed_objective = plan_cost + expected_emergency_cost + terminal_cost
    objective_difference = abs(recomputed_objective - float(polished.fun))
    integrality_error = float(np.max(np.abs(modes_raw - modes)))
    worst = max(violations.values())
    checks = {
        **violations, "max_violation_kwh": worst,
        "integrality_error": integrality_error,
        "original_mip_integrality_error": original_integer_error,
        "objective_difference_yuan": objective_difference,
        "physical_tolerance_kwh": PHYSICAL_TOL_KWH,
        "objective_tolerance_yuan": OBJECTIVE_TOL_YUAN,
        "passed": bool(worst <= PHYSICAL_TOL_KWH and integrality_error <= INTEGRALITY_TOL and objective_difference <= OBJECTIVE_TOL_YUAN),
    }
    if not checks["passed"]:
        raise RuntimeError(f"Polished MILP plan failed physical/objective verification: {checks}")
    raw_gap = getattr(result, "mip_gap", None)
    original_gap = None if raw_gap is None or not np.isfinite(raw_gap) else float(raw_gap)
    dual = getattr(result, "mip_dual_bound", None)
    dual = None if dual is None or not np.isfinite(dual) else float(dual)
    bound_error = None if dual is None else max(dual - recomputed_objective, 0.)
    bound_consistent = dual is not None and bound_error <= OBJECTIVE_TOL_YUAN
    absolute_gap = max(recomputed_objective - dual, 0.) if bound_consistent else None
    gap = absolute_gap / max(abs(recomputed_objective), 1e-10) if bound_consistent else None
    # Conservatively retain an unproven label for an originally time-limited
    # solve, even if its global lower bound happens to meet the polished value.
    proven = bool(result.status == 0 and gap is not None and gap <= float(mip_rel_gap) + 1e-10)
    status = "optimal_within_requested_gap" if proven else "feasible_unproven"
    mip_diagnostics = {
        "status_code": int(result.status), "success": bool(result.success),
        "message": str(result.message), "objective_yuan": float(result.fun),
        "reported_gap": original_gap, "dual_bound_yuan": dual,
        "solve_seconds": mip_seconds, "time_limit_seconds": float(time_limit),
        "integrality_error": original_integer_error,
        "mip_feasibility_tolerance": MIP_FEASIBILITY_TOL,
    }
    polish_diagnostics = {
        "method": "LP highs-ds with rounded MILP modes fixed exactly",
        "status_code": int(polished.status), "success": bool(polished.success),
        "message": str(polished.message), "objective_yuan": float(polished.fun),
        "recomputed_objective_yuan": recomputed_objective,
        "objective_change_yuan": recomputed_objective - float(result.fun),
        "solve_seconds": polish_seconds, "time_limit_seconds": float(time_limit),
        "feasibility_tolerance": LP_FEASIBILITY_TOL,
        "fixed_binary_variables": int(integer.sum()),
        "ordinary_g_reoptimized_except_fixed_prefix": True,
        "gap_against_original_global_dual_bound": gap,
        "absolute_gap_yuan": absolute_gap, "global_bound_consistent": bound_consistent,
        "dual_bound_above_primal_yuan": bound_error,
    }
    return {
        "g": g, **flows, "w": v + r, "s": s, "u": modes,
        "objective": recomputed_objective, "plan_cost": plan_cost,
        "plan_cost_scope": "Full supplied horizon, including the already paid fixed-prefix constant; use new_plan_cost for new-contract billing.",
        "fixed_prefix_length": prefix_length, "fixed_prefix_g": prefix,
        "fixed_prefix_plan_cost": fixed_prefix_plan_cost, "new_plan_cost": new_plan_cost,
        "state_at_new_window_start_kwh": s[:, prefix_length].copy(),
        "expected_emergency_cost": expected_emergency_cost, "terminal_cost": terminal_cost,
        "scenario_emergency_cost": scenario_emergency_cost,
        "scenario_terminal_cost": scenario_terminal_cost,
        "terminal_shortfall_kwh": shortfall,
        "probabilities": probability, "scenario_count": m,
        "scenario_load_kwh": scenario_load, "scenario_pv_kwh": scenario_pv,
        "terminal_weight": kappa, "s_ref": s_ref,
        "status": status, "status_code": int(result.status), "message": str(result.message),
        "success": True, "optimality_proven": proven,
        "mip_gap": gap, "gap": gap, "requested_mip_rel_gap": float(mip_rel_gap),
        "dual_bound": dual, "absolute_gap_yuan": absolute_gap,
        "gap_basis": "Polished primal objective versus original MILP global dual bound; not the fixed-mode LP bound.",
        "mip_diagnostics": mip_diagnostics, "polish_diagnostics": polish_diagnostics,
        "solve_seconds": seconds, "checks": checks,
        "ordinary_purchase_upper_kwh": g_upper,
        "recourse_information": "Each scenario's recourse sees the whole supplied horizon, including a forecast-only fixed-contract prefix: a two-stage approximation, not causal MPC execution cost.",
        "bounds_explanation": "New g<=max_s(load_s)+rate; fixed-prefix bounds are enlarged to honor inherited contracts; e_s<=load_s; discarded energy<=g_upper+pv_s. These are sufficient optimization bounds, not a grid power limit.",
    }
