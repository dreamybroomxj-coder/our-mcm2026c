"""Synthetic causality, accounting and handoff tests for prefix execution."""
from __future__ import annotations

import unittest
from unittest.mock import patch

import numpy as np

import window_control
from control_refined import run_controller
from window_control import execute_prefix


class WindowControlTests(unittest.TestCase):
    def test_143_and_144_prefixes_have_correct_boundaries_and_balances(self):
        n = 145
        g = np.r_[np.tile(np.r_[np.full(24, 600.), np.full(24, 419.)], 3), 600.]
        load = np.full(n, 500.)
        pv = np.zeros(n)
        p = np.full(n, .5)
        for method in ("greedy", "mpc"):
            for steps in (143, 144):
                with self.subTest(method=method, steps=steps):
                    out = execute_prefix(method, g, load[:steps], pv[:steps], load, pv, p, 6000., steps)
                    self.assertEqual(len(out["g"]), steps)
                    self.assertEqual(len(out["s"]), steps + 1)
                    self.assertEqual(out["horizon_steps"], 145)
                    self.assertTrue(out["checks"]["passed"])
                    self.assertAlmostEqual(out["fees_plan"], float(p[:steps] @ g[:steps]))
                    np.testing.assert_allclose(out["g"] - out["v"] + out["pv"] - out["r"] + out["d"] + out["e"],
                                               out["load"] + out["c"], atol=1e-6)

    def test_one_step_considers_full_145_forecast_horizon(self):
        n = 145
        g, pv = np.zeros(n), np.zeros(n)
        forecast = np.r_[999., 100., np.zeros(n - 2)]
        price = np.r_[.4, 1., np.full(n - 2, .4)]
        mpc = execute_prefix("mpc", g, [100.], [0.], forecast, pv, price, 1300., 1)
        greedy = execute_prefix("greedy", g, [100.], [0.], forecast, pv, price, 1300., 1)
        self.assertAlmostEqual(mpc["d"][0], 0., places=5)
        self.assertAlmostEqual(greedy["d"][0], 90., places=5)
        self.assertAlmostEqual(mpc["fees_emergency"], 200., places=5)
        self.assertAlmostEqual(mpc["s"][-1], 1300., places=5)
        self.assertEqual(mpc["executed_steps"], 1)
        self.assertEqual(mpc["unexecuted_steps"], 144)

    def test_missing_or_extra_actuals_are_rejected(self):
        n = 145
        args = dict(method="mpc", g=np.zeros(n), load_actual=[100.], pv_actual=[0.],
                    load_forecast=np.full(n, 100.), pv_forecast=np.zeros(n),
                    price=np.full(n, .5), s0=6000., steps=2)
        with self.assertRaises(ValueError):
            execute_prefix(**args)
        with self.assertRaises(ValueError):
            execute_prefix(**{**args, "steps": 1, "load_actual": [100., 100.]})
        for steps in (0, 146, 1.5, True):
            with self.subTest(steps=steps), self.assertRaises(ValueError):
                execute_prefix(**{**args, "steps": steps})

    def test_lp_only_receives_current_actual_then_forecasts(self):
        n, steps = 145, 2
        forecast = np.arange(n, dtype=float) + 100.
        pv_forecast = np.arange(n, dtype=float)
        seen = []
        original = window_control.solve_refined_horizon

        def record(g, load, pv, price, s0, **kwargs):
            t = n - len(g)
            self.assertEqual(load[0], [150., 180.][t])
            self.assertEqual(pv[0], [0., 1.][t])
            np.testing.assert_array_equal(load[1:], forecast[t + 1:])
            np.testing.assert_array_equal(pv[1:], pv_forecast[t + 1:])
            seen.append(len(g))
            return original(g, load, pv, price, s0, **kwargs)

        with patch.object(window_control, "solve_refined_horizon", side_effect=record):
            out = execute_prefix("mpc", np.zeros(n), [150., 180.], [0., 1.],
                                 forecast, pv_forecast, np.full(n, .5), 1300., steps)
        self.assertEqual(seen, [145, 144])
        self.assertTrue(out["checks"]["passed"])

    def test_later_actuals_do_not_change_first_action(self):
        n = 145
        forecast = np.full(n, 100.)
        price = np.linspace(.4, 1., n)
        first = execute_prefix("mpc", np.zeros(n), [110., 120.], [0., 0.],
                               forecast, np.zeros(n), price, 1300., 2)
        second = execute_prefix("mpc", np.zeros(n), [110., 9000.], [0., 8000.],
                                forecast, np.zeros(n), price, 1300., 2)
        for key in ("c", "d", "e", "v", "r"):
            self.assertAlmostEqual(first[key][0], second[key][0], places=8)
        self.assertAlmostEqual(first["s"][1], second["s"][1], places=8)

    def test_split_horizon_state_and_fees_connect_without_reset(self):
        g = np.array([600., 419., 600., 419.])
        la, pv = np.full(4, 500.), np.zeros(4)
        price = np.array([.4, .7, .5, 1.])
        for method in ("greedy", "mpc"):
            full = execute_prefix(method, g, la, pv, la, pv, price, 6000., 4, terminal_weight=.4)
            first = execute_prefix(method, g, la[:3], pv[:3], la, pv, price, 6000., 3, terminal_weight=.4)
            tail = execute_prefix(method, g[3:], la[3:], pv[3:], la[3:], pv[3:], price[3:],
                                  first["s"][-1], 1, terminal_weight=.4)
            for key in ("g", "c", "d", "e", "v", "r"):
                np.testing.assert_allclose(np.r_[first[key], tail[key]], full[key], atol=1e-6)
            np.testing.assert_allclose(np.r_[first["s"], tail["s"][1:]], full["s"], atol=1e-6)
            self.assertAlmostEqual(first["fees_total"] + tail["fees_total"], full["fees_total"], places=5)
            self.assertAlmostEqual(tail["s"][0], first["s"][-1])

    def test_full_execution_matches_existing_controller(self):
        g = np.array([600., 400., 300., 650.])
        actual = np.array([500., 600., 500., 500.])
        forecast = np.full(4, 500.)
        pv = np.zeros(4)
        price = np.array([.4, .5, 1., .3])
        original = g.copy()
        for method in ("greedy", "mpc"):
            out = execute_prefix(method, g, actual, pv, forecast, pv, price, 1500., 4)
            existing = run_controller(method, g, actual, pv, forecast, pv, price, 1500.)
            for key in ("c", "d", "e", "s"):
                np.testing.assert_allclose(out[key], existing[key], atol=1e-6)
            self.assertAlmostEqual(out["fees_total"], existing["fees_total"], places=5)
        np.testing.assert_array_equal(g, original)

    def test_unexecuted_contract_is_not_billed(self):
        out = execute_prefix("greedy", [100., 9999.], [100.], [0.], [100., 0.],
                             [0., 0.], [.4, 1.], 6000., 1)
        self.assertAlmostEqual(out["fees_plan"], 40.)
        self.assertAlmostEqual(out["fees_total"], 40.)
        self.assertAlmostEqual(out["s"][-1], 6000.)


if __name__ == "__main__":
    unittest.main(verbosity=2)
