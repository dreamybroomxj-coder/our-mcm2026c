"""Explicit interval interfaces. No inference of point/mean from column count."""
from __future__ import annotations
import csv
import datetime as dt
import hashlib
import json
from pathlib import Path
import re
import numpy as np
from openpyxl import load_workbook

FORECAST_FIELDS = ['plan_date', 'issued_at', 'interval_start', 'interval_end',
                   'load_forecast_kw', 'pv_forecast_kw']
ACTUAL_FIELDS = ['interval_start', 'interval_end', 'load_actual_kw', 'pv_actual_kw']

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def timestamp(value):
    x = value if isinstance(value, dt.datetime) else dt.datetime.fromisoformat(str(value))
    if x.tzinfo is not None:
        x = x.astimezone(dt.timezone(dt.timedelta(hours=8))).replace(tzinfo=None)
    if x.second or x.microsecond:
        raise ValueError('Timestamp must be on a minute boundary')
    return x

def clock_minute(value):
    if isinstance(value, dt.time):
        return value.hour*60+value.minute
    s = str(value).strip().replace('：', ':')
    tomorrow = '次日' in s or '+1' in s
    s = s.replace('次日', '').replace('+1', '').strip()
    match = re.fullmatch(r'(\d{1,2}):(\d{2})', s)
    if not match:
        raise ValueError(f'Unrecognized clock {value!r}')
    h, m = map(int, match.groups())
    if h > 24 or m > 59 or (h == 24 and m):
        raise ValueError('Invalid clock')
    return h*60+m+(1440 if tomorrow and h < 24 else 0)

def interval_header(value):
    # Specific alias explicitly confirmed by the user for the supplied format.
    if str(value).strip() == '次日00:00':
        return 1430, 1440
    parts = re.split(r'[—–～~\-]', str(value).strip())
    if len(parts) != 2:
        raise ValueError(f'Explicit interval required, got {value!r}')
    a, b = map(clock_minute, parts)
    if b == 0 and a == 1430:
        b = 1440
    if b-a != 10:
        raise ValueError(f'Not a ten-minute interval: {value!r}')
    return a, b

def read_wide_means(path, sheet=None):
    """User format: date + 145 interval means; ambiguous midnight alias disclosed."""
    w = load_workbook(path, read_only=True, data_only=True)
    try:
        if sheet is None and len(w.sheetnames) != 1:
            raise ValueError('Workbook has multiple sheets; explicitly choose one')
        s = w[sheet] if sheet else w.worksheets[0]
        rows = list(s.values)
        bounds = [interval_header(h) for h in rows[0][1:]]
        if bounds != [(i*10, i*10+10) for i in range(145)]:
            raise ValueError('Expected 144 current-day intervals plus next-day first interval')
        dates = [timestamp(r[0]).date() for r in rows[1:]]
        if dates != sorted(set(dates)):
            raise ValueError('Dates must be unique and sorted')
        values = np.asarray([r[1:] for r in rows[1:]], dtype=float)
        if values.shape != (len(dates),145) or not np.isfinite(values).all() or (values < 0).any():
            raise ValueError('Invalid or missing interval-average powers')
        return dates, values, {'filename':Path(path).name,'sha256':sha(path),
            'sheet':s.title,'days':len(dates),'intervals_per_issue':145,
            'alias':{'次日00:00':'23:50—24:00 (user confirmed)'},
            'value_kind':'interval_mean_kw','no_averaging_performed':True}
    finally:
        w.close()

def read_price(path):
    w = load_workbook(path, read_only=True, data_only=True)
    try:
        rows = list(w.worksheets[0].values)
    finally:
        w.close()
    if len(rows) != 145 or tuple(rows[0][:2]) != ('时间','电价'):
        raise ValueError('Attachment1 headers/row count differ')
    if [clock_minute(r[0]) for r in rows[1:]] != list(range(10,1441,10)):
        raise ValueError('Attachment1 instantaneous nodes must be 00:10 through 24:00')
    p = np.asarray([r[1] for r in rows[1:]],float)
    if not np.isfinite(p).all() or (p <= 0).any():
        raise ValueError('Prices must be positive')
    nodes = np.r_[p[-1],p]
    mean = (nodes[:-1]+nodes[1:])/2
    return mean, {'filename':Path(path).name,'sha256':sha(path),
        'source_kind':'instantaneous_price','zero_boundary':'periodic p(00:00)=p(24:00)',
        'price_nodes':145,'mean_intervals':144,'price_first':float(mean[0]),
        'price_last':float(mean[-1]),'settlement':'interval mean price approximation'}

def write_csv(path, records, fields=None):
    records = list(records)
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    with Path(path).open('w',newline='',encoding='utf-8-sig') as f:
        w = csv.DictWriter(f,fieldnames=fields or list(records[0]))
        w.writeheader()
        w.writerows(records)

def pair_forecast_workbooks(load_path,pv_path,out,load_sheet=None,pv_sheet=None):
    """Conversion assumes user-declared midnight issue. It does not prove provenance."""
    if Path(load_path).resolve()==Path(pv_path).resolve() and load_sheet==pv_sheet:
        raise ValueError('Load and PV must be distinct explicitly selected sheets')
    dl, l, lm = read_wide_means(load_path,load_sheet)
    dg, g, gm = read_wide_means(pv_path,pv_sheet)
    if Path(load_path).resolve()==Path(pv_path).resolve() and lm['sheet']==gm['sheet']:
        raise ValueError('Load and PV resolved to the same sheet')
    if dl != dg:
        raise ValueError('Load/PV forecast dates do not match')
    records=[]
    for i,day in enumerate(dl):
        zero=dt.datetime.combine(day,dt.time())
        for t in range(145):
            start=zero+dt.timedelta(minutes=10*t)
            records.append(dict(plan_date=day.isoformat(),issued_at=zero.isoformat(),
                interval_start=start.isoformat(),interval_end=(start+dt.timedelta(minutes=10)).isoformat(),
                load_forecast_kw=l[i,t],pv_forecast_kw=g[i,t]))
    write_csv(out,records,FORECAST_FIELDS)
    meta={'load':lm,'pv':gm,'issuance_basis':'user declaration: issued by plan-date midnight; not verified from generator',
          'extra_interval':'next-day first interval retained; excluded from daily optimization'}
    Path(out).with_suffix('.metadata.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')

def load_bundle(forecasts_csv,actual_csv):
    """Strict gate: explicit interval targets, complete 145 forecasts / 144 actuals."""
    provenance={}
    for label,path in [('forecast',Path(forecasts_csv)),('actual',Path(actual_csv))]:
        sidecar=path.with_suffix('.metadata.json')
        if sidecar.exists():
            provenance[label]=json.loads(sidecar.read_text(encoding='utf-8'))
        manifest=path.parent/'synthetic_manifest.json'
        if manifest.exists():
            provenance[label+'_directory_manifest']=json.loads(manifest.read_text(encoding='utf-8'))
    known_synthetic=any(isinstance(m,dict) and
        (str(m.get('role','')).startswith('synthetic') or m.get('data_role')=='synthetic')
        for m in provenance.values())
    role='synthetic' if known_synthetic else 'supplied_unverified'
    with Path(forecasts_csv).open(encoding='utf-8-sig',newline='') as f:
        rows=list(csv.DictReader(f))
    if not rows or not set(FORECAST_FIELDS).issubset(rows[0]):
        raise ValueError('Forecast CSV must contain paired load/PV, plan_date, issued_at, interval_start/end')
    groups={}
    for r in rows:
        day=dt.date.fromisoformat(r['plan_date'])
        zero=dt.datetime.combine(day,dt.time())
        issue=timestamp(r['issued_at'])
        a,b=timestamp(r['interval_start']),timestamp(r['interval_end'])
        if issue>zero or b-a!=dt.timedelta(minutes=10):
            raise ValueError('Forecast was issued after the decision or has invalid duration')
        index=int((a-zero).total_seconds()/600)
        if a-zero!=dt.timedelta(minutes=index*10) or not 0<=index<145:
            raise ValueError('Forecast interval outside its 145-slot target')
        cells=groups.setdefault(day,{})
        if index in cells:
            raise ValueError('Duplicate forecast target/version; select the actual midnight version explicitly')
        cells[index]=(float(r['load_forecast_kw']),float(r['pv_forecast_kw']))
    days=sorted(groups)
    if any(days[i]-days[i-1]!=dt.timedelta(days=1) for i in range(1,len(days))):
        raise ValueError('Forecast days must be consecutive for stateful experiments')
    for day in days:
        if set(groups[day])!=set(range(145)):
            raise ValueError(f'{day}: incomplete 145 forecast intervals')
    with Path(actual_csv).open(encoding='utf-8-sig',newline='') as f:
        raw=list(csv.DictReader(f))
    if not raw or not set(ACTUAL_FIELDS).issubset(raw[0]):
        raise ValueError('Actual CSV must use explicit interval_start/end and paired load/PV')
    actual={}
    for r in raw:
        a,b=timestamp(r['interval_start']),timestamp(r['interval_end'])
        if b-a!=dt.timedelta(minutes=10) or a.minute%10:
            raise ValueError('Invalid actual interval')
        if a in actual:
            raise ValueError('Duplicate actual interval')
        actual[a]=(float(r['load_actual_kw']),float(r['pv_actual_kw']))
    fdata=np.asarray([[groups[day][i] for i in range(145)] for day in days])
    adata=[]
    for day in days:
        zero=dt.datetime.combine(day,dt.time())
        keys=[zero+dt.timedelta(minutes=10*i) for i in range(144)]
        if any(k not in actual for k in keys):
            raise ValueError(f'{day}: actual data missing a current-day interval')
        adata.append([actual[k] for k in keys])
    adata=np.asarray(adata)
    if not np.isfinite(fdata).all() or not np.isfinite(adata).all() or (fdata<0).any() or (adata<0).any():
        raise ValueError('Missing, negative or nonfinite power value')
    return {'dates':days,'load_f':fdata[:,:144,0],'pv_f':fdata[:,:144,1],
        'extra_load_f':fdata[:,144,0],'extra_pv_f':fdata[:,144,1],
        'load_a':adata[:,:,0],'pv_a':adata[:,:,1],
        'metadata':{'forecast_sha256':sha(forecasts_csv),'actual_sha256':sha(actual_csv),
            'source_role':role,'source_provenance':provenance,
            'time_zone':'Asia/Shanghai','value_kind':'interval_mean_kw','daily_intervals':144,
            'forecast_intervals_per_issue':145,'extra_interval_used_for_dispatch':False,
            'actual_feedback':'current interval mean used as fast within-interval response approximation',
            'issuance_check':'declared issued_at <= plan_date midnight; generator causality must be audited separately'}}
