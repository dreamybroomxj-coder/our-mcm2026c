"""Numerical regressions for integer-tolerance leakage and LP polishing."""
import unittest
from unittest.mock import patch

import numpy as np
from scipy.optimize import OptimizeResult

from control import Battery
from planners import PHYSICAL_TOL_KWH, solve_plan


class PlannerPolishTests(unittest.TestCase):
    def setUp(self):
        self.small = Battery(low=0, high=100, power_kw=600, eta_c=1, eta_d=1)

    def test_epsilon_binary_big_m_leak_is_removed_without_looser_physics(self):
        epsilon, leaked = 1e-7, 3e-4
        battery = Battery(low=0, high=1000, power_kw=6000, eta_c=1, eta_d=1)

        def almost_integer_incumbent(**kwargs):
            # One-slot order: g,c,d,e,v,r,S,u,xi. With load=PV=1000,
            # M=g_upper+PV=3000. Tiny u permits d=r=3000*u although
            # true ordinary supply has no deficit at all.
            x = np.array([0., 0., leaked, 0., 0., leaked,
                          100. - leaked, epsilon, 0.])
            self.assertEqual(kwargs["options"]["mip_feasibility_tolerance"], 1e-9)
            rows = kwargs["constraints"]
            lhs = rows.A @ x
            self.assertTrue(np.all(lhs >= rows.lb - 1e-9))
            self.assertTrue(np.all(lhs <= rows.ub + 1e-9))
            self.assertGreater(leaked, PHYSICAL_TOL_KWH)
            return OptimizeResult(x=x, fun=0., status=0, success=True,
                                  message="Injected near-integer incumbent",
                                  mip_gap=0., mip_dual_bound=0.)

        with patch("planners.milp", side_effect=almost_integer_incumbent):
            result = solve_plan([1000], [1000], [1], 100, b=battery,
                                terminal_weight=0, s_ref=0)
        self.assertEqual(result["checks"]["physical_tolerance_kwh"], 1e-5)
        self.assertAlmostEqual(result["checks"]["original_mip_integrality_error"], epsilon)
        self.assertEqual(result["checks"]["integrality_error"], 0.)
        self.assertLess(result["checks"]["max_violation_kwh"], 1e-8)
        np.testing.assert_allclose(result["d"], 0., atol=1e-9)
        np.testing.assert_allclose(result["r"], 0., atol=1e-9)
        np.testing.assert_allclose(result["s"], [[100., 100.]], atol=1e-9)
        self.assertTrue(result["polish_diagnostics"]["success"])
        self.assertEqual(result["polish_diagnostics"]["fixed_binary_variables"], 1)

    def test_g_objective_and_gap_are_recomputed_after_fixed_mode_lp(self):
        def limited_incumbent(**kwargs):
            # A feasible but unnecessarily expensive charging plan. Fixed u=1
            # still allows the LP to drop ten kWh of unnecessary purchase.
            x = np.array([110., 10., 0., 0., 0., 0., 10., 1., 0.])
            return OptimizeResult(x=x, fun=110., status=1, success=False,
                                  message="Injected time-limited incumbent",
                                  mip_gap=20. / 110., mip_dual_bound=90.)

        with patch("planners.milp", side_effect=limited_incumbent):
            result = solve_plan([100], [0], [1], 0, b=self.small,
                                terminal_weight=0, s_ref=0)
        self.assertAlmostEqual(result["g"][0], 100.)
        self.assertAlmostEqual(result["objective"], 100.)
        self.assertAlmostEqual(result["mip_diagnostics"]["objective_yuan"], 110.)
        self.assertAlmostEqual(result["polish_diagnostics"]["objective_change_yuan"], -10.)
        self.assertAlmostEqual(result["mip_gap"], .1)
        self.assertAlmostEqual(result["absolute_gap_yuan"], 10.)
        self.assertNotAlmostEqual(result["mip_gap"], result["mip_diagnostics"]["reported_gap"])
        self.assertEqual(result["status"], "feasible_unproven")
        self.assertFalse(result["optimality_proven"])
        self.assertEqual(result["mip_diagnostics"]["status_code"], 1)
        self.assertEqual(result["polish_diagnostics"]["status_code"], 0)
        self.assertGreaterEqual(result["solve_seconds"],
                                result["mip_diagnostics"]["solve_seconds"] +
                                result["polish_diagnostics"]["solve_seconds"])

    def test_successful_restricted_lp_is_not_a_global_bound(self):
        incumbent = OptimizeResult(
            x=np.array([100., 0., 0., 0., 0., 0., 0., 0., 0.]),
            fun=100., status=0, success=True, message="No global bound supplied",
            mip_gap=0., mip_dual_bound=None,
        )
        with patch("planners.milp", return_value=incumbent):
            result = solve_plan([100], [0], [1], 0, b=self.small,
                                terminal_weight=0, s_ref=0)
        self.assertTrue(result["polish_diagnostics"]["success"])
        self.assertIsNone(result["mip_gap"])
        self.assertFalse(result["optimality_proven"])

    def test_failed_lp_is_explicit_and_never_returns_raw_incumbent(self):
        failure = OptimizeResult(status=2, success=False, x=None, fun=None,
                                 message="Synthetic fixed-mode infeasibility")
        with patch("planners.linprog", return_value=failure):
            with self.assertRaisesRegex(RuntimeError, "Fixed-mode LP polishing failed"):
                solve_plan([10], [0], [1], 0, b=self.small,
                           terminal_weight=0, s_ref=0)

    def test_limit_without_incumbent_does_not_start_polishing(self):
        failure = OptimizeResult(status=1, success=False, x=None, fun=None,
                                 message="Synthetic time limit without incumbent")
        with patch("planners.milp", return_value=failure), patch("planners.linprog") as lp:
            with self.assertRaisesRegex(RuntimeError, "No usable MILP incumbent"):
                solve_plan([10], [0], [1], 0, b=self.small,
                           terminal_weight=0, s_ref=0)
            lp.assert_not_called()


if __name__ == "__main__":
    unittest.main()
