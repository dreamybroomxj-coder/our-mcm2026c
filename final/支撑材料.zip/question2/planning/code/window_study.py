"""Ordered supplied-data evaluation with causal midnight contract bridging."""
import argparse,csv,datetime as dt,hashlib,json,multiprocessing as mp,time
from concurrent.futures import ProcessPoolExecutor,as_completed
from pathlib import Path
import numpy as np
from window_io import read_team_forecasts,attach_actuals,prices,write_canonical,risk_inputs
from window_control import execute_prefix
from control import check_trajectory, DEFAULT_BATTERY
from planners import solve_plan
from input_io import write_csv
from study import json_write,daily_record,summarize

ROOT=Path(__file__).resolve().parents[1]
DATA=None;PRICE=None;CONFIG=None


class ExperimentPool(ProcessPoolExecutor):
    """Stop this experiment's own workers promptly after an error/interruption."""
    def __exit__(self,exc_type,exc_val,exc_tb):
        if exc_type is not None:
            for process in list((self._processes or {}).values()):
                process.terminate()
        return super().__exit__(exc_type,exc_val,exc_tb)


def calibration_indices(data,cut,minimum=14,tail=7):
    return [i for i in range(cut) if data['window_end'][i]<=data['issued_at'][cut]
        and sum(data['window_end'][j]<=data['issued_at'][i] for j in range(i))>=minimum][-tail:]


def initialize(data,p,config):
    global DATA,PRICE,CONFIG
    DATA,PRICE,CONFIG=data,p,config


def plan(i,method,s0,q,prefix=None):
    lf,pf,sl,sp,meta=risk_inputs(DATA,i,method,CONFIG,q)
    p=PRICE;fixed=None
    if prefix is not None:
        old_g,old_l,old_pv=prefix
        lf=np.r_[old_l,lf];pf=np.r_[old_pv,pf];p=np.r_[PRICE[-1],PRICE]
        if sl is not None:
            sl=np.column_stack((np.full(len(sl),old_l),sl))
            sp=np.column_stack((np.full(len(sp),old_pv),sp))
        fixed=[old_g]
        meta['bridge_prefix']='old forecast and fixed contract, not future actual'
    pl=solve_plan(lf/6,pf/6,p,s0,scenario_load_kwh=None if sl is None else sl/6,
        scenario_pv_kwh=None if sp is None else sp/6,fixed_prefix_g=fixed,
        terminal_weight=CONFIG['terminal_weight'],s_ref=6000,
        time_limit=CONFIG['milp_seconds'],mip_rel_gap=CONFIG['mip_gap'])
    return pl,meta


def execute(method,g,la,pa,lf,pf,p,s0,steps):
    return execute_prefix('greedy' if method=='A' else 'mpc',g,np.asarray(la)/6,np.asarray(pa)/6,
        np.asarray(lf)/6,np.asarray(pf)/6,p,s0,steps,
        terminal_weight=CONFIG['terminal_weight'],s_ref=6000)


def record(i,method,stage,pl,op,meta):
    r=daily_record(DATA,i,method,stage,pl,op,meta,CONFIG)
    r.update(window_start=str(DATA['window_start'][i]),window_end=str(DATA['window_end'][i]),
        issued_at=str(DATA['issued_at'][i]),actual_estimated_intervals=int(DATA['actual_estimated'][i].sum()),
        dayahead_objective_scope='full optimization horizon including old fixed prefix when present',
        initial_state_basis='experiment prescribed' if stage!='continuous' or i==0 else 'actual execution from preceding window')
    est=DATA['actual_estimated'][i]
    r['estimated_interval_emergency_yuan']=float(np.sum(5*PRICE[est]*op['e'][est]))
    r['known_contract_plus_observed_emergency_yuan']=r['cash_cost_yuan']-r['estimated_interval_emergency_yuan']
    return r


def local_job(job):
    i,mode,q=job;s0=CONFIG['initial_soc'];m='B' if mode=='AB' else mode
    try:pl,meta=plan(i,m,s0,q)
    except Exception as e:raise RuntimeError(f'Window {DATA["dates"][i]}, method {mode}: {e}') from e
    output=[]
    for method in ('A','B') if mode=='AB' else (mode,):
        op=execute(method,pl['g'],DATA['load_a'][i],DATA['pv_a'][i],DATA['load_f'][i],DATA['pv_f'][i],PRICE,s0,144)
        output.append(record(i,method,'same_contract' if mode=='AB' else 'local_dayahead',pl,op,meta))
    return {'rows':output,'risk':meta,'checks':pl['checks'],'gap':pl['mip_gap'],'status':pl['status'],
        'mip_diagnostics':pl.get('mip_diagnostics'),'polish_diagnostics':pl.get('polish_diagnostics')}


def merge(prefix,tail):
    out={k:np.r_[prefix[k],tail[k]] for k in ('g','c','d','e','v','r','w','price','load','pv')}
    if abs(prefix['s'][-1]-tail['s'][0])>1e-6:raise AssertionError('SOC broken at midnight')
    out['s']=np.r_[prefix['s'],tail['s'][1:]]
    for k in ('fees_plan','fees_emergency','fees_total','solve_seconds'):out[k]=prefix[k]+tail[k]
    out['checks']=check_trajectory(out)
    if not out['checks']['passed']:raise AssertionError(out['checks'])
    return out


def trace_rows(i,method,op):
    for t in range(144):
        a=DATA['window_start'][i]+dt.timedelta(minutes=10*t)
        yield {'method':method,'plan_date':str(DATA['dates'][i]),'interval_start':a.isoformat(),
            'interval_end':(a+dt.timedelta(minutes=10)).isoformat(),'price_yuan_per_kwh':PRICE[t],
            'load_forecast_kw':DATA['load_f'][i,t],'pv_forecast_kw':DATA['pv_f'][i,t],
            'load_actual_kw':DATA['load_a'][i,t],'pv_actual_kw':DATA['pv_a'][i,t],
            'actual_estimated':bool(DATA['actual_estimated'][i,t]),
            'g_kwh':op['g'][t],'charge_kwh':op['c'][t],'discharge_kwh':op['d'][t],
            'emergency_kwh':op['e'][t],'unused_paid_kwh':op['v'][t],'curtailed_pv_kwh':op['r'][t],
            'soc_start_kwh':op['s'][t],'soc_end_kwh':op['s'][t+1],
            'cash_cost_yuan':PRICE[t]*op['g'][t]+5*PRICE[t]*op['e'][t]}


def continuous_job(job):
    method,q_selected,outname,n,s0=job
    out=Path(outname);out.mkdir(parents=True,exist_ok=True)
    daily=[];logs=[];boundary=[]
    fh=(out/f'{method}_trace.csv').open('w',newline='',encoding='utf-8-sig');writer=None
    def complete(i,pl,meta,op):
        nonlocal writer
        stage='test' if i>=CONFIG['calibration_days'] else 'warmup_calibration'
        r=record(i,method,'continuous',pl,op,meta);r['stage']=stage
        daily.append(r)
        for row in trace_rows(i,method,op):
            if writer is None:
                writer=csv.DictWriter(fh,fieldnames=list(row));writer.writeheader()
            writer.writerow(row)
        if (i+1)%28==0:
            fh.flush();write_csv(out/f'{method}_daily.csv',daily)
            print(f'continuous {method}: {i+1}/{n}',flush=True)
    try:
        for i in range(n):
            q=q_selected if i>=CONFIG['calibration_days'] else CONFIG['default_quantile']
            prefix=None if i==0 else (g_prev[-1],DATA['load_f'][i-1,-1],DATA['pv_f'][i-1,-1])
            # No current bridge actual is used before this new contract is fixed.
            pl,meta=plan(i,method,s0,q,prefix)
            g=pl['g'] if i==0 else pl['g'][1:]
            logs.append({'method':method,'date':str(DATA['dates'][i]),'midnight_observed_soc':s0,
                'forecast_soc_at_window_start':pl.get('state_at_new_window_start_kwh'),
                'new_contract_kwh':float(g.sum()),'new_contract_cost':float(PRICE@g),
                'fixed_prefix_kwh':None if prefix is None else prefix[0],
                'status':pl['status'],'gap':pl['mip_gap'],'checks':pl['checks'],'risk':meta,
                'mip_diagnostics':pl.get('mip_diagnostics'),'polish_diagnostics':pl.get('polish_diagnostics')})
            if i>0:
                aug_g=np.r_[g_prev[-1],g]
                aug_l=np.r_[DATA['load_f'][i-1,-1],DATA['load_f'][i]]
                aug_pv=np.r_[DATA['pv_f'][i-1,-1],DATA['pv_f'][i]]
                tail=execute(method,aug_g,DATA['load_a'][i-1,-1:],DATA['pv_a'][i-1,-1:],
                    aug_l,aug_pv,np.r_[PRICE[-1],PRICE],s0,1)
                complete(i-1,pl_prev,meta_prev,merge(part_prev,tail))
                s0=float(tail['s'][-1])
                logs[-1]['executed_soc_at_window_start']=s0
            else:logs[-1]['executed_soc_at_window_start']=s0
            part=execute(method,g,DATA['load_a'][i,:143],DATA['pv_a'][i,:143],
                DATA['load_f'][i],DATA['pv_f'][i],PRICE,s0,143)
            s0=float(part['s'][-1]);g_prev=g;part_prev=part;pl_prev=pl;meta_prev=meta
        i=n-1
        tail=execute(method,g_prev[-1:],DATA['load_a'][i,-1:],DATA['pv_a'][i,-1:],
            DATA['load_f'][i,-1:],DATA['pv_f'][i,-1:],PRICE[-1:],s0,1)
        complete(i,pl_prev,meta_prev,merge(part_prev,tail))
        if DATA['actual_estimated'][i,-1]:
            for name,candidate in DATA.get('last_boundary_candidates',{}).items():
                op=execute(method,g_prev[-1:],[candidate['load_mean_kw']],[candidate['pv_mean_kw']],
                    DATA['load_f'][i,-1:],DATA['pv_f'][i,-1:],PRICE[-1:],s0,1)
                boundary.append({'method':method,'boundary_method':name,**candidate,
                    'last_interval_cash_yuan':op['fees_total'],'last_interval_emergency_yuan':op['fees_emergency'],
                    'total_cash_yuan':sum(r['cash_cost_yuan'] for r in daily)-tail['fees_total']+op['fees_total'],
                    'final_soc_kwh':op['s'][-1]})
    finally:fh.close()
    write_csv(out/f'{method}_daily.csv',daily)
    json_write(out/f'{method}_solver.json',logs)
    if boundary:write_csv(out/f'{method}_boundary.csv',boundary)
    return {'method':method,'daily':daily,'boundary':boundary}


def parallel(pool,jobs,worker,name,cache=None):
    out=[];pending=[]
    if cache is not None:Path(cache).mkdir(parents=True,exist_ok=True)
    for j in jobs:
        key=hashlib.sha256(json.dumps(j).encode()).hexdigest()[:20]
        path=None if cache is None else Path(cache)/(key+'.json')
        if path is not None and path.exists():out.append(json.loads(path.read_text()))
        else:pending.append((j,path))
    if out:print(f'{name}: reused {len(out)} completed checked jobs',flush=True)
    futures={pool.submit(worker,j):path for j,path in pending}
    for k,f in enumerate(as_completed(futures),1):
        value=f.result();out.append(value)
        if futures[f] is not None:json_write(futures[f],value)
        if k%28==0 or k==len(futures):print(f'{name}: {k}/{len(futures)}',flush=True)
    return out


def run(data,p,config,out,workers=3):
    out=Path(out);out.mkdir(parents=True,exist_ok=True);n=len(data['dates']);cut=config['calibration_days']
    if not 15<cut<n:raise ValueError('Need calibration history and a held-out test period')
    if not 1<=config['min_history']<=config['window'] or config['scenarios']<1:raise ValueError('Invalid history/scenarios')
    initialize(data,p,config);t0=time.perf_counter();events=[]
    source_digest=hashlib.sha256()
    for name in ('planners.py','window_study.py','window_io.py','window_control.py','control.py','control_refined.py'):
        source_digest.update((ROOT/'code'/name).read_bytes())
    signature={'code_sha256':source_digest.hexdigest(),'inputs':data['metadata'],'config':config,'windows':n}
    run_hash=hashlib.sha256(json.dumps(signature,sort_keys=True,default=str).encode()).hexdigest()
    cache=out/'job_cache'/run_hash[:16];json_write(out/'run_signature.json',signature)
    def event(s):
        events.append({'order':len(events)+1,'stage':s});json_write(out/'events.json',events);print(s,flush=True)
    with ExperimentPool(max_workers=workers,mp_context=mp.get_context('spawn'),initializer=initialize,initargs=(data,p,config)) as pool:
        event('1 same-contract A/B local comparison')
        first=parallel(pool,[(i,'AB',0) for i in range(cut,n)],local_job,'A/B',cache/'ab')
        same=sorted([r for x in first for r in x['rows']],key=lambda r:(r['date'],r['method']))
        write_csv(out/'stage1_same_contract_daily.csv',same)
        event('calibration only; test data not used for parameter choice')
        eligible=calibration_indices(data,cut,config['min_history'])
        calibration=[]
        for q in [0,.5,.8,.9]:
            for x in parallel(pool,[(i,'C',q) for i in eligible],local_job,f'calibrate q={q}',cache/'calibration'):
                calibration.extend([{'quantile':q,**r} for r in x['rows']])
        q=min([0,.5,.8,.9],key=lambda a:(sum(r['inventory_adjusted_cost_yuan'] for r in calibration if r['quantile']==a),a)) if calibration else config['default_quantile']
        if calibration:write_csv(out/'calibration_quantiles.csv',calibration)
        frozen={'config':config,'selected_quantile':q,'calibration_dates':[str(data['dates'][i]) for i in eligible],
            'effective_from':str(data['dates'][cut]),'scenario_count_status':'preset 8, not optimized',
            'selection_status':'calibration_only' if calibration else 'preset_insufficient_eligible_windows',
            'test_data_used_for_selection':False,'initial_soc_basis':'user-prescribed experiment state at first window start'}
        json_write(out/'frozen_parameters.json',frozen)
        event('2 B/C/D same-MPC local planning comparison')
        second=parallel(pool,[(i,m,q) for i in range(cut,n) for m in ('C','D')],local_job,'C/D',cache/'cd')
        local=[dict(r,stage='local_dayahead') for r in same if r['method']=='B']+[r for x in second for r in x['rows']]
        local.sort(key=lambda r:(r['date'],r['method']));write_csv(out/'stage2_dayahead_daily.csv',local)
        json_write(out/'local_solver_audit.json',first+second)
        event('3 continuous midnight decisions, bridged to 00:10 window starts')
        continuous=parallel(pool,[(m,q,str(out/'continuous'),n,config['initial_soc']) for m in ('A','B','C','D')],continuous_job,'systems')
        daily=sorted([r for x in continuous for r in x['daily']],key=lambda r:(r['date'],r['method']))
        write_csv(out/'stage3_continuous_daily.csv',daily)
        with (out/'stage3_interval_trace.csv').open('w',encoding='utf-8-sig',newline='') as f:
            writer=None
            for m in ('A','B','C','D'):
                with (out/f'continuous/{m}_trace.csv').open(encoding='utf-8-sig',newline='') as source:
                    for r in csv.DictReader(source):
                        if writer is None:writer=csv.DictWriter(f,fieldnames=list(r));writer.writeheader()
                        writer.writerow(r)
        boundary=[r for x in continuous for r in x['boundary']]
        if boundary:write_csv(out/'final_interval_sensitivity.csv',boundary)
        event('4 initial SOC sensitivity, independent equal-length 28-window experiments')
        sensitivity=[]
        # The configured reference state (6000 in this experiment) must also
        # end after 28 windows. A slice of the 334-window run would let its last
        # interval use the 29th contract, unlike the two bounded-state runs.
        for s0 in (1200.,float(config['initial_soc']),10800.):
            results=parallel(pool,[(m,q,str(out/f'initial_soc_{int(s0)}'),min(28,n),s0) for m in ('A','B','C','D')],continuous_job,f'S0={s0}')
            for x in results:
                sensitivity.extend([dict(r,experiment_initial_soc=s0) for r in x['daily']])
        write_csv(out/'initial_soc_sensitivity_daily.csv',sensitivity)
    summaries=summarize(same,'same_contract_local')+summarize(local,'dayahead_local')+summarize(daily,'continuous_all')+summarize([r for r in daily if r['stage']=='test'],'continuous_test')
    write_csv(out/'comparison_summary.csv',summaries)
    summary={'data_role':'supplied_forecasts_with_endpoint_averaged_actuals','real_competition_result':False,
        'interpretation':'Conditional on user-prescribed first SOC and forecast provenance; final interval actual uses an explicitly estimated endpoint.',
        'dates':[str(data['window_start'][0]),str(data['window_end'][-1])],
        'test_dates':[str(data['dates'][cut]),str(data['dates'][-1])],'elapsed_seconds':time.perf_counter()-t0,
        'selected_quantile':q,'all_physical_checks_passed':all(r['all_constraints_passed'] for r in summaries),
        'periods':summaries,'input_metadata':data['metadata'],'estimated_actual_intervals':int(data['actual_estimated'].sum()),
        'midnight_bridge':'plan with observed 00:00 state before using 00:00-00:10 actual; fixed prefix paid only once',
        'initial_soc_sensitivity_scope':'independent first 28 windows for each initial state, identical one-step final interval; no full-period claim'}
    json_write(out/'summary.json',summary);event('complete')
    return summary


def main():
    a=argparse.ArgumentParser(description=__doc__)
    a.add_argument('--out',type=Path,default=ROOT/'results/team')
    a.add_argument('--forecasts',type=Path,default=ROOT/'data/team_forecasts.xlsx')
    a.add_argument('--actuals',type=Path,default=ROOT/'data/attachment2_original.xlsx')
    a.add_argument('--workers',type=int,default=3);a.add_argument('--calibration-days',type=int,default=24)
    a.add_argument('--scenarios',type=int,default=8);a.add_argument('--milp-seconds',type=float,default=30)
    a.add_argument('--s0',type=float,default=6000);a.add_argument('--limit-days',type=int)
    args=a.parse_args()
    data=attach_actuals(read_team_forecasts(args.forecasts),args.actuals,confirmed_instantaneous=True)
    p,pm=prices(ROOT/'data/attachment1.xlsx');data['metadata']['price']=pm
    data['metadata']['initial_soc_experiment_user_confirmed']=args.s0
    if args.limit_days:
        for key in ('dates','window_start','window_end','issued_at','load_f','pv_f','load_a','pv_a','actual_estimated'):data[key]=data[key][:args.limit_days]
    args.out.mkdir(exist_ok=True,parents=True);write_canonical(data,args.out)
    config={'initial_soc':args.s0,'calibration_days':args.calibration_days,'window':28,'min_history':14,
        'scenarios':args.scenarios,'seed':20260911,'terminal_weight':float(p.min()/DEFAULT_BATTERY.eta_c),
        'inventory_value':float(p.min()/DEFAULT_BATTERY.eta_c),'s_ref':6000,'default_quantile':.8,
        'milp_seconds':args.milp_seconds,'mip_gap':1e-5}
    run(data,p,config,args.out,args.workers)


if __name__=='__main__':main()
