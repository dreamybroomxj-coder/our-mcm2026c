"""Ordered A--D comparison. Report synthetic and supplied-data studies distinctly."""
from __future__ import annotations
import argparse
import datetime as dt
import json
from pathlib import Path
import time
import numpy as np
from input_io import load_bundle,read_price,write_csv,pair_forecast_workbooks
from synthetic import generate
from risk import build_risk_inputs
from planners import solve_plan
from control_refined import run_controller

ROOT=Path(__file__).resolve().parents[1]

def json_write(path,data):
    def convert(x):
        if isinstance(x,np.ndarray):return x.tolist()
        if isinstance(x,np.generic):return x.item()
        if isinstance(x,(dt.datetime,dt.date,Path)):return str(x)
        raise TypeError(type(x).__name__)
    Path(path).write_text(json.dumps(data,ensure_ascii=False,indent=2,default=convert,allow_nan=False),encoding='utf-8')

def plan_day(data,i,method,p,s0,config,q):
    lf,pf,sl,sp,meta=build_risk_inputs(data,i,method,quantile=q,
        window=config['window'],min_history=config['min_history'],
        scenarios=config['scenarios'],seed=config['seed'])
    result=solve_plan(lf/6,pf/6,p,s0,
        scenario_load_kwh=None if sl is None else sl/6,
        scenario_pv_kwh=None if sp is None else sp/6,
        terminal_weight=config['terminal_weight'],s_ref=config['s_ref'],
        time_limit=config['milp_seconds'],mip_rel_gap=config['mip_gap'])
    return result,meta

def operate(data,i,p,g,s0,method,config):
    return run_controller('greedy' if method=='A' else 'mpc',g,
        data['load_a'][i]/6,data['pv_a'][i]/6,data['load_f'][i]/6,data['pv_f'][i]/6,p,s0,
        terminal_weight=config['terminal_weight'],s_ref=config['s_ref'])

def daily_record(data,i,method,stage,plan,op,meta,config):
    return {'date':str(data['dates'][i]),'method':method,'stage':stage,
        'cash_cost_yuan':op['fees_total'],'planned_cost_yuan':op['fees_plan'],
        'emergency_cost_yuan':op['fees_emergency'],
        'inventory_adjusted_cost_yuan':op['fees_total']-config['inventory_value']*(op['s'][-1]-op['s'][0]),
        'initial_soc_kwh':op['s'][0],'final_soc_kwh':op['s'][-1],
        'planned_kwh':float(op['g'].sum()),'emergency_kwh':float(op['e'].sum()),
        'emergency_intervals':int((op['e']>1e-5).sum()),
        'unused_paid_kwh':float(op['v'].sum()),'curtailed_pv_kwh':float(op['r'].sum()),
        'fallback_to_point':meta.get('fallback',False),'historical_residual_days':meta.get('history_days',0),
        'dayahead_solver_status':plan['status'],'dayahead_mip_gap':plan['mip_gap'],
        'dayahead_solve_seconds':plan['solve_seconds'],'controller_solve_seconds':op['solve_seconds'],
        'planner_checks_passed':bool(plan['checks']['passed']),
        'controller_checks_passed':bool(op['checks']['passed']),
        'dayahead_expected_emergency_yuan':plan['expected_emergency_cost'],
        'dayahead_objective_not_real_bill':plan['objective']}

def trajectory_rows(data,i,method,op,p):
    zero=dt.datetime.combine(data['dates'][i],dt.time())
    for t in range(144):
        a=zero+dt.timedelta(minutes=10*t)
        yield {'method':method,'interval_start':a.isoformat(),'interval_end':(a+dt.timedelta(minutes=10)).isoformat(),
            'price_yuan_per_kwh':p[t],'load_forecast_kw':data['load_f'][i,t],
            'pv_forecast_kw':data['pv_f'][i,t],'load_actual_kw':data['load_a'][i,t],
            'pv_actual_kw':data['pv_a'][i,t],'g_kwh':op['g'][t],'charge_kwh':op['c'][t],
            'discharge_kwh':op['d'][t],'emergency_kwh':op['e'][t],
            'unused_paid_kwh':op['v'][t],'curtailed_pv_kwh':op['r'][t],
            'soc_start_kwh':op['s'][t],'soc_end_kwh':op['s'][t+1],
            'cash_cost_yuan':p[t]*op['g'][t]+5*p[t]*op['e'][t]}

def summarize(rows,phase):
    result=[]
    for method in ('A','B','C','D'):
        part=[r for r in rows if r['method']==method]
        if not part:continue
        cost=np.array([r['cash_cost_yuan'] for r in part])
        result.append({'phase':phase,'method':method,'days':len(part),
            'cash_cost_yuan':float(cost.sum()),
            'inventory_adjusted_cost_yuan':float(sum(r['inventory_adjusted_cost_yuan'] for r in part)),
            'planned_cost_yuan':float(sum(r['planned_cost_yuan'] for r in part)),
            'emergency_cost_yuan':float(sum(r['emergency_cost_yuan'] for r in part)),
            'emergency_kwh':float(sum(r['emergency_kwh'] for r in part)),
            'unused_paid_kwh':float(sum(r['unused_paid_kwh'] for r in part)),
            'curtailed_pv_kwh':float(sum(r['curtailed_pv_kwh'] for r in part)),
            'p95_daily_cash_cost_yuan':float(np.quantile(cost,.95)),
            'maximum_daily_cash_cost_yuan':float(cost.max()),
            'initial_soc_kwh':part[0]['initial_soc_kwh'],'final_soc_kwh':part[-1]['final_soc_kwh'],
            'fallback_days':sum(r['fallback_to_point'] for r in part),
            'unproven_plan_days':sum(r['dayahead_solver_status']!='optimal_within_requested_gap' for r in part),
            'all_constraints_passed':all(r['planner_checks_passed'] and r['controller_checks_passed'] for r in part)})
    return result

def run_study(data,p,config,out,role):
    n=len(data['dates']);cut=config['calibration_days']
    if not 1<=cut<n:
        raise ValueError('Need nonempty chronological calibration and test periods')
    if not 1<=config['min_history']<=config['window'] or config['scenarios']<1:
        raise ValueError('Require 1 <= min_history <= window and positive scenario count')
    if config['calibration_tail']<1 or not config['quantile_candidates']:
        raise ValueError('Need a positive calibration tail and at least one quantile candidate')
    numbers=[config[k] for k in ('initial_soc','terminal_weight','inventory_value','s_ref','milp_seconds','mip_gap')]
    if not np.isfinite(numbers).all() or not 1200<=config['initial_soc']<=10800:
        raise ValueError('Invalid numeric parameter or initial SOC outside physical bounds')
    if min(config['terminal_weight'],config['inventory_value'],config['mip_gap'])<0 or config['milp_seconds']<=0:
        raise ValueError('Invalid cost weight, gap or solve time limit')
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    s0=config['initial_soc'];test=list(range(cut,n));started=time.perf_counter()
    events=[];all_rows=[];solver_log=[]
    def event(name,details):
        events.append({'order':len(events)+1,'stage':name,**details})
        json_write(out/'experiment_events.json',events)
        print(name,details,flush=True)
    # Stage 1: contract held fixed for control-only attribution.
    event('1_same_contract_control_comparison',{'test_days':len(test),'local_initial_soc':s0})
    same=[];reference={}
    for i in test:
        pl,meta=plan_day(data,i,'B',p,s0,config,0)
        reference[i]=(pl,meta)
        for method in ('A','B'):
            op=operate(data,i,p,pl['g'],s0,method,config)
            row=daily_record(data,i,method,'same_contract',pl,op,meta,config)
            same.append(row)
        if (i-cut+1)%4==0:print('same-contract days',i-cut+1,flush=True)
    write_csv(out/'stage1_same_contract_daily.csv',same)
    # Stage 2: all tuning uses calibration days, never the test days above.
    eligible=list(range(config['min_history'],cut))[-config['calibration_tail']:]
    tuning=[];q_selected=config['default_quantile'];selection_status='preset_no_eligible_calibration_days'
    for q in config['quantile_candidates']:
        for i in eligible:
            pl,meta=plan_day(data,i,'C',p,s0,config,q)
            op=operate(data,i,p,pl['g'],s0,'C',config)
            tuning.append({'quantile':q,**daily_record(data,i,'C','calibration_only',pl,op,meta,config)})
    if tuning:
        scores={q:sum(r['inventory_adjusted_cost_yuan'] for r in tuning if r['quantile']==q) for q in config['quantile_candidates']}
        q_selected=min(scores,key=lambda q:(scores[q],q))
        selection_status='selected_on_calibration_only'
        write_csv(out/'calibration_quantiles.csv',tuning)
    json_write(out/'frozen_parameters.json',{'config':config,'selected_quantile':q_selected,
        'selection_status':selection_status,'selected_from_dates':[str(data['dates'][i]) for i in eligible],
        'effective_from':str(data['dates'][cut]),'scenario_count_status':'preset_not_claimed_optimal',
        'test_was_not_used_for_tuning':True})
    event('2_dayahead_planning_comparison',{'methods':['B','C','D'],'same_controller':'mpc','selected_quantile':q_selected})
    local=[]
    for i in test:
        for method in ('B','C','D'):
            pl,meta=reference[i] if method=='B' else plan_day(data,i,method,p,s0,config,q_selected)
            op=operate(data,i,p,pl['g'],s0,method,config)
            local.append(daily_record(data,i,method,'local_dayahead',pl,op,meta,config))
            solver_log.append({'stage':'local','date':str(data['dates'][i]),'method':method,
                'status':pl['status'],'gap':pl['mip_gap'],'checks':pl['checks'],'risk':meta})
        if (i-cut+1)%4==0:print('dayahead comparison days',i-cut+1,flush=True)
    write_csv(out/'stage2_dayahead_daily.csv',local)
    # Stage 3: whole supplied period, including an honest preset warm-up phase.
    # Each system has its own measured state and hence its own next-day contract.
    event('3_continuous_system_replay',{'all_days':n,'initial_soc':s0,'calibration_days':cut})
    continuous=[];traces=[]
    states={m:s0 for m in ('A','B','C','D')}
    for i in range(n):
        q=q_selected if i>=cut else config['default_quantile']
        for method in ('A','B','C','D'):
            initial=states[method]
            pl,meta=plan_day(data,i,method,p,initial,config,q)
            op=operate(data,i,p,pl['g'],initial,method,config)
            states[method]=float(op['s'][-1])
            phase='test' if i>=cut else 'warmup_calibration'
            row=daily_record(data,i,method,phase,pl,op,meta,config)
            continuous.append(row);traces.extend(trajectory_rows(data,i,method,op,p))
            solver_log.append({'stage':'continuous','date':str(data['dates'][i]),'method':method,
                'status':pl['status'],'gap':pl['mip_gap'],'checks':pl['checks'],'risk':meta})
        if (i+1)%4==0:print('continuous days',i+1,flush=True)
    write_csv(out/'stage3_continuous_daily.csv',continuous)
    write_csv(out/'stage3_interval_trace.csv',traces)
    summaries=(summarize(same,'same_contract_local')+summarize(local,'dayahead_local')+
        summarize(continuous,'continuous_all')+
        summarize([r for r in continuous if r['stage']=='test'],'continuous_test'))
    write_csv(out/'comparison_summary.csv',summaries)
    json_write(out/'solver_audit.json',solver_log)
    summary={'data_role':role,'real_competition_result':False,
        'provenance_status':'synthetic_engineering_only' if role=='synthetic' else 'conditional_on_supplied_forecast_provenance_not_independently_verified',
        'elapsed_seconds':time.perf_counter()-started,'dates':[str(data['dates'][0]),str(data['dates'][-1])],
        'test_dates':[str(data['dates'][cut]),str(data['dates'][-1])],
        'all_physical_checks_passed':all(r['all_constraints_passed'] for r in summaries),
        'selected_quantile':q_selected,'scenarios':config['scenarios'],
        'periods':summaries,'input_metadata':data['metadata'],
        'interpretation':'Synthetic fixture outputs only validate execution. Do not use them to rank real A-D policies.' if role=='synthetic' else
            'Historical evaluation conditional on input forecasts; two-stage scenario objectives are not realized bills.',
        'terminal_inventory_comparison':'cash minus common value times inventory change; not a refund; report cash and inventories separately',
        'test_subset_initial_states':'After policy-specific warmup, test-boundary SOC may differ; inventory adjustment is reported separately.'}
    json_write(out/'summary.json',summary)
    event('4_reports_complete',{'all_checks_passed':summary['all_physical_checks_passed']})
    return summary

def main():
    a=argparse.ArgumentParser(description=__doc__);sp=a.add_subparsers(dest='command',required=True)
    cv=sp.add_parser('convert-forecast');cv.add_argument('--workbook',type=Path,required=True)
    cv.add_argument('--load-sheet',default='负载预测');cv.add_argument('--pv-sheet',default='光伏预测')
    cv.add_argument('--output',type=Path,required=True)
    for name in ('synthetic','evaluate'):
        x=sp.add_parser(name);x.add_argument('--out',type=Path,default=ROOT/'results'/name)
        x.add_argument('--price',type=Path,default=ROOT/'data/attachment1.xlsx')
        x.add_argument('--calibration-days',type=int,default=24)
        x.add_argument('--min-history',type=int,default=14);x.add_argument('--window',type=int,default=28)
        x.add_argument('--scenarios',type=int,default=8);x.add_argument('--seed',type=int,default=20260911)
        x.add_argument('--milp-seconds',type=float,default=30);x.add_argument('--mip-gap',type=float,default=1e-5)
        if name=='evaluate':
            x.add_argument('--forecasts',type=Path,required=True);x.add_argument('--actuals',type=Path,required=True)
            x.add_argument('--s0',type=float,required=True,help='State at first supplied date, not an assumed February 6000')
        else:x.add_argument('--days',type=int,default=40);x.add_argument('--s0',type=float,default=6000)
    args=a.parse_args()
    if args.command=='convert-forecast':
        pair_forecast_workbooks(args.workbook,args.workbook,args.output,args.load_sheet,args.pv_sheet)
        print(args.output);return
    if args.command=='synthetic':
        fp,ap=generate(ROOT/'data/synthetic_fixture',args.days,args.seed)
    else:
        fp,ap=args.forecasts,args.actuals
        # The supplied format workbook is never selected as an actual forecast by this command.
    data=load_bundle(fp,ap)
    if args.command=='evaluate' and data['metadata']['source_role']=='synthetic':
        raise ValueError('Known synthetic data cannot enter supplied-data evaluation; use synthetic command')
    p,pm=read_price(args.price)
    config={'initial_soc':args.s0,'calibration_days':args.calibration_days,'calibration_tail':7,
        'window':args.window,'min_history':args.min_history,'scenarios':args.scenarios,'seed':args.seed,
        'terminal_weight':float(p.min()/.9),'inventory_value':float(p.min()/.9),'s_ref':6000,
        'default_quantile':.8,'quantile_candidates':[0,.5,.8,.9],
        'milp_seconds':args.milp_seconds,'mip_gap':args.mip_gap}
    data['metadata']['price']=pm
    result=run_study(data,p,config,args.out,'synthetic' if args.command=='synthetic' else 'supplied_forecasts')
    print(json.dumps({'out':str(args.out),'all_checks_passed':result['all_physical_checks_passed'],
                      'data_role':result['data_role']},ensure_ascii=False))

if __name__=='__main__':main()
