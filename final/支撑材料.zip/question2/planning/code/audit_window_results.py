"""Independent audit of frozen shifted-window Q2 results; never waits for a run.

The accounting group is (method, plan_date), not the calendar date of a slot.
Generate optional standard scientific figures only after all checks pass.
"""
from __future__ import annotations

import argparse
from collections import defaultdict
import csv
import datetime as dt
import hashlib
import json
import math
from pathlib import Path
from unittest.mock import patch

import numpy as np

from study import json_write
from window_control import execute_prefix


ROOT = Path(__file__).resolve().parents[1]
METHODS = ("A", "B", "C", "D")
TOL = 1e-4
PHYSICAL_TOL = 1e-5


def csv_rows(path):
    with Path(path).open(encoding="utf-8-sig", newline="") as f:
        yield from csv.DictReader(f)


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def boolean(x):
    if isinstance(x, bool):
        return x
    if str(x).lower() in ("true", "1"):
        return True
    if str(x).lower() in ("false", "0"):
        return False
    raise ValueError(f"Invalid boolean {x!r}")


def file_sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def assignment_probe():
    """Runtime structural check, distinguished from stored vector evidence."""
    import window_study as ws
    g = np.arange(144, dtype=float) + .125
    data = {k: np.zeros((1, 144)) for k in ("load_a", "pv_a", "load_f", "pv_f")}
    pl = {"g": g, "checks": {"passed": True}, "mip_gap": 0., "status": "test_only"}
    captures = []

    def capture(method, contract, *args):
        captures.append((method, contract is g, np.asarray(contract).copy()))
        return {}

    with patch.object(ws, "DATA", data), patch.object(ws, "PRICE", np.ones(144)), \
         patch.object(ws, "CONFIG", {"initial_soc": 6000.}), \
         patch.object(ws, "plan", return_value=(pl, {})) as planner, \
         patch.object(ws, "execute", side_effect=capture), \
         patch.object(ws, "record", side_effect=lambda *args: {}):
        ws.local_job((0, "AB", 0))
    return {"passed": planner.call_count == 1 and len(captures) == 2
            and [x[0] for x in captures] == ["A", "B"]
            and all(x[1] for x in captures)
            and np.array_equal(captures[0][2], captures[1][2]),
            "scope": "current local_job code passes the same g object/vector to A and B; not a reconstruction of saved per-day vectors"}


def make_figures(out, daily, summary):
    """Each plot has one task: cost decomposition; window-month variation."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({"font.size": 10, "axes.titlesize": 12,
                         "axes.labelsize": 10, "savefig.dpi": 220,
                         "axes.spines.top": False, "axes.spines.right": False})
    figdir = out / "figures"
    figdir.mkdir(exist_ok=True)
    planned = [sum(float(r["planned_cost_yuan"]) for r in daily if r["method"] == m) / 1e6 for m in METHODS]
    emergency = [sum(float(r["emergency_cost_yuan"]) for r in daily if r["method"] == m) / 1e6 for m in METHODS]
    fig, ax = plt.subplots(figsize=(7.6, 4.7), layout="constrained")
    x = np.arange(4)
    ax.bar(x, planned, color="#557F9E", width=.58, label="Ordinary fixed contract")
    ax.bar(x, emergency, bottom=planned, color="#CE9B68", width=.58, label="Emergency purchase")
    for i, value in enumerate(np.add(planned, emergency)):
        ax.annotate(f"{value:.3f}", (i, value), xytext=(0, 5), textcoords="offset points", ha="center")
    ax.set_xticks(x, METHODS)
    ax.set_ylabel("Cash cost (million CNY)")
    ax.set_title("Continuous operation: cost by component")
    ax.grid(axis="y", alpha=.2)
    ax.set_axisbelow(True)
    ax.margins(y=.16)
    ax.legend(frameon=False, loc="upper center", ncols=2)
    for suffix in ("png", "pdf"):
        fig.savefig(figdir / f"cost_components.{suffix}", bbox_inches="tight")
    plt.close(fig)
    months = sorted({r["window_start"][:7] for r in daily})
    colors = ("#557F9E", "#508B84", "#CE9B68", "#8A7894")
    fig, ax = plt.subplots(figsize=(8.2, 4.7), layout="constrained")
    for method, color in zip(METHODS, colors):
        values = [sum(float(r["cash_cost_yuan"]) for r in daily
                      if r["method"] == method and r["window_start"][:7] == month) / 1e6 for month in months]
        ax.plot(np.arange(len(months)), values, marker="o", markersize=4,
                linewidth=1.6, color=color, label=method)
    ax.set_xticks(np.arange(len(months)), months, rotation=35, ha="right")
    ax.set_xlabel("Month of window start (00:10)")
    ax.set_ylabel("Window-month cash cost (million CNY)")
    ax.set_title("Monthly cash cost grouped by window start")
    ax.grid(alpha=.2)
    ax.legend(title="Method", ncols=4, frameon=False)
    for suffix in ("png", "pdf"):
        fig.savefig(figdir / f"monthly_window_cash.{suffix}", bbox_inches="tight")
    plt.close(fig)
    return {"files": [f"figures/{name}.{suffix}" for name in ("cost_components", "monthly_window_cash") for suffix in ("png", "pdf")],
            "scope": "conditional continuous-run cash bills; first SOC prescribed; final interval partly estimated; not calendar-month meter totals",
            "figure_tasks": ["Separate planned cost from emergency cost", "Show variation using the month of each 00:10-start window"]}


def audit(out, figures=False):
    out = Path(out)
    if not (out / "summary.json").exists():
        raise SystemExit("结果尚未冻结：summary.json不存在。脚本不等待，也不审计未完成输出。")
    summary = read_json(out / "summary.json")
    frozen = read_json(out / "frozen_parameters.json")
    config = frozen["config"]
    errors, counts, maxima = [], defaultdict(int), defaultdict(float)

    def require(ok, detail):
        counts["assertions_checked"] += 1
        if not ok:
            counts["assertions_failed"] += 1
            if len(errors) < 80:
                errors.append(detail)

    def residual(name, value):
        require(math.isfinite(float(value)), f"Nonfinite residual {name}")
        maxima[name] = max(maxima[name], abs(float(value)))

    canonical = {}
    windows = {}
    estimated_keys = set()
    for r in csv_rows(out / "canonical_intervals.csv"):
        key = (r["plan_date"], r["interval_start"])
        require(key not in canonical, f"Duplicate canonical interval {key}")
        canonical[key] = (float(r["load_actual_kw"]), float(r["pv_actual_kw"]), boolean(r["actual_estimated"]), r["interval_end"])
        if canonical[key][2]:
            estimated_keys.add(key)
        w = windows.setdefault(r["plan_date"], {"issued": r["issued_at"], "starts": []})
        w["starts"].append(r["interval_start"])
        require(w["issued"] == r["issued_at"], f"Mixed forecast issue times {r['plan_date']}")
    dates = sorted(windows)
    for day in dates:
        w = windows[day]
        start = dt.datetime.combine(dt.date.fromisoformat(day), dt.time(0, 10))
        w["start"], w["end"] = start, start + dt.timedelta(days=1)
        require(w["starts"] == [(start + dt.timedelta(minutes=10 * t)).isoformat() for t in range(144)],
                f"Canonical window is not 144 ordered 00:10-start slots: {day}")
        require(dt.datetime.fromisoformat(w["issued"]) <= start - dt.timedelta(minutes=10), f"Late issue {day}")
    require(len(estimated_keys) == 1, f"Full-source expected exactly one estimated interval, got {len(estimated_keys)}")
    if estimated_keys:
        expected_last_key = (dates[-1], (windows[dates[-1]]["end"] - dt.timedelta(minutes=10)).isoformat())
        require(estimated_keys == {expected_last_key}, "Estimated mask is not restricted to the final interval")
    daily = list(csv_rows(out / "stage3_continuous_daily.csv"))
    daily_map = {(r["method"], r["date"]): r for r in daily}
    require(len(daily_map) == len(daily) == len(dates) * 4, "Duplicate or missing continuous daily rows")
    ledger = {}
    last, final_rows, estimate_counts = {}, {}, defaultdict(int)
    for r in csv_rows(out / "stage3_interval_trace.csv"):
        counts["trace_intervals"] += 1
        method, day = r["method"], r["plan_date"]
        require(method in METHODS and day in windows, f"Unknown method/window {method} {day}")
        key = (method, day)
        z = ledger.setdefault(key, {"g": [], "p": [], "cash": 0., "planned": 0., "emergency": 0.,
                                    "emergency_kwh": 0., "estimated_emergency": 0., "s0": float(r["soc_start_kwh"])})
        t = len(z["g"])
        a, end = dt.datetime.fromisoformat(r["interval_start"]), dt.datetime.fromisoformat(r["interval_end"])
        require(t < 144 and a == windows[day]["start"] + dt.timedelta(minutes=10 * t)
                and end - a == dt.timedelta(minutes=10), f"Wrong interval order/window grouping {key} t={t}")
        source_key = (day, r["interval_start"])
        require(source_key in canonical, f"Missing canonical source {source_key}")
        load_kw, pv_kw = float(r["load_actual_kw"]), float(r["pv_actual_kw"])
        ca = canonical[source_key]
        residual("source_load_kw", load_kw - ca[0]); residual("source_pv_kw", pv_kw - ca[1])
        estimated = boolean(r["actual_estimated"])
        require(estimated == ca[2], f"Source estimate mask changed {key} t={t}")
        estimate_counts[method] += int(estimated)
        g, c, d, e, v, dump, p, s0, s1, cash = [float(r[f]) for f in (
            "g_kwh", "charge_kwh", "discharge_kwh", "emergency_kwh", "unused_paid_kwh",
            "curtailed_pv_kwh", "price_yuan_per_kwh", "soc_start_kwh", "soc_end_kwh", "cash_cost_yuan")]
        require(all(math.isfinite(x) for x in (g, c, d, e, v, dump, p, s0, s1, cash)), f"Nonfinite trace values {key} t={t}")
        load, pv = load_kw / 6., pv_kw / 6.
        surplus, deficit = max(g + pv - load, 0.), max(load - g - pv, 0.)
        residual("energy_balance_kwh", g - v + pv - dump + d + e - load - c)
        residual("soc_transition_kwh", s1 - s0 - .9 * c + d / .9)
        residual("slot_cash_yuan", cash - p * g - 5. * p * e)
        residual("physical_bound_violation", max(0., 1200. - s0, 1200. - s1, s0 - 10800., s1 - 10800.,
            c - 5000. / 6., d - 5000. / 6., c - surplus, d - deficit, abs(e - deficit + d),
            v - g, dump - pv, -min(g, c, d, e, v, dump), min(c, d), min(c, e)))
        if method in last:
            residual("cross_slot_and_window_soc_kwh", s0 - last[method][1])
            require(a == last[method][0], f"Time gap/overlap across windows for {method}: {a}")
        last[method] = (end, s1)
        z["g"].append(g); z["p"].append(p)
        z["cash"] += cash; z["planned"] += p * g; z["emergency"] += 5. * p * e
        z["emergency_kwh"] += e; z["estimated_emergency"] += 5. * p * e * estimated
        z["s1"] = s1
        if t == 143:
            z["tail_s0"] = s0
        final_rows[method] = r
    require(set(ledger) == set(daily_map), "Trace windows differ from daily-table windows")
    for key, z in ledger.items():
        r = daily_map[key]
        require(len(z["g"]) == 144, f"Window {key} does not contain 144 slots")
        for expected, actual, label in ((z["cash"], r["cash_cost_yuan"], "window_cash_yuan"),
            (z["planned"], r["planned_cost_yuan"], "window_planned_yuan"),
            (z["emergency"], r["emergency_cost_yuan"], "window_emergency_yuan"),
            (z["emergency_kwh"], r["emergency_kwh"], "window_emergency_kwh"),
            (z["s0"], r["initial_soc_kwh"], "window_initial_soc_kwh"),
            (z["s1"], r["final_soc_kwh"], "window_final_soc_kwh"),
            (z["estimated_emergency"], r["estimated_interval_emergency_yuan"], "estimated_emergency_yuan")):
            residual(label, expected - float(actual))
        adjusted = z["cash"] - config["inventory_value"] * (z["s1"] - z["s0"])
        residual("inventory_adjusted_cost_yuan", adjusted - float(r["inventory_adjusted_cost_yuan"]))
        residual("known_bill_decomposition_yuan", z["cash"] - z["estimated_emergency"] - float(r["known_contract_plus_observed_emergency_yuan"]))
    for method in METHODS:
        require(estimate_counts[method] == 1, f"{method} does not have exactly one estimated interval")
        logs = read_json(out / "continuous" / f"{method}_solver.json")
        require(len(logs) == len(dates), f"Wrong contract-log count for {method}")
        for i, log in enumerate(logs):
            day = dates[i]; z = ledger[(method, day)]
            require(log["date"] == day, f"Wrong contract-log date {method} {i}")
            residual("new_contract_total_kwh", float(log["new_contract_kwh"]) - sum(z["g"]))
            residual("new_contract_cost_yuan", float(log["new_contract_cost"]) - z["planned"])
            residual("executed_window_start_soc_kwh", float(log["executed_soc_at_window_start"]) - z["s0"])
            if i:
                previous = ledger[(method, dates[i - 1])]
                residual("fixed_prefix_contract_kwh", float(log["fixed_prefix_kwh"]) - previous["g"][-1])
                residual("midnight_before_old_tail_soc_kwh", float(log["midnight_observed_soc"]) - float(previous["tail_s0"]))
            else:
                require(log["fixed_prefix_kwh"] is None, f"Unexpected prefix for first {method} contract")
    for report in summary["periods"]:
        if report["phase"] not in ("continuous_all", "continuous_test"):
            continue
        chosen = [r for r in daily if r["method"] == report["method"]
                  and (report["phase"] == "continuous_all" or r["stage"] == "test")]
        require(len(chosen) == report["days"], "Summary day count differs from daily table")
        for field in ("cash_cost_yuan", "planned_cost_yuan", "emergency_cost_yuan", "inventory_adjusted_cost_yuan"):
            residual("summary_" + field, sum(float(r[field]) for r in chosen) - float(report[field]))
    # A/B: inspect all persisted comparable quantities and any contract hashes.
    ab = list(csv_rows(out / "stage1_same_contract_daily.csv"))
    abmap = {(r["method"], r["date"]): r for r in ab}
    abdates = sorted({r["date"] for r in ab})
    hash_pairs = 0
    for day in abdates:
        a, b = abmap[("A", day)], abmap[("B", day)]
        for field in ("initial_soc_kwh", "planned_kwh", "planned_cost_yuan"):
            residual("AB_same_contract_" + field, float(a[field]) - float(b[field]))
        hashfield = next((f for f in ("fixed_contract_sha256", "contract_sha256", "g_sha256", "contract_vector_sha256") if a.get(f) and b.get(f)), None)
        if hashfield:
            require(a[hashfield] == b[hashfield], f"A/B contract digest mismatch {day}")
            hash_pairs += 1
    probe = assignment_probe()
    require(probe["passed"], "A/B same-vector assignment probe failed")
    # Every recorded history set and scenario draw must end by its issue time.
    history_sets = 0
    solver_status_counts = defaultdict(int)
    gaps = []
    def walk(value):
        nonlocal history_sets
        if isinstance(value, dict):
            if "history_indices" in value:
                history_sets += 1
                issued = dt.datetime.fromisoformat(value["issued_at"])
                history = value["history_indices"]
                expected = [j for j, day in enumerate(dates) if windows[day]["end"] <= issued][-config["window"]:]
                require(history == expected, f"History differs from completed trailing-window rule at {issued}")
                for j in history:
                    require(0 <= j < len(dates) and windows[dates[j]]["end"] <= issued,
                            f"History leaks incomplete window {j} at {issued}")
                for j in value.get("scenario_history_indices", []):
                    require(j in history, f"Scenario uses unapproved history {j} at {issued}")
            if "status" in value and "gap" in value and "checks" in value:
                solver_status_counts[value["status"]] += 1
                require(bool(value["checks"]["passed"]), "Recorded planner checks failed")
                if value["gap"] is not None:
                    gaps.append(float(value["gap"]))
            for child in value.values():
                walk(child)
        elif isinstance(value, list):
            for child in value:
                walk(child)
    solver_files = sorted(out.rglob("*_solver.json")) + [out / "local_solver_audit.json"]
    for path in solver_files:
        walk(read_json(path))
    effective = dt.datetime.combine(dt.date.fromisoformat(frozen["effective_from"]), dt.time())
    for day in frozen["calibration_dates"]:
        require(day in windows and windows[day]["end"] <= effective,
                f"Calibration target not completed before frozen parameters become effective: {day}")
    calibration = list(csv_rows(out / "calibration_quantiles.csv"))
    for r in calibration:
        require(r["date"] in frozen["calibration_dates"], "Unexpected calibration date")
        issued = dt.datetime.fromisoformat(windows[r["date"]]["issued"])
        expected = [j for j, day in enumerate(dates) if windows[day]["end"] <= issued][-config["window"]:]
        require(int(r["historical_residual_days"]) == len(expected), "Calibration history-count mismatch")
    scores = {q: sum(float(r["inventory_adjusted_cost_yuan"]) for r in calibration if float(r["quantile"]) == q)
              for q in sorted({float(r["quantile"]) for r in calibration})}
    require(bool(scores), "Empty calibration records")
    if scores:
        require(float(frozen["selected_quantile"]) == min(scores, key=lambda q: (scores[q], q)), "Frozen quantile does not reproduce calibration-only choice")
    # Recompute each final-boundary alternative with identical g and prefix SOC.
    boundary_rows = list(csv_rows(out / "final_interval_sensitivity.csv"))
    source_candidates = read_json(out / "input_audit.json")["last_boundary_candidates"]
    candidate_names = set(source_candidates)
    require(len(boundary_rows) == 4 * len(candidate_names), "Missing final-boundary candidate rows")
    require({(r["method"], r["boundary_method"]) for r in boundary_rows}
            == {(method, name) for method in METHODS for name in candidate_names},
            "Missing/duplicate final-boundary method combination")
    boundary_checks = []
    for r in boundary_rows:
        method = r["method"]; lastrow = final_rows[method]
        for field in ("load_mean_kw", "pv_mean_kw", "load_right_endpoint_kw", "pv_right_endpoint_kw"):
            residual("boundary_source_" + field, float(r[field]) - float(source_candidates[r["boundary_method"]][field]))
        g = float(lastrow["g_kwh"]); p = float(lastrow["price_yuan_per_kwh"])
        s0 = float(lastrow["soc_start_kwh"])
        op = execute_prefix("greedy" if method == "A" else "mpc", [g],
            [float(r["load_mean_kw"]) / 6.], [float(r["pv_mean_kw"]) / 6.],
            [float(lastrow["load_forecast_kw"]) / 6.], [float(lastrow["pv_forecast_kw"]) / 6.],
            [p], s0, 1, terminal_weight=config["terminal_weight"], s_ref=6000.)
        require(op["checks"]["passed"] and op["g"][0] == g, "Boundary replay changed contract or violated physics")
        base_total = sum(z["cash"] for (m, _), z in ledger.items() if m == method)
        expected_total = base_total - float(lastrow["cash_cost_yuan"]) + op["fees_total"]
        for expected, stored, field in ((op["fees_total"], r["last_interval_cash_yuan"], "boundary_cash_yuan"),
            (op["fees_emergency"], r["last_interval_emergency_yuan"], "boundary_emergency_yuan"),
            (op["s"][-1], r["final_soc_kwh"], "boundary_final_soc_kwh"),
            (expected_total, r["total_cash_yuan"], "boundary_total_cost_yuan")):
            residual(field, expected - float(stored))
        boundary_checks.append({"method": method, "candidate": r["boundary_method"], "fixed_g_kwh": g,
                                "unchanged_last_step_initial_soc_kwh": s0,
                                "total_cost_change_yuan": expected_total - base_total})
    for field, value in maxima.items():
        tolerance = TOL if field.endswith("_yuan") else PHYSICAL_TOL
        require(value <= tolerance, f"Residual {field}={value} exceeds {tolerance}")
    result = {
        "audit_passed": not errors and counts["assertions_failed"] == 0,
        "scope": "frozen shifted-window outputs grouped by plan_date; independent cash, SOC, timing and terminal-boundary audit",
        "cash_tolerance_yuan": TOL, "physical_tolerance_kwh": PHYSICAL_TOL,
        "counts": dict(counts), "windows_per_method": len(dates),
        "max_absolute_residuals": dict(maxima), "estimated_intervals_per_method": dict(estimate_counts),
        "AB_evidence": {"paired_days": len(abdates), "persisted_digest_pairs": hash_pairs,
            "same_assignment_probe": probe,
            "limitation": None if hash_pairs == len(abdates) else "Saved stage1 rows lack per-slot contract vectors/digests; equality of totals is supplemented by a runtime same-vector code probe, not misrepresented as persisted vector verification."},
        "recorded_history_sets_checked": history_sets,
        "calibration_history_scope": "recorded date/count plus reconstruction of completed-window rule; per-calibration scenario arrays not stored",
        "solver_status_counts": dict(solver_status_counts), "maximum_recorded_gap": max(gaps) if gaps else None,
        "boundary_recomputation": boundary_checks,
        "limitations": ["Forecast-generation causality remains conditional on provided forecast provenance.",
                        "Current interval means are a fast-feedback approximation.",
                        "Instantaneous-node trapezoidal means are approximations; final right endpoint is estimated.",
                        "Initial SOC is a user-prescribed experiment condition; this is not an unconditional competition optimum."],
        "errors": errors,
        "source_hashes": {name: file_sha(out / name) for name in ("summary.json", "canonical_intervals.csv", "stage3_interval_trace.csv", "frozen_parameters.json")},
        "audit_script_sha256": file_sha(Path(__file__)),
    }
    if result["audit_passed"] and figures:
        result["figures"] = make_figures(out, daily, summary)
    json_write(out / "window_result_audit.json", result)
    lines = ["# 第二问窗口结果独立审计", "", f"审计状态：{'通过' if result['audit_passed'] else '未通过'}。",
        f"按计划日期分组，核对每方案{len(dates)}个窗口、每窗口144段；共核对{counts['trace_intervals']:,}条执行记录。",
        "", "已核对：区间能量守恒、充放电与储电边界、跨午夜SOC连接、固定旧末段合同、新窗口计划费用与逐段账本、历史误差截止时刻、校准日期、最后边界估计。",
        f"每方案估计实际量仅{len(estimated_keys)}段；边界替代法以相同固定购电量和末段初始SOC重算，完整回放费用变化恰为该末段变化。",
        f"全部数值检查的最大绝对残差为{max(maxima.values(), default=0.):.6g}；混合单位的各项残差详见JSON。",
        "", "A/B同合同证据：所有配对初态、总购电量与计划费一致；执行函数同向量传参测试通过。" + ("并已核对每个日期的合同摘要。" if hash_pairs == len(abdates) else "现有阶段1表未保存逐段合同或摘要，不能仅凭总量相等宣称已独立逐段核对。"),
        "", "这份审计证明所列结果与给定口径、物理约束和账本一致，不证明预测来源完全无信息泄漏，也不把时限内可行解称为已证明最优。"]
    if errors:
        lines += ["", "发现的问题："] + ["- " + x for x in errors]
    if "figures" in result:
        lines += ["", "图1拆分计划费与紧急费；图2按窗口起点月份汇总费用。跨年最后一段归属12月31日计划窗口，不按其自然日重新分组。"]
    (out / "独立审计说明.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    if not result["audit_passed"]:
        raise AssertionError(f"Audit failed; inspect window_result_audit.json: {errors[:5]}")
    print(json.dumps({"audit_passed": True, "windows_per_method": len(dates),
                      "trace_intervals": counts["trace_intervals"], "figures": bool(figures)}, ensure_ascii=False), flush=True)
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("result_directory", type=Path, nargs="?", default=ROOT / "results/final_team")
    parser.add_argument("--figures", action="store_true")
    args = parser.parse_args()
    audit(args.result_directory, args.figures)
