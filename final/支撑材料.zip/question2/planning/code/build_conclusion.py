"""Generate a traceable Chinese interpretation from the frozen Q2 ledgers."""
import argparse
import csv
import json
from pathlib import Path
import numpy as np
from evaluate_reports import paired_block_interval

ROOT = Path(__file__).resolve().parents[1]
NAMES = {'A': '点预测MILP＋贪心', 'B': '点预测MILP＋MPC',
         'C': '误差裕量MILP＋MPC', 'D': '场景随机MILP＋MPC'}


def read_rows(path):
    with path.open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))


def build(out):
    summary = json.loads((out / 'summary.json').read_text())
    frozen = json.loads((out / 'frozen_parameters.json').read_text())
    config = frozen['config']
    audit = json.loads((out / 'window_result_audit.json').read_text())
    ledger = json.loads((out / 'independent_evaluation.json').read_text())
    report = json.loads((out / '中文报表/报表核验.json').read_text())
    assert audit['audit_passed'] and ledger['independent_checks_passed'] and report['all_checks_passed']
    all_rows = {x['method']: x for x in summary['periods'] if x['phase'] == 'continuous_all'}
    test_rows = {x['method']: x for x in summary['periods'] if x['phase'] == 'continuous_test'}
    daily = read_rows(out / 'stage3_continuous_daily.csv')
    best = min(all_rows, key=lambda m: all_rows[m]['cash_cost_yuan'])
    inventory_best = min(all_rows, key=lambda m: all_rows[m]['inventory_adjusted_cost_yuan'])
    saving = all_rows['A']['cash_cost_yuan'] - all_rows[best]['cash_cost_yuan']
    text = ['# 第二问：新144段输入的计算结论', '',
        f'在本次队伍预测、共同6000 kWh实验初态和统一物理条件下，334窗口连续回放现金费用最低的是**方案{best}（{NAMES[best]}）**。',
        f'相对A累计少支出{saving:,.2f}元（{100*saving/all_rows["A"]["cash_cost_yuan"]:.2f}%）。这是当前输入与预设参数下的历史比较，不代表所有预测版本或参数下都最优。', '',
        '输入为2025年2月1日至12月31日的334行预测；每行覆盖本日00:10至次日00:10，共48,096段。完整执行结束于2026年1月1日00:10，不是全年自然日账单。', '',
        '## 1. 连续运行总费用', '',
        '|方案|普通购电费/元|紧急购电费/元|总现金费用/元|最终储电/kWh|库存修正指标/元|',
        '|---|---:|---:|---:|---:|---:|']
    for m, r in all_rows.items():
        text.append(f'|{m} {NAMES[m]}|{r["planned_cost_yuan"]:,.2f}|{r["emergency_cost_yuan"]:,.2f}|{r["cash_cost_yuan"]:,.2f}|{r["final_soc_kwh"]:,.2f}|{r["inventory_adjusted_cost_yuan"]:,.2f}|')
    months = sorted({r['window_start'][:7] for r in daily})
    monthly = {month: {m: sum(float(r['cash_cost_yuan']) for r in daily
               if r['method'] == m and r['window_start'].startswith(month)) for m in NAMES}
               for month in months}
    monthly_winners = {month: min(costs, key=costs.get) for month, costs in monthly.items()}
    best_months = sum(m == best for m in monthly_winners.values())
    exceptions = '、'.join(f'{month}为{method}' for month, method in monthly_winners.items() if method != best)
    text += ['', f'按窗口起点月份分组，方案{best}在{len(months)}个月中的{best_months}个月现金费用最低。' + (f'其他月份：{exceptions}。' if exceptions else ''),
        '各月比较承接各自既有电池状态，不代表每个月重新从相同SOC开始；逐月图见独立审计的figures目录。',
        f'库存修正为现金费用−{config["inventory_value"]:.10f}×（末储电−初储电），只用于比较库存消耗，绝不当作退款。实际费用包含已签普通电与五倍价格紧急电；未用普通电不退款，软末态惩罚不计费。',
        f'按库存修正指标最低的是方案{inventory_best}；现金排名和库存修正排名需结合末态储电量一起判断。', '',
        '最后一段的右端瞬时节点缺失，主结果以持平估计补齐；其余48,095段均有左右实测节点。所有实际区间均值仍采用端点平均近似，最后一段的估计标记和替代估计结果完整保留。', '',
        '## 2. 按顺序区分控制作用与日前规划作用', '',
        '|对照|相同条件|比较窗口数|累计现金减少/元|累计库存修正减少/元|候选现金更低窗口|平均每窗现金差/元及95%块Bootstrap区间|',
        '|---|---|---:|---:|---:|---:|---|']
    comparisons = [('stage1_same_contract_daily.csv', 'A', 'B', '同一合同g、同6000初态'),
                   ('stage2_dayahead_daily.csv', 'B', 'C', '同MPC、同6000初态'),
                   ('stage2_dayahead_daily.csv', 'B', 'D', '同MPC、同6000初态'),
                   ('stage2_dayahead_daily.csv', 'C', 'D', '同MPC、同6000初态')]
    for file, base, candidate, condition in comparisons:
        rows = read_rows(out / file)
        ref = {x['date']: x for x in rows if x['method'] == base}
        cand = sorted([x for x in rows if x['method'] == candidate], key=lambda x: x['date'])
        if len(cand) != len({x['date'] for x in cand}) or set(ref) != {x['date'] for x in cand}:
            raise AssertionError('Paired comparison dates are missing or duplicated')
        for x in cand:
            baseline = ref[x['date']]
            if abs(float(x['initial_soc_kwh']) - float(baseline['initial_soc_kwh'])) > 1e-6:
                raise AssertionError('Local comparison does not share the same initial SOC')
            if file.startswith('stage1'):
                for key in ('planned_cost_yuan', 'planned_kwh'):
                    if abs(float(x[key]) - float(baseline[key])) > 1e-5:
                        raise AssertionError('A/B declared same-contract totals differ')
        diff = np.array([float(x['cash_cost_yuan']) - float(ref[x['date']]['cash_cost_yuan']) for x in cand])
        inventory_diff = np.array([float(x['inventory_adjusted_cost_yuan']) - float(ref[x['date']]['inventory_adjusted_cost_yuan']) for x in cand])
        ci = paired_block_interval(diff)
        ci_label = '样本不足' if ci is None else f'[{ci[0]:,.2f}, {ci[1]:,.2f}]'
        text.append(f'|{candidate}相对{base}|{condition}|{len(diff)}|{-diff.sum():,.2f}|{-inventory_diff.sum():,.2f}|{(diff < -1e-5).sum()}/{len(diff)}|{diff.mean():,.2f}；{ci_label}|')
    text += ['', '上表“累计减少”为基线−候选，正值表示候选更省；“平均每窗差”为候选−基线，负值表示候选更省。库存修正列用于检查现金改善是否部分来自消耗更多末态库存。',
        'A/B的逐段同合同由主程序把同一次日前求解的g分别交给两种控制器保证；购电总量与费用相同是汇总防错检查，不能单独代替时段级同合同条件。',
        'Bootstrap使用7窗口圆形移动块、1000次重采样和固定种子，给出配对平均现金差的条件性95%区间；它是描述性检查，未作多重比较校正，不能消除季节变化或保证未来收益。逐窗实验每窗重置初态，只用来区分升级的作用，其费用之和不能冒充连续运行账单。', '',
        'MPC根据后续预测和电价尝试把部分电量留给后面更贵的缺口；裕量和场景方案可能增加或重新分配普通购电，以改变紧急购电风险。是否值得，要用执行后的两种费用总和判断。即使D累计更省，也不能据此推断每个窗口都更省，具体窗口胜出数见表。', '',
        '## 3. 参数冻结后的时间顺序测试期', '',
        f'前{config["calibration_days"]}窗是热身/校准；测试合同从{summary["test_dates"][0]}开始，每方案{test_rows["A"]["days"]}窗。四方案测试起点SOC来自各自此前运行；该表衡量各自历史运行后继续执行的条件表现，不能单独作为同起始资源的控制器对照，应结合上面的同初态局部实验。', '',
        '|方案|测试期现金/元|测试起始SOC/kWh|测试末SOC/kWh|测试期库存修正指标/元|', '|---|---:|---:|---:|---:|']
    for m, r in test_rows.items():
        text.append(f'|{m}|{r["cash_cost_yuan"]:,.2f}|{r["initial_soc_kwh"]:,.2f}|{r["final_soc_kwh"]:,.2f}|{r["inventory_adjusted_cost_yuan"]:,.2f}|')
    calibration_dates = frozen['calibration_dates']
    calibration_scope = f'{calibration_dates[0]}至{calibration_dates[-1]}的{len(calibration_dates)}个已完成窗口' if calibration_dates else '没有足够的已完成窗口，采用预设值'
    text += ['', f'裕量分位数校准范围为{calibration_scope}，使用q={summary["selected_quantile"]}；自{frozen["effective_from"]}起冻结，代码没有使用测试期实际费用选择该参数。上一窗口到决策日00:10才结束，故不能用于决策日零点的参数选择。',
        '这只保证本规划实验的时间切分与参数筛选顺序，不等于已独立审计原预测器的训练截止时间；最终比较与方法建议也属于看完这批回放后的历史评价。', '',
        '|裕量q|校准现金/元|校准库存修正指标/元|校准紧急费/元|', '|---|---:|---:|---:|']
    calibration = read_rows(out / 'calibration_quantiles.csv')
    for q in (0, .5, .8, .9):
        rows = [r for r in calibration if float(r['quantile']) == q]
        sums = [sum(float(r[k]) for r in rows) for k in ('cash_cost_yuan','inventory_adjusted_cost_yuan','emergency_cost_yuan')]
        text.append(f'|{q:g}|{sums[0]:,.2f}|{sums[1]:,.2f}|{sums[2]:,.2f}|')
    text += ['', f'更大裕量不一定更好：它可能降低紧急费，也可能买下更多用不掉且不退款的合同电。本次只有{len(calibration_dates)}个有效校准窗口，所选分位数是当前实验候选，不能称为跨季节最优参数。', '',
        '## 4. 初态与末端敏感性', '',
        '三种初态均独立运行相同的前28窗口，使用相同预测、冻结参数与最后一段结束规则。6000基准没有从334窗主回放直接截取，以避免其多看到第29窗合同造成不公平。', '',
        '|初态/kWh|A现金/元|B现金/元|C现金/元|D现金/元|本组最低|', '|---:|---:|---:|---:|---:|---|']
    sensitivity = read_rows(out / 'initial_soc_sensitivity_daily.csv')
    for s0 in (1200.,6000.,10800.):
        costs = {m: sum(float(r['cash_cost_yuan']) for r in sensitivity if r['method']==m and float(r['experiment_initial_soc'])==s0) for m in NAMES}
        text.append(f'|{s0:,.0f}|' + '|'.join(f'{costs[m]:,.2f}' for m in NAMES) + f'|{min(costs,key=costs.get)}|')
    text += ['', '不同初态拥有不同数量的初始电，不能把跨初态的现金差直接当作算法优劣；应在同一初态内比较方案。这项检验覆盖28窗，不声称已经做三种初态的334窗全程实验。', '',
        '最后缺失端点用持平、末两点线性外推、末六点OLS外推三种方法，只重放末段，之前合同与动作完全固定。', '',
        '|方案|三种估计下总现金最小/元|最大/元|跨度/元|', '|---|---:|---:|---:|']
    boundary = read_rows(out / 'final_interval_sensitivity.csv')
    for m in NAMES:
        values = [float(r['total_cash_yuan']) for r in boundary if r['method']==m]
        text.append(f'|{m}|{min(values):,.2f}|{max(values):,.2f}|{max(values)-min(values):,.2f}|')
    text += ['', '这些端点估计用于说明最后一段对结论的影响，不能称为已获得缺失的实测数据，也没有据结果反选最便宜的填充值。', '',
        '## 5. 求解精度与运行代价', '',
        '|方案|日前平均求解/秒|日内全部LP求解/秒|未证达到目标Gap的窗口|最大相对Gap|', '|---|---:|---:|---:|---:|']
    for m in NAMES:
        rows = [r for r in daily if r['method']==m]
        secs = np.mean([float(r['dayahead_solve_seconds']) for r in rows])
        control = sum(float(r['controller_solve_seconds']) for r in rows)
        limited = sum(r['dayahead_solver_status'] != 'optimal_within_requested_gap' for r in rows)
        reported_gaps = [float(r['dayahead_mip_gap']) for r in rows if r['dayahead_mip_gap'] not in ('', None)]
        gap_label = f'{100*max(reported_gaps):.6f}%' if reported_gaps else '未报告'
        if len(reported_gaps) < len(rows):
            gap_label += f'；{len(rows)-len(reported_gaps)}窗未报告'
        text.append(f'|{m}|{secs:.4f}|{control:.2f}|{limited}/{len(rows)}|{gap_label}|')
    text += ['', '上表统计连续回放。局部规划对照也可能含限时可行解，其状态另外列出：', '',
        '|局部实验|方案|未证达到请求Gap窗口数|总窗口数|', '|---|---|---:|---:|']
    for filename, label in [('stage1_same_contract_daily.csv', '同g控制对照'), ('stage2_dayahead_daily.csv', '同MPC规划对照')]:
        local_rows = read_rows(out / filename)
        for method in sorted({r['method'] for r in local_rows}):
            group = [r for r in local_rows if r['method'] == method]
            text.append(f'|{label}|{method}|{sum(r["dayahead_solver_status"] != "optimal_within_requested_gap" for r in group)}|{len(group)}|')
    text += ['', f'求解时间为本机记录，受并行负载影响，不是普遍速度承诺。日前先MILP、再固定整数模式进行LP精修，两个阶段各限{config["milp_seconds"]:g}秒；请求相对Gap为{100*config["mip_gap"]:.6f}%，最终Gap使用原MILP的全局下界。限时可行解通过物理核验后用于回放，但不能称为已证明全局最优；LP精修也不等于重新完成了全局整数搜索。', '',
        '独立程序核对四方案共192,384条逐段记录的能量守恒、SOC转移、功率和容量边界、费用、跨零点合同衔接及历史截止时刻。工作簿另核对逐段—逐窗—汇总一致性。机器可读证据见独立审计JSON和中文报表核验文件。', '',
        '## 6. 建议与适用边界', '',
        f'当前预测版本若以累计购电现金费用为主要目标，可将{best}作为本轮优先候选，但这是本批结果的事后筛选。应保留B作为点预测控制基线；C避免D的多场景整数模型，可作为相对D较简洁的风险处理候选，是否取用仍看本表费用、库存和求解记录。', '',
        'D使用预设8场景和单个固定种子，两阶段场景补救具有整条路径预见性，实际收益必须看MPC回放。尚不能声称已完成场景数、随机种子、风险偏好和所有预测版本的全面优化。', '',
        '本次只评估规划模块。预测工作簿没有训练截止或版本日志，其零点前可用基于队伍说明；今后更换预测模型，应重建对应历史误差库，在相同窗口、物理条件、实验初态及切分下重新比较A—D，不能把当前费用或胜负直接沿用。', '',
        '操作步骤、完整模型和标准格式见README及support/模型与执行步骤.md。中文汇总位于results/final_team/中文报表/问题二_计算结果.xlsx，四份策略工作簿及逐段CSV在同一目录。', '']
    target = ROOT / 'support/计算结论.md'
    target.parent.mkdir(exist_ok=True)
    target.write_text('\n'.join(text), encoding='utf-8')
    print(target)
    return target


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('results', type=Path, nargs='?', default=ROOT/'results/final_team')
    build(parser.parse_args().results)
