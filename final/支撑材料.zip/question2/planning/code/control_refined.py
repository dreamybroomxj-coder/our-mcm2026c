"""Fixed-contract greedy/MPC execution for the Q2 A/B/C/D comparison.

The public interface is ``run_controller``. Every flow input is already kWh per
ten-minute interval; this module does not parse timestamps or average samples.
All methods share the same physical model and fixed contract. Only current
actuals replace forecasts, under the explicit fast intra-interval feedback
approximation; future actuals are never passed to the optimization solver.

The MPC primary objective is emergency cash cost plus a soft terminal shortfall.
No small weighted tie-break term is hidden in that objective: stage two imposes
an explicit primary-cost upper bound and maximizes the current discharge.
Positive current surplus is charged as much as physically possible; free
disposal and a nonincreasing terminal penalty make higher stored energy weakly
preferable in this particular model. This rule assumes no degradation cost.
"""

from __future__ import annotations

from time import perf_counter

import numpy as np
from scipy.optimize import linprog
from scipy.sparse import coo_matrix, vstack

from control import (
    Battery, DEFAULT_BATTERY, LP_TOL, PHYSICAL_TOL,
    _initial_state, _vector, check_trajectory, greedy_step, solve_horizon,
    simulate_day,
)


PRIMARY_ALLOWANCE_YUAN = 1e-7
PRIMARY_VERIFICATION_TOL_YUAN = 1e-5


def _dispatch_lp(g, load, pv, price, s0, b, terminal, weight, s_ref):
    """Build the same physical model independently for explicit stage two."""
    g = _vector(g, "g")
    n = len(g)
    load = _vector(load, "load", n)
    pv = _vector(pv, "pv", n)
    price = _vector(price, "price", n)
    s0 = _initial_state(s0, b)
    if terminal not in ("shortfall", "value"):
        raise ValueError("Refined controller supports shortfall or value terminal modes.")
    if not np.isfinite(weight) or weight < 0 or not np.isfinite(s_ref):
        raise ValueError("Invalid terminal weight or reference.")
    a = np.maximum(g + pv - load, 0.0)
    deficit = np.maximum(load - g - pv, 0.0)
    nvar = 3 * n + int(terminal == "shortfall")
    f = np.zeros(nvar)
    f[n : 2 * n] = -5 * price
    if terminal == "shortfall":
        f[-1] = weight
    else:
        f[3 * n - 1] = -weight
    indices = np.arange(n)
    row = np.concatenate((indices, indices, indices, indices[1:]))
    col = np.concatenate((indices, n + indices, 2 * n + indices, 2 * n + indices[:-1]))
    val = np.concatenate((
        np.full(n, -b.eta_c), np.full(n, 1 / b.eta_d),
        np.ones(n), -np.ones(max(n - 1, 0)),
    ))
    equality = coo_matrix((val, (row, col)), shape=(n, nvar)).tocsc()
    equality_rhs = np.zeros(n)
    equality_rhs[0] = s0
    bounds = (
        [(0., float(z)) for z in np.minimum(a, b.rate)]
        + [(0., float(z)) for z in np.minimum(deficit, b.rate)]
        + [(b.low, b.high)] * n
    )
    upper = None
    upper_rhs = None
    if terminal == "shortfall":
        bounds.append((0., None))
        upper = coo_matrix(
            ([-1., -1.], ([0, 0], [3 * n - 1, nvar - 1])),
            shape=(1, nvar),
        ).tocsc()
        upper_rhs = np.array([-s_ref])
    return {
        "g": g, "load": load, "pv": pv, "price": price,
        "s0": s0, "n": n, "nvar": nvar, "surplus": a, "deficit": deficit,
        "primary_linear": f, "primary_constant": float(5 * price @ deficit),
        "A_eq": equality, "b_eq": equality_rhs,
        "A_ub": upper, "b_ub": upper_rhs, "bounds": bounds,
    }


def _solve_built(problem, objective, b, terminal, weight, s_ref,
                 primary_ceiling=None, forced_first_charge=None):
    n = problem["n"]
    bounds = list(problem["bounds"])
    if forced_first_charge is not None:
        forced_first_charge = float(forced_first_charge)
        if not bounds[0][0] - PHYSICAL_TOL <= forced_first_charge <= bounds[0][1] + PHYSICAL_TOL:
            raise ValueError("Forced first charge lies outside the surplus/power bounds.")
        bounds[0] = (forced_first_charge, forced_first_charge)
    upper, rhs = problem["A_ub"], problem["b_ub"]
    if primary_ceiling is not None:
        # This is an explicit epsilon-constraint, not a weighted extra objective.
        ceiling_row = coo_matrix(problem["primary_linear"].reshape(1, -1)).tocsc()
        ceiling_rhs = float(primary_ceiling - problem["primary_constant"])
        upper = ceiling_row if upper is None else vstack((upper, ceiling_row), format="csc")
        rhs = np.array([ceiling_rhs]) if rhs is None else np.append(rhs, ceiling_rhs)
    started = perf_counter()
    result = linprog(
        objective, A_eq=problem["A_eq"], b_eq=problem["b_eq"],
        A_ub=upper, b_ub=rhs, bounds=bounds, method="highs",
        options={"primal_feasibility_tolerance": LP_TOL,
                 "dual_feasibility_tolerance": LP_TOL},
    )
    seconds = perf_counter() - started
    if not result.success:
        raise RuntimeError(f"Refinement LP failed ({result.status}): {result.message}")
    c = np.clip(result.x[:n], 0, np.minimum(problem["surplus"], b.rate))
    d = np.clip(result.x[n : 2 * n], 0, np.minimum(problem["deficit"], b.rate))
    s = np.r_[problem["s0"], problem["s0"] + np.cumsum(b.eta_c * c - d / b.eta_d)]
    e = np.maximum(problem["deficit"] - d, 0)
    w = np.maximum(problem["surplus"] - c, 0)
    v = np.minimum(w, problem["g"])
    r = w - v
    terminal_cost = (
        weight * max(s_ref - float(s[-1]), 0.) if terminal == "shortfall"
        else -weight * float(s[-1])
    )
    primary = float(5 * problem["price"] @ e) + terminal_cost
    out = {
        "g": problem["g"], "load": problem["load"], "pv": problem["pv"],
        "c": c, "d": d, "e": e, "v": v, "r": r, "w": w, "s": s,
        "primary_objective": primary, "solve_seconds": seconds,
        "status_code": int(result.status), "message": str(result.message),
    }
    checks = check_trajectory(out, b)
    if not checks["passed"]:
        raise RuntimeError(f"Refinement physical checks failed: {checks}")
    out["checks"] = checks
    return out


def solve_refined_horizon(
    g, load, pv, price, s0,
    b: Battery = DEFAULT_BATTERY, terminal="shortfall", weight=None,
    s_ref=6000.,
) -> dict:
    """Primary optimum, then maximize current d within 1e-7 yuan of that cost."""
    price = _vector(price, "price")
    weight = float(np.min(price) / b.eta_c if weight is None else weight)
    primary = solve_horizon(g, load, pv, price, s0, b, terminal, weight, s_ref)
    problem = _dispatch_lp(g, load, pv, price, s0, b, terminal, weight, s_ref)
    secondary_objective = np.zeros(problem["nvar"])
    secondary_objective[problem["n"]] = -1.0
    out = _solve_built(
        problem, secondary_objective, b, terminal, weight, s_ref,
        primary_ceiling=primary["objective"] + PRIMARY_ALLOWANCE_YUAN,
    )
    error = out["primary_objective"] - primary["objective"]
    if abs(error) > PRIMARY_VERIFICATION_TOL_YUAN:
        raise RuntimeError(f"Secondary stage changed primary objective by {error} yuan.")
    out.update(
        primary_optimum=primary["objective"], primary_cost_error_yuan=float(error),
        solve_count=2,
        solve_seconds=out["solve_seconds"] + primary["solve_seconds"],
        success=True,
    )
    return out


def forced_charge_primary_objective(
    g, load, pv, price, s0, forced_first_charge,
    b: Battery = DEFAULT_BATTERY, terminal="shortfall", weight=None, s_ref=6000.,
) -> dict:
    """Verification helper: primary LP with a prescribed first charge amount.

    It is not used by the online controller or for policy selection.
    """
    price = _vector(price, "price")
    weight = float(np.min(price) / b.eta_c if weight is None else weight)
    problem = _dispatch_lp(g, load, pv, price, s0, b, terminal, weight, s_ref)
    return _solve_built(
        problem, problem["primary_linear"], b, terminal, weight, s_ref,
        forced_first_charge=forced_first_charge,
    )


def simulate_refined_day(
    g, load_actual, pv_actual, load_forecast, pv_forecast, price, s0,
    terminal="shortfall", weight=None, s_ref=6000., b: Battery = DEFAULT_BATTERY,
) -> dict:
    """Causal replay using maximal surplus charging and explicit LP refinement.

    Current actual values replace the first element of a future forecast suffix.
    No future actual observation is passed to either LP. Neutral/surplus slots
    need no optimization; deficit slots each use two LP solves.
    """
    g = _vector(g, "g")
    n = len(g)
    load_actual = _vector(load_actual, "load_actual", n)
    pv_actual = _vector(pv_actual, "pv_actual", n)
    load_forecast = _vector(load_forecast, "load_forecast", n)
    pv_forecast = _vector(pv_forecast, "pv_forecast", n)
    price = _vector(price, "price", n)
    if terminal not in ("shortfall", "value"):
        raise ValueError("terminal must be shortfall or value.")
    weight = float(np.min(price) / b.eta_c if weight is None else weight)
    if not np.isfinite(weight) or weight < 0 or not np.isfinite(s_ref):
        raise ValueError("Invalid terminal weight or reference.")
    s = np.empty(n + 1)
    s[0] = _initial_state(s0, b)
    actions = {key: np.empty(n) for key in ("c", "d", "e", "v", "r", "w")}
    solve_count = 0
    solve_seconds = 0.0
    primary_errors = []
    forced_charge_steps = 0
    neutral_steps = 0
    for t in range(n):
        net = g[t] + pv_actual[t] - load_actual[t]
        if net >= 0:
            step = greedy_step(g[t], load_actual[t], pv_actual[t], s[t], b)
            for key in actions:
                actions[key][t] = step[key]
            s[t + 1] = step["s_next"]
            if net > 0:
                forced_charge_steps += 1
            else:
                neutral_steps += 1
            continue
        remaining_load = load_forecast[t:].copy()
        remaining_pv = pv_forecast[t:].copy()
        remaining_load[0] = load_actual[t]
        remaining_pv[0] = pv_actual[t]
        horizon = solve_refined_horizon(
            g[t:], remaining_load, remaining_pv, price[t:], s[t],
            b=b, terminal=terminal, weight=weight, s_ref=s_ref,
        )
        for key in actions:
            actions[key][t] = horizon[key][0]
        s[t + 1] = horizon["s"][1]
        solve_count += horizon["solve_count"]
        solve_seconds += horizon["solve_seconds"]
        primary_errors.append(horizon["primary_cost_error_yuan"])
    fees_plan = float(price @ g)
    fees_emergency = float(5 * price @ actions["e"])
    out = {
        **actions, "g": g, "s": s, "price": price,
        "load": load_actual, "pv": pv_actual,
        "load_forecast": load_forecast, "pv_forecast": pv_forecast,
        "method": "refined_soft" if terminal == "shortfall" else "refined_value",
        "terminal": terminal, "weight": weight, "s_ref": float(s_ref),
        "fees_plan": fees_plan, "fees_emergency": fees_emergency,
        "fees_total": fees_plan + fees_emergency,
        "solve_count": solve_count, "solve_seconds": solve_seconds,
        "max_primary_cost_error_yuan": max([abs(x) for x in primary_errors] or [0.]),
        "max_primary_cost_increase_yuan": max(primary_errors + [0.]),
        "primary_allowance_yuan": PRIMARY_ALLOWANCE_YUAN,
        "primary_verification_tolerance_yuan": PRIMARY_VERIFICATION_TOL_YUAN,
        "forced_surplus_charge_steps": forced_charge_steps,
        "neutral_steps": neutral_steps, "two_stage_steps": len(primary_errors),
        "success": True, "status_code": 0,
    }
    out["checks"] = check_trajectory(out, b)
    if not out["checks"]["passed"]:
        raise RuntimeError(f"Refined replay trajectory checks failed: {out['checks']}")
    return out


def run_controller(
    method, g, load_actual, pv_actual, load_forecast, pv_forecast, price, s0,
    terminal_weight=None, s_ref=6000., b: Battery = DEFAULT_BATTERY,
) -> dict:
    """Run one supplied horizon using a fixed ordinary purchase contract.

    ``method`` is ``greedy`` or ``mpc``. Inputs g/load/pv are interval energies
    (kWh), price is yuan/kWh, and s0 is measured internal stored energy (kWh).
    A full production day contains exactly 144 slots; shorter horizons are
    accepted here for independent verification. Input/output boundary handling
    and selection of a day's 144 intervals belong to the data interface.

    The default MPC kappa is min(full_day_price) / eta_c and stays fixed in every
    shrinking suffix solve. It is a candidate terminal-valuation setting, not
    a competition rule or a parameter selected from future outcomes. A caller
    should pass one calibrated value explicitly when conducting sensitivity
    studies. The terminal penalty is never included in fees_total.

    Actual state is carried across days by passing the previous result's s[-1]
    as the next s0. This function never resets state to 6000 automatically.
    Returned arrays c/d/e/v/r/w have n elements and s has n+1 boundaries.
    """
    if method not in ("greedy", "mpc"):
        raise ValueError("method must be 'greedy' or 'mpc'.")
    p = _vector(price, "price")
    weight = float(np.min(p) / b.eta_c if terminal_weight is None else terminal_weight)
    if not np.isfinite(weight) or weight < 0 or not np.isfinite(s_ref):
        raise ValueError("Terminal weight and reference must be finite; weight >= 0.")
    contract_before = _vector(g, "g", len(p))
    if method == "greedy":
        out = simulate_day(
            contract_before, load_actual, pv_actual, load_forecast, pv_forecast,
            p, s0, method="greedy", weight=0., s_ref=s_ref, b=b,
        )
    else:
        out = simulate_refined_day(
            contract_before, load_actual, pv_actual, load_forecast, pv_forecast,
            p, s0, terminal="shortfall", weight=weight, s_ref=s_ref, b=b,
        )
    contract_unchanged = bool(np.array_equal(out["g"], contract_before))
    out["checks"]["fixed_contract_unchanged"] = contract_unchanged
    out["checks"]["passed"] = bool(out["checks"]["passed"] and contract_unchanged)
    out.update(
        method=method,
        terminal_weight=weight if method == "mpc" else 0.,
        terminal_shortfall_kwh=max(float(s_ref - out["s"][-1]), 0.),
        terminal_penalty_yuan=(weight * max(float(s_ref - out["s"][-1]), 0.)
                               if method == "mpc" else 0.),
        observation_assumption="current_interval_mean_as_fast_feedback_proxy",
        future_inputs="day_ahead_forecast_only",
        execution_rule="execute_first_step_then_reobserve",
        surplus_bookkeeping="use_PV_first_then_paid_grid; unused_paid_grid_has_no_refund",
        input_flow_units="kWh_per_10min_interval",
    )
    if not out["checks"]["passed"]:
        raise RuntimeError(f"Controller physical checks failed: {out['checks']}")
    return out
