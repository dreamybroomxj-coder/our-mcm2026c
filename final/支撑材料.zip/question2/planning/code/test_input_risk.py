"""Data-interface and causal risk checks using synthetic temporary fixtures."""

from __future__ import annotations

import copy
import csv
import datetime as dt
from pathlib import Path
import tempfile
import unittest

import numpy as np
from openpyxl import Workbook

from input_io import (
    clock_minute, interval_header, load_bundle, pair_forecast_workbooks,
    read_price, read_wide_means,
)
from risk import build_risk_inputs, historical_residuals


FORECAST_COLUMNS = [
    "plan_date", "issued_at", "interval_start", "interval_end",
    "load_forecast_kw", "pv_forecast_kw",
]
ACTUAL_COLUMNS = ["interval_start", "interval_end", "load_actual_kw", "pv_actual_kw"]


def write_rows(path, rows, columns):
    with Path(path).open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns)
        writer.writeheader()
        writer.writerows(rows)


def interval_headers():
    def clock(minutes):
        if minutes >= 1440:
            return f"次日{(minutes - 1440)//60:02d}:{(minutes - 1440)%60:02d}"
        return f"{minutes//60:02d}:{minutes%60:02d}"
    return [f"{clock(10*t)}—{clock(10*t+10)}" for t in range(145)]


def fixture_rows(days):
    forecast, actual = [], []
    for day_index, day in enumerate(days):
        zero = dt.datetime.combine(day, dt.time())
        for t in range(145):
            start = zero + dt.timedelta(minutes=10*t)
            forecast.append({
                "plan_date": day.isoformat(), "issued_at": zero.isoformat(),
                "interval_start": start.isoformat(),
                "interval_end": (start + dt.timedelta(minutes=10)).isoformat(),
                "load_forecast_kw": 100 + 10 * day_index + (100 if t % 2 else 0),
                "pv_forecast_kw": 10 + t / 100,
            })
            if t < 144:
                actual.append({
                    "interval_start": start.isoformat(),
                    "interval_end": (start + dt.timedelta(minutes=10)).isoformat(),
                    "load_actual_kw": 200 + day_index + t / 100,
                    "pv_actual_kw": 15 + t / 100,
                })
    return forecast, actual


def risk_fixture(days=35):
    dates = [dt.date(2025, 1, 1) + dt.timedelta(days=i) for i in range(days)]
    slots = np.arange(144)[None, :]
    day_id = np.arange(days)[:, None]
    load_forecast = np.full((days, 144), 1000.)
    pv_forecast = np.full((days, 144), 400.)
    # Each day has a unique full-path residual, and the two paths are paired.
    load_residual = 10 * (day_id + 1) + .01 * slots
    pv_residual = 2 * (day_id + 1) + .003 * slots
    return {
        "dates": dates, "load_f": load_forecast, "pv_f": pv_forecast,
        "load_a": load_forecast + load_residual,
        "pv_a": pv_forecast + pv_residual,
    }


class InputRiskTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.days = [dt.date(2025, 2, 1), dt.date(2025, 2, 2)]

    def tearDown(self):
        self.temp.cleanup()

    def bundle(self, forecast, actual, forecast_columns=FORECAST_COLUMNS):
        fp, ap = self.root / "forecast.csv", self.root / "actual.csv"
        write_rows(fp, forecast, forecast_columns)
        write_rows(ap, actual, ACTUAL_COLUMNS)
        return load_bundle(fp, ap)

    def test_145_interval_means_survive_xlsx_conversion_without_averaging(self):
        book = Workbook()
        load_sheet = book.active
        load_sheet.title = "负载预测"
        pv_sheet = book.create_sheet("光伏预测")
        headers = interval_headers()
        # The supplied format's specifically confirmed alias must also work.
        headers[143] = "次日00:00"
        for sheet in (load_sheet, pv_sheet):
            sheet.append(["日期"] + headers)
        expected_load, expected_pv = [], []
        for j, day in enumerate(self.days):
            load = 100 + j * 1000 + 300 * (np.arange(145) % 2)
            pv = 10 + j * 10 + np.arange(145) / 10
            load[-1] = 999999 + j
            pv[-1] = 77777 + j
            expected_load.append(load)
            expected_pv.append(pv)
            load_sheet.append([dt.datetime.combine(day, dt.time())] + load.tolist())
            pv_sheet.append([dt.datetime.combine(day, dt.time())] + pv.tolist())
        path = self.root / "paired_forecasts.xlsx"
        book.save(path)
        dates, values, metadata = read_wide_means(path, "负载预测")
        self.assertEqual(dates, self.days)
        np.testing.assert_array_equal(values, np.array(expected_load))
        self.assertTrue(metadata["no_averaging_performed"])
        forecast_path = self.root / "converted.csv"
        with self.assertRaises(ValueError):
            pair_forecast_workbooks(path, path, forecast_path, "负载预测", "负载预测")
        pair_forecast_workbooks(path, path, forecast_path, "负载预测", "光伏预测")
        _, actual = fixture_rows(self.days)
        actual_path = self.root / "actual.csv"
        write_rows(actual_path, actual, ACTUAL_COLUMNS)
        bundle = load_bundle(forecast_path, actual_path)
        np.testing.assert_array_equal(bundle["load_f"], np.array(expected_load)[:, :144])
        np.testing.assert_array_equal(bundle["pv_f"], np.array(expected_pv)[:, :144])
        np.testing.assert_array_equal(bundle["extra_load_f"], np.array(expected_load)[:, 144])
        self.assertEqual(bundle["load_f"].shape, (2, 144))
        self.assertFalse(bundle["metadata"]["extra_interval_used_for_dispatch"])
        self.assertEqual(bundle["load_f"][1, 0], expected_load[1][0])
        self.assertNotEqual(bundle["load_f"][1, 0], bundle["extra_load_f"][0])

    def test_instantaneous_prices_use_periodic_zero_and_both_interval_endpoints(self):
        book = Workbook()
        sheet = book.active
        sheet.append(["时间", "电价"])
        nodes_given = .1 + np.arange(1, 145) / 100
        for t, price in enumerate(nodes_given, start=1):
            minutes = 10 * t
            label = "00:00+1" if t == 144 else f"{minutes//60:02d}:{minutes%60:02d}"
            sheet.append([label, float(price)])
        path = self.root / "attachment1.xlsx"
        book.save(path)
        interval_price, metadata = read_price(path)
        self.assertEqual(interval_price.shape, (144,))
        self.assertAlmostEqual(interval_price[0], (nodes_given[-1] + nodes_given[0]) / 2)
        self.assertAlmostEqual(interval_price[1], (nodes_given[0] + nodes_given[1]) / 2)
        self.assertAlmostEqual(interval_price[-1], (nodes_given[-2] + nodes_given[-1]) / 2)
        self.assertEqual(metadata["price_nodes"], 145)
        self.assertEqual(metadata["mean_intervals"], 144)

    def test_illegal_clocks_and_non_ten_minute_intervals_are_rejected(self):
        for value in ("25:50", "24:10", "12:60"):
            with self.subTest(clock=value), self.assertRaises(ValueError):
                clock_minute(value)
        for value in ("25:50—26:00", "00:00—00:20", "00:05—00:10"):
            with self.subTest(interval=value), self.assertRaises(ValueError):
                interval_header(value)

    def test_missing_pv_and_late_forecast_release_are_rejected(self):
        forecast, actual = fixture_rows(self.days)
        missing = [{k: v for k, v in row.items() if k != "pv_forecast_kw"} for row in forecast]
        columns = [x for x in FORECAST_COLUMNS if x != "pv_forecast_kw"]
        with self.assertRaises(ValueError):
            self.bundle(missing, actual, columns)
        forecast[0]["issued_at"] = "2025-02-01T00:01:00"
        with self.assertRaises(ValueError):
            self.bundle(forecast, actual)

    def test_missing_actual_slot_and_nonconsecutive_dates_are_rejected(self):
        forecast, actual = fixture_rows(self.days)
        with self.assertRaises(ValueError):
            self.bundle(forecast, actual[:70] + actual[71:])
        discontinuous = [self.days[0], self.days[1] + dt.timedelta(days=1)]
        forecast, actual = fixture_rows(discontinuous)
        with self.assertRaises(ValueError):
            self.bundle(forecast, actual)

    def test_current_and_future_actual_changes_do_not_change_risk_inputs(self):
        data = risk_fixture()
        i = 30
        altered = copy.deepcopy(data)
        altered["load_a"][i:] += 100000
        altered["pv_a"][i:] += 50000
        altered["load_f"][i + 1:] += 5000
        altered["pv_f"][i + 1:] += 2000
        # Records outside the declared past window must also be irrelevant.
        altered["load_a"][:i - 7] += 80000
        for method in ("C", "D"):
            a = build_risk_inputs(data, i, method, window=7, min_history=5, scenarios=12, seed=31)
            z = build_risk_inputs(altered, i, method, window=7, min_history=5, scenarios=12, seed=31)
            for left, right in zip(a[:4], z[:4]):
                if left is None:
                    self.assertIsNone(right)
                else:
                    np.testing.assert_array_equal(left, right)
            self.assertEqual(a[4], z[4])
            self.assertEqual(a[4]["history_days"], 7)

    def test_scenarios_sample_whole_day_load_pv_residual_pairs(self):
        data = risk_fixture()
        i = 20
        lf, pf, sl, sp, meta = build_risk_inputs(data, i, "D", window=8, min_history=5, scenarios=20, seed=902)
        historical_indices = meta["historical_day_indices"]
        self.assertEqual(len(historical_indices), 20)
        self.assertTrue(all(i - 8 <= j < i for j in historical_indices))
        for scenario, day in enumerate(historical_indices):
            np.testing.assert_allclose(sl[scenario] - lf, data["load_a"][day] - data["load_f"][day])
            np.testing.assert_allclose(sp[scenario] - pf, data["pv_a"][day] - data["pv_f"][day])
        # A repeat must reproduce both paths and the selected historical days.
        again = build_risk_inputs(data, i, "D", window=8, min_history=5, scenarios=20, seed=902)
        np.testing.assert_array_equal(sl, again[2])
        np.testing.assert_array_equal(sp, again[3])

    def test_margin_uses_one_sided_net_residual_and_zero_means_no_margin(self):
        data = risk_fixture(days=5)
        data["load_f"][:] = 100
        data["pv_f"][:] = 50
        data["pv_a"][:] = 55
        data["load_a"][:] = 90
        data["load_a"][:4, 0] = 100 + np.array([-5, 5, 15, 25])
        lf, pf, _, _, meta = build_risk_inputs(data, 4, "C", window=4, min_history=4, quantile=.5)
        # Net residuals at slot zero are -10,0,10,20; median is 5 kW.
        self.assertAlmostEqual(lf[0], 105)
        np.testing.assert_array_equal(lf[1:], data["load_f"][4, 1:])
        np.testing.assert_array_equal(pf, data["pv_f"][4])
        self.assertAlmostEqual(meta["margin_kwh"], 5 / 6)
        no_margin = build_risk_inputs(data, 4, "C", window=4, min_history=4, quantile=0)
        np.testing.assert_array_equal(no_margin[0], data["load_f"][4])

    def test_short_history_falls_back_and_future_dated_history_is_rejected(self):
        data = risk_fixture(days=5)
        for method in ("C", "D"):
            lf, pf, sl, sp, meta = build_risk_inputs(data, 2, method, min_history=3)
            np.testing.assert_array_equal(lf, data["load_f"][2])
            np.testing.assert_array_equal(pf, data["pv_f"][2])
            self.assertIsNone(sl)
            self.assertIsNone(sp)
            self.assertTrue(meta["fallback"])
            self.assertEqual(meta["history_days"], 2)
        data["dates"][0] = data["dates"][3]
        with self.assertRaises(ValueError):
            historical_residuals(data, 2)

    def test_invalid_risk_configuration_is_rejected_before_short_history_fallback(self):
        data = risk_fixture(days=5)
        configurations = (
            {"method": "unknown"},
            {"method": "C", "quantile": 1.0},
            {"method": "C", "quantile": -0.1},
            {"method": "D", "scenarios": 0},
            {"method": "D", "window": 0},
            {"method": "D", "window": 28, "min_history": 29},
        )
        for configuration in configurations:
            with self.subTest(configuration=configuration), self.assertRaises(ValueError):
                build_risk_inputs(data, 0, **configuration)


if __name__ == "__main__":
    unittest.main()
