"""Independent accounting checks and paired day-block cost diagnostics."""
import argparse
import csv
import json
from pathlib import Path
import numpy as np


def rows(path):
    with Path(path).open(encoding='utf-8-sig',newline='') as f:
        return list(csv.DictReader(f))


def paired_block_interval(values,block=7,draws=1000,seed=20260911):
    """Circular moving-block bootstrap; paired daily differences, not raw slots.

    This is a conditional finite-sample diagnostic, not a guarantee of future
    cost or a correction for all policy-state dependence/nonstationarity.
    """
    x=np.asarray(values,float)
    if len(x)<2:
        return None
    block=min(block,len(x));rng=np.random.default_rng(seed)
    means=[]
    for _ in range(draws):
        starts=rng.integers(0,len(x),size=int(np.ceil(len(x)/block)))
        indices=((starts[:,None]+np.arange(block))%len(x)).ravel()[:len(x)]
        means.append(float(x[indices].mean()))
    return np.quantile(means,[.025,.975]).tolist()


def audit(out):
    out=Path(out);summary=json.loads((out/'summary.json').read_text())
    daily=rows(out/'stage3_continuous_daily.csv')
    trace=rows(out/'stage3_interval_trace.csv')
    maxima={'energy_balance_kwh':0.,'soc_transition_kwh':0.,'soc_link_kwh':0.,
            'daily_bill_yuan':0.,'interval_bill_yuan':0.,'bound_violation':0.}
    ledger={};last={}
    for r in trace:
        k=r['method'];date=r.get('plan_date',r['interval_start'][:10]);key=(k,date)
        g,c,d,e,v,pv_dump=[float(r[f]) for f in ('g_kwh','charge_kwh','discharge_kwh','emergency_kwh','unused_paid_kwh','curtailed_pv_kwh')]
        load,pv=float(r['load_actual_kw'])/6,float(r['pv_actual_kw'])/6
        s0,s1=float(r['soc_start_kwh']),float(r['soc_end_kwh'])
        p=float(r['price_yuan_per_kwh']);cost=float(r['cash_cost_yuan'])
        maxima['energy_balance_kwh']=max(maxima['energy_balance_kwh'],abs(g-v+pv-pv_dump+d+e-load-c))
        maxima['soc_transition_kwh']=max(maxima['soc_transition_kwh'],abs(s1-s0-.9*c+d/.9))
        maxima['interval_bill_yuan']=max(maxima['interval_bill_yuan'],abs(cost-p*g-5*p*e))
        a=max(g+pv-load,0);deficit=max(load-g-pv,0)
        maxima['bound_violation']=max(maxima['bound_violation'],
            1200-s0,1200-s1,s0-10800,s1-10800,c-5000/6,d-5000/6,c-a,d-deficit,
            abs(e-deficit+d),v-g,pv_dump-pv,-min(g,c,d,e,v,pv_dump))
        if k in last:
            maxima['soc_link_kwh']=max(maxima['soc_link_kwh'],abs(s0-last[k]))
        last[k]=s1
        ledger.setdefault(key,[]).append(cost)
    for r in daily:
        values=ledger[(r['method'],r['date'])]
        if len(values)!=144:
            raise AssertionError('Executed day must have exactly 144 intervals')
        maxima['daily_bill_yuan']=max(maxima['daily_bill_yuan'],abs(sum(values)-float(r['cash_cost_yuan'])))
    if not all(v<1e-4 for v in maxima.values()):
        raise AssertionError(f'Independent ledger audit failed: {maxima}')
    comparisons=[]
    for filename,base,candidates in [('stage1_same_contract_daily.csv','A',['B']),
                                      ('stage2_dayahead_daily.csv','B',['C','D'])]:
        src=rows(out/filename);ref={r['date']:r for r in src if r['method']==base}
        for candidate in candidates:
            cand=sorted([r for r in src if r['method']==candidate],key=lambda r:r['date'])
            for metric in ['cash_cost_yuan','inventory_adjusted_cost_yuan']:
                diff=[]
                for r in cand:
                    b=ref[r['date']]
                    assert abs(float(r['initial_soc_kwh'])-float(b['initial_soc_kwh']))<1e-6
                    if filename.startswith('stage1'):
                        assert abs(float(r['planned_cost_yuan'])-float(b['planned_cost_yuan']))<1e-5
                        assert abs(float(r['planned_kwh'])-float(b['planned_kwh']))<1e-5
                    diff.append(float(r[metric])-float(b[metric]))
                comparisons.append({'comparison':candidate+' minus '+base,'metric':metric,
                    'days':len(diff),'mean_daily_difference_yuan':float(np.mean(diff)),
                    'candidate_lower_fraction':float(np.mean(np.asarray(diff)<-1e-5)),
                    'block_length_days':min(7,len(diff)),'bootstrap_draws':1000,
                    'conditional_95pct_mean_interval_yuan':paired_block_interval(diff),
                    'small_sample_caution':len(diff)<30})
    result={'data_role':summary['data_role'],'independent_checks_passed':True,
        'max_absolute_residuals':maxima,'paired_local_comparisons':comparisons,
        'interpretation':'Negative difference favors candidate only for these supplied inputs and declared data assumptions. Bootstrap is descriptive, not a guarantee across seasons or forecast versions.'}
    (out/'independent_evaluation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
    print(json.dumps({'independent_checks_passed':True,'max_residuals':maxima}))
    return result


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('result_directory',type=Path)
    audit(p.parse_args().result_directory)
