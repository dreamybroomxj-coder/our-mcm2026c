"""Synthetic engineering checks; these tests are not a real-data policy ranking.

Run from this directory with: python -m unittest test_control_v2 -v
"""

from __future__ import annotations

import unittest
from unittest.mock import patch

import numpy as np

import control_refined
from control import Battery, DEFAULT_BATTERY, solve_horizon
from control_refined import run_controller, solve_refined_horizon


class ControlV2Tests(unittest.TestCase):
    def test_two_slot_90_kwh_example_same_contract(self):
        args = dict(g=[0., 0.], load_actual=[100., 100.], pv_actual=[0., 0.],
                    load_forecast=[100., 100.], pv_forecast=[0., 0.],
                    price=[.4, 1.], s0=1300.)
        greedy = run_controller("greedy", **args)
        mpc = run_controller("mpc", **args)
        self.assertAlmostEqual(greedy["fees_total"], 520., places=5)
        self.assertAlmostEqual(mpc["fees_total"], 250., places=5)
        np.testing.assert_allclose(greedy["d"], [90., 0.], atol=1e-6)
        np.testing.assert_allclose(mpc["d"], [0., 90.], atol=1e-6)
        self.assertAlmostEqual(mpc["s"][-1], 1200., places=5)
        # The soft terminal penalty is deliberately excluded from cash fees.
        self.assertGreater(mpc["terminal_penalty_yuan"], 0.)
        self.assertAlmostEqual(mpc["fees_total"], mpc["fees_plan"] + mpc["fees_emergency"])

    def test_units_and_efficiencies_independently(self):
        b = DEFAULT_BATTERY
        self.assertAlmostEqual(b.rate, 5000. / 6.)
        discharge = run_controller("greedy", [0.], [1000.], [0.], [1000.], [0.], [.5], 6000.)
        self.assertAlmostEqual(discharge["d"][0], 5000. / 6.)
        self.assertAlmostEqual(discharge["e"][0], 1000. - 5000. / 6.)
        self.assertAlmostEqual(discharge["s"][1], 6000. - (5000. / 6.) / .9)
        self.assertAlmostEqual(discharge["fees_emergency"], 5. * .5 * (1000. - 5000. / 6.))
        charge = run_controller("greedy", [1000.], [0.], [0.], [0.], [0.], [.5], 6000.)
        self.assertAlmostEqual(charge["c"][0], 5000. / 6.)
        self.assertAlmostEqual(charge["s"][1], 6750.)
        self.assertAlmostEqual(charge["fees_plan"], 500.)
        # Already-converted 100 kWh must not be divided by six again.
        neutral = run_controller("mpc", [100.], [100.], [0.], [100.], [0.], [.5], 6000.)
        self.assertAlmostEqual(neutral["fees_plan"], 50.)
        self.assertAlmostEqual(neutral["s"][1], 6000.)

    def test_future_actual_perturbation_cannot_change_past_actions(self):
        n = 12
        g = np.full(n, 100.)
        lf = np.full(n, 200.)
        pf = np.zeros(n)
        actual1 = np.full(n, 220.)
        actual2 = actual1.copy()
        actual2[4:] += 500.
        pv2 = pf.copy()
        pv2[5:] = 1000.
        price = np.linspace(.3, 1., n)
        first = run_controller("mpc", g, actual1, pf, lf, pf, price, 2100.)
        second = run_controller("mpc", g, actual2, pv2, lf, pf, price, 2100.)
        for key in ("c", "d", "e", "v", "r"):
            np.testing.assert_allclose(first[key][:4], second[key][:4], atol=1e-8)
        np.testing.assert_allclose(first["s"][:5], second["s"][:5], atol=1e-8)

    def test_solver_receives_forecast_suffix_and_current_actual_only(self):
        n = 6
        lf = np.arange(n, dtype=float) + 100.
        pf = np.arange(n, dtype=float)
        actual = lf + 30.
        pva = pf + 2.
        p = np.array([.1, .5, .6, .7, .8, .9])
        captured = []
        original = control_refined.solve_refined_horizon

        def record(g, load, pv, price, s0, **kwargs):
            t = n - len(g)
            self.assertAlmostEqual(load[0], actual[t])
            self.assertAlmostEqual(pv[0], pva[t])
            np.testing.assert_array_equal(load[1:], lf[t + 1:])
            np.testing.assert_array_equal(pv[1:], pf[t + 1:])
            captured.append((t, kwargs["weight"]))
            return original(g, load, pv, price, s0, **kwargs)

        with patch.object(control_refined, "solve_refined_horizon", side_effect=record):
            out = run_controller("mpc", np.zeros(n), actual, pva, lf, pf, p, 1300.)
        self.assertEqual([t for t, _ in captured], list(range(n)))
        np.testing.assert_allclose([weight for _, weight in captured], .1 / .9)
        self.assertTrue(out["checks"]["passed"])

    def test_only_first_horizon_action_is_executed(self):
        starts = []

        def fake_horizon(g, load, pv, price, s0, **kwargs):
            starts.append(s0)
            n = len(g)
            # Deliberately unusable future actions must never be executed.
            out = {key: np.r_[0., np.full(n - 1, 99999.)]
                   for key in ("c", "d", "v", "r", "w")}
            out["e"] = np.r_[100., np.full(n - 1, 99999.)]
            out["s"] = np.r_[s0, s0, np.full(n - 1, -99999.)]
            out.update(solve_count=2, solve_seconds=0., primary_cost_error_yuan=0.)
            return out

        with patch.object(control_refined, "solve_refined_horizon", side_effect=fake_horizon):
            out = run_controller("mpc", [0.] * 3, [100.] * 3, [0.] * 3,
                                 [100.] * 3, [0.] * 3, [.5] * 3, 6000.)
        np.testing.assert_array_equal(out["d"], [0., 0., 0.])
        np.testing.assert_array_equal(out["e"], [100., 100., 100.])
        np.testing.assert_array_equal(out["s"], [6000.] * 4)
        self.assertEqual(starts, [6000.] * 3)
        self.assertTrue(out["checks"]["passed"])

    def test_zero_error_144_slot_feasible_cycle(self):
        load = np.full(144, 500.)
        g = np.tile(np.r_[np.full(24, 600.), np.full(24, 419.)], 3)
        pv = np.zeros(144)
        price = np.full(144, .5)
        original_g = g.copy()
        for method in ("greedy", "mpc"):
            out = run_controller(method, g, load, pv, load, pv, price, 6000.)
            self.assertTrue(out["checks"]["passed"])
            self.assertLess(out["fees_emergency"], 1e-5)
            np.testing.assert_allclose(out["s"][-1], 6000., atol=1e-5)
            self.assertEqual(len(out["s"]), 145)
            self.assertEqual(len(out["c"]), 144)
            np.testing.assert_array_equal(out["g"], original_g)
        np.testing.assert_array_equal(g, original_g)

    def test_bounds_and_emergency_never_charges(self):
        for method in ("greedy", "mpc"):
            empty = run_controller(method, [0.], [500.], [0.], [500.], [0.], [.5], 1200.)
            self.assertAlmostEqual(empty["c"][0], 0.)
            self.assertAlmostEqual(empty["d"][0], 0.)
            self.assertAlmostEqual(empty["e"][0], 500.)
            self.assertAlmostEqual(empty["s"][-1], 1200.)
            full = run_controller(method, [400.], [100.], [200.], [100.], [200.], [.5], 10800.)
            self.assertAlmostEqual(full["c"][0], 0.)
            self.assertAlmostEqual(full["v"][0], 400.)
            self.assertAlmostEqual(full["r"][0], 100.)
            self.assertAlmostEqual(full["fees_plan"], 200.)
            self.assertAlmostEqual(full["s"][-1], 10800.)
            self.assertTrue(full["checks"]["passed"])

    def test_state_carries_between_calls(self):
        day1 = run_controller("greedy", [100.], [0.], [0.], [0.], [0.], [.5], 6000.)
        day2 = run_controller("greedy", [0.], [100.], [0.], [100.], [0.], [.5], day1["s"][-1])
        self.assertAlmostEqual(day1["s"][-1], 6090.)
        self.assertAlmostEqual(day2["s"][0], 6090.)
        self.assertAlmostEqual(day2["s"][-1], 6090. - 100. / .9)

    def test_refinement_preserves_primary_objective(self):
        rng = np.random.default_rng(20260911)
        for _ in range(5):
            n = 12
            g, load, pv = (rng.uniform(0, 500, n) for _ in range(3))
            price = rng.uniform(.3, 1., n)
            s0 = float(rng.uniform(1200, 10800))
            weight = float(np.min(price) / .9)
            basic = solve_horizon(g, load, pv, price, s0, weight=weight)
            refined = solve_refined_horizon(g, load, pv, price, s0, weight=weight)
            self.assertLess(abs(basic["objective"] - refined["primary_objective"]), 1e-5)
            self.assertTrue(refined["checks"]["passed"])

    def test_invalid_inputs_fail_loudly(self):
        valid = dict(g=[0.], load_actual=[100.], pv_actual=[0.], load_forecast=[100.],
                     pv_forecast=[0.], price=[.5], s0=6000.)
        for key, value in (("g", [-1.]), ("price", [np.nan]), ("s0", 1190.),
                           ("load_forecast", [100., 100.])):
            with self.subTest(key=key), self.assertRaises(ValueError):
                run_controller("mpc", **{**valid, key: value})
        with self.assertRaises(ValueError):
            run_controller("unknown", **valid)
        with self.assertRaises(ValueError):
            run_controller("mpc", **valid, terminal_weight=-1.)
        with self.assertRaises(ValueError):
            Battery(eta_c=0.)


if __name__ == "__main__":
    unittest.main(verbosity=2)
