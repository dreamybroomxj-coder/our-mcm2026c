"""Midnight-bridge integration tests with real physical prefix execution.

The inexpensive test planner is deliberately state-dependent and is not a
candidate dispatch model. Three complete 144-slot windows isolate scheduling
order, causal handoff, contract preservation and cash bookkeeping.
"""
from __future__ import annotations

import csv
import datetime as dt
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import numpy as np

import window_study as ws


def fixture(days=3):
    dates = [dt.date(2030, 2, 1) + dt.timedelta(days=i) for i in range(days)]
    origins = [dt.datetime.combine(day, dt.time()) for day in dates]
    starts = [origin + dt.timedelta(minutes=10) for origin in origins]
    return {
        "dates": dates, "issued_at": origins, "window_start": starts,
        "window_end": [start + dt.timedelta(days=1) for start in starts],
        "load_f": np.full((days, 144), 600.), "pv_f": np.zeros((days, 144)),
        "load_a": np.full((days, 144), 600.), "pv_a": np.zeros((days, 144)),
        "actual_estimated": np.zeros((days, 144), dtype=bool),
        "metadata": {"role": "synthetic_midnight_bridge_test"},
    }


def config():
    return dict(initial_soc=6000., calibration_days=1, default_quantile=.8,
                inventory_value=.5 / .9, terminal_weight=.5 / .9,
                milp_seconds=30., mip_gap=1e-5, s_ref=6000.)


class MidnightBridgeTests(unittest.TestCase):
    def replay(self, changed_final_actual=False, method="B"):
        data = fixture()
        if changed_final_actual:
            # The interval [next midnight, next 00:10] is not observed yet when
            # the next midnight contract is signed.
            data["load_a"][0, -1] = 1200.
        p = np.full(144, .5)
        ws.initialize(data, p, config())
        events, plan_records, execution_records = [], [], []
        original_execute = ws.execute

        def cheap_state_dependent_plan(i, mode, s0, q, prefix=None):
            events.append(("plan", i))
            # Restore any inherited deficit gradually over the *new* window.
            new_g = np.full(144, 100. + (6000. - s0) / (.9 * 144.))
            contract = new_g if prefix is None else np.r_[prefix[0], new_g]
            plan_records.append({"i": i, "s0": float(s0), "prefix": prefix,
                                 "new_g": new_g.copy(), "full_g": contract.copy()})
            pl = {
                "g": contract, "status": "optimal_within_requested_gap", "mip_gap": 0.,
                "checks": {"passed": True, "scope": "mock planner; physical execution independently checked"},
                "solve_seconds": 0., "expected_emergency_cost": 0.,
                "objective": float(.5 * contract.sum()),
                "state_at_new_window_start_kwh": float(s0),
            }
            return pl, {"history_days": 0, "fallback": False, "test_planner": True}

        def record_execution(mode, g, la, pa, lf, pf, price, s0, steps):
            if steps == 143:
                name = ("body", sum(e[0] == "body" for e in events))
            else:
                name = ("tail", sum(e[0] == "tail" for e in events))
            events.append(name)
            out = original_execute(mode, g, la, pa, lf, pf, price, s0, steps)
            execution_records.append({"event": name, "s0": float(s0),
                "g_horizon": np.asarray(g).copy(), "forecast_horizon": np.asarray(lf).copy(),
                "actual": np.asarray(la).copy(), "steps": steps, "out": out})
            return out

        with tempfile.TemporaryDirectory() as tmp:
            with patch.object(ws, "plan", side_effect=cheap_state_dependent_plan), \
                 patch.object(ws, "execute", side_effect=record_execution):
                result = ws.continuous_job((method, .8, tmp, 3, 6000.))
            with (Path(tmp) / f"{method}_trace.csv").open(encoding="utf-8-sig", newline="") as f:
                trace = list(csv.DictReader(f))
            logs = json.loads((Path(tmp) / f"{method}_solver.json").read_text(encoding="utf-8"))
        return result, trace, events, plan_records, execution_records, logs

    def test_new_plan_precedes_unobserved_old_tail_feedback(self):
        _, _, events, plans, executions, logs = self.replay(True)
        self.assertEqual(events, [("plan", 0), ("body", 0), ("plan", 1), ("tail", 0),
                                  ("body", 1), ("plan", 2), ("tail", 1), ("body", 2), ("tail", 2)])
        self.assertEqual(plans[1]["prefix"], (100., 600., 0.))
        self.assertEqual(plans[1]["s0"], 6000.)
        bridge = next(x for x in executions if x["event"] == ("tail", 0))
        self.assertEqual(len(bridge["g_horizon"]), 145)
        self.assertEqual(len(bridge["actual"]), 1)
        self.assertEqual(bridge["g_horizon"][0], plans[0]["new_g"][-1])
        self.assertEqual(bridge["forecast_horizon"][0], 600.)
        self.assertEqual(bridge["actual"][0], 1200.)
        self.assertAlmostEqual(logs[1]["executed_soc_at_window_start"], 6000. - 100. / .9)

    def test_old_tail_perturbation_cannot_change_just_signed_new_contract(self):
        for method in ("A", "B"):
            with self.subTest(method=method):
                base = self.replay(False, method)
                changed = self.replay(True, method)
                bp, cp = base[3], changed[3]
                np.testing.assert_array_equal(bp[0]["new_g"], cp[0]["new_g"])
                np.testing.assert_array_equal(bp[1]["new_g"], cp[1]["new_g"])
                self.assertEqual(bp[1]["s0"], cp[1]["s0"])
                self.assertGreater(np.max(np.abs(bp[2]["new_g"] - cp[2]["new_g"])), .1)
                self.assertNotAlmostEqual(base[5][1]["executed_soc_at_window_start"],
                                          changed[5][1]["executed_soc_at_window_start"])

    def test_window_states_and_slot_times_are_contiguous(self):
        result, trace, _, _, _, _ = self.replay(True)
        days = result["daily"]
        self.assertEqual(len(days), 3)
        self.assertEqual(len(trace), 3 * 144)
        self.assertEqual(trace[0]["interval_start"], "2030-02-01T00:10:00")
        self.assertEqual(trace[-1]["interval_end"], "2030-02-04T00:10:00")
        for i in (1, 2):
            self.assertAlmostEqual(days[i - 1]["final_soc_kwh"], days[i]["initial_soc_kwh"])
        for a, b in zip(trace, trace[1:]):
            self.assertEqual(a["interval_end"], b["interval_start"])
            self.assertAlmostEqual(float(a["soc_end_kwh"]), float(b["soc_start_kwh"]))
        self.assertEqual(len({r["interval_start"] for r in trace}), len(trace))
        self.assertTrue(all(r["planner_checks_passed"] and r["controller_checks_passed"] for r in days))

    def test_prefix_cost_is_counted_once_in_its_own_window(self):
        result, trace, _, plans, _, logs = self.replay(True)
        days = result["daily"]
        for i, day in enumerate(days):
            rows = trace[i * 144:(i + 1) * 144]
            self.assertEqual(len(rows), 144)
            np.testing.assert_allclose([float(r["g_kwh"]) for r in rows], plans[i]["new_g"])
            cash = sum(float(r["cash_cost_yuan"]) for r in rows)
            planned = sum(float(r["price_yuan_per_kwh"]) * float(r["g_kwh"]) for r in rows)
            emergency = sum(5. * float(r["price_yuan_per_kwh"]) * float(r["emergency_kwh"]) for r in rows)
            self.assertAlmostEqual(cash, day["cash_cost_yuan"], places=6)
            self.assertAlmostEqual(planned, day["planned_cost_yuan"], places=6)
            self.assertAlmostEqual(emergency, day["emergency_cost_yuan"], places=6)
            self.assertAlmostEqual(planned, logs[i]["new_contract_cost"], places=6)
        expected_contract_cash = sum(.5 * r["new_g"].sum() for r in plans)
        self.assertAlmostEqual(sum(r["planned_cost_yuan"] for r in days), expected_contract_cash, places=6)

    def test_plan_passes_fixed_prefix_to_milp_and_preserves_new_forecasts(self):
        data = fixture()
        p = np.linspace(.4, .8, 144)
        ws.initialize(data, p, config())
        lf = np.arange(144, dtype=float) + 600.
        pf = np.arange(144, dtype=float)
        sl = np.stack((lf, lf + 6.))
        sp = np.stack((pf, pf + 3.))
        seen = {}

        def fake_solve(load_kwh, pv_kwh, price, s0, **kwargs):
            seen.update(load=np.asarray(load_kwh), pv=np.asarray(pv_kwh), price=np.asarray(price),
                        s0=s0, **kwargs)
            return {"g": np.r_[123., np.full(144, 100.)]}

        with patch.object(ws, "risk_inputs", return_value=(lf, pf, sl, sp, {})), \
             patch.object(ws, "solve_plan", side_effect=fake_solve):
            _, meta = ws.plan(1, "D", 5432., .8, prefix=(123., 900., 60.))
        self.assertEqual(seen["fixed_prefix_g"], [123.])
        self.assertEqual(seen["s0"], 5432.)
        self.assertEqual(len(seen["load"]), 145)
        self.assertEqual(seen["load"][0], 150.)
        self.assertEqual(seen["pv"][0], 10.)
        self.assertEqual(seen["price"][0], p[-1])
        np.testing.assert_array_equal(seen["load"][1:], lf / 6.)
        np.testing.assert_array_equal(seen["pv"][1:], pf / 6.)
        np.testing.assert_array_equal(seen["scenario_load_kwh"][:, 0], [150., 150.])
        np.testing.assert_array_equal(seen["scenario_pv_kwh"][:, 0], [10., 10.])
        np.testing.assert_array_equal(seen["scenario_load_kwh"][:, 1:], sl / 6.)
        self.assertIn("not future actual", meta["bridge_prefix"])

    def test_incomplete_old_window_is_not_used_for_margin_or_scenarios(self):
        data = fixture()
        cfg = {**config(), "window": 28, "min_history": 1, "scenarios": 2, "seed": 20260911}
        ws.initialize(data, np.full(144, .5), cfg)
        for method in ("C", "D"):
            data["load_a"][1, -1] = 600.
            before = ws.risk_inputs(data, 2, method, cfg, .8)
            data["load_a"][1, -1] = 90000.
            after = ws.risk_inputs(data, 2, method, cfg, .8)
            self.assertEqual(before[-1]["history_indices"], [0])
            self.assertEqual(after[-1]["history_indices"], [0])
            for a, b in zip(before[:4], after[:4]):
                if a is None:
                    self.assertIsNone(b)
                else:
                    np.testing.assert_array_equal(a, b)


if __name__ == "__main__":
    unittest.main(verbosity=2)
