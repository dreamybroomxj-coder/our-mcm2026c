"""Synthetic checks of inherited contracts in a 00:00 planning horizon."""

import unittest

import numpy as np

from control import Battery
from planners import solve_plan


class PlannerPrefixTests(unittest.TestCase):
    def setUp(self):
        self.b = Battery(low=0, high=100, power_kw=600, eta_c=1, eta_d=1)

    def test_inherited_contract_above_optimization_cap_is_honored_and_paid(self):
        # max(load)+rate=110, but an inherited 500-kWh contract must be honored.
        # The battery is already full. Its 540-kWh supply surplus can be unused.
        out = solve_plan(
            [10], [50], [2], 100, fixed_prefix_g=[500],
            b=self.b, terminal_weight=0, s_ref=0,
        )
        self.assertAlmostEqual(out["g"][0], 500)
        self.assertGreaterEqual(out["ordinary_purchase_upper_kwh"][0], 500)
        self.assertAlmostEqual(out["v"][0, 0] + out["r"][0, 0], 540)
        self.assertAlmostEqual(out["plan_cost"], 1000)
        self.assertAlmostEqual(out["fixed_prefix_plan_cost"], 1000)
        self.assertAlmostEqual(out["new_plan_cost"], 0)
        self.assertTrue(out["checks"]["passed"])

    def test_145_slots_keep_prefix_and_exact_new_contract_cost_split(self):
        # One inherited slot and 144 new slots, each needing one kWh. The paid
        # prefix contains 5 kWh, of which 4 can be carried into the new window.
        out = solve_plan(
            np.ones(145), np.zeros(145), np.ones(145), 0,
            fixed_prefix_g=[5], b=self.b, terminal_weight=0, s_ref=0,
        )
        self.assertEqual(out["g"].shape, (145,))
        self.assertEqual(out["s"].shape, (1, 146))
        self.assertEqual(out["fixed_prefix_length"], 1)
        self.assertAlmostEqual(out["g"][0], 5)
        self.assertAlmostEqual(out["state_at_new_window_start_kwh"][0], 4)
        self.assertAlmostEqual(out["fixed_prefix_plan_cost"], 5)
        self.assertAlmostEqual(out["new_plan_cost"], 140)
        self.assertAlmostEqual(out["plan_cost"], 145)
        self.assertAlmostEqual(out["objective"], 145)
        self.assertAlmostEqual(out["plan_cost"], out["fixed_prefix_plan_cost"] + out["new_plan_cost"])

    def test_prefix_end_state_is_a_forecast_scenario_not_an_observed_state(self):
        # Midnight SOC is known (50). The unfinished prefix load is uncertain.
        # Its two forecast scenarios produce two different planned 00:10 SOCs.
        out = solve_plan(
            [30, 0], [0, 0], [1, 1], 50,
            scenario_load_kwh=[[20, 0], [40, 0]],
            scenario_pv_kwh=[[0, 0], [0, 0]], probabilities=[.5, .5],
            fixed_prefix_g=[0], b=self.b, terminal_weight=0, s_ref=0,
        )
        np.testing.assert_allclose(out["s"][:, 0], [50, 50])
        np.testing.assert_allclose(out["state_at_new_window_start_kwh"], [30, 10])
        np.testing.assert_allclose(out["g"], [0, 0], atol=1e-6)
        self.assertAlmostEqual(out["expected_emergency_cost"], 0)
        # Prefix endpoint observations are not accepted as a planning input.
        with self.assertRaises(TypeError):
            solve_plan([30, 0], [0, 0], [1, 1], 50,
                       fixed_prefix_g=[0], observed_prefix_end_soc=99)

    def test_fixed_zero_contract_cannot_be_replaced_with_cheaper_ordinary_purchase(self):
        # With no battery energy and no ordinary prefix purchase, 5 kWh must be
        # bought at 5 times the 2-yuan rate. The planner cannot reopen that slot.
        out = solve_plan(
            [5, 0], [0, 0], [2, 1], 0, fixed_prefix_g=[0],
            b=self.b, terminal_weight=0, s_ref=0,
        )
        self.assertAlmostEqual(out["g"][0], 0)
        self.assertAlmostEqual(out["e"][0, 0], 5)
        self.assertAlmostEqual(out["plan_cost"], 0)
        self.assertAlmostEqual(out["expected_emergency_cost"], 50)
        self.assertAlmostEqual(out["objective"], 50)

    def test_multi_slot_prefix_is_unchanged(self):
        original = np.array([0., 80.])
        out = solve_plan(
            [10, 50, 20], [0, 0, 0], [1, 2, 3], 20,
            fixed_prefix_g=original, b=self.b, terminal_weight=0, s_ref=0,
        )
        np.testing.assert_array_equal(original, [0, 80])
        np.testing.assert_allclose(out["g"][:2], original)
        self.assertEqual(out["fixed_prefix_length"], 2)
        self.assertAlmostEqual(out["fixed_prefix_plan_cost"], 160)
        self.assertAlmostEqual(out["plan_cost"], out["fixed_prefix_plan_cost"] + out["new_plan_cost"])
        self.assertTrue(out["checks"]["passed"])

    def test_empty_prefix_is_compatible_and_invalid_prefixes_fail(self):
        args = dict(load_kwh=[10, 20], pv_kwh=[0, 0], price=[1, 2], s0=0,
                    b=self.b, terminal_weight=0, s_ref=0)
        unprefixed = solve_plan(**args)
        empty = solve_plan(**args, fixed_prefix_g=[])
        self.assertAlmostEqual(unprefixed["objective"], empty["objective"])
        self.assertEqual(empty["fixed_prefix_length"], 0)
        self.assertAlmostEqual(empty["new_plan_cost"], empty["plan_cost"])
        for bad in ([[1]], [1, 2, 3], [-1], [np.nan], [np.inf]):
            with self.subTest(prefix=bad), self.assertRaises(ValueError):
                solve_plan(**args, fixed_prefix_g=bad)


if __name__ == "__main__":
    unittest.main()
