import os, sys, json
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

ETA = 0.9 ** 0.5
os.environ['MCM_BATTERY_ETA'] = str(ETA)
ROOT = Path(__file__).resolve().parent

def run_q3_one(spec):
    d = ROOT / '附件' / 'question3' / '第三问_完整计算' / '第三问_完整计算'
    sys.path.insert(0, str(d / 'code'))
    import q3_runner
    out = d / 'results_sqrt09'
    controller, scenarios, name = spec
    return q3_runner.run_strategy(d/'data', out, (0,6,12,18), config={'controller': controller, 'scenarios': scenarios}, name=name)

def run_q3():
    specs=[('mpc',8,'H0_6_12_18_scenario_mpc_sqrt09'),('mpc',1,'H0_6_12_18_deterministic_mpc_sqrt09'),('greedy',8,'H0_6_12_18_scenario_greedy_sqrt09')]
    with ProcessPoolExecutor(max_workers=3) as pool:
        return list(pool.map(run_q3_one,specs))

def run_q4_one(spec):
    d = ROOT / '附件' / 'question4' / '第四问_完整计算' / '第四问_完整计算'
    sys.path.insert(0, str(d / 'code'))
    import q4_runner
    out = d / 'results_sqrt09'
    branch, schedule, name = spec
    cfg={'controller':'mpc','scenarios':8,'price_mode':'point','price_hours':[0,6,12,18]}
    return q4_runner.run_strategy(d/'data', out, schedule, branch=branch, config=cfg, name=name)

def run_q4():
    specs=[('4-2',(0,),'Q42_point_H0_sqrt09'),('4-3',(0,6,12,18),'Q43_point_H0_6_12_18_sqrt09')]
    with ProcessPoolExecutor(max_workers=2) as pool:
        return list(pool.map(run_q4_one,specs))

if __name__ == '__main__':
    all_results = {'eta': ETA, 'q3': run_q3(), 'q4': run_q4()}
    (ROOT/'efficiency_sensitivity_sqrt09_raw.json').write_text(json.dumps(all_results, ensure_ascii=False, indent=2, default=str), encoding='utf-8')
    print(json.dumps(all_results, ensure_ascii=False, default=str))
