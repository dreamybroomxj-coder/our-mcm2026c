"""CUMCM C: causal empirical-scenario procurement and storage dispatch.
Run from project root: python solve.py --smoke; python solve.py --all
Input XLSX files are read only. All power samples are right-end samples.
"""
from pathlib import Path
import argparse, json, time, sys, hashlib
from copy import copy
import numpy as np
import pandas as pd
from openpyxl import load_workbook
from scipy.optimize import linprog, milp, Bounds, LinearConstraint
from scipy.sparse import lil_matrix, vstack, hstack, csr_matrix

ROOT = Path(__file__).resolve().parent
SEED = 20260910
DT, EMIN, EMAX, EINIT, B = 1/6, 1200., 10800., 6000., 5000/6
SKILL = Path('C:/Users/admin/.codex/skills/math-modeling-skill')
np.random.seed(SEED)

def read_data():
    def rows(name, sheet=0):
        w=load_workbook(ROOT/'附件'/name, read_only=True, data_only=True)
        s=w.worksheets[sheet] if isinstance(sheet,int) else w[sheet]
        out=list(s.values); w.close(); return out
    a=np.array(rows('附件1.xlsx')[1:],object)[:,1:].astype(float)
    lrows=rows('附件2.xlsx',0); srows=rows('附件2.xlsx',1)
    prows=rows('附件4.xlsx'); frows=rows('附件3.xlsx')
    dates=pd.DatetimeIndex([r[0] for r in lrows[1:]])
    assert list(dates)==list(pd.date_range('2025-01-01','2025-12-31'))
    for rr in [srows,prows]:
        assert [r[0] for r in rr[1:]]==list(dates.to_pydatetime())
        assert rr[0][1:]==lrows[0][1:]
    L=np.array([r[1:] for r in lrows[1:]],float)*DT
    S=np.array([r[1:] for r in srows[1:]],float)*DT
    P=np.array([r[1:] for r in prows[1:]],float)
    F=np.array([r[2:] for r in frows[1:]],float).reshape(365,4,24)*DT
    date=None
    for i,r in enumerate(frows[1:]):
        if r[0]: date=pd.Timestamp(r[0])
        assert date==dates[i//4] and r[1]==f'{(i%4)*6}:00'
    assert a.shape==(144,3) and L.shape==S.shape==P.shape==(365,144)
    assert F.shape==(365,4,24)
    for v in [a,L,S,P,F]: assert np.isfinite(v).all() and v.min()>=0
    return dict(a=a, L=L,S=S,P=P,F=F,dates=dates)

def forecast(data, day, release, step=False):
    """Only release data and already-observed PV at the release boundary."""
    start=release*36
    anchor=data['S'][day,start-1] if start else (data['S'][day-1,-1] if day else 0.)
    hourly=data['F'][day,release]
    if step: return np.repeat(hourly,6)
    return np.maximum(0,np.interp(np.arange(1,145)/6,np.arange(25),np.r_[anchor,hourly]))

def scenarios(data,day,release,pv,K=14,step=False):
    slots=(release*36+np.arange(144))%144
    if day==0:
        load=data['a'][:,1]*DT
        sol=forecast(data,day,release,step) if pv else data['a'][slots,2]*DT
        return (load[slots]-sol)[None,:]
    if not pv:
        hist=np.arange(max(0,day-K),day)
        return (data['L'][hist]-data['S'][hist])[:,slots]
    latest=forecast(data,day,release,step)
    # Historical 24-hour forecasts have finished before the current day.
    hist=np.arange(max(0,day-1-K),day-1)
    if not len(hist):
        hist=np.arange(max(0,day-K),day)
        return data['L'][hist][:,slots]-latest
    err=[]
    flat=data['S'].ravel()
    for h in hist:
        k=h*144+release*36
        err.append(flat[k:k+144]-forecast(data,h,release,step))
    return data['L'][hist][:,slots]-np.maximum(0,latest+np.array(err))

def prices(data,day,release,variable,oracle=False):
    slots=(release*36+np.arange(144))%144
    if not variable: return data['a'][slots,0]
    if oracle:
        arr=data['P'].ravel(); ix=day*144+release*36+np.arange(144)
        # Beyond the supplied year no oracle is available; repeat last day.
        return arr[np.minimum(ix,len(arr)-1)] if ix[-1]<len(arr) else np.r_[arr[ix[ix<len(arr)]],data['P'][-1,slots[ix>=len(arr)]]]
    return (data['P'][max(0,day-7):day].mean(0) if day else data['a'][:,0])[slots]

def optimize(net,price,E0,eta=.9,base=None,known=None,terminal=True,no_battery=False):
    """LP: g,c,d,E,scenario r, purchase cost epigraph q, terminal abs h."""
    m,T=net.shape
    G,C,D,E,R,Q,H=0,T,2*T,3*T,4*T,4*T+m*T,5*T+m*T
    nv=H+1; obj=np.zeros(nv)
    obj[R:Q]=np.tile(5*price/m,m); obj[Q:H]=1
    obj[H]=np.median(price)/eta if terminal else 0
    # Small lexicographic regularizer only breaks near-degenerate cycling.
    obj[C:D]=1e-9; obj[D:E]=1e-9
    bounds=[(0,None)]*nv
    for t in range(T):
        bounds[C+t]=(0,0 if no_battery else B)
        bounds[D+t]=(0,0 if no_battery else (min(B,known[t]) if known is not None else B))
        bounds[E+t]=(EMIN,EMAX)
    if not terminal: bounds[E+T-1]=(E0,E0)
    if known is not None:
        for j in range(R,Q): bounds[j]=(0,0)
    eq=lil_matrix((T,nv)); beq=np.zeros(T); beq[0]=E0
    for t in range(T):
        eq[t,E+t]=1; eq[t,C+t]=-eta; eq[t,D+t]=1/eta
        if t: eq[t,E+t-1]=-1
    ub=lil_matrix((m*T+2*T+2,nv)); bu=np.zeros(ub.shape[0])
    for s in range(m):
        rr=np.arange(T)+s*T
        for t,j in enumerate(rr):
            ub[j,C+t]=1;ub[j,D+t]=-1;ub[j,G+t]=-1;ub[j,R+j]=-1
        bu[rr]=-net[s]
    for t in range(T):
        rr=m*T+2*t
        if base is not None and np.isfinite(base[t]):
            # f(g)=max(.5 p(g+g0), 1.5pg-.5pg0).
            ub[rr,G+t]=.5*price[t];ub[rr,Q+t]=-1;bu[rr]=-.5*price[t]*base[t]
            ub[rr+1,G+t]=1.5*price[t];ub[rr+1,Q+t]=-1;bu[rr+1]=.5*price[t]*base[t]
        else:
            ub[rr,G+t]=price[t];ub[rr,Q+t]=-1
            ub[rr+1,G+t]=price[t];ub[rr+1,Q+t]=-1
    ub[-2,E+T-1]=1;ub[-2,H]=-1;bu[-2]=EINIT
    ub[-1,E+T-1]=-1;ub[-1,H]=-1;bu[-1]=-EINIT
    ans=linprog(obj,A_ub=ub.tocsr(),b_ub=bu,A_eq=eq.tocsr(),b_eq=beq,bounds=bounds,method='highs')
    if not ans.success: raise RuntimeError(ans.message)
    g=np.maximum(ans.x[G:C],0);c=np.maximum(ans.x[C:D],0);d=np.maximum(ans.x[D:E],0)
    remove=np.minimum(c,d/eta**2);c-=remove;d-=eta**2*remove
    energy=np.r_[E0,E0+np.cumsum(eta*c-d/eta)]
    assert np.min(energy)>=EMIN-1e-6 and np.max(energy)<=EMAX+1e-6
    assert np.max(np.minimum(c,d))<1e-6
    return dict(g=g,c=c,d=d,E=energy,objective=float(ans.fun),nit=ans.nit,
                residual=float(np.max(np.abs(eq@ans.x-beq))))

def execute(g,cplan,dplan,L,S,E0,eta):
    T=len(g);c=np.zeros(T);d=np.zeros(T);E=np.zeros(T+1);E[0]=E0
    for t in range(T):
        c[t]=min(cplan[t],max(0,(EMAX-E[t])/eta))
        d[t]=min(dplan[t],max(0,eta*(E[t]-EMIN)),L[t])
        E[t+1]=E[t]+eta*c[t]-d[t]/eta
    x=g+S+d-L-c;r=np.maximum(-x,0);w=np.minimum(S,np.maximum(x,0));z=np.maximum(x,0)-w
    balance=g-z+S+d+r-L-c-w
    assert max(np.abs(balance))<1e-6 and max(z-g)<1e-6
    assert min(E)>=EMIN-1e-6 and max(E)<=EMAX+1e-6
    assert max(np.minimum(c,d))<1e-6 and max(c)<=B+1e-6 and max(d)<=B+1e-6
    return dict(c=c,d=d,E=E,r=r,w=w,z=z,projection=np.abs(c-cplan)+np.abs(d-dplan),balance=balance)

def q1(data,eta=.9):
    a=data['a'];L=a[:,1]*DT;S=a[:,2]*DT;p=a[:,0]
    sol=optimize((L-S)[None,:],p,EINIT,eta,known=L,terminal=False)
    actual=execute(sol['g'],sol['c'],sol['d'],L,S,EINIT,eta)
    assert max(actual['projection'])<1e-6 and max(actual['r'])<1e-6
    out=pd.DataFrame(dict(t=np.arange(144),L=L,S=S,p=p,g=sol['g'],c=actual['c'],d=actual['d'],E0=actual['E'][:-1],E1=actual['E'][1:],w=actual['w'],z=actual['z']))
    out['cost']=out.p*out.g
    return out,dict(cost=float(out.cost.sum()),purchase=float(out.g.sum()),baseline=float(np.dot(p,np.maximum(L-S,0))),lp_objective=sol['objective'],max_residual=sol['residual'])

def simulate(data,name,days=365,K=14,eta=.9,pv=False,update=False,variable=False,oracle=False,step=False,no_battery=False,verbose=True):
    frames=[];E0=EINIT;starttime=time.perf_counter()
    for day in range(days):
        original=None;records=[];previous=np.zeros(144);seq_extra=np.zeros(144)
        for release in (range(4) if update else [0]):
            start=36*release;size=36 if update else 144
            n=scenarios(data,day,release,pv,K,step)
            pp=prices(data,day,release,variable,oracle)
            base=None if release==0 else np.r_[original[start:],np.full(start,np.nan)]
            sol=optimize(n,pp,E0,eta,base=base,no_battery=no_battery)
            if release==0:
                original=sol['g'].copy();previous=original.copy()
            else:
                new=sol['g'][:144-start];old=previous[start:]
                # Increment to normal-price actual quantity cost for successive changes.
                seq_extra[start:]+=.5*np.abs(new-old)
                previous[start:]=new
            g=sol['g'][:size];L=data['L'][day,start:start+size];S=data['S'][day,start:start+size]
            act=execute(g,sol['c'][:size],sol['d'][:size],L,S,E0,eta)
            realp=data['P'][day,start:start+size] if variable else data['a'][start:start+size,0]
            baseg=original[start:start+size];up=np.maximum(g-baseg,0);down=np.maximum(baseg-g,0)
            ordinary=realp*baseg;refund=-realp*down;cancel=.5*realp*down;add=1.5*realp*up;emergency=5*realp*act['r']
            cost=ordinary+refund+cancel+add+emergency
            assert np.max(np.abs(cost-(realp*np.minimum(baseg,g)+.5*realp*down+1.5*realp*up+emergency)))<1e-6
            records.append(pd.DataFrame(dict(scheme=name,date=str(data['dates'][day].date()),t=np.arange(start,start+size),
                L=L,S=S,p=realp,p_hat=pp[:size],g0=baseg,g=g,c_plan=sol['c'][:size],d_plan=sol['d'][:size],
                c=act['c'],d=act['d'],E0=act['E'][:-1],E1=act['E'][1:],r=act['r'],w=act['w'],z=act['z'],
                projection=act['projection'],ordinary=ordinary,refund=refund,cancel=cancel,add=add,emergency=emergency,cost=cost,
                no_refund_cost=cost-refund,seq_cost=realp*(g+seq_extra[start:start+size])+emergency,
                net_mean=n.mean(0)[:size],net_q80=np.quantile(n,.8,axis=0)[:size],balance=act['balance'],solver_residual=sol['residual'])))
            E0=act['E'][-1]
        frames.extend(records)
        if verbose and (day+1)%60==0: print(name,day+1,'days',round(time.perf_counter()-starttime,1),'s',flush=True)
    return pd.concat(frames,ignore_index=True)

def interval(t):
    def fmt(k): return f'{k//6:02d}:{(k%6)*10:02d}'
    return fmt(t)+'–'+fmt(t+1)

def events(frame):
    records=[]
    for date,day in frame.groupby('date',sort=False):
        r=day.r.to_numpy();mask=r>1e-6;t=0;found=False
        while t<144:
            if not mask[t]:t+=1;continue
            a=t
            while t<144 and mask[t]:t+=1
            records.append(dict(date=date,start=a,end=t,period=interval(a).split('–')[0]+'–'+interval(t-1).split('–')[1],energy=float(r[a:t].sum())))
            found=True
        if not found:records.append(dict(date=date,start=-1,end=-1,period='无',energy=0.))
    return pd.DataFrame(records)

def summarize(frame):
    sums=['g0','g','r','c','d','w','z','ordinary','refund','cancel','add','emergency','cost','no_refund_cost','seq_cost','projection']
    daily=frame.groupby(['scheme','date'])[sums].sum().reset_index()
    en=frame.groupby(['scheme','date']).agg(E_start=('E0','first'),E_end=('E1','last'))
    daily=daily.merge(en.reset_index())
    return daily

def write_template(name,frame,one=None):
    wb=load_workbook(ROOT/'附件'/'附件5'/f'{name}.xlsx')
    if name=='result1':
        sh=wb['计划购电量']
        for t in range(144):sh.cell(t+2,1,interval(t));sh.cell(t+2,2,float(one.g.iloc[t]))
        sh=wb['充放电量']
        for b in range(6):
            sh.cell(b+2,2,float(one.c.iloc[b*24:(b+1)*24].sum()));sh.cell(b+2,3,float(one.d.iloc[b*24:(b+1)*24].sum()))
        sh.cell(2,5,float(one.E0.iloc[0]));sh.cell(3,5,float(one.E1.iloc[-1]))
    else:
        daily=summarize(frame)
        for sname,col in [('计划购电量','g0'),('调整购电量','g')]:
            if sname not in wb:continue
            sh=wb[sname]
            for t in range(144):sh.cell(1,t+2,interval(t))
            for i,(date,day) in enumerate(frame.groupby('date',sort=False),2):
                sh.cell(i,1,pd.Timestamp(date).to_pydatetime())
                for t,v in enumerate(day[col],2):sh.cell(i,t,float(v))
                sh.cell(i,146,float(day[col].sum()))
                # Original order sheet bills original normal purchases; adjusted sheet total final settlement.
                sh.cell(i,147,float(day.ordinary.sum() if col=='g0' else day.cost.sum()))
        sh=wb['充放电量'];sh.delete_rows(2,sh.max_row)
        for date,day in frame.groupby('date',sort=False):
            for b in range(6):
                chunk=day.iloc[b*24:(b+1)*24]
                sh.append([pd.Timestamp(date).to_pydatetime() if b==0 else None,f'{4*b}:00-{4*b+4}:00',float(chunk.c.sum()),float(chunk.d.sum()),'0:00' if b==0 else ('24:00' if b==1 else None),float(day.E0.iloc[0]) if b==0 else (float(day.E1.iloc[-1]) if b==1 else None)])
        sh=wb['紧急购电量'];sh.delete_rows(2,sh.max_row)
        for row in events(frame).itertuples():sh.append([pd.Timestamp(row.date).to_pydatetime(),row.period,row.energy])
    for sh in wb:
        for row in sh:
            for c in row:
                if isinstance(c.value,float):c.number_format='0.000000'
        assert all(c.data_type!='e' and c.data_type!='f' for row in sh for c in row)
    wb.save(ROOT/'results'/f'{name}.xlsx')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--smoke',action='store_true');ap.add_argument('--all',action='store_true');ap.add_argument('--plots',action='store_true');ap.add_argument('--output',default='results')
    args=ap.parse_args();data=read_data();out=ROOT/args.output;out.mkdir(parents=True,exist_ok=True)
    one,stat=q1(data);one.to_csv(out/'q1_dispatch.csv',index=False)
    if args.smoke:
        reports={'q1':stat}
        for name,pv,upd,var in [('q2',False,False,False),('q3',True,True,False),('q4_2',False,False,True),('q4_3',True,True,True)]:
            f=simulate(data,name,days=3,pv=pv,update=upd,variable=var,verbose=False)
            f.to_csv(out/f'{name}_smoke.csv',index=False)
            # Future actual perturbation, while release forecasts and historical info stay fixed.
            altered={**data,'L':data['L'].copy(),'S':data['S'].copy(),'P':data['P'].copy()}
            altered['L'][1:]*=1.15;altered['S'][1:]*=.8;altered['P'][1:]*=1.2
            before=scenarios(data,1,0,pv);after=scenarios(altered,1,0,pv)
            assert np.array_equal(before,after)
            assert np.array_equal(prices(data,1,0,var),prices(altered,1,0,var))
            reports[name]={'days':3,'cost':float(f.cost.sum()),'emergency':float(f.r.sum()),'max_balance':float(f.balance.abs().max()),'E_min':float(f.E1.min()),'E_max':float(f.E1.max()),'projection':float(f.projection.sum()),'causal_check':True}
        (out/'smoke.json').write_text(json.dumps(reports,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(reports,ensure_ascii=False,indent=2));return
    if not args.all:return
    # Additional experiments and figures are introduced only after P1 approval.
    raise RuntimeError('Full run awaits P1 gate')

if __name__=='__main__':main()
