# C题支撑材料说明

本目录汇总 C 题四个小问实际使用或保留的程序源代码、原生说明文档和题目结果工作簿。原始工程位于 `附件` 下，本次只复制归档，没有移动或修改原文件。

## 目录结构

- `question1`：第一问确定性 MILP 源码、依赖、原生 README、结果说明与审计说明。
- `question2/prediction`：第二问负载和光伏预测、区间化与规划输入导出程序。
- `question2/planning`：正式采用的 `第二问_新144段计算` 规划工程；统一入口为 `code/run_all.py`，单独计算入口为 `code/window_study.py`。
- `question3/prediction`：第三问分时光伏区间预测与版本比较程序。
- `question3/planning`：第三问滚动随机 MILP、调单、MPC、报表和审计程序；统一入口为 `code/run_all.py`。
- `question3/judge`：第三问补充预报价值分析程序。
- `question4`：第四问 XGBoost 电价、随机 MILP、滚动控制、结果导出与审计程序；统一入口为 `code/run_all.py`。
- `common`：早期一体化求解程序和充放电效率敏感性程序，仅作过程支撑，不作为当前各问正式入口。
- `result`：题目要求或当前正式计算产生的结果工作簿。
- `generate_code_appendix.py`：自动扫描五个源码目录并生成 Markdown 代码附录。
- `源代码附录.md`：由上述程序生成的完整 Python 文本附录，共收录 97 个源文件。

## 第二问版本说明

第二问的正式规划版本来自：

`附件/question2/第二问_新144段计算`

该版本采用 00:10 至次日 00:10 的 144 段合同窗口，正式结果为 `result/result2_正式新144段计算.xlsx`。原工程明确说明该工作簿不是题目自然日模板格式。

目录中的 `result/result2.xlsx` 是现有唯一按题目 `result2.xlsx` 命名的工作簿，来源为旧目录 `附件/question2/完整代码与结果/results/result2.xlsx`。它与正式“新144段”规划工程不是同一版本，不能用它反向说明正式模型的数值结果。若最终提交必须严格使用题目原 `result2.xlsx` 模板，应依据新144段正式账本另行完成自然日重组和模板填充。

## 结果文件来源

- `result1.xlsx`：`附件/question1/results/result1.xlsx`，充、放电效率均为 0.9 的正式结果。
- `result2.xlsx`：旧版题目模板工作簿，版本限制见上节。
- `result2_正式新144段计算.xlsx`：第二问当前正式规划计算汇总。
- `result3.xlsx`：第三问完整计算工程的正式报表。
- `result4-2.xlsx`、`result4-3.xlsx`：第四问完整计算工程的正式报表。

## 复现提示

各目录保留了原生 `README.md`、`requirements.txt`、模型说明和复现说明。代码依赖的原始附件、预测工作簿和大型中间账本没有重复复制到本支撑材料目录；需要完整重算时，应在原工程目录执行 README 中的命令，或按原有相对路径补齐数据文件。

在本目录执行 `python generate_code_appendix.py` 可以重新生成 `源代码附录.md`。可用 `--output` 修改输出文件名，用 `--folders` 修改扫描目录；默认包含测试、审计和报表程序。

`文件清单.csv` 记录除清单自身外所有交付文件的相对路径、大小和 SHA-256，可用于提交前核对。
